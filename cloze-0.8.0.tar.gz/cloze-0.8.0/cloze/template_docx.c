



#ifndef PY_SSIZE_T_CLEAN
#define PY_SSIZE_T_CLEAN
#endif 

#if defined(Py_LIMITED_API)
  #if !defined(CYTHON_LIMITED_API)
  #define CYTHON_LIMITED_API 1
  #endif
#elif defined(CYTHON_LIMITED_API)
  #ifdef _MSC_VER
  #pragma message ("Limited API usage is enabled with 'CYTHON_LIMITED_API' but 'Py_LIMITED_API' does not define a Python target version. Consider setting 'Py_LIMITED_API' instead.")
  #else
  #warning Limited API usage is enabled with 'CYTHON_LIMITED_API' but 'Py_LIMITED_API' does not define a Python target version. Consider setting 'Py_LIMITED_API' instead.
  #endif
#endif

#include "Python.h"
#ifndef Py_PYTHON_H
    #error Python headers needed to compile C extensions, please install development version of Python.
#elif PY_VERSION_HEX < 0x03090000
    #error Cython requires Python 3.9+.
#elif defined(Py_LIMITED_API) && (Py_LIMITED_API & 0xFFFF0000) > (PY_VERSION_HEX & 0xFFFF0000)
    #error 'Py_LIMITED_API' can only select past Python X.Y versions, not future ones.
#else
#define __PYX_ABI_VERSION "3_3_0"
#define CYTHON_HEX_VERSION 0x030300F0
#define CYTHON_FUTURE_DIVISION 1

#include <stddef.h>
#ifndef offsetof
  #define offsetof(type, member) ( (size_t) & ((type*)0) -> member )
#endif
#if !defined(_WIN32) && !defined(WIN32) && !defined(MS_WINDOWS)
  #ifndef __stdcall
    #define __stdcall
  #endif
  #ifndef __cdecl
    #define __cdecl
  #endif
  #ifndef __fastcall
    #define __fastcall
  #endif
#endif
#ifdef __has_builtin
  #define __Pyx_has_cbuiltin(name) __has_builtin(name)
#else
  #define __Pyx_has_cbuiltin(name) (0)
#endif
#ifndef DL_IMPORT
  #define DL_IMPORT(t) t
#endif
#ifndef DL_EXPORT
  #define DL_EXPORT(t) t
#endif
#define __PYX_COMMA ,
#ifndef PY_LONG_LONG
  #define PY_LONG_LONG LONG_LONG
#endif
#ifndef Py_HUGE_VAL
  #define Py_HUGE_VAL HUGE_VAL
#endif
#define __PYX_LIMITED_VERSION_HEX PY_VERSION_HEX
#if defined(CYTHON_LIMITED_API)
  #ifdef Py_LIMITED_API
    #undef __PYX_LIMITED_VERSION_HEX
    #define __PYX_LIMITED_VERSION_HEX Py_LIMITED_API
    #if Py_LIMITED_API < 0x03090000
      #error "Cython 3.3 requires the Python Limited API version to be 3.9 or greater."
    #endif
  #endif
  #if defined(GRAALVM_PYTHON) || defined(PYPY_VERSION)
    #ifdef _MSC_VER
      #pragma message ("Py_LIMITED_API is defined on PyPy or GraalPy. This takes precedence over Cython's specialized\
        code for PyPy and GraalPy and is unlikely to work.")
    #else
      #warning "Py_LIMITED_API is defined on PyPy or GraalPy. This takes precedence over Cython's specialized\
        code for PyPy and GraalPy and is unlikely to work."
    #endif
  #endif
  #define CYTHON_COMPILING_IN_PYPY 0
  #define CYTHON_COMPILING_IN_CPYTHON 0
  #define CYTHON_COMPILING_IN_LIMITED_API 1
  #define CYTHON_COMPILING_IN_GRAAL 0
  #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 0
  #undef CYTHON_USE_TYPE_SLOTS
  #define CYTHON_USE_TYPE_SLOTS 0
  #undef CYTHON_USE_TYPE_SPECS
  #define CYTHON_USE_TYPE_SPECS 1
  #undef CYTHON_USE_PYTYPE_LOOKUP
  #define CYTHON_USE_PYTYPE_LOOKUP 0
  #undef CYTHON_USE_PYLIST_INTERNALS
  #define CYTHON_USE_PYLIST_INTERNALS 0
  #undef CYTHON_USE_UNICODE_INTERNALS
  #define CYTHON_USE_UNICODE_INTERNALS 0
  #ifndef CYTHON_USE_UNICODE_WRITER
    #define CYTHON_USE_UNICODE_WRITER 0
  #endif
  #undef CYTHON_USE_PYLONG_INTERNALS
  #define CYTHON_USE_PYLONG_INTERNALS 0
  #ifndef CYTHON_AVOID_BORROWED_REFS
    #define CYTHON_AVOID_BORROWED_REFS 0
  #endif
  #ifndef CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
    #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 0
  #endif
  #undef CYTHON_ASSUME_SAFE_MACROS
  #define CYTHON_ASSUME_SAFE_MACROS 0
  #undef CYTHON_ASSUME_SAFE_SIZE
  #define CYTHON_ASSUME_SAFE_SIZE 0
  #undef CYTHON_UNPACK_METHODS
  #define CYTHON_UNPACK_METHODS 0
  #undef CYTHON_FAST_THREAD_STATE
  #define CYTHON_FAST_THREAD_STATE 0
  #undef CYTHON_FAST_GIL
  #define CYTHON_FAST_GIL 0
  #undef CYTHON_VECTORCALL
  #define CYTHON_VECTORCALL (__PYX_LIMITED_VERSION_HEX >= 0x030C0000)
  #ifndef CYTHON_VECTORCALL_TPNEW
    #define CYTHON_VECTORCALL_TPNEW (CYTHON_VECTORCALL && __PYX_LIMITED_VERSION_HEX >= 0x030E0000)
  #endif
  #ifndef CYTHON_PEP487_INIT_SUBCLASS
    #define CYTHON_PEP487_INIT_SUBCLASS 1
  #endif
  #ifndef CYTHON_PEP489_MULTI_PHASE_INIT
    #define CYTHON_PEP489_MULTI_PHASE_INIT 1
  #endif
  #ifndef CYTHON_USE_MODULE_STATE
    #define CYTHON_USE_MODULE_STATE 0
  #endif
  #undef CYTHON_USE_SYS_MONITORING
  #define CYTHON_USE_SYS_MONITORING 0
  #ifndef CYTHON_USE_TP_FINALIZE
    #define CYTHON_USE_TP_FINALIZE (__PYX_LIMITED_VERSION_HEX >= 0x030F0000 && PY_VERSION_HEX > 0x030F00A8)
  #endif
  #ifndef CYTHON_USE_AM_SEND
    #define CYTHON_USE_AM_SEND (__PYX_LIMITED_VERSION_HEX >= 0x030A0000)
  #endif
  #undef CYTHON_USE_DICT_VERSIONS
  #define CYTHON_USE_DICT_VERSIONS 0
  #undef CYTHON_USE_EXC_INFO_STACK
  #define CYTHON_USE_EXC_INFO_STACK 0
  #ifndef CYTHON_UPDATE_DESCRIPTOR_DOC
    #define CYTHON_UPDATE_DESCRIPTOR_DOC 0
  #endif
  #ifndef CYTHON_USE_OWN_PREP_RERAISE_STAR
    #define CYTHON_USE_OWN_PREP_RERAISE_STAR 1
  #endif
  #ifndef CYTHON_USE_FREELISTS
  #define CYTHON_USE_FREELISTS 1
  #endif
  #undef CYTHON_IMMORTAL_CONSTANTS
  #define CYTHON_IMMORTAL_CONSTANTS 0
  #if __PYX_LIMITED_VERSION_HEX < 0x030E0000
  #undef CYTHON_OPAQUE_OBJECTS
  #define CYTHON_OPAQUE_OBJECTS 0
  #elif !defined(CYTHON_OPAQUE_OBJECTS)
  #define CYTHON_OPAQUE_OBJECTS (__PYX_LIMITED_VERSION_HEX >= 0x030F0000)
  #endif
#elif defined(GRAALVM_PYTHON)
  
  #define CYTHON_COMPILING_IN_PYPY 0
  #define CYTHON_COMPILING_IN_CPYTHON 0
  #define CYTHON_COMPILING_IN_LIMITED_API 0
  #define CYTHON_COMPILING_IN_GRAAL 1
  #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 0
  #ifndef CYTHON_USE_TYPE_SLOTS
    #define CYTHON_USE_TYPE_SLOTS 0
  #endif
  #undef CYTHON_USE_TYPE_SPECS
  #define CYTHON_USE_TYPE_SPECS 0
  #undef CYTHON_USE_PYTYPE_LOOKUP
  #define CYTHON_USE_PYTYPE_LOOKUP 0
  #undef CYTHON_USE_PYLIST_INTERNALS
  #define CYTHON_USE_PYLIST_INTERNALS 0
  #undef CYTHON_USE_UNICODE_INTERNALS
  #define CYTHON_USE_UNICODE_INTERNALS 0
  #undef CYTHON_USE_UNICODE_WRITER
  #define CYTHON_USE_UNICODE_WRITER 0
  #undef CYTHON_USE_PYLONG_INTERNALS
  #define CYTHON_USE_PYLONG_INTERNALS 0
  #undef CYTHON_AVOID_BORROWED_REFS
  #define CYTHON_AVOID_BORROWED_REFS 1
  #undef CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
  #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 0
  #undef CYTHON_ASSUME_SAFE_MACROS
  #define CYTHON_ASSUME_SAFE_MACROS 0
  #undef CYTHON_ASSUME_SAFE_SIZE
  #define CYTHON_ASSUME_SAFE_SIZE 0
  #undef CYTHON_UNPACK_METHODS
  #define CYTHON_UNPACK_METHODS 0
  #undef CYTHON_FAST_THREAD_STATE
  #define CYTHON_FAST_THREAD_STATE 0
  #undef CYTHON_FAST_GIL
  #define CYTHON_FAST_GIL 0
  #ifndef CYTHON_VECTORCALL
    #define CYTHON_VECTORCALL 1
  #endif
  #if CYTHON_USE_TYPE_SPECS && PY_VERSION_HEX < 0x030E0000
    #undef CYTHON_VECTORCALL_TPNEW
    #define CYTHON_VECTORCALL_TPNEW 0
  #elif !defined(CYTHON_VECTORCALL_TPNEW)
    #define CYTHON_VECTORCALL_TPNEW CYTHON_VECTORCALL
  #endif
  #ifndef CYTHON_PEP487_INIT_SUBCLASS
    #define CYTHON_PEP487_INIT_SUBCLASS 1
  #endif
  #undef CYTHON_PEP489_MULTI_PHASE_INIT
  #define CYTHON_PEP489_MULTI_PHASE_INIT 1
  #undef CYTHON_USE_MODULE_STATE
  #define CYTHON_USE_MODULE_STATE 0
  #undef CYTHON_USE_SYS_MONITORING
  #define CYTHON_USE_SYS_MONITORING 0
  #undef CYTHON_USE_TP_FINALIZE
  #define CYTHON_USE_TP_FINALIZE 0
  #undef CYTHON_USE_AM_SEND
  #define CYTHON_USE_AM_SEND 0
  #undef CYTHON_USE_DICT_VERSIONS
  #define CYTHON_USE_DICT_VERSIONS 0
  #undef CYTHON_USE_EXC_INFO_STACK
  #define CYTHON_USE_EXC_INFO_STACK 1
  #ifndef CYTHON_UPDATE_DESCRIPTOR_DOC
    #define CYTHON_UPDATE_DESCRIPTOR_DOC 0
  #endif
  #ifndef CYTHON_USE_OWN_PREP_RERAISE_STAR
    #define CYTHON_USE_OWN_PREP_RERAISE_STAR 1
  #endif
  #undef CYTHON_USE_FREELISTS
  #define CYTHON_USE_FREELISTS 0
  #undef CYTHON_IMMORTAL_CONSTANTS
  #define CYTHON_IMMORTAL_CONSTANTS 0
  #undef CYTHON_OPAQUE_OBJECTS
  #define CYTHON_OPAQUE_OBJECTS 0
#elif defined(PYPY_VERSION)
  #define CYTHON_COMPILING_IN_PYPY 1
  #define CYTHON_COMPILING_IN_CPYTHON 0
  #define CYTHON_COMPILING_IN_LIMITED_API 0
  #define CYTHON_COMPILING_IN_GRAAL 0
  #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 0
  #undef CYTHON_USE_TYPE_SLOTS
  #define CYTHON_USE_TYPE_SLOTS 1
  #ifndef CYTHON_USE_TYPE_SPECS
    #define CYTHON_USE_TYPE_SPECS 0
  #endif
  #undef CYTHON_USE_PYTYPE_LOOKUP
  #define CYTHON_USE_PYTYPE_LOOKUP 0
  #undef CYTHON_USE_PYLIST_INTERNALS
  #define CYTHON_USE_PYLIST_INTERNALS 0
  #undef CYTHON_USE_UNICODE_INTERNALS
  #define CYTHON_USE_UNICODE_INTERNALS 0
  #undef CYTHON_USE_UNICODE_WRITER
  #define CYTHON_USE_UNICODE_WRITER 0
  #undef CYTHON_USE_PYLONG_INTERNALS
  #define CYTHON_USE_PYLONG_INTERNALS 0
  #undef CYTHON_AVOID_BORROWED_REFS
  #define CYTHON_AVOID_BORROWED_REFS 1
  #undef CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
  #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 1
  #undef CYTHON_ASSUME_SAFE_MACROS
  #define CYTHON_ASSUME_SAFE_MACROS 0
  #ifndef CYTHON_ASSUME_SAFE_SIZE
    #define CYTHON_ASSUME_SAFE_SIZE 1
  #endif
  #undef CYTHON_UNPACK_METHODS
  #define CYTHON_UNPACK_METHODS 0
  #undef CYTHON_FAST_THREAD_STATE
  #define CYTHON_FAST_THREAD_STATE 0
  #undef CYTHON_FAST_GIL
  #define CYTHON_FAST_GIL 0
  #ifndef CYTHON_VECTORCALL
    #define CYTHON_VECTORCALL 1
  #endif
  #if CYTHON_USE_TYPE_SPECS && PY_VERSION_HEX < 0x030E0000
    #undef CYTHON_VECTORCALL_TPNEW
    #define CYTHON_VECTORCALL_TPNEW 0
  #elif !defined(CYTHON_VECTORCALL_TPNEW)
    #define CYTHON_VECTORCALL_TPNEW (PYPY_VERSION_NUM >= 0x07030800 && CYTHON_VECTORCALL)
  #endif
  #ifndef CYTHON_PEP487_INIT_SUBCLASS
    #define CYTHON_PEP487_INIT_SUBCLASS 1
  #endif
  #ifndef CYTHON_PEP489_MULTI_PHASE_INIT
    #define CYTHON_PEP489_MULTI_PHASE_INIT 1
  #endif
  #undef CYTHON_USE_MODULE_STATE
  #define CYTHON_USE_MODULE_STATE 0
  #undef CYTHON_USE_SYS_MONITORING
  #define CYTHON_USE_SYS_MONITORING 0
  #ifndef CYTHON_USE_TP_FINALIZE
    #define CYTHON_USE_TP_FINALIZE (PYPY_VERSION_NUM >= 0x07030C00)
  #endif
  #undef CYTHON_USE_AM_SEND
  #define CYTHON_USE_AM_SEND 0
  #undef CYTHON_USE_DICT_VERSIONS
  #define CYTHON_USE_DICT_VERSIONS 0
  #undef CYTHON_USE_EXC_INFO_STACK
  #define CYTHON_USE_EXC_INFO_STACK 0
  #ifndef CYTHON_UPDATE_DESCRIPTOR_DOC
    #define CYTHON_UPDATE_DESCRIPTOR_DOC (PYPY_VERSION_NUM >= 0x07031100)
  #endif
  #ifndef CYTHON_USE_OWN_PREP_RERAISE_STAR
    #define CYTHON_USE_OWN_PREP_RERAISE_STAR 1
  #endif
  #undef CYTHON_USE_FREELISTS
  #define CYTHON_USE_FREELISTS 0
  #undef CYTHON_IMMORTAL_CONSTANTS
  #define CYTHON_IMMORTAL_CONSTANTS 0
  #undef CYTHON_OPAQUE_OBJECTS
  #define CYTHON_OPAQUE_OBJECTS 0
#else
  #define CYTHON_COMPILING_IN_PYPY 0
  #define CYTHON_COMPILING_IN_CPYTHON 1
  #define CYTHON_COMPILING_IN_LIMITED_API 0
  #define CYTHON_COMPILING_IN_GRAAL 0
  #ifdef Py_GIL_DISABLED
    #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 1
  #else
    #define CYTHON_COMPILING_IN_CPYTHON_FREETHREADING 0
  #endif
  #if PY_VERSION_HEX < 0x030A0000
    #undef CYTHON_USE_TYPE_SLOTS
    #define CYTHON_USE_TYPE_SLOTS 1
  #elif !defined(CYTHON_USE_TYPE_SLOTS)
    #define CYTHON_USE_TYPE_SLOTS 1
  #endif
  #ifndef CYTHON_USE_TYPE_SPECS
    #define CYTHON_USE_TYPE_SPECS 0
  #endif
  #ifndef CYTHON_USE_PYTYPE_LOOKUP
    #define CYTHON_USE_PYTYPE_LOOKUP 1
  #endif
  #ifndef CYTHON_USE_PYLONG_INTERNALS
    #define CYTHON_USE_PYLONG_INTERNALS 1
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    #undef CYTHON_USE_PYLIST_INTERNALS
    #define CYTHON_USE_PYLIST_INTERNALS 0
  #elif !defined(CYTHON_USE_PYLIST_INTERNALS)
    #define CYTHON_USE_PYLIST_INTERNALS 1
  #endif
  #ifndef CYTHON_USE_UNICODE_INTERNALS
    #define CYTHON_USE_UNICODE_INTERNALS 1
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING || PY_VERSION_HEX >= 0x030B00A2
    #undef CYTHON_USE_UNICODE_WRITER
    #define CYTHON_USE_UNICODE_WRITER 0
  #elif !defined(CYTHON_USE_UNICODE_WRITER)
    #define CYTHON_USE_UNICODE_WRITER 1
  #endif
  #ifndef CYTHON_AVOID_BORROWED_REFS
    #define CYTHON_AVOID_BORROWED_REFS 0
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    #undef CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
    #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 1
  #elif !defined(CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS)
    #define CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS 0
  #endif
  #ifndef CYTHON_ASSUME_SAFE_MACROS
    #define CYTHON_ASSUME_SAFE_MACROS 1
  #endif
  #ifndef CYTHON_ASSUME_SAFE_SIZE
    #define CYTHON_ASSUME_SAFE_SIZE 1
  #endif
  #ifndef CYTHON_UNPACK_METHODS
    #define CYTHON_UNPACK_METHODS 1
  #endif
  #ifndef CYTHON_FAST_THREAD_STATE
    #define CYTHON_FAST_THREAD_STATE 1
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    #undef CYTHON_FAST_GIL
    #define CYTHON_FAST_GIL 0
  #elif !defined(CYTHON_FAST_GIL)
    #define CYTHON_FAST_GIL (PY_VERSION_HEX < 0x030C00A6)
  #endif
  #ifndef CYTHON_VECTORCALL
    #define CYTHON_VECTORCALL 1
  #endif
  #if CYTHON_USE_TYPE_SPECS && PY_VERSION_HEX < 0x030E0000
    #undef CYTHON_VECTORCALL_TPNEW
    #define CYTHON_VECTORCALL_TPNEW 0
  #elif !defined(CYTHON_VECTORCALL_TPNEW)
    #define CYTHON_VECTORCALL_TPNEW CYTHON_VECTORCALL
  #endif
  #ifndef CYTHON_PEP487_INIT_SUBCLASS
    #define CYTHON_PEP487_INIT_SUBCLASS 1
  #endif
  #ifndef CYTHON_PEP489_MULTI_PHASE_INIT
    #define CYTHON_PEP489_MULTI_PHASE_INIT 1
  #endif
  #ifndef CYTHON_USE_MODULE_STATE
    #define CYTHON_USE_MODULE_STATE 0
  #endif
  #ifndef CYTHON_USE_SYS_MONITORING
    #define CYTHON_USE_SYS_MONITORING (PY_VERSION_HEX >= 0x030d00B1)
  #endif
  #ifndef CYTHON_USE_TP_FINALIZE
    #define CYTHON_USE_TP_FINALIZE 1
  #endif
  #ifndef CYTHON_USE_AM_SEND
    #define CYTHON_USE_AM_SEND 1
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    #undef CYTHON_USE_DICT_VERSIONS
    #define CYTHON_USE_DICT_VERSIONS 0
  #elif !defined(CYTHON_USE_DICT_VERSIONS)
    #define CYTHON_USE_DICT_VERSIONS  (PY_VERSION_HEX < 0x030C00A5 && !CYTHON_USE_MODULE_STATE)
  #endif
  #ifndef CYTHON_USE_EXC_INFO_STACK
    #define CYTHON_USE_EXC_INFO_STACK 1
  #endif
  #ifndef CYTHON_UPDATE_DESCRIPTOR_DOC
    #define CYTHON_UPDATE_DESCRIPTOR_DOC 1
  #endif
  #ifndef CYTHON_USE_OWN_PREP_RERAISE_STAR
    #define CYTHON_USE_OWN_PREP_RERAISE_STAR (PY_VERSION_HEX < 0x030C00B2)
  #endif
  #ifndef CYTHON_USE_FREELISTS
    #define CYTHON_USE_FREELISTS (!CYTHON_COMPILING_IN_CPYTHON_FREETHREADING)
  #endif
  #if defined(CYTHON_IMMORTAL_CONSTANTS) && PY_VERSION_HEX < 0x030C0000
    #undef CYTHON_IMMORTAL_CONSTANTS
    #define CYTHON_IMMORTAL_CONSTANTS 0  // definitely won't work
  #elif !defined(CYTHON_IMMORTAL_CONSTANTS)
    #define CYTHON_IMMORTAL_CONSTANTS (PY_VERSION_HEX >= 0x030C0000 && !CYTHON_USE_MODULE_STATE && CYTHON_COMPILING_IN_CPYTHON_FREETHREADING)
  #endif
  #ifndef CYTHON_OPAQUE_OBJECTS
    #define CYTHON_OPAQUE_OBJECTS 0
  #endif
#endif
#if CYTHON_USE_PYLONG_INTERNALS
  #undef SHIFT
  #undef BASE
  #undef MASK
  #ifdef SIZEOF_VOID_P
    enum { __pyx_check_sizeof_voidp = 1 / (int)(SIZEOF_VOID_P == sizeof(void*)) };
  #endif
#endif
#ifndef __has_attribute
  #define __has_attribute(x) 0
#endif
#ifndef __has_cpp_attribute
  #define __has_cpp_attribute(x) 0
#endif
#ifndef CYTHON_RESTRICT
  #if defined(__GNUC__)
    #define CYTHON_RESTRICT __restrict__
  #elif defined(_MSC_VER) && _MSC_VER >= 1400
    #define CYTHON_RESTRICT __restrict
  #elif defined (__STDC_VERSION__) && __STDC_VERSION__ >= 199901L
    #define CYTHON_RESTRICT restrict
  #else
    #define CYTHON_RESTRICT
  #endif
#endif
#ifndef CYTHON_UNUSED
  #if defined(__cplusplus)
    
    #if ((defined(_MSVC_LANG) && _MSVC_LANG >= 201703L) || __cplusplus >= 201703L)
      #if __has_cpp_attribute(maybe_unused)
        #define CYTHON_UNUSED [[maybe_unused]]
      #endif
    #endif
  #elif defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
    #define CYTHON_UNUSED [[maybe_unused]]
  #endif
#endif
#ifndef CYTHON_UNUSED
# if defined(__GNUC__)
#   if !(defined(__cplusplus)) || (__GNUC__ > 3 || (__GNUC__ == 3 && __GNUC_MINOR__ >= 4))
#     define CYTHON_UNUSED __attribute__ ((__unused__))
#   else
#     define CYTHON_UNUSED
#   endif
# elif defined(__ICC) || (defined(__INTEL_COMPILER) && !defined(_MSC_VER))
#   define CYTHON_UNUSED __attribute__ ((__unused__))
# else
#   define CYTHON_UNUSED
# endif
#endif
#ifndef CYTHON_UNUSED_VAR
#  if defined(__cplusplus)
     template<class T> void CYTHON_UNUSED_VAR( const T& ) { }
#  else
#    define CYTHON_UNUSED_VAR(x) (void)(x)
#  endif
#endif
#ifndef CYTHON_MAYBE_UNUSED_VAR
  #define CYTHON_MAYBE_UNUSED_VAR(x) CYTHON_UNUSED_VAR(x)
#endif
#ifndef CYTHON_NCP_UNUSED
# if CYTHON_COMPILING_IN_CPYTHON && !CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
#  define CYTHON_NCP_UNUSED
# else
#  define CYTHON_NCP_UNUSED CYTHON_UNUSED
# endif
#endif
#ifndef CYTHON_USE_CPP_STD_MOVE
  #if defined(__cplusplus) && (\
    __cplusplus >= 201103L || (defined(_MSC_VER) && _MSC_VER >= 1600))
    #define CYTHON_USE_CPP_STD_MOVE 1
  #else
    #define CYTHON_USE_CPP_STD_MOVE 0
  #endif
#endif
#define __Pyx_void_to_None(void_result) ((void)(void_result), Py_INCREF(Py_None), Py_None)
#include <stdint.h>
typedef uintptr_t  __pyx_uintptr_t;
#ifndef CYTHON_FALLTHROUGH
  #if defined(__cplusplus)
    
    #if ((defined(_MSVC_LANG) && _MSVC_LANG >= 201703L) || __cplusplus >= 201703L)
      #if __has_cpp_attribute(fallthrough)
        #define CYTHON_FALLTHROUGH [[fallthrough]]
      #endif
    #endif
    #ifndef CYTHON_FALLTHROUGH
      #if __has_cpp_attribute(clang::fallthrough)
        #define CYTHON_FALLTHROUGH [[clang::fallthrough]]
      #elif __has_cpp_attribute(gnu::fallthrough)
        #define CYTHON_FALLTHROUGH [[gnu::fallthrough]]
      #endif
    #endif
  #endif
  #ifndef CYTHON_FALLTHROUGH
    #if __has_attribute(fallthrough)
      #define CYTHON_FALLTHROUGH __attribute__((fallthrough))
    #else
      #define CYTHON_FALLTHROUGH
    #endif
  #endif
  #if defined(__clang__) && defined(__apple_build_version__)
    #if __apple_build_version__ < 7000000
      #undef  CYTHON_FALLTHROUGH
      #define CYTHON_FALLTHROUGH
    #endif
  #endif
#endif
#ifdef Py_UNREACHABLE
  #define __Pyx_UNREACHABLE() Py_UNREACHABLE()
#elif __Pyx_has_cbuiltin(__builtin_unreachable)
  #define __Pyx_UNREACHABLE() __builtin_unreachable()
#elif defined(__clang__) || defined(__INTEL_COMPILER) || (defined(__GNUC__) && (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 5)))
  #define __Pyx_UNREACHABLE() __builtin_unreachable()
#elif defined(_MSC_VER)
  #define __Pyx_UNREACHABLE() __assume(0)
#else
  #define __Pyx_UNREACHABLE() Py_FatalError("Unreachable C code path reached")
#endif
#ifndef Py_UNREACHABLE
  #define Py_UNREACHABLE() __Pyx_UNREACHABLE()
#endif
#ifdef __cplusplus
  template <typename T>
  struct __PYX_IS_UNSIGNED_IMPL {static const bool value = T(0) < T(-1);};
  #define __PYX_IS_UNSIGNED(type) (__PYX_IS_UNSIGNED_IMPL<type>::value)
#else
  #define __PYX_IS_UNSIGNED(type) (((type)-1) > 0)
#endif
#if CYTHON_COMPILING_IN_PYPY == 1
  #define __PYX_NEED_TP_PRINT_SLOT  (PY_VERSION_HEX < 0x030A0000)
#else
  #define __PYX_NEED_TP_PRINT_SLOT  0
#endif
#define __PYX_REINTERPRET_FUNCION(func_pointer, other_pointer) ((func_pointer)(void(*)(void))(other_pointer))
#if __PYX_LIMITED_VERSION_HEX < 0x030C0000
#define __Pyx_PyErr_FetchException(petype, peval, petb) PyErr_Fetch(petype, peval, petb)
#define __Pyx_PyErr_RestoreException(etype, eval, etb) PyErr_Restore(etype, eval, etb)
#else
#define __Pyx_PyErr_FetchException(petype, peval, petb) *(petype)=NULL; *(peval)=PyErr_GetRaisedException(); *(petb)=NULL
#define __Pyx_PyErr_RestoreException(etype, eval, etb) PyErr_SetRaisedException(eval)
#endif


#ifndef CYTHON_INLINE
  #if defined(__clang__)
    #define CYTHON_INLINE __inline__ __attribute__ ((__unused__))
  #elif defined(__GNUC__)
    #define CYTHON_INLINE __inline__
  #elif defined(_MSC_VER)
    #define CYTHON_INLINE __inline
  #elif defined (__STDC_VERSION__) && __STDC_VERSION__ >= 199901L
    #define CYTHON_INLINE inline
  #else
    #define CYTHON_INLINE
  #endif
#endif


#define __PYX_BUILD_PY_SSIZE_T "n"
#define CYTHON_FORMAT_SSIZE_T "z"
#define __Pyx_BUILTIN_MODULE_NAME "builtins"
#define __Pyx_DefaultClassType PyType_Type
#if CYTHON_COMPILING_IN_LIMITED_API
    #ifndef CO_OPTIMIZED
    static int CO_OPTIMIZED;
    #endif
    #ifndef CO_NEWLOCALS
    static int CO_NEWLOCALS;
    #endif
    #ifndef CO_VARARGS
    static int CO_VARARGS;
    #endif
    #ifndef CO_VARKEYWORDS
    static int CO_VARKEYWORDS;
    #endif
    #ifndef CO_ASYNC_GENERATOR
    static int CO_ASYNC_GENERATOR;
    #endif
    #ifndef CO_GENERATOR
    static int CO_GENERATOR;
    #endif
    #ifndef CO_COROUTINE
    static int CO_COROUTINE;
    #endif
#else
    #ifndef CO_COROUTINE
      #define CO_COROUTINE 0x80
    #endif
    #ifndef CO_ASYNC_GENERATOR
      #define CO_ASYNC_GENERATOR 0x200
    #endif
#endif
static int __Pyx_init_co_variables(void);
#if PY_VERSION_HEX >= 0x030A00B1 || defined(Py_Is)
  #define __Pyx_Py_Is(x, y)  Py_Is(x, y)
#else
  #define __Pyx_Py_Is(x, y) ((x) == (y))
#endif
#if PY_VERSION_HEX >= 0x030A00B1 || defined(Py_IsNone)
  #define __Pyx_Py_IsNone(ob) Py_IsNone(ob)
#else
  #define __Pyx_Py_IsNone(ob) __Pyx_Py_Is((ob), Py_None)
#endif
#if PY_VERSION_HEX >= 0x030A00B1 || defined(Py_IsTrue)
  #define __Pyx_Py_IsTrue(ob) Py_IsTrue(ob)
#else
  #define __Pyx_Py_IsTrue(ob) __Pyx_Py_Is((ob), Py_True)
#endif
#if PY_VERSION_HEX >= 0x030A00B1 || defined(Py_IsFalse)
  #define __Pyx_Py_IsFalse(ob) Py_IsFalse(ob)
#else
  #define __Pyx_Py_IsFalse(ob) __Pyx_Py_Is((ob), Py_False)
#endif
#define __Pyx_NoneAsNull(obj)  (__Pyx_Py_IsNone(obj) ? NULL : (obj))
#if CYTHON_COMPILING_IN_PYPY
  #define __Pyx_PyObject_GC_IsFinalized(o) _PyGC_FINALIZED(o)
#else
  #define __Pyx_PyObject_GC_IsFinalized(o) PyObject_GC_IsFinalized(o)
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
static unsigned long __Pyx_Runtime_TPFLAGS_SEQUENCE;
static unsigned long __Pyx_Runtime_TPFLAGS_MAPPING;
#else
#define __Pyx_Runtime_TPFLAGS_SEQUENCE Py_TPFLAGS_SEQUENCE
#define __Pyx_Runtime_TPFLAGS_MAPPING Py_TPFLAGS_MAPPING
#endif
static int __Pyx_init_tpflags_variables(void);
#ifndef Py_TPFLAGS_HAVE_FINALIZE
  #define Py_TPFLAGS_HAVE_FINALIZE 0
#endif
#ifndef Py_TPFLAGS_SEQUENCE
  #define Py_TPFLAGS_SEQUENCE (CYTHON_COMPILING_IN_LIMITED_API ? 0 : 1 << 5)
#endif
#ifndef Py_TPFLAGS_MAPPING
  #define Py_TPFLAGS_MAPPING (CYTHON_COMPILING_IN_LIMITED_API ? 0 : 1 << 6)
#endif
#ifndef Py_TPFLAGS_IMMUTABLETYPE
  #define Py_TPFLAGS_IMMUTABLETYPE (1UL << 8)
#endif
#ifndef Py_TPFLAGS_DISALLOW_INSTANTIATION
  #define Py_TPFLAGS_DISALLOW_INSTANTIATION (1UL << 7)
#endif
#ifndef METH_STACKLESS
  #define METH_STACKLESS 0
#endif
#if !defined(METH_FASTCALL) || CYTHON_COMPILING_IN_PYPY
  #ifndef METH_FASTCALL
     #define METH_FASTCALL 0x80
  #endif
  typedef PyObject *(*__Pyx_PyCFunctionFast) (PyObject *self, PyObject *const *args, Py_ssize_t nargs);
  typedef PyObject *(*__Pyx_PyCFunctionFastWithKeywords) (PyObject *self, PyObject *const *args,
                                                          Py_ssize_t nargs, PyObject *kwnames);
#else
  #if PY_VERSION_HEX >= 0x030d00A4
  #  define __Pyx_PyCFunctionFast PyCFunctionFast
  #  define __Pyx_PyCFunctionFastWithKeywords PyCFunctionFastWithKeywords
  #else
  #  define __Pyx_PyCFunctionFast _PyCFunctionFast
  #  define __Pyx_PyCFunctionFastWithKeywords _PyCFunctionFastWithKeywords
  #endif
#endif
#if CYTHON_VECTORCALL
  #define __Pyx_METH_FASTCALL METH_FASTCALL
  #define __Pyx_PyCFunction_FastCall __Pyx_PyCFunctionFast
  #define __Pyx_PyCFunction_FastCallWithKeywords __Pyx_PyCFunctionFastWithKeywords
#else
  #define __Pyx_METH_FASTCALL METH_VARARGS
  #define __Pyx_PyCFunction_FastCall PyCFunction
  #define __Pyx_PyCFunction_FastCallWithKeywords PyCFunctionWithKeywords
#endif
#if CYTHON_VECTORCALL
  #define __pyx_vectorcallfunc vectorcallfunc
  #define __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET  PY_VECTORCALL_ARGUMENTS_OFFSET
  #define __Pyx_PyVectorcall_NARGS(n)  PyVectorcall_NARGS((size_t)(n))
#else
  #define __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET  0
  #define __Pyx_PyVectorcall_NARGS(n)  ((Py_ssize_t)(n))
#endif
#define __Pyx_PyCFunction_CheckExact(func) PyCFunction_CheckExact(func)
#define __Pyx_CyOrPyCFunction_Check(func)  PyCFunction_Check(func)
#if CYTHON_COMPILING_IN_CPYTHON
#define __Pyx_CyOrPyCFunction_GET_FUNCTION(func)  (((PyCFunctionObject*)(func))->m_ml->ml_meth)
#elif !CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_CyOrPyCFunction_GET_FUNCTION(func)  PyCFunction_GET_FUNCTION(func)
#endif
#if CYTHON_COMPILING_IN_CPYTHON
#define __Pyx_CyOrPyCFunction_GET_FLAGS(func)  (((PyCFunctionObject*)(func))->m_ml->ml_flags)
static CYTHON_INLINE PyObject* __Pyx_CyOrPyCFunction_GET_SELF(PyObject *func) {
    return (__Pyx_CyOrPyCFunction_GET_FLAGS(func) & METH_STATIC) ? NULL : ((PyCFunctionObject*)func)->m_self;
}
#endif
static CYTHON_INLINE int __Pyx__IsSameCFunction(PyObject *func, void (*cfunc)(void)) {
#if CYTHON_COMPILING_IN_LIMITED_API
    return PyCFunction_Check(func) && PyCFunction_GetFunction(func) == (PyCFunction) cfunc;
#else
    return PyCFunction_Check(func) && PyCFunction_GET_FUNCTION(func) == (PyCFunction) cfunc;
#endif
}
#define __Pyx_IsSameCFunction(func, cfunc)   __Pyx__IsSameCFunction(func, cfunc)
#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030A0000
  #define __Pyx_PyType_FromModuleAndSpec(m, s, b)  ((void)m, PyType_FromSpecWithBases(s, b))
#else
  #define __Pyx_PyType_FromModuleAndSpec(m, s, b)  PyType_FromModuleAndSpec(m, s, b)
#endif
#if CYTHON_COMPILING_IN_PYPY
  typedef PyObject *(*__Pyx_PyCMethod)(PyObject *, PyTypeObject *, PyObject *const *, size_t, PyObject *);
#else
  #define __Pyx_PyCMethod  PyCMethod
#endif
#ifndef METH_METHOD
  #define METH_METHOD 0x200
#endif
#if CYTHON_COMPILING_IN_PYPY && !defined(PyObject_Malloc)
  #define PyObject_Malloc(s)   PyMem_Malloc(s)
  #define PyObject_Free(p)     PyMem_Free(p)
  #define PyObject_Realloc(p)  PyMem_Realloc(p)
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
  #define __Pyx_PyFrame_SetLineNumber(frame, lineno)
#elif CYTHON_COMPILING_IN_GRAAL && defined(GRAALPY_VERSION_NUM) && GRAALPY_VERSION_NUM > 0x19000000
  #define __Pyx_PyCode_HasFreeVars(co)  (PyCode_GetNumFree(co) > 0)
  #define __Pyx_PyFrame_SetLineNumber(frame, lineno) GraalPyFrame_SetLineNumber((frame), (lineno))
#elif CYTHON_COMPILING_IN_GRAAL
  #define __Pyx_PyCode_HasFreeVars(co)  (PyCode_GetNumFree(co) > 0)
  #define __Pyx_PyFrame_SetLineNumber(frame, lineno) _PyFrame_SetLineNumber((frame), (lineno))
#else
  #define __Pyx_PyCode_HasFreeVars(co)  (PyCode_GetNumFree(co) > 0)
  #define __Pyx_PyFrame_SetLineNumber(frame, lineno)  (frame)->f_lineno = (lineno)
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
  #define __Pyx_PyThreadState_Current PyThreadState_Get()
#elif !CYTHON_FAST_THREAD_STATE
  #define __Pyx_PyThreadState_Current PyThreadState_GET()
#elif PY_VERSION_HEX >= 0x030d00A1
  #define __Pyx_PyThreadState_Current PyThreadState_GetUnchecked()
#else
  #define __Pyx_PyThreadState_Current _PyThreadState_UncheckedGet()
#endif
#if CYTHON_OPAQUE_OBJECTS && CYTHON_COMPILING_IN_LIMITED_API
    #define __PYX_SHARED_SIZEOF(T) -((int)sizeof(T))
    #define __PYX_SHARED_RELATIVE_OFFSET Py_RELATIVE_OFFSET
    #define CYTHON_OPAQUE_SHARED_TYPES 1
#else
    #define __PYX_SHARED_SIZEOF(T) sizeof(T)
    #define __PYX_SHARED_RELATIVE_OFFSET 0
    #define CYTHON_OPAQUE_SHARED_TYPES 0
#endif
#if CYTHON_USE_MODULE_STATE
static CYTHON_INLINE void *__Pyx__PyModule_GetState(PyObject *op)
{
    void *result;
    result = PyModule_GetState(op);
    if (!result)
        Py_FatalError("Couldn't find the module state");
    return result;
}
#define __Pyx_PyModule_GetState(o) (__pyx_mstatetype *)__Pyx__PyModule_GetState(o)
#else
#define __Pyx_PyModule_GetState(op) ((void)op,__pyx_mstate_global)
#endif
#define __Pyx_PyObject_GetSlot(obj, name, func_ctype)  __Pyx_PyType_GetSlot(Py_TYPE((PyObject *) obj), name, func_ctype)
#define __Pyx_PyObject_TryGetSlot(obj, name, func_ctype) __Pyx_PyType_TryGetSlot(Py_TYPE(obj), name, func_ctype)
#define __Pyx_PyObject_GetSubSlot(obj, sub, name, func_ctype) __Pyx_PyType_GetSubSlot(Py_TYPE(obj), sub, name, func_ctype)
#define __Pyx_PyObject_TryGetSubSlot(obj, sub, name, func_ctype) __Pyx_PyType_TryGetSubSlot(Py_TYPE(obj), sub, name, func_ctype)
#if CYTHON_USE_TYPE_SLOTS
  #define __Pyx_PyType_GetSlot(type, name, func_ctype)  ((type)->name)
  #define __Pyx_PyType_TryGetSlot(type, name, func_ctype) __Pyx_PyType_GetSlot(type, name, func_ctype)
  #define __Pyx_PyType_GetSubSlot(type, sub, name, func_ctype) (((type)->sub) ? ((type)->sub->name) : NULL)
  #define __Pyx_PyType_TryGetSubSlot(type, sub, name, func_ctype) __Pyx_PyType_GetSubSlot(type, sub, name, func_ctype)
#else
  #define __Pyx_PyType_GetSlot(type, name, func_ctype)  ((func_ctype) PyType_GetSlot((type), Py_##name))
  #define __Pyx_PyType_TryGetSlot(type, name, func_ctype)\
    ((__PYX_LIMITED_VERSION_HEX >= 0x030A0000 ||\
     (PyType_GetFlags(type) & Py_TPFLAGS_HEAPTYPE) || __Pyx_get_runtime_version() >= 0x030A0000) ?\
     __Pyx_PyType_GetSlot(type, name, func_ctype) : NULL)
  #define __Pyx_PyType_GetSubSlot(obj, sub, name, func_ctype) __Pyx_PyType_GetSlot(obj, name, func_ctype)
  #define __Pyx_PyType_TryGetSubSlot(obj, sub, name, func_ctype) __Pyx_PyType_TryGetSlot(obj, name, func_ctype)
#endif
#if CYTHON_COMPILING_IN_CPYTHON || defined(_PyDict_NewPresized)
#define __Pyx_PyDict_NewPresized(n)  ((n <= 8) ? PyDict_New() : _PyDict_NewPresized(n))
#else
#define __Pyx_PyDict_NewPresized(n)  PyDict_New()
#endif
#define __Pyx_PyNumber_Divide(x,y)         PyNumber_TrueDivide(x,y)
#define __Pyx_PyNumber_InPlaceDivide(x,y)  PyNumber_InPlaceTrueDivide(x,y)
#if CYTHON_COMPILING_IN_CPYTHON && CYTHON_USE_UNICODE_INTERNALS
#define __Pyx_PyDict_GetItemStrWithError(dict, name)  _PyDict_GetItem_KnownHash(dict, name, ((PyASCIIObject *) name)->hash)
static CYTHON_INLINE PyObject * __Pyx_PyDict_GetItemStr(PyObject *dict, PyObject *name) {
    PyObject *res = __Pyx_PyDict_GetItemStrWithError(dict, name);
    if (res == NULL && PyErr_Occurred()) {
        PyErr_WriteUnraisable(NULL);
    }
    return res;
}
#elif !CYTHON_COMPILING_IN_PYPY || PYPY_VERSION_NUM >= 0x07020000
#define __Pyx_PyDict_GetItemStrWithError  PyDict_GetItemWithError
#define __Pyx_PyDict_GetItemStr           PyDict_GetItem
#else
static CYTHON_INLINE PyObject * __Pyx_PyDict_GetItemStrWithError(PyObject *dict, PyObject *name) {
#if CYTHON_COMPILING_IN_PYPY
    return PyDict_GetItem(dict, name);
#else
    PyDictEntry *ep;
    PyDictObject *mp = (PyDictObject*) dict;
    long hash = ((PyStringObject *) name)->ob_shash;
    assert(hash != -1);
    ep = (mp->ma_lookup)(mp, name, hash);
    if (ep == NULL) {
        return NULL;
    }
    return ep->me_value;
#endif
}
#define __Pyx_PyDict_GetItemStr           PyDict_GetItem
#endif
#if CYTHON_USE_TYPE_SLOTS
  #define __Pyx_PyType_GetFlags(tp)   (((PyTypeObject *)tp)->tp_flags)
  #define __Pyx_PyType_HasFeature(type, feature)  ((__Pyx_PyType_GetFlags(type) & (feature)) != 0)
#else
  #define __Pyx_PyType_GetFlags(tp)   (PyType_GetFlags((PyTypeObject *)tp))
  #define __Pyx_PyType_HasFeature(type, feature)  PyType_HasFeature(type, feature)
#endif
#define __Pyx_PyObject_GetIterNextFunc(iterator)  __Pyx_PyObject_GetSlot(iterator, tp_iternext, iternextfunc)
#if CYTHON_USE_TYPE_SPECS
#define __Pyx_PyHeapTypeObject_GC_Del(obj)  {\
    PyTypeObject *type = Py_TYPE((PyObject*)obj);\
    assert(__Pyx_PyType_HasFeature(type, Py_TPFLAGS_HEAPTYPE));\
    PyObject_GC_Del(obj);\
    Py_DECREF(type);\
}
#else
#define __Pyx_PyHeapTypeObject_GC_Del(obj)  PyObject_GC_Del(obj)
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
  #define __Pyx_PyUnicode_READY(op)       (0)
  #define __Pyx_PyUnicode_READ_CHAR(u, i) PyUnicode_ReadChar(u, i)
  #define __Pyx_PyUnicode_MAX_CHAR_VALUE(u)   ((void)u, 1114111U)
  #define __Pyx_PyUnicode_KIND(u)         ((void)u, (0))
  #define __Pyx_PyUnicode_KIND_04(u)      __Pyx_PyUnicode_KIND(u)
  #define __Pyx_PyUnicode_DATA(u)         ((void*)u)
  #define __Pyx_PyUnicode_READ(k, d, i)   ((void)k, PyUnicode_ReadChar((PyObject*)(d), i))
  #define __Pyx_PyUnicode_IS_TRUE(u)      (0 != PyUnicode_GetLength(u))
#else
  #if PY_VERSION_HEX >= 0x030C0000
    #define __Pyx_PyUnicode_READY(op)       (0)
  #else
    #define __Pyx_PyUnicode_READY(op)       (likely(PyUnicode_IS_READY(op)) ?\
                                                0 : _PyUnicode_Ready((PyObject *)(op)))
  #endif
  #define __Pyx_PyUnicode_READ_CHAR(u, i) PyUnicode_READ_CHAR(u, i)
  #define __Pyx_PyUnicode_MAX_CHAR_VALUE(u)   PyUnicode_MAX_CHAR_VALUE(u)
  #define __Pyx_PyUnicode_KIND(u)         ((int)PyUnicode_KIND(u))
  #define __Pyx_PyUnicode_DATA(u)         PyUnicode_DATA(u)
  #define __Pyx_PyUnicode_READ(k, d, i)   PyUnicode_READ(k, d, i)
  #define __Pyx_PyUnicode_WRITE(k, d, i, ch)  PyUnicode_WRITE(k, d, i, (Py_UCS4) ch)
  #if PY_VERSION_HEX >= 0x030C0000
    #define __Pyx_PyUnicode_IS_TRUE(u)      (0 != PyUnicode_GET_LENGTH(u))
  #else
    #if CYTHON_COMPILING_IN_CPYTHON
    #define __Pyx_PyUnicode_IS_TRUE(u)      (0 != (likely(PyUnicode_IS_READY(u)) ? PyUnicode_GET_LENGTH(u) : ((PyCompactUnicodeObject *)(u))->wstr_length))
    #else
    #define __Pyx_PyUnicode_IS_TRUE(u)      (0 != (likely(PyUnicode_IS_READY(u)) ? PyUnicode_GET_LENGTH(u) : PyUnicode_GET_SIZE(u)))
    #endif
  #endif
  static CYTHON_INLINE int __Pyx_PyUnicode_KIND_04(PyObject *o) {
      return __Pyx_PyUnicode_KIND(o) - (int) !!PyUnicode_IS_ASCII(o);
  }
#endif
#if CYTHON_COMPILING_IN_PYPY
  #define __Pyx_PyUnicode_Concat(a, b)      PyNumber_Add(a, b)
  #define __Pyx_PyUnicode_ConcatSafe(a, b)  PyNumber_Add(a, b)
#else
  #define __Pyx_PyUnicode_Concat(a, b)      PyUnicode_Concat(a, b)
  #define __Pyx_PyUnicode_ConcatSafe(a, b)  ((unlikely((a) == Py_None) || unlikely((b) == Py_None)) ?\
      PyNumber_Add(a, b) : __Pyx_PyUnicode_Concat(a, b))
#endif
#if CYTHON_COMPILING_IN_PYPY
  #if !defined(PyUnicode_DecodeUnicodeEscape)
    #define PyUnicode_DecodeUnicodeEscape(s, size, errors)  PyUnicode_Decode(s, size, "unicode_escape", errors)
  #endif
  #if !defined(PyUnicode_Contains)
    #define PyUnicode_Contains(u, s)  PySequence_Contains(u, s)
  #endif
  #if !defined(PyByteArray_Check)
    #define PyByteArray_Check(obj)  PyObject_TypeCheck(obj, &PyByteArray_Type)
  #endif
  #if !defined(PyObject_Format)
    #define PyObject_Format(obj, fmt)  PyObject_CallMethod(obj, "__format__", "O", fmt)
  #endif
#endif
#define __Pyx_PyUnicode_FormatSafe(a, b)  ((unlikely((a) == Py_None || (PyUnicode_Check(b) && !PyUnicode_CheckExact(b)))) ? PyNumber_Remainder(a, b) : PyUnicode_Format(a, b))
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030E0000
  #define __Pyx_PySequence_ListKeepNew(obj)\
    (likely(PyList_CheckExact(obj) && PyUnstable_Object_IsUniquelyReferenced(obj)) ? __Pyx_NewRef(obj) : PySequence_List(obj))
#elif CYTHON_COMPILING_IN_CPYTHON
  #define __Pyx_PySequence_ListKeepNew(obj)\
    (likely(PyList_CheckExact(obj) && Py_REFCNT(obj) == 1) ? __Pyx_NewRef(obj) : PySequence_List(obj))
#else
  #define __Pyx_PySequence_ListKeepNew(obj)  PySequence_List(obj)
#endif
#ifndef PySet_CheckExact
  #define PySet_CheckExact(obj)        Py_IS_TYPE(obj, &PySet_Type)
#endif
enum __Pyx_ReferenceSharing {
  __Pyx_ReferenceSharing_DefinitelyUnique, // We created it so we know it's unshared - no need to check
  __Pyx_ReferenceSharing_OwnStrongReference,
  __Pyx_ReferenceSharing_FunctionArgument,
  __Pyx_ReferenceSharing_SharedReference, // Never trust it to be unshared because it's a global or similar
};
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING && PY_VERSION_HEX >= 0x030E0000
#define __Pyx_IS_UNIQUELY_REFERENCED(o, sharing)\
    (sharing == __Pyx_ReferenceSharing_DefinitelyUnique ? 1 :\
      (sharing == __Pyx_ReferenceSharing_FunctionArgument ? PyUnstable_Object_IsUniqueReferencedTemporary(o) :\
      (sharing == __Pyx_ReferenceSharing_OwnStrongReference ? PyUnstable_Object_IsUniquelyReferenced(o) : 0)))
#elif (CYTHON_COMPILING_IN_CPYTHON && !CYTHON_COMPILING_IN_CPYTHON_FREETHREADING) || CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_IS_UNIQUELY_REFERENCED(o, sharing) (((void)sharing), Py_REFCNT(o) == 1)
#else
#define __Pyx_IS_UNIQUELY_REFERENCED(o, sharing) (((void)o), ((void)sharing), 0)
#endif
#if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
  #define __Pyx_PyList_GetItemRef(o, i) PyList_GetItemRef(o, i)
#elif CYTHON_AVOID_BORROWED_REFS || CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
  #if CYTHON_COMPILING_IN_LIMITED_API || !CYTHON_ASSUME_SAFE_MACROS
    #define __Pyx_PyList_GetItemRef(o, i) (likely((i) >= 0) ? PySequence_GetItem(o, i) : (PyErr_SetString(PyExc_IndexError, "list index out of range"), (PyObject*)NULL))
  #else
    #define __Pyx_PyList_GetItemRef(o, i) PySequence_ITEM(o, i)
  #endif
#elif CYTHON_COMPILING_IN_LIMITED_API || !(CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE)
  #define __Pyx_PyList_GetItemRef(o, i) __Pyx_XNewRef(PyList_GetItem(o, i))
#else
  #define __Pyx_PyList_GetItemRef(o, i) (likely(__Pyx_is_valid_index(i, PyList_GET_SIZE(o))) ?\
    __Pyx_NewRef(PyList_GET_ITEM(o, i)) : (PyErr_SetString(PyExc_IndexError, "list index out of range"), (PyObject*)NULL))
#endif
#if CYTHON_AVOID_BORROWED_REFS || CYTHON_COMPILING_IN_LIMITED_API
  #define __Pyx_PyList_GET_ITEM_REF(o, i, unsafe_shared)  ((void)(unsafe_shared),\
      __Pyx_PyList_GetItemRef(o, i))
#elif CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
  #if CYTHON_ASSUME_SAFE_MACROS
  #define __Pyx_PyList_GET_ITEM_REF(o, i, unsafe_shared) (\
      __Pyx_IS_UNIQUELY_REFERENCED(o, unsafe_shared) ?\
      __Pyx_NewRef(PyList_GET_ITEM(o, i)) : __Pyx_PyList_GetItemRef(o, i))
  #else
  #define __Pyx_PyList_GET_ITEM_REF(o, i, unsafe_shared) (\
      __Pyx_IS_UNIQUELY_REFERENCED(o, unsafe_shared) ?\
      __Pyx_XNewRef(PyList_GetItem(o, i)) : __Pyx_PyList_GetItemRef(o, i))
  #endif
#elif CYTHON_ASSUME_SAFE_MACROS
  #define __Pyx_PyList_GET_ITEM_REF(o, i, unsafe_shared)  ((void)(unsafe_shared),\
      __Pyx_NewRef(PyList_GET_ITEM(o, i)))
#else
  #define __Pyx_PyList_GET_ITEM_REF(o, i, unsafe_shared)  ((void)(unsafe_shared),\
      __Pyx_XNewRef(PyList_GetItem(o, i)))
#endif
#if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
#define __Pyx_PyDict_GetItemRef(dict, key, result) PyDict_GetItemRef(dict, key, result)
#elif CYTHON_AVOID_BORROWED_REFS || CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
static CYTHON_INLINE int __Pyx_PyDict_GetItemRef(PyObject *dict, PyObject *key, PyObject **result) {
  *result = PyObject_GetItem(dict, key);
  if (*result == NULL) {
    if (PyErr_ExceptionMatches(PyExc_KeyError)) {
      PyErr_Clear();
      return 0;
    }
    return -1;
  }
  return 1;
}
#else
static CYTHON_INLINE int __Pyx_PyDict_GetItemRef(PyObject *dict, PyObject *key, PyObject **result) {
  *result = PyDict_GetItemWithError(dict, key);
  if (*result == NULL) {
    return PyErr_Occurred() ? -1 : 0;
  }
  Py_INCREF(*result);
  return 1;
}
#endif
#if defined(CYTHON_DEBUG_VISIT_CONST) && CYTHON_DEBUG_VISIT_CONST
  #define __Pyx_VISIT_CONST(obj)  Py_VISIT(obj)
#else
  #define __Pyx_VISIT_CONST(obj)
#endif
#if CYTHON_ASSUME_SAFE_MACROS
  #define __Pyx_PySequence_ITEM(o, i) PySequence_ITEM(o, i)
  #define __Pyx_PySequence_SIZE(seq)  Py_SIZE(seq)
  #define __Pyx_PyTuple_SET_ITEM(o, i, v) (PyTuple_SET_ITEM(o, i, v), (0))
  #define __Pyx_PyTuple_GET_ITEM(o, i) PyTuple_GET_ITEM(o, i)
  #define __Pyx_PyList_SET_ITEM(o, i, v) (PyList_SET_ITEM(o, i, v), (0))
  #define __Pyx_PyList_GET_ITEM(o, i) PyList_GET_ITEM(o, i)
#else
  #define __Pyx_PySequence_ITEM(o, i) PySequence_GetItem(o, i)
  #define __Pyx_PySequence_SIZE(seq)  PySequence_Size(seq)
  #define __Pyx_PyTuple_SET_ITEM(o, i, v) PyTuple_SetItem(o, i, v)
  #define __Pyx_PyTuple_GET_ITEM(o, i) PyTuple_GetItem(o, i)
  #define __Pyx_PyList_SET_ITEM(o, i, v) PyList_SetItem(o, i, v)
  #define __Pyx_PyList_GET_ITEM(o, i) PyList_GetItem(o, i)
#endif
#if CYTHON_ASSUME_SAFE_SIZE
  #define __Pyx_PyTuple_GET_SIZE(o) PyTuple_GET_SIZE(o)
  #define __Pyx_PyList_GET_SIZE(o) PyList_GET_SIZE(o)
  #define __Pyx_PySet_GET_SIZE(o) PySet_GET_SIZE(o)
  #define __Pyx_PyDict_GET_SIZE(o) PyDict_GET_SIZE(o)
  #define __Pyx_PyBytes_GET_SIZE(o) PyBytes_GET_SIZE(o)
  #define __Pyx_PyByteArray_GET_SIZE(o) PyByteArray_GET_SIZE(o)
  #define __Pyx_PyUnicode_GET_LENGTH(o) PyUnicode_GET_LENGTH(o)
#else
  #define __Pyx_PyTuple_GET_SIZE(o) PyTuple_Size(o)
  #define __Pyx_PyList_GET_SIZE(o) PyList_Size(o)
  #define __Pyx_PySet_GET_SIZE(o) PySet_Size(o)
  #define __Pyx_PyDict_GET_SIZE(o) PyDict_Size(o)
  #define __Pyx_PyBytes_GET_SIZE(o) PyBytes_Size(o)
  #define __Pyx_PyByteArray_GET_SIZE(o) PyByteArray_Size(o)
  #define __Pyx_PyUnicode_GET_LENGTH(o) PyUnicode_GetLength(o)
#endif
#if CYTHON_COMPILING_IN_PYPY && !defined(PyUnicode_InternFromString)
  #define PyUnicode_InternFromString(s) PyUnicode_FromString(s)
#endif
#define __Pyx_PyLong_FromHash_t PyLong_FromSsize_t
#define __Pyx_PyLong_AsHash_t   __Pyx_PyIndex_AsSsize_t
#if __PYX_LIMITED_VERSION_HEX >= 0x030A0000
    #define __Pyx_PySendResult PySendResult
#else
    typedef enum {
        PYGEN_RETURN = 0,
        PYGEN_ERROR = -1,
        PYGEN_NEXT = 1,
    } __Pyx_PySendResult;
#endif
#if CYTHON_COMPILING_IN_LIMITED_API || PY_VERSION_HEX < 0x030A00A3
  typedef __Pyx_PySendResult (*__Pyx_pyiter_sendfunc)(PyObject *iter, PyObject *value, PyObject **result);
#else
  #define __Pyx_pyiter_sendfunc sendfunc
#endif
#if !CYTHON_USE_AM_SEND
#define __PYX_HAS_PY_AM_SEND 0
#elif __PYX_LIMITED_VERSION_HEX >= 0x030A0000
#define __PYX_HAS_PY_AM_SEND 1
#else
#define __PYX_HAS_PY_AM_SEND 2  // our own backported implementation
#endif
#if __PYX_HAS_PY_AM_SEND < 2
    #define __Pyx_PyAsyncMethodsStruct PyAsyncMethods
#else
    typedef struct {
        unaryfunc am_await;
        unaryfunc am_aiter;
        unaryfunc am_anext;
        __Pyx_pyiter_sendfunc am_send;
    } __Pyx_PyAsyncMethodsStruct;
    #define __Pyx_SlotTpAsAsync(s) ((PyAsyncMethods*)(s))
#endif
#if CYTHON_USE_AM_SEND && PY_VERSION_HEX < 0x030A00F0
    #define __Pyx_TPFLAGS_HAVE_AM_SEND (1UL << 21)
#else
    #define __Pyx_TPFLAGS_HAVE_AM_SEND (0)
#endif
#if CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX < 0x030A0000
#ifdef __cplusplus
extern "C"
#endif
PyAPI_FUNC(void *) PyMem_Calloc(size_t nelem, size_t elsize);
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
static int __Pyx_init_co_variable(PyObject *inspect, const char* name, int *write_to) {
    int value;
    PyObject *py_value = PyObject_GetAttrString(inspect, name);
    if (!py_value) return 0;
    value = (int) PyLong_AsLong(py_value);
    Py_DECREF(py_value);
    *write_to = value;
    return value != -1 || !PyErr_Occurred();
}
static int __Pyx_init_co_variables(void) {
    PyObject *inspect;
    int result;
    inspect = PyImport_ImportModule("inspect");
    result =
#if !defined(CO_OPTIMIZED)
        __Pyx_init_co_variable(inspect, "CO_OPTIMIZED", &CO_OPTIMIZED) &&
#endif
#if !defined(CO_NEWLOCALS)
        __Pyx_init_co_variable(inspect, "CO_NEWLOCALS", &CO_NEWLOCALS) &&
#endif
#if !defined(CO_VARARGS)
        __Pyx_init_co_variable(inspect, "CO_VARARGS", &CO_VARARGS) &&
#endif
#if !defined(CO_VARKEYWORDS)
        __Pyx_init_co_variable(inspect, "CO_VARKEYWORDS", &CO_VARKEYWORDS) &&
#endif
#if !defined(CO_ASYNC_GENERATOR)
        __Pyx_init_co_variable(inspect, "CO_ASYNC_GENERATOR", &CO_ASYNC_GENERATOR) &&
#endif
#if !defined(CO_GENERATOR)
        __Pyx_init_co_variable(inspect, "CO_GENERATOR", &CO_GENERATOR) &&
#endif
#if !defined(CO_COROUTINE)
        __Pyx_init_co_variable(inspect, "CO_COROUTINE", &CO_COROUTINE) &&
#endif
        1;
    Py_DECREF(inspect);
    return result ? 0 : -1;
}
static int __Pyx_init_tpflags_bitcount(unsigned long flag) {
    int count = 0;
    while (flag) {
        count += (int) (flag & 1);
        flag >>= 1;
    }
    return count;
}
static int __Pyx_init_tpflags_variables(void) {
    if (__Pyx_Runtime_TPFLAGS_SEQUENCE != 0 && __Pyx_Runtime_TPFLAGS_MAPPING != 0) {
        return 0;
    }
    PyObject *collections_abc = PyImport_ImportModule("collections.abc");
    if (!collections_abc) return -1;
    int result = 0;
    PyObject *sequence = NULL, *mapping = NULL;
#if __PYX_LIMITED_VERSION_HEX >= 0x030D0000
    if (PyObject_GetOptionalAttrString(collections_abc, "Sequence", &sequence) != 1) goto fail;
    if (PyObject_GetOptionalAttrString(collections_abc, "Mapping", &mapping) != 1) goto fail;
#else
    sequence = PyObject_GetAttrString(collections_abc, "Sequence");
    if (!sequence) goto fail_attr_lookup;
    mapping = PyObject_GetAttrString(collections_abc, "Mapping");
    if (!mapping) goto fail_attr_lookup;
#endif
    if (!PyType_Check(sequence) || !PyType_Check(mapping)) goto fail;
    {
        unsigned long sequence_flags = PyType_GetFlags((PyTypeObject*)sequence);
        unsigned long mapping_flags = PyType_GetFlags((PyTypeObject*)mapping);
        unsigned long mutual_flags = sequence_flags & mapping_flags;
        sequence_flags = sequence_flags ^ mutual_flags;
        mapping_flags = mapping_flags ^ mutual_flags;
        if (__Pyx_Runtime_TPFLAGS_SEQUENCE == 0 && __Pyx_init_tpflags_bitcount(sequence_flags) == 1) {
            __Pyx_Runtime_TPFLAGS_SEQUENCE = sequence_flags;
        }
        if (__Pyx_Runtime_TPFLAGS_MAPPING == 0 && __Pyx_init_tpflags_bitcount(mapping_flags) == 1) {
            __Pyx_Runtime_TPFLAGS_MAPPING = mapping_flags;
        }
    }
    cleanup:
    Py_XDECREF(mapping);
    Py_XDECREF(sequence);
    Py_DECREF(collections_abc);
    return result;
#if __PYX_LIMITED_VERSION_HEX < 0x030D0000
    fail_attr_lookup:
    if (PyErr_ExceptionMatches(PyExc_AttributeError)) {
        PyErr_Clear();
    }
#endif
    fail:
    result = PyErr_Occurred() ? -1 : 0;
    goto cleanup;
}
#else
static int __Pyx_init_co_variables(void) {
    return 0;  // It's a limited API-only feature
}
static int __Pyx_init_tpflags_variables(void) {
    return 0;  // It's a limited API-only feature
}
#endif


#if defined(_WIN32) || defined(WIN32) || defined(MS_WINDOWS)
  #ifndef _USE_MATH_DEFINES
    #define _USE_MATH_DEFINES
  #endif
#endif
#include <math.h>
#if defined(__CYGWIN__) && defined(_LDBL_EQ_DBL)
#define __Pyx_truncl trunc
#else
#define __Pyx_truncl truncl
#endif

#ifndef CYTHON_CLINE_IN_TRACEBACK_RUNTIME
#define CYTHON_CLINE_IN_TRACEBACK_RUNTIME 0
#endif
#ifndef CYTHON_CLINE_IN_TRACEBACK
#define CYTHON_CLINE_IN_TRACEBACK CYTHON_CLINE_IN_TRACEBACK_RUNTIME
#endif
#if CYTHON_CLINE_IN_TRACEBACK
#define __PYX_MARK_ERR_POS(f_index, lineno)  { __pyx_filename = __pyx_f[f_index]; (void) __pyx_filename; __pyx_lineno = lineno; (void) __pyx_lineno; __pyx_clineno = __LINE__; (void) __pyx_clineno; }
#else
#define __PYX_MARK_ERR_POS(f_index, lineno)  { __pyx_filename = __pyx_f[f_index]; (void) __pyx_filename; __pyx_lineno = lineno; (void) __pyx_lineno; (void) __pyx_clineno; }
#endif
#define __PYX_ERR(f_index, lineno, Ln_error) \
    { __PYX_MARK_ERR_POS(f_index, lineno) goto Ln_error; }

#ifdef CYTHON_EXTERN_C
    #undef __PYX_EXTERN_C
    #define __PYX_EXTERN_C CYTHON_EXTERN_C
#elif defined(__PYX_EXTERN_C)
    #ifdef _MSC_VER
    #pragma message ("Please do not define the '__PYX_EXTERN_C' macro externally. Use 'CYTHON_EXTERN_C' instead.")
    #else
    #warning Please do not define the '__PYX_EXTERN_C' macro externally. Use 'CYTHON_EXTERN_C' instead.
    #endif
#else
  #ifdef __cplusplus
    #define __PYX_EXTERN_C extern "C"
  #else
    #define __PYX_EXTERN_C extern
  #endif
#endif

#define __PYX_HAVE__cloze__template_docx
#define __PYX_HAVE_API__cloze__template_docx

#ifdef _OPENMP
#include <omp.h>
#endif 

#if defined(PYREX_WITHOUT_ASSERTIONS) && !defined(CYTHON_WITHOUT_ASSERTIONS)
#define CYTHON_WITHOUT_ASSERTIONS
#endif

#ifdef CYTHON_FREETHREADING_COMPATIBLE
#if CYTHON_FREETHREADING_COMPATIBLE
#define __Pyx_FREETHREADING_COMPATIBLE Py_MOD_GIL_NOT_USED
#else
#define __Pyx_FREETHREADING_COMPATIBLE Py_MOD_GIL_USED
#endif
#else
#define __Pyx_FREETHREADING_COMPATIBLE Py_MOD_GIL_USED
#endif
#define __PYX_DEFAULT_STRING_ENCODING_IS_ASCII 0
#define __PYX_DEFAULT_STRING_ENCODING_IS_UTF8 0
#define __PYX_DEFAULT_STRING_ENCODING ""
#define __Pyx_PyObject_FromString __Pyx_PyBytes_FromString
#define __Pyx_PyObject_FromStringAndSize __Pyx_PyBytes_FromStringAndSize
#define __Pyx_uchar_cast(c) ((unsigned char)c)
#define __Pyx_long_cast(x) ((long)x)
#define __Pyx_fits_Py_ssize_t(v, type, is_signed)  (\
    (sizeof(type) < sizeof(Py_ssize_t))  ||\
    (sizeof(type) > sizeof(Py_ssize_t) &&\
          likely(v < (type)PY_SSIZE_T_MAX ||\
                 v == (type)PY_SSIZE_T_MAX)  &&\
          (!is_signed || likely(v > (type)PY_SSIZE_T_MIN ||\
                                v == (type)PY_SSIZE_T_MIN)))  ||\
    (sizeof(type) == sizeof(Py_ssize_t) &&\
          (is_signed || likely(v < (type)PY_SSIZE_T_MAX ||\
                               v == (type)PY_SSIZE_T_MAX)))  )
static CYTHON_INLINE int __Pyx_is_valid_index(Py_ssize_t i, Py_ssize_t limit) {
    return (size_t) i < (size_t) limit;
}
#if defined (__cplusplus) && __cplusplus >= 201103L
    #include <cstdlib>
    #define __Pyx_sst_abs(value) std::abs(value)
#elif SIZEOF_INT >= SIZEOF_SIZE_T
    #define __Pyx_sst_abs(value) abs(value)
#elif SIZEOF_LONG >= SIZEOF_SIZE_T
    #define __Pyx_sst_abs(value) labs(value)
#elif defined (_MSC_VER)
    #define __Pyx_sst_abs(value) ((Py_ssize_t)_abs64(value))
#elif defined (__STDC_VERSION__) && __STDC_VERSION__ >= 199901L
    #define __Pyx_sst_abs(value) llabs(value)
#elif defined (__GNUC__)
    #define __Pyx_sst_abs(value) __builtin_llabs(value)
#else
    #define __Pyx_sst_abs(value) ((value<0) ? -value : value)
#endif
static CYTHON_INLINE Py_ssize_t __Pyx_ssize_strlen(const char *s);
static CYTHON_INLINE const char* __Pyx_PyObject_AsString(PyObject*);
static CYTHON_INLINE const char* __Pyx_PyObject_AsStringAndSize(PyObject*, Py_ssize_t* length);
static CYTHON_INLINE PyObject* __Pyx_PyByteArray_FromString(const char*);
#define __Pyx_PyByteArray_FromStringAndSize(s, l) PyByteArray_FromStringAndSize((const char*)s, l)
#define __Pyx_PyBytes_FromString        PyBytes_FromString
#define __Pyx_PyBytes_FromStringAndSize PyBytes_FromStringAndSize
static CYTHON_INLINE PyObject* __Pyx_PyUnicode_FromString(const char*);
#if CYTHON_ASSUME_SAFE_MACROS
    #define __Pyx_PyBytes_AsWritableString(s)     ((char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsWritableSString(s)    ((signed char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsWritableUString(s)    ((unsigned char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsString(s)     ((const char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsSString(s)    ((const signed char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyBytes_AsUString(s)    ((const unsigned char*) PyBytes_AS_STRING(s))
    #define __Pyx_PyByteArray_AsString(s) PyByteArray_AS_STRING(s)
#else
    #define __Pyx_PyBytes_AsWritableString(s)     ((char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsWritableSString(s)    ((signed char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsWritableUString(s)    ((unsigned char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsString(s)     ((const char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsSString(s)    ((const signed char*) PyBytes_AsString(s))
    #define __Pyx_PyBytes_AsUString(s)    ((const unsigned char*) PyBytes_AsString(s))
    #define __Pyx_PyByteArray_AsString(s) PyByteArray_AsString(s)
#endif
#define __Pyx_PyObject_AsWritableString(s)    ((char*)(__pyx_uintptr_t) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_AsWritableSString(s)    ((signed char*)(__pyx_uintptr_t) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_AsWritableUString(s)    ((unsigned char*)(__pyx_uintptr_t) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_AsSString(s)    ((const signed char*) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_AsUString(s)    ((const unsigned char*) __Pyx_PyObject_AsString(s))
#define __Pyx_PyObject_FromCString(s)  __Pyx_PyObject_FromString((const char*)s)
#define __Pyx_PyBytes_FromCString(s)   __Pyx_PyBytes_FromString((const char*)s)
#define __Pyx_PyByteArray_FromCString(s)   __Pyx_PyByteArray_FromString((const char*)s)
#define __Pyx_PyUnicode_FromCString(s) __Pyx_PyUnicode_FromString((const char*)s)
#define __Pyx_PyUnicode_FromOrdinal(o)       PyUnicode_FromOrdinal((int)o)
#define __Pyx_PyUnicode_AsUnicode            PyUnicode_AsUnicode
static CYTHON_INLINE PyObject *__Pyx_NewRef(PyObject *obj) {
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030a0000 || defined(Py_NewRef)
    return Py_NewRef(obj);
#else
    Py_INCREF(obj);
    return obj;
#endif
}
static CYTHON_INLINE PyObject *__Pyx_XNewRef(PyObject *obj) {
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030a0000 || defined(Py_XNewRef)
    return Py_XNewRef(obj);
#else
    Py_XINCREF(obj);
    return obj;
#endif
}
static CYTHON_INLINE PyObject *__Pyx_Owned_Py_None(int b);
static CYTHON_INLINE PyObject * __Pyx_PyBool_FromLong(long b);
static CYTHON_INLINE int __Pyx_PyObject_IsTrue(PyObject*);
static CYTHON_INLINE int __Pyx_PyObject_IsTrueAndDecref(PyObject*);
static CYTHON_INLINE PyObject* __Pyx_PyNumber_Long(PyObject* x);
#define __Pyx_PyObject_RichCompareBool(a,b,cmp)  __Pyx_PyObject_IsTrueAndDecref(PyObject_RichCompare((a),(b),(cmp)))
#define __Pyx_PySequence_Tuple(obj)\
    (likely(PyTuple_CheckExact(obj)) ? __Pyx_NewRef(obj) : PySequence_Tuple(obj))
static CYTHON_INLINE Py_ssize_t __Pyx_PyIndex_AsSsize_t(PyObject*);
static CYTHON_INLINE PyObject * __Pyx_PyLong_FromSize_t(size_t);
static CYTHON_INLINE Py_hash_t __Pyx_PyIndex_AsHash_t(PyObject*);
#if CYTHON_ASSUME_SAFE_MACROS
#define __Pyx_PyFloat_AsDouble(x) (PyFloat_CheckExact(x) ? PyFloat_AS_DOUBLE(x) : PyFloat_AsDouble(x))
#define __Pyx_PyFloat_AS_DOUBLE(x) PyFloat_AS_DOUBLE(x)
#define __Pyx_PyFloat_IsNonZero(x) (PyFloat_AS_DOUBLE(x) != 0.0)
#else
#define __Pyx_PyFloat_AsDouble(x) PyFloat_AsDouble(x)
#define __Pyx_PyFloat_AS_DOUBLE(x) PyFloat_AsDouble(x)
#define __Pyx_PyFloat_IsNonZero(x) PyObject_IsTrue(x)
#endif
#define __Pyx_PyFloat_AsFloat(x) ((float) __Pyx_PyFloat_AsDouble(x))
#define __Pyx_PyNumber_Int(x) (PyLong_CheckExact(x) ? __Pyx_NewRef(x) : PyNumber_Long(x))
#if CYTHON_USE_PYLONG_INTERNALS
  #if PY_VERSION_HEX >= 0x030C00A7
  #ifndef _PyLong_SIGN_MASK
    #define _PyLong_SIGN_MASK 3
  #endif
  #ifndef _PyLong_NON_SIZE_BITS
    #define _PyLong_NON_SIZE_BITS 3
  #endif
  #define __Pyx_PyLong_SignBits(x)  ((int) (((PyLongObject*)x)->long_value.lv_tag & _PyLong_SIGN_MASK))
  #define __Pyx_PyLong_Sign(x)  (1 - __Pyx_PyLong_SignBits(x))
  #define __Pyx_PyLong_IsNeg(x)  ((__Pyx_PyLong_SignBits(x) & 2) != 0)
  #define __Pyx_PyLong_IsNonNeg(x)  (!__Pyx_PyLong_IsNeg(x))
  #define __Pyx_PyLong_IsZero(x)  (__Pyx_PyLong_SignBits(x) & 1)
  #define __Pyx_PyLong_IsPos(x)  (__Pyx_PyLong_SignBits(x) == 0)
  #define __Pyx_PyLong_CompactValueUnsigned(x)  (__Pyx_PyLong_Digits(x)[0])
  #define __Pyx_PyLong_DigitCount(x)  ((Py_ssize_t) (((PyLongObject*)x)->long_value.lv_tag >> _PyLong_NON_SIZE_BITS))
  #define __Pyx_PyLong_SignedDigitCount(x)\
        (((Py_ssize_t) __Pyx_PyLong_Sign(x)) * __Pyx_PyLong_DigitCount(x))
  #if defined(PyUnstable_Long_IsCompact) && defined(PyUnstable_Long_CompactValue)
    #define __Pyx_PyLong_IsCompact(x)     PyUnstable_Long_IsCompact((PyLongObject*) x)
    #define __Pyx_PyLong_CompactValue(x)  PyUnstable_Long_CompactValue((PyLongObject*) x)
  #else
    #define __Pyx_PyLong_IsCompact(x)     (((PyLongObject*)x)->long_value.lv_tag < (2 << _PyLong_NON_SIZE_BITS))
    #define __Pyx_PyLong_CompactValue(x)  (((Py_ssize_t) __Pyx_PyLong_Sign(x)) * (Py_ssize_t) __Pyx_PyLong_Digits(x)[0])
  #endif
  static CYTHON_INLINE Py_ssize_t __Pyx_PyLong_CompareSignAndSize(PyObject *a, PyObject *b) {
      uintptr_t tag_a = ((PyLongObject*)a)->long_value.lv_tag;
      uintptr_t tag_b = ((PyLongObject*)b)->long_value.lv_tag;
      if (tag_a == tag_b) return 0;
      int sign_a = (int) (tag_a & _PyLong_SIGN_MASK);
      int sign_b = (int) (tag_b & _PyLong_SIGN_MASK);
      if (sign_a > sign_b) return -1;
      if (sign_a < sign_b) return 1;
      Py_ssize_t size_a = (Py_ssize_t) (tag_a >> _PyLong_NON_SIZE_BITS);
      Py_ssize_t size_b = (Py_ssize_t) (tag_b >> _PyLong_NON_SIZE_BITS);
      return (1 - sign_a) * (size_a - size_b);
  }
  typedef Py_ssize_t  __Pyx_compact_pylong;
  typedef size_t  __Pyx_compact_upylong;
  #else
  #define __Pyx_PyLong_Sign(x)  ((int) ((Py_SIZE(x) == 0) ? 0 : (Py_SIZE(x) < 0) ? -1 : 1))
  #define __Pyx_PyLong_IsNeg(x)  (Py_SIZE(x) < 0)
  #define __Pyx_PyLong_IsNonNeg(x)  (Py_SIZE(x) >= 0)
  #define __Pyx_PyLong_IsZero(x)  (Py_SIZE(x) == 0)
  #define __Pyx_PyLong_IsPos(x)  (Py_SIZE(x) > 0)
  #define __Pyx_PyLong_CompactValueUnsigned(x)  ((Py_SIZE(x) == 0) ? 0 : __Pyx_PyLong_Digits(x)[0])
  #define __Pyx_PyLong_DigitCount(x)  __Pyx_sst_abs(Py_SIZE(x))
  #define __Pyx_PyLong_SignedDigitCount(x)  Py_SIZE(x)
  #define __Pyx_PyLong_IsCompact(x)  (Py_SIZE(x) == 0 || Py_SIZE(x) == 1 || Py_SIZE(x) == -1)
  #define __Pyx_PyLong_CompactValue(x)\
        ((Py_SIZE(x) == 0) ? (sdigit) 0 : ((Py_SIZE(x) < 0) ? -(sdigit)__Pyx_PyLong_Digits(x)[0] : (sdigit)__Pyx_PyLong_Digits(x)[0]))
  #define __Pyx_PyLong_CompareSignAndSize(a, b)  (Py_SIZE(a) - Py_SIZE(b))
  typedef sdigit  __Pyx_compact_pylong;
  typedef digit  __Pyx_compact_upylong;
  #endif
  #if PY_VERSION_HEX >= 0x030C00A5
  #define __Pyx_PyLong_Digits(x)  (((PyLongObject*)x)->long_value.ob_digit)
  #else
  #define __Pyx_PyLong_Digits(x)  (((PyLongObject*)x)->ob_digit)
  #endif
  #define __Pyx_PyLong_IsNonZero(x)  (!__Pyx_PyLong_IsZero(x))
#else
  #define __Pyx_PyLong_IsNonZero(x)  PyObject_IsTrue(x)
#endif
#if __PYX_DEFAULT_STRING_ENCODING_IS_UTF8
  #define __Pyx_PyUnicode_FromStringAndSize(c_str, size) PyUnicode_DecodeUTF8(c_str, size, NULL)
#elif __PYX_DEFAULT_STRING_ENCODING_IS_ASCII
  #define __Pyx_PyUnicode_FromStringAndSize(c_str, size) PyUnicode_DecodeASCII(c_str, size, NULL)
#else
  #define __Pyx_PyUnicode_FromStringAndSize(c_str, size) PyUnicode_Decode(c_str, size, __PYX_DEFAULT_STRING_ENCODING, NULL)
#endif



#if defined(__GNUC__)     && (__GNUC__ > 2 || (__GNUC__ == 2 && (__GNUC_MINOR__ > 95)))
  #define likely(x)   __builtin_expect(!!(x), 1)
  #define unlikely(x) __builtin_expect(!!(x), 0)
#else 
  #define likely(x)   (x)
  #define unlikely(x) (x)
#endif 

#ifdef __cplusplus
#if __cplusplus > 201103L
#include <type_traits>
#endif
template <typename T>
static void __Pyx_pretend_to_initialize(T* ptr) {
#if __cplusplus > 201103L
    if ((std::is_trivially_default_constructible<T>::value))
#endif
        *ptr = T();
    (void)ptr;
}
#else
static CYTHON_INLINE void __Pyx_pretend_to_initialize(void* ptr) { (void)ptr; }
#endif


#if !CYTHON_USE_MODULE_STATE
static PyObject *__pyx_m = NULL;
#endif
static const char * const __pyx_cfilenm = __FILE__;



static const char* const __pyx_f[] = {
  "cloze/template_docx.py",
};


#include <pythread.h>
#ifndef CYTHON_ATOMICS
    #define CYTHON_ATOMICS 1
#endif
#define __PYX_CYTHON_ATOMICS_ENABLED() CYTHON_ATOMICS
#define __PYX_GET_CYTHON_COMPILING_IN_CPYTHON_FREETHREADING() CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
#define __pyx_atomic_int_type int
#define __pyx_nonatomic_int_type int
#if CYTHON_ATOMICS && (defined(__STDC_VERSION__) &&\
                        (__STDC_VERSION__ >= 201112L) &&\
                        !defined(__STDC_NO_ATOMICS__))
    #include <stdatomic.h>
#elif CYTHON_ATOMICS && (defined(__cplusplus) && (\
                    (__cplusplus >= 201103L) ||\
                    (defined(_MSC_VER) && _MSC_VER >= 1700)))
    #include <atomic>
#endif
#if CYTHON_ATOMICS && (defined(__STDC_VERSION__) &&\
                        (__STDC_VERSION__ >= 201112L) &&\
                        !defined(__STDC_NO_ATOMICS__) &&\
                       ATOMIC_INT_LOCK_FREE == 2)
    #undef __pyx_atomic_int_type
    #define __pyx_atomic_int_type atomic_int
    #define __pyx_atomic_ptr_type atomic_uintptr_t
    #define __pyx_nonatomic_ptr_type uintptr_t
    #define __pyx_atomic_incr_relaxed(value) atomic_fetch_add_explicit(value, 1, memory_order_relaxed)
    #define __pyx_atomic_incr_acq_rel(value) atomic_fetch_add_explicit(value, 1, memory_order_acq_rel)
    #define __pyx_atomic_decr_acq_rel(value) atomic_fetch_sub_explicit(value, 1, memory_order_acq_rel)
    #define __pyx_atomic_sub(value, arg) atomic_fetch_sub(value, arg)
    #define __pyx_atomic_int_cmp_exchange(value, expected, desired) atomic_compare_exchange_strong(value, expected, desired)
    #define __pyx_atomic_load(value) atomic_load(value)
    #define __pyx_atomic_store(value, new_value) atomic_store(value, new_value)
    #define __pyx_atomic_pointer_load_relaxed(value) atomic_load_explicit(value, memory_order_relaxed)
    #define __pyx_atomic_pointer_load_acquire(value) atomic_load_explicit(value, memory_order_acquire)
    #define __pyx_atomic_pointer_exchange(value, new_value) atomic_exchange(value, (__pyx_nonatomic_ptr_type)new_value)
    #define __pyx_atomic_pointer_cmp_exchange(value, expected, desired) atomic_compare_exchange_strong(value, expected, desired)
    #if defined(__PYX_DEBUG_ATOMICS) && defined(_MSC_VER)
        #pragma message ("Using standard C atomics")
    #elif defined(__PYX_DEBUG_ATOMICS)
        #warning "Using standard C atomics"
    #endif
#elif CYTHON_ATOMICS && (defined(__cplusplus) && (\
                    (__cplusplus >= 201103L) ||\
\
                    (defined(_MSC_VER) && _MSC_VER >= 1700)) &&\
                    ATOMIC_INT_LOCK_FREE == 2)
    #undef __pyx_atomic_int_type
    #define __pyx_atomic_int_type std::atomic_int
    #define __pyx_atomic_ptr_type std::atomic_uintptr_t
    #define __pyx_nonatomic_ptr_type uintptr_t
    #define __pyx_atomic_incr_relaxed(value) std::atomic_fetch_add_explicit(value, 1, std::memory_order_relaxed)
    #define __pyx_atomic_incr_acq_rel(value) std::atomic_fetch_add_explicit(value, 1, std::memory_order_acq_rel)
    #define __pyx_atomic_decr_acq_rel(value) std::atomic_fetch_sub_explicit(value, 1, std::memory_order_acq_rel)
    #define __pyx_atomic_sub(value, arg) std::atomic_fetch_sub(value, arg)
    #define __pyx_atomic_int_cmp_exchange(value, expected, desired) std::atomic_compare_exchange_strong(value, expected, desired)
    #define __pyx_atomic_load(value) std::atomic_load(value)
    #define __pyx_atomic_store(value, new_value) std::atomic_store(value, new_value)
    #define __pyx_atomic_pointer_load_relaxed(value) std::atomic_load_explicit(value, std::memory_order_relaxed)
    #define __pyx_atomic_pointer_load_acquire(value) std::atomic_load_explicit(value, std::memory_order_acquire)
    #define __pyx_atomic_pointer_exchange(value, new_value) std::atomic_exchange(value, (__pyx_nonatomic_ptr_type)new_value)
    #define __pyx_atomic_pointer_cmp_exchange(value, expected, desired) std::atomic_compare_exchange_strong(value, expected, desired)
    #if defined(__PYX_DEBUG_ATOMICS) && defined(_MSC_VER)
        #pragma message ("Using standard C++ atomics")
    #elif defined(__PYX_DEBUG_ATOMICS)
        #warning "Using standard C++ atomics"
    #endif
#elif CYTHON_ATOMICS && (__GNUC__ >= 5 || (__GNUC__ == 4 &&\
                    (__GNUC_MINOR__ > 1 ||\
                    (__GNUC_MINOR__ == 1 && __GNUC_PATCHLEVEL__ >= 2))))
    #define __pyx_atomic_ptr_type void*
    #define __pyx_nonatomic_ptr_type void*
    #define __pyx_atomic_incr_relaxed(value) __sync_fetch_and_add(value, 1)
    #define __pyx_atomic_incr_acq_rel(value) __sync_fetch_and_add(value, 1)
    #define __pyx_atomic_decr_acq_rel(value) __sync_fetch_and_sub(value, 1)
    #define __pyx_atomic_sub(value, arg) __sync_fetch_and_sub(value, arg)
    static CYTHON_INLINE int __pyx_atomic_int_cmp_exchange(__pyx_atomic_int_type* value, __pyx_nonatomic_int_type* expected, __pyx_nonatomic_int_type desired) {
        __pyx_nonatomic_int_type old = __sync_val_compare_and_swap(value, *expected, desired);
        int result = old == *expected;
        *expected = old;
        return result;
    }
    #define __pyx_atomic_load(value) __sync_fetch_and_add(value, 0)
    #define __pyx_atomic_store(value, new_value) __sync_lock_test_and_set(value, new_value)
    #define __pyx_atomic_pointer_load_relaxed(value) __sync_fetch_and_add(value, 0)
    #define __pyx_atomic_pointer_load_acquire(value) __sync_fetch_and_add(value, 0)
    #define __pyx_atomic_pointer_exchange(value, new_value) __sync_lock_test_and_set(value, (__pyx_atomic_ptr_type)new_value)
    static CYTHON_INLINE int __pyx_atomic_pointer_cmp_exchange(__pyx_atomic_ptr_type* value, __pyx_nonatomic_ptr_type* expected, __pyx_nonatomic_ptr_type desired) {
        __pyx_nonatomic_ptr_type old = __sync_val_compare_and_swap(value, *expected, desired);
        int result = old == *expected;
        *expected = old;
        return result;
    }
    #ifdef __PYX_DEBUG_ATOMICS
        #warning "Using GNU atomics"
    #endif
#elif CYTHON_ATOMICS && defined(_MSC_VER)
    #include <intrin.h>
    #undef __pyx_atomic_int_type
    #define __pyx_atomic_int_type long
    #define __pyx_atomic_ptr_type void*
    #undef __pyx_nonatomic_int_type
    #define __pyx_nonatomic_int_type long
    #define __pyx_nonatomic_ptr_type void*
    #pragma intrinsic (_InterlockedExchangeAdd, _InterlockedExchange, _InterlockedCompareExchange, _InterlockedCompareExchangePointer, _InterlockedExchangePointer)
    #define __pyx_atomic_incr_relaxed(value) _InterlockedExchangeAdd(value, 1)
    #define __pyx_atomic_incr_acq_rel(value) _InterlockedExchangeAdd(value, 1)
    #define __pyx_atomic_decr_acq_rel(value) _InterlockedExchangeAdd(value, -1)
    #define __pyx_atomic_sub(value, arg) _InterlockedExchangeAdd(value, -arg)
    static CYTHON_INLINE int __pyx_atomic_int_cmp_exchange(__pyx_atomic_int_type* value, __pyx_nonatomic_int_type* expected, __pyx_nonatomic_int_type desired) {
        __pyx_nonatomic_int_type old = _InterlockedCompareExchange(value, desired, *expected);
        int result = old == *expected;
        *expected = old;
        return result;
    }
    #define __pyx_atomic_load(value) _InterlockedExchangeAdd(value, 0)
    #define __pyx_atomic_store(value, new_value) _InterlockedExchange(value, new_value)
    #define __pyx_atomic_pointer_load_relaxed(value) *(void * volatile *)value
    #define __pyx_atomic_pointer_load_acquire(value) _InterlockedCompareExchangePointer(value, 0, 0)
    #define __pyx_atomic_pointer_exchange(value, new_value) _InterlockedExchangePointer(value, (__pyx_atomic_ptr_type)new_value)
    static CYTHON_INLINE int __pyx_atomic_pointer_cmp_exchange(__pyx_atomic_ptr_type* value, __pyx_nonatomic_ptr_type* expected, __pyx_nonatomic_ptr_type desired) {
        __pyx_atomic_ptr_type old = _InterlockedCompareExchangePointer(value, desired, *expected);
        int result = old == *expected;
        *expected = old;
        return result;
    }
    #ifdef __PYX_DEBUG_ATOMICS
        #pragma message ("Using MSVC atomics")
    #endif
#else
    #undef CYTHON_ATOMICS
    #define CYTHON_ATOMICS 0
    #ifdef __PYX_DEBUG_ATOMICS
        #warning "Not using atomics"
    #endif
#endif


#if !CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
#define __Pyx_PyCriticalSection void*
#define __Pyx_PyCriticalSection2 void*
#define __Pyx_PyCriticalSection_End(cs)
#define __Pyx_PyCriticalSection2_End(cs)
#else
#define __Pyx_PyCriticalSection PyCriticalSection
#define __Pyx_PyCriticalSection2 PyCriticalSection2
#define __Pyx_PyCriticalSection_End PyCriticalSection_End
#define __Pyx_PyCriticalSection2_End PyCriticalSection2_End
#endif


#if !CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
#define __Pyx_PyCriticalSection_Begin(cs, arg) (void)(cs)
#define __Pyx_PyCriticalSection2_Begin(cs, arg1, arg2) (void)(cs)
#else
#define __Pyx_PyCriticalSection_Begin PyCriticalSection_Begin
#define __Pyx_PyCriticalSection2_Begin PyCriticalSection2_Begin
#endif
#if PY_VERSION_HEX < 0x030d0000 || CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_BEGIN_CRITICAL_SECTION(o) {
#define __Pyx_END_CRITICAL_SECTION() }
#else
#define __Pyx_BEGIN_CRITICAL_SECTION Py_BEGIN_CRITICAL_SECTION
#define __Pyx_END_CRITICAL_SECTION Py_END_CRITICAL_SECTION
#endif


#include <structmember.h>






struct __pyx_defaults;


struct __pyx_defaults {
  PyObject_HEAD
  PyObject *arg0;
};





#ifndef CYTHON_REFNANNY
  #define CYTHON_REFNANNY 0
#endif
#if CYTHON_REFNANNY
  typedef struct {
    void (*INCREF)(void*, PyObject*, Py_ssize_t);
    void (*DECREF)(void*, PyObject*, Py_ssize_t);
    void (*GOTREF)(void*, PyObject*, Py_ssize_t);
    void (*GIVEREF)(void*, PyObject*, Py_ssize_t);
    void* (*SetupContext)(const char*, Py_ssize_t, const char*);
    void (*FinishContext)(void**);
  } __Pyx_RefNannyAPIStruct;
  static __Pyx_RefNannyAPIStruct *__Pyx_RefNanny = NULL;
  static __Pyx_RefNannyAPIStruct *__Pyx_RefNannyImportAPI(const char *modname);
  #define __Pyx_RefNannyDeclarations void *__pyx_refnanny = NULL;
  #define __Pyx_RefNannySetupContext(name, acquire_gil)\
          if (acquire_gil) {\
              PyGILState_STATE __pyx_gilstate_save = PyGILState_Ensure();\
              __pyx_refnanny = __Pyx_RefNanny->SetupContext((name), (__LINE__), (__FILE__));\
              PyGILState_Release(__pyx_gilstate_save);\
          } else {\
              __pyx_refnanny = __Pyx_RefNanny->SetupContext((name), (__LINE__), (__FILE__));\
          }
  #define __Pyx_RefNannyFinishContextNogil() {\
              PyGILState_STATE __pyx_gilstate_save = PyGILState_Ensure();\
              __Pyx_RefNannyFinishContext();\
              PyGILState_Release(__pyx_gilstate_save);\
          }
  #define __Pyx_RefNannyFinishContextNogil() {\
              PyGILState_STATE __pyx_gilstate_save = PyGILState_Ensure();\
              __Pyx_RefNannyFinishContext();\
              PyGILState_Release(__pyx_gilstate_save);\
          }
  #define __Pyx_RefNannyFinishContext()\
          __Pyx_RefNanny->FinishContext(&__pyx_refnanny)
  #define __Pyx_INCREF(r)  __Pyx_RefNanny->INCREF(__pyx_refnanny, (PyObject *)(r), (__LINE__))
  #define __Pyx_DECREF(r)  __Pyx_RefNanny->DECREF(__pyx_refnanny, (PyObject *)(r), (__LINE__))
  #define __Pyx_GOTREF(r)  __Pyx_RefNanny->GOTREF(__pyx_refnanny, (PyObject *)(r), (__LINE__))
  #define __Pyx_GIVEREF(r) __Pyx_RefNanny->GIVEREF(__pyx_refnanny, (PyObject *)(r), (__LINE__))
  #define __Pyx_XINCREF(r)  do { if((r) == NULL); else {__Pyx_INCREF(r); }} while(0)
  #define __Pyx_XDECREF(r)  do { if((r) == NULL); else {__Pyx_DECREF(r); }} while(0)
  #define __Pyx_XGOTREF(r)  do { if((r) == NULL); else {__Pyx_GOTREF(r); }} while(0)
  #define __Pyx_XGIVEREF(r) do { if((r) == NULL); else {__Pyx_GIVEREF(r);}} while(0)
#else
  #define __Pyx_RefNannyDeclarations
  #define __Pyx_RefNannySetupContext(name, acquire_gil)
  #define __Pyx_RefNannyFinishContextNogil()
  #define __Pyx_RefNannyFinishContext()
  #define __Pyx_INCREF(r) Py_INCREF(r)
  #define __Pyx_DECREF(r) Py_DECREF(r)
  #define __Pyx_GOTREF(r)
  #define __Pyx_GIVEREF(r)
  #define __Pyx_XINCREF(r) Py_XINCREF(r)
  #define __Pyx_XDECREF(r) Py_XDECREF(r)
  #define __Pyx_XGOTREF(r)
  #define __Pyx_XGIVEREF(r)
#endif
#define __Pyx_Py_XDECREF_SET(r, v) do {\
        PyObject *tmp = (PyObject *) r;\
        r = v; Py_XDECREF(tmp);\
    } while (0)
#define __Pyx_XDECREF_SET(r, v) do {\
        PyObject *tmp = (PyObject *) r;\
        r = v; __Pyx_XDECREF(tmp);\
    } while (0)
#define __Pyx_DECREF_SET(r, v) do {\
        PyObject *tmp = (PyObject *) r;\
        r = v; __Pyx_DECREF(tmp);\
    } while (0)
#define __Pyx_CLEAR(r)    do { PyObject* tmp = ((PyObject*)(r)); r = NULL; __Pyx_DECREF(tmp);} while(0)
#define __Pyx_XCLEAR(r)   do { if((r) != NULL) {PyObject* tmp = ((PyObject*)(r)); r = NULL; __Pyx_DECREF(tmp);}} while(0)


#if CYTHON_COMPILING_IN_CPYTHON
#define __Pyx_TypeCheck(obj, type) __Pyx_IsSubtype(Py_TYPE(obj), (PyTypeObject *)type)
#define __Pyx_TypeCheck2(obj, type1, type2) __Pyx_IsAnySubtype2(Py_TYPE(obj), (PyTypeObject *)type1, (PyTypeObject *)type2)
static CYTHON_INLINE int __Pyx_IsSubtype(PyTypeObject *a, PyTypeObject *b);
static CYTHON_INLINE int __Pyx_IsAnySubtype2(PyTypeObject *cls, PyTypeObject *a, PyTypeObject *b);
#define __Pyx_PyAnySet_Check(obj)  __Pyx_TypeCheck2(obj, &PySet_Type, &PyFrozenSet_Type)
#else
#define __Pyx_TypeCheck(obj, type) PyObject_TypeCheck(obj, (PyTypeObject *)type)
#define __Pyx_TypeCheck2(obj, type1, type2) (PyObject_TypeCheck(obj, (PyTypeObject *)type1) || PyObject_TypeCheck(obj, (PyTypeObject *)type2))
#define __Pyx_PyAnySet_Check(obj)  PyAnySet_Check(obj)
#endif


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_PyThreadState_declare  PyThreadState *__pyx_tstate;
#define __Pyx_PyThreadState_assign  __pyx_tstate = __Pyx_PyThreadState_Current;
#if PY_VERSION_HEX >= 0x030C00A6
#define __Pyx_PyErr_Occurred()  (__pyx_tstate->current_exception != NULL)
#define __Pyx_PyErr_CurrentExceptionType()  (__pyx_tstate->current_exception ? (PyObject*) Py_TYPE(__pyx_tstate->current_exception) : (PyObject*) NULL)
#else
#define __Pyx_PyErr_Occurred()  (__pyx_tstate->curexc_type != NULL)
#define __Pyx_PyErr_CurrentExceptionType()  (__pyx_tstate->curexc_type)
#endif
#else
#define __Pyx_PyThreadState_declare
#define __Pyx_PyThreadState_assign
#define __Pyx_PyErr_Occurred()  (PyErr_Occurred() != NULL)
#define __Pyx_PyErr_CurrentExceptionType()  PyErr_Occurred()
#endif


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_PyErr_Clear() __Pyx_ErrRestore(NULL, NULL, NULL)
#define __Pyx_ErrRestoreWithState(type, value, tb)  __Pyx_ErrRestoreInState(PyThreadState_GET(), type, value, tb)
#define __Pyx_ErrFetchWithState(type, value, tb)    __Pyx_ErrFetchInState(PyThreadState_GET(), type, value, tb)
#define __Pyx_ErrRestore(type, value, tb)  __Pyx_ErrRestoreInState(__pyx_tstate, type, value, tb)
#define __Pyx_ErrFetch(type, value, tb)    __Pyx_ErrFetchInState(__pyx_tstate, type, value, tb)
static CYTHON_INLINE void __Pyx_ErrRestoreInState(PyThreadState *tstate, PyObject *type, PyObject *value, PyObject *tb);
static CYTHON_INLINE void __Pyx_ErrFetchInState(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb);
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX < 0x030C00A6
#define __Pyx_PyErr_SetNone(exc) (Py_INCREF(exc), __Pyx_ErrRestore((exc), NULL, NULL))
#else
#define __Pyx_PyErr_SetNone(exc) PyErr_SetNone(exc)
#endif
#else
#define __Pyx_PyErr_Clear() PyErr_Clear()
#define __Pyx_PyErr_SetNone(exc) PyErr_SetNone(exc)
#define __Pyx_ErrRestoreWithState(type, value, tb)  PyErr_Restore(type, value, tb)
#define __Pyx_ErrFetchWithState(type, value, tb)  PyErr_Fetch(type, value, tb)
#define __Pyx_ErrRestoreInState(tstate, type, value, tb)  PyErr_Restore(type, value, tb)
#define __Pyx_ErrFetchInState(tstate, type, value, tb)  PyErr_Fetch(type, value, tb)
#define __Pyx_ErrRestore(type, value, tb)  PyErr_Restore(type, value, tb)
#define __Pyx_ErrFetch(type, value, tb)  PyErr_Fetch(type, value, tb)
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches(PyObject *err, PyObject *type);
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches2(PyObject *err, PyObject *type1, PyObject *type2);
#else
#define __Pyx_PyErr_GivenExceptionMatches(err, type) PyErr_GivenExceptionMatches(err, type)
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches2(PyObject *err, PyObject *type1, PyObject *type2) {
    return PyErr_GivenExceptionMatches(err, type1) || PyErr_GivenExceptionMatches(err, type2);
}
#endif
#define __Pyx_PyErr_ExceptionMatches2(err1, err2)  __Pyx_PyErr_GivenExceptionMatches2(__Pyx_PyErr_CurrentExceptionType(), err1, err2)


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_PyErr_ExceptionMatches(err) __Pyx_PyErr_ExceptionMatchesInState(__pyx_tstate, err)
static CYTHON_INLINE int __Pyx_PyErr_ExceptionMatchesInState(PyThreadState* tstate, PyObject* err);
#else
#define __Pyx_PyErr_ExceptionMatches(err)  PyErr_ExceptionMatches(err)
#endif


#if CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE PyObject* __Pyx_PyObject_GetAttrStr(PyObject* obj, PyObject* attr_name);
#else
#define __Pyx_PyObject_GetAttrStr(o,n) PyObject_GetAttr(o,n)
#endif


static CYTHON_INLINE PyObject* __Pyx_PyObject_GetAttrStrNoError(PyObject* obj, PyObject* attr_name);


static PyObject *__Pyx_GetBuiltinName(PyObject *name);


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE void __Pyx_copy_object_array(PyObject *const *CYTHON_RESTRICT src, PyObject** CYTHON_RESTRICT dest, Py_ssize_t length);
#endif


#if PY_VERSION_HEX >= 0x030F0000 && !CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_PyTuple_FromArray(src, n) PyTuple_FromArray(src, ((n)<0) ? 0 : (n))
#else
CYTHON_UNUSED static PyObject *
__Pyx_PyTuple_FromArray(PyObject *const *src, Py_ssize_t n);
#endif





#include <string.h>


static CYTHON_INLINE int __Pyx_PyObject_CompareBoolEq_str_str(PyObject *op1, PyObject *op2, int pyop);


#define __Pyx_PyUnicode_Equals(s1, s2)  __Pyx_PyObject_CompareBoolEq_str_str(s1, s2, Py_EQ)


#if CYTHON_AVOID_BORROWED_REFS
    #define __Pyx_ArgRef_VARARGS(args, i) __Pyx_PySequence_ITEM(args, i)
#elif CYTHON_ASSUME_SAFE_MACROS
    #define __Pyx_ArgRef_VARARGS(args, i) __Pyx_NewRef(__Pyx_PyTuple_GET_ITEM(args, i))
#else
    #define __Pyx_ArgRef_VARARGS(args, i) __Pyx_XNewRef(PyTuple_GetItem(args, i))
#endif
#define __Pyx_NumKwargs_VARARGS(kwds) PyDict_Size(kwds)
#define __Pyx_KwValues_VARARGS(args, nargs) NULL
#define __Pyx_GetKwValue_VARARGS(kw, kwvalues, s) __Pyx_PyDict_GetItemStrWithError(kw, s)
#define __Pyx_KwargsAsDict_VARARGS(kw, kwvalues) PyDict_Copy(kw)
#if CYTHON_VECTORCALL
    #define __Pyx_ArgRef_FASTCALL(args, i) __Pyx_NewRef(args[i])
    #define __Pyx_NumKwargs_FASTCALL(kwds) __Pyx_PyTuple_GET_SIZE(kwds)
    #define __Pyx_KwValues_FASTCALL(args, nargs) ((args) + (nargs))
    static CYTHON_INLINE PyObject * __Pyx_GetKwValue_FASTCALL(PyObject *kwnames, PyObject *const *kwvalues, PyObject *s);
  #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030d0000 || CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL
    CYTHON_UNUSED static PyObject *__Pyx_KwargsAsDict_FASTCALL(PyObject *kwnames, PyObject *const *kwvalues);
  #else
    #define __Pyx_KwargsAsDict_FASTCALL(kw, kwvalues) _PyStack_AsDict(kwvalues, kw)
  #endif
#else
    #define __Pyx_ArgRef_FASTCALL __Pyx_ArgRef_VARARGS
    #define __Pyx_NumKwargs_FASTCALL __Pyx_NumKwargs_VARARGS
    #define __Pyx_KwValues_FASTCALL __Pyx_KwValues_VARARGS
    #define __Pyx_GetKwValue_FASTCALL __Pyx_GetKwValue_VARARGS
    #define __Pyx_KwargsAsDict_FASTCALL __Pyx_KwargsAsDict_VARARGS
#endif
#if CYTHON_VECTORCALL_TPNEW
    #if !CYTHON_VECTORCALL
        #error Enabling CYTHON_VECTORCALL_TPNEW without CYTHON_VECTORCALL is not supported
    #endif
    #define __Pyx_ArgRef_FASTCALL_TPNEW __Pyx_ArgRef_FASTCALL
    #define __Pyx_NumKwargs_FASTCALL_TPNEW __Pyx_NumKwargs_FASTCALL
    #define __Pyx_KwValues_FASTCALL_TPNEW __Pyx_KwValues_FASTCALL
    #define __Pyx_GetKwValue_FASTCALL_TPNEW __Pyx_GetKwValue_FASTCALL
    #define __Pyx_KwargsAsDict_FASTCALL_TPNEW __Pyx_KwargsAsDict_FASTCALL
#else
    #define __Pyx_ArgRef_FASTCALL_TPNEW __Pyx_ArgRef_VARARGS
    #define __Pyx_NumKwargs_FASTCALL_TPNEW __Pyx_NumKwargs_VARARGS
    #define __Pyx_KwValues_FASTCALL_TPNEW __Pyx_KwValues_VARARGS
    #define __Pyx_GetKwValue_FASTCALL_TPNEW __Pyx_GetKwValue_VARARGS
    #define __Pyx_KwargsAsDict_FASTCALL_TPNEW __Pyx_KwargsAsDict_VARARGS
#endif
#define __Pyx_ArgsSlice_VARARGS(args, start, stop) PyTuple_GetSlice(args, start, stop)
#if CYTHON_VECTORCALL
#define __Pyx_ArgsSlice_FASTCALL(args, start, stop) __Pyx_PyTuple_FromArray(args + start, stop - start)
#else
#define __Pyx_ArgsSlice_FASTCALL __Pyx_ArgsSlice_VARARGS
#endif


#define __Pyx_PyDict_items_TypePtr  (&PyDictKeys_Type)
#define __Pyx_PyDict_items_Check(obj)  PyObject_TypeCheck((obj), __Pyx_PyDictItems_TypePtr)
#define __Pyx_PyDict_items_CheckExact(obj)  Py_IS_TYPE((obj), __Pyx_PyDictItems_TypePtr)
static CYTHON_INLINE PyObject* __Pyx_PyDict_Items(PyObject* d);


#define __Pyx_CallCFunction(cfunc, self, args)\
    ((PyCFunction)(void(*)(void))(cfunc)->func)(self, args)
#define __Pyx_CallCFunctionWithKeywords(cfunc, self, args, kwargs)\
    ((PyCFunctionWithKeywords)(void(*)(void))(cfunc)->func)(self, args, kwargs)
#define __Pyx_CallCFunctionFast(cfunc, self, args, nargs)\
    ((__Pyx_PyCFunctionFast)(void(*)(void))(PyCFunction)(cfunc)->func)(self, args, nargs)
#define __Pyx_CallCFunctionFastWithKeywords(cfunc, self, args, nargs, kwnames)\
    ((__Pyx_PyCFunctionFastWithKeywords)(void(*)(void))(PyCFunction)(cfunc)->func)(self, args, nargs, kwnames)


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyObject_Call(PyObject *func, PyObject *arg, PyObject *kw);
#else
#define __Pyx_PyObject_Call(func, arg, kw) PyObject_Call(func, arg, kw)
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyObject_CallMethO(PyObject *func, PyObject *arg);
#endif


#define __Pyx_PyObject_FastCall(func, args, nargs)  __Pyx_PyObject_FastCallDict(func, args, (size_t)(nargs), NULL)
static CYTHON_INLINE PyObject* __Pyx_PyObject_FastCallDict(PyObject *func, PyObject * const*args, size_t nargsf, PyObject *kwargs);


static CYTHON_INLINE PyObject* __Pyx_PyObject_CallOneArg(PyObject *func, PyObject *arg);


typedef struct {
    PyObject *type;
    PyObject **method_name;
    PyCFunction func;
    PyObject *method;
    int flag;
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING && CYTHON_ATOMICS
    __pyx_atomic_int_type initialized;
#endif
} __Pyx_CachedCFunction;


static CYTHON_INLINE int __Pyx_IgnoreGivenException(PyObject *given_exception, PyObject *ignorable_exception);
#define __Pyx_IgnoreException(ignorable_exception) __Pyx_IgnoreGivenException(NULL, ignorable_exception)


static int __Pyx_TryUnpackUnboundCMethod(__Pyx_CachedCFunction* target);


#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
static CYTHON_INLINE int __Pyx_CachedCFunction_GetAndSetInitializing(__Pyx_CachedCFunction *cfunc) {
#if !CYTHON_ATOMICS
    return 1;
#else
    __pyx_nonatomic_int_type expected = 0;
    if (__pyx_atomic_int_cmp_exchange(&cfunc->initialized, &expected, 1)) {
        return 0;
    }
    return expected;
#endif
}
static CYTHON_INLINE void __Pyx_CachedCFunction_SetFinishedInitializing(__Pyx_CachedCFunction *cfunc) {
#if CYTHON_ATOMICS
    __pyx_atomic_store(&cfunc->initialized, 2);
#endif
}
#else
#define __Pyx_CachedCFunction_GetAndSetInitializing(cfunc) 2
#define __Pyx_CachedCFunction_SetFinishedInitializing(cfunc)
#endif


CYTHON_UNUSED
static PyObject* __Pyx__CallUnboundCMethod0(__Pyx_CachedCFunction* cfunc, PyObject* self);
#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_CallUnboundCMethod0(__Pyx_CachedCFunction* cfunc, PyObject* self);
#else
#define __Pyx_CallUnboundCMethod0(cfunc, self)  __Pyx__CallUnboundCMethod0(cfunc, self)
#endif


#define __Pyx_PyDict_values_TypePtr  (&PyDictKeys_Type)
#define __Pyx_PyDict_values_Check(obj)  PyObject_TypeCheck((obj), __Pyx_PyDictValues_TypePtr)
#define __Pyx_PyDict_values_CheckExact(obj)  Py_IS_TYPE((obj), __Pyx_PyDictValues_TypePtr)
static CYTHON_INLINE PyObject* __Pyx_PyDict_Values(PyObject* d);


#if CYTHON_AVOID_BORROWED_REFS
static int __Pyx_PyDict_NextRef(PyObject *p, PyObject **ppos, PyObject **pkey, PyObject **pvalue);
#else
CYTHON_INLINE
static int __Pyx_PyDict_NextRef(PyObject *p, Py_ssize_t *ppos, PyObject **pkey, PyObject **pvalue);
#endif


static void __Pyx_RaiseDoubleKeywordsError(const char* func_name, PyObject* kw_name);


static int __Pyx_ParseKeywordsTuple(
    PyObject *kwds,
    PyObject * const *kwvalues,
    PyObject ** const argnames[],
    PyObject *kwds2,
    PyObject *values[],
    Py_ssize_t num_pos_args,
    Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs
);
static int __Pyx_ParseKeywordDictToDict(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject *kwds2,
    PyObject *values[],
    Py_ssize_t num_pos_args,
    const char* function_name
);
static int __Pyx_ParseKeywordDict(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject *values[],
    Py_ssize_t num_pos_args,
    Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs
);


CYTHON_UNUSED
static PyObject* __Pyx__CallUnboundCMethod2(__Pyx_CachedCFunction* cfunc, PyObject* self, PyObject* arg1, PyObject* arg2);
#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject *__Pyx_CallUnboundCMethod2(__Pyx_CachedCFunction *cfunc, PyObject *self, PyObject *arg1, PyObject *arg2);
#else
#define __Pyx_CallUnboundCMethod2(cfunc, self, arg1, arg2)  __Pyx__CallUnboundCMethod2(cfunc, self, arg1, arg2)
#endif


static CYTHON_INLINE int __Pyx_ParseKeywords(
    PyObject *kwds, PyObject *const *kwvalues, PyObject ** const argnames[],
    PyObject *kwds2, PyObject *values[],
    Py_ssize_t num_pos_args, Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs
);


static void __Pyx_RaiseArgtupleInvalid(const char* func_name, int exact,
    Py_ssize_t num_min, Py_ssize_t num_max, Py_ssize_t num_found);


static CYTHON_INLINE int __Pyx_PyObject_CompareBoolEq_object_str(PyObject *op1, PyObject *op2, int pyop);


#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030d0000
#define __Pyx_PyObject_DelAttr(o, n) PyObject_SetAttr(o, n, NULL)
#else
#define __Pyx_PyObject_DelAttr(o, n) PyObject_DelAttr(o, n)
#endif


#if CYTHON_USE_TYPE_SLOTS
#define __Pyx_PyObject_DelAttrStr(o,n) __Pyx_PyObject_SetAttrStr(o, n, NULL)
static CYTHON_INLINE int __Pyx_PyObject_SetAttrStr(PyObject* obj, PyObject* attr_name, PyObject* value);
#else
#define __Pyx_PyObject_DelAttrStr(o,n)   __Pyx_PyObject_DelAttr(o,n)
#define __Pyx_PyObject_SetAttrStr(o,n,v) PyObject_SetAttr(o,n,v)
#endif


#define __Pyx_PyExc_ValueError_Check(obj)  __Pyx_TypeCheck(obj, PyExc_ValueError)


static void __Pyx_Raise(PyObject *type, PyObject *value, PyObject *tb, PyObject *cause);


#if CYTHON_COMPILING_IN_LIMITED_API  ||  PY_VERSION_HEX >= 0x030C0000
  static int __pyx_assertions_enabled_flag;
  #define __pyx_assertions_enabled() (__pyx_assertions_enabled_flag)
  #if __clang__ || __GNUC__
  __attribute__((no_sanitize("thread")))
  #endif
  static int __Pyx_init_assertions_enabled(void) {
    PyObject *builtins, *debug, *debug_str;
    int flag;
    builtins = PyEval_GetBuiltins();
    if (!builtins) goto bad;
    debug_str = PyUnicode_FromStringAndSize("__debug__", 9);
    if (!debug_str) goto bad;
    debug = PyObject_GetItem(builtins, debug_str);
    Py_DECREF(debug_str);
    if (!debug) goto bad;
    flag = PyObject_IsTrue(debug);
    Py_DECREF(debug);
    if (flag == -1) goto bad;
    __pyx_assertions_enabled_flag = flag;
    return 0;
  bad:
    __pyx_assertions_enabled_flag = 1;
    return -1;
  }
#else
  #define __Pyx_init_assertions_enabled()  (0)
  #define __pyx_assertions_enabled()  (!Py_OptimizeFlag)
#endif


#if CYTHON_VECTORCALL
#define __Pyx_PyObject_FastCallMethod(name, args, nargsf) PyObject_VectorcallMethod(name, args, nargsf, NULL)
#else
static PyObject *__Pyx_PyObject_FastCallMethod(PyObject *name, PyObject *const *args, size_t nargsf);
#endif


#define __Pyx_PyExc_AssertionError_Check(obj)  __Pyx_TypeCheck(obj, PyExc_AssertionError)


#if CYTHON_USE_DICT_VERSIONS && CYTHON_USE_TYPE_SLOTS
#define __PYX_DICT_VERSION_INIT  ((PY_UINT64_T) -1)
#define __PYX_GET_DICT_VERSION(dict)  (((PyDictObject*)(dict))->ma_version_tag)
#define __PYX_UPDATE_DICT_CACHE(dict, value, cache_var, version_var)\
    (version_var) = __PYX_GET_DICT_VERSION(dict);\
    (cache_var) = (value);
#define __PYX_PY_DICT_LOOKUP_IF_MODIFIED(VAR, DICT, LOOKUP) {\
    static PY_UINT64_T __pyx_dict_version = 0;\
    static PyObject *__pyx_dict_cached_value = NULL;\
    if (likely(__PYX_GET_DICT_VERSION(DICT) == __pyx_dict_version)) {\
        (VAR) = __Pyx_XNewRef(__pyx_dict_cached_value);\
    } else {\
        (VAR) = __pyx_dict_cached_value = (LOOKUP);\
        __pyx_dict_version = __PYX_GET_DICT_VERSION(DICT);\
    }\
}
static CYTHON_INLINE PY_UINT64_T __Pyx_get_tp_dict_version(PyObject *obj);
static CYTHON_INLINE PY_UINT64_T __Pyx_get_object_dict_version(PyObject *obj);
static CYTHON_INLINE int __Pyx_object_dict_version_matches(PyObject* obj, PY_UINT64_T tp_dict_version, PY_UINT64_T obj_dict_version);
#else
#define __PYX_GET_DICT_VERSION(dict)  (0)
#define __PYX_UPDATE_DICT_CACHE(dict, value, cache_var, version_var)
#define __PYX_PY_DICT_LOOKUP_IF_MODIFIED(VAR, DICT, LOOKUP)  (VAR) = (LOOKUP);
#endif


#if CYTHON_USE_DICT_VERSIONS
#define __Pyx_GetModuleGlobalName(var, name)  do {\
    static PY_UINT64_T __pyx_dict_version = 0;\
    static PyObject *__pyx_dict_cached_value = NULL;\
    (var) = (likely(__pyx_dict_version == __PYX_GET_DICT_VERSION(__pyx_mstate_global->__pyx_d))) ?\
        (likely(__pyx_dict_cached_value) ? __Pyx_NewRef(__pyx_dict_cached_value) : __Pyx_GetBuiltinName(name)) :\
        __Pyx__GetModuleGlobalName(name, &__pyx_dict_version, &__pyx_dict_cached_value);\
} while(0)
#define __Pyx_GetModuleGlobalNameUncached(var, name)  do {\
    PY_UINT64_T __pyx_dict_version;\
    PyObject *__pyx_dict_cached_value;\
    (var) = __Pyx__GetModuleGlobalName(name, &__pyx_dict_version, &__pyx_dict_cached_value);\
} while(0)
static PyObject *__Pyx__GetModuleGlobalName(PyObject *name, PY_UINT64_T *dict_version, PyObject **dict_cached_value);
#else
#define __Pyx_GetModuleGlobalName(var, name)  (var) = __Pyx__GetModuleGlobalName(name)
#define __Pyx_GetModuleGlobalNameUncached(var, name)  (var) = __Pyx__GetModuleGlobalName(name)
static CYTHON_INLINE PyObject *__Pyx__GetModuleGlobalName(PyObject *name);
#endif


#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX >= 0x030d0000
typedef PyObject *__Pyx_TypeName;
#define __Pyx_FMT_TYPENAME "%N"
#define __Pyx_PyType_GetFullyQualifiedName(tp) Py_NewRef((PyObject*)tp)
#define __Pyx_DECREF_TypeName(obj) Py_DECREF(obj)
#elif CYTHON_COMPILING_IN_LIMITED_API
typedef PyObject *__Pyx_TypeName;
#define __Pyx_FMT_TYPENAME "%U"
#define __Pyx_DECREF_TypeName(obj) Py_XDECREF(obj)
static __Pyx_TypeName __Pyx_PyType_GetFullyQualifiedName(PyTypeObject* tp);
#else  // !LIMITED_API
typedef const char *__Pyx_TypeName;
#define __Pyx_FMT_TYPENAME "%.200s"
#define __Pyx_PyType_GetFullyQualifiedName(tp) ((tp)->tp_name)
#define __Pyx_DECREF_TypeName(obj)
#endif


#define __Pyx_RaiseErrorWithObjectTypes1(exc_type, message, arg, obj1, obj2) __Pyx_RaiseErrorWithTypes1(exc_type, message, arg, Py_TYPE(obj1), Py_TYPE(obj2))
#define __Pyx_RaiseTypeErrorWithObjectTypes(message, obj1, obj2) __Pyx_RaiseTypeErrorWithTypes(message, Py_TYPE(obj1), Py_TYPE(obj2))
#define __Pyx_RaiseTypeErrorWithTypes(message, type_obj1, type_obj2) __Pyx_RaiseErrorWithTypes1(PyExc_TypeError, "%.1s" message, "", type_obj1, type_obj2)
CYTHON_UNUSED
static void __Pyx_RaiseErrorWithTypes1(PyObject* exc_type, const char *message, const char *arg, PyTypeObject *type_obj1, PyTypeObject *type_obj2);


#if CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL || CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_PyNumber_Add_object_object(op1, op2)  PyNumber_Add(op1, op2)
#define __Pyx_PyNumber_InPlaceAdd_object_object(op1, op2)  PyNumber_InPlaceAdd(op1, op2)
#else
#define __Pyx_PyNumber_Add_object_object(op1, op2)  __Pyx__PyNumber_Add_object_object(op1, op2, 0)
#define __Pyx_PyNumber_InPlaceAdd_object_object(op1, op2)  __Pyx__PyNumber_Add_object_object(op1, op2, 1)
static CYTHON_INLINE PyObject* __Pyx__PyNumber_Add_object_object(PyObject *op1, PyObject *op2, int inplace);
#endif


#if !CYTHON_COMPILING_IN_PYPY
static CYTHON_INLINE PyObject* __Pyx_PyLong_AddObjC(PyObject *op1, PyObject *op2, long intval, int inplace, int zerodivision_check);
#else
#define __Pyx_PyLong_AddObjC(op1, op2, intval, inplace, zerodivision_check)\
    (inplace ? PyNumber_InPlaceAdd(op1, op2) : PyNumber_Add(op1, op2))
#endif


static CYTHON_INLINE int __Pyx_PySequence_ContainsTF(PyObject* item, PyObject* seq, int eq) {
    int result = PySequence_Contains(seq, item);
    return unlikely(result < 0) ? result : (result == (eq == Py_EQ));
}


static CYTHON_INLINE int __Pyx_PyObject_CompareBoolEq_object_object(PyObject *op1, PyObject *op2, int pyop);


#if CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_PyFrozenDict_TypePtr  ((PyTypeObject*) __pyx_mstate_global->__Pyx_PyFrozenDictType)
#define __Pyx_PyFrozenDict_New(it)  __Pyx__PyFrozenDict_New(__pyx_mstate_global->__Pyx_PyFrozenDictType, it)
static CYTHON_INLINE PyObject* __Pyx__PyFrozenDict_New(PyObject* frozendict_type, PyObject* it);
#define __Pyx_PyFrozenDict_NewEmpty()  __Pyx_PyFrozenDict_New(NULL)
#define __Pyx_PyFrozenDict_Check(obj)  PyObject_TypeCheck((obj), __Pyx_PyFrozenDict_TypePtr)
#define __Pyx_PyFrozenDict_CheckExact(obj)  Py_IS_TYPE((obj), __Pyx_PyFrozenDict_TypePtr)
#define __Pyx_PyAnyDict_Check(obj)   __Pyx__PyAnyDict_Check(obj, __Pyx_PyFrozenDict_TypePtr)
static CYTHON_INLINE int __Pyx__PyAnyDict_Check(PyObject *obj, PyTypeObject* frozendict_type) {
    return PyObject_TypeCheck(obj, &PyDict_Type) || PyObject_TypeCheck(obj, frozendict_type);
}
#define __Pyx_PyAnyDict_CheckExact(obj)  __Pyx__PyAnyDict_CheckExact(obj, __Pyx_PyFrozenDict_TypePtr)
static CYTHON_INLINE int __Pyx__PyAnyDict_CheckExact(PyObject *obj, PyTypeObject* frozendict_type) {
    return Py_IS_TYPE(obj, &PyDict_Type) || Py_IS_TYPE(obj, frozendict_type);
}
#elif PY_VERSION_HEX >= 0x030f00a6 ||\
    (defined(PyFrozenDict_Check) && defined(PyAnyDict_Check) && defined(PyFrozenDict_New))
#define __Pyx_PyFrozenDict_TypePtr  (&PyFrozenDict_Type)
#define __Pyx_PyFrozenDict_New(it)  PyFrozenDict_New(it)
#define __Pyx_PyFrozenDict_NewEmpty()  PyFrozenDict_New(NULL)
#define __Pyx_PyFrozenDict_Check(obj)  PyFrozenDict_Check(obj)
#define __Pyx_PyFrozenDict_CheckExact(obj)  PyFrozenDict_CheckExact(obj)
#define __Pyx_PyAnyDict_Check(obj)  PyAnyDict_Check(obj)
#define __Pyx_PyAnyDict_CheckExact(obj)  PyAnyDict_CheckExact(obj)
#else
#define __Pyx_PyFrozenDict_TypePtr  (&PyDict_Type)
static CYTHON_INLINE PyObject* __Pyx_PyFrozenDict_New(PyObject* it) {
    if (!it) {
        return PyDict_New();
    } else if (PyDict_Check(it)) {
        return PyDict_Copy(it);
    } else {
        PyObject *dict = PyDict_New();
        if (!dict) return NULL;
        PyObject *result = PyNumber_InPlaceOr(dict, it);
        Py_DECREF(dict);
        return result;
    }
}
#define __Pyx_PyFrozenDict_NewEmpty()  PyDict_New()
#define __Pyx_PyFrozenDict_Check(obj)  PyDict_Check(obj)
#define __Pyx_PyFrozenDict_CheckExact(obj)  PyDict_CheckExact(obj)
#define __Pyx_PyAnyDict_Check(obj)  PyDict_Check(obj)
#define __Pyx_PyAnyDict_CheckExact(obj)  PyDict_CheckExact(obj)
#endif


#define __Pyx_GetItemInt(o, i, type, is_signed, to_py_func, wraparound, boundscheck, has_gil, unsafe_shared)\
    (__Pyx_fits_Py_ssize_t(i, type, is_signed) ?\
    __Pyx_GetItemInt_Fast(o, (Py_ssize_t)i, wraparound, boundscheck, unsafe_shared) :\
    __Pyx_GetItemInt_Generic(o, to_py_func(i)))
#define __Pyx_GetItemInt_List(o, i, type, is_signed, to_py_func, wraparound, boundscheck, has_gil, unsafe_shared)\
    (__Pyx_fits_Py_ssize_t(i, type, is_signed) ?\
    __Pyx_GetItemInt_List_Fast(o, (Py_ssize_t)i, wraparound, boundscheck, unsafe_shared) :\
    (PyErr_SetString(PyExc_IndexError, "list index out of range"), (PyObject*)NULL))
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_List_Fast(PyObject *o, Py_ssize_t i,
                                                              int wraparound, int boundscheck, int unsafe_shared);
#define __Pyx_GetItemInt_Tuple(o, i, type, is_signed, to_py_func, wraparound, boundscheck, has_gil, unsafe_shared)\
    (__Pyx_fits_Py_ssize_t(i, type, is_signed) ?\
    __Pyx_GetItemInt_Tuple_Fast(o, (Py_ssize_t)i, wraparound, boundscheck, unsafe_shared) :\
    (PyErr_SetString(PyExc_IndexError, "tuple index out of range"), (PyObject*)NULL))
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_Tuple_Fast(PyObject *o, Py_ssize_t i,
                                                              int wraparound, int boundscheck, int unsafe_shared);
static PyObject *__Pyx_GetItemInt_Generic(PyObject *o, PyObject* j);
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_Fast(PyObject *o, Py_ssize_t i,
                                                     int wraparound, int boundscheck, int unsafe_shared);


#if CYTHON_USE_EXC_INFO_STACK && CYTHON_FAST_THREAD_STATE
static _PyErr_StackItem * __Pyx_PyErr_GetTopmostException(PyThreadState *tstate);
#endif


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_ExceptionSave(type, value, tb)  __Pyx__ExceptionSave(__pyx_tstate, type, value, tb)
static CYTHON_INLINE void __Pyx__ExceptionSave(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb);
#define __Pyx_ExceptionReset(type, value, tb)  __Pyx__ExceptionReset(__pyx_tstate, type, value, tb)
static CYTHON_INLINE void __Pyx__ExceptionReset(PyThreadState *tstate, PyObject *type, PyObject *value, PyObject *tb);
#else
#define __Pyx_ExceptionSave(type, value, tb)   PyErr_GetExcInfo(type, value, tb)
#define __Pyx_ExceptionReset(type, value, tb)  PyErr_SetExcInfo(type, value, tb)
#endif


#if CYTHON_FAST_THREAD_STATE
#define __Pyx_GetException(type, value, tb)  __Pyx__GetException(__pyx_tstate, type, value, tb)
static int __Pyx__GetException(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb);
#else
static int __Pyx_GetException(PyObject **type, PyObject **value, PyObject **tb);
#endif


#if CYTHON_USE_PYLIST_INTERNALS && CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE
static CYTHON_INLINE int __Pyx_PyList_Append(PyObject* list, PyObject* x);
#else
#define __Pyx_PyList_Append(L,x) PyList_Append(L,x)
#endif


static CYTHON_INLINE PyObject* __Pyx_PyObject_CallMethod1(PyObject* obj, PyObject* method_name, PyObject* arg);


static CYTHON_INLINE int __Pyx_PyObject_Append(PyObject* L, PyObject* x);


#if CYTHON_COMPILING_IN_PYPY && !defined(PyRange_Check)
  #define PyRange_Check(obj)  __Pyx_TypeCheck((obj), &PyRange_Type)
#endif


#if CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL || CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_PyNumber_Subtract_object_int(op1, op2)  PyNumber_Subtract(op1, op2)
#define __Pyx_PyNumber_InPlaceSubtract_object_int(op1, op2)  PyNumber_InPlaceSubtract(op1, op2)
#else
#define __Pyx_PyNumber_Subtract_object_int(op1, op2)  __Pyx__PyNumber_Subtract_object_int(op1, op2, 0)
#define __Pyx_PyNumber_InPlaceSubtract_object_int(op1, op2)  __Pyx__PyNumber_Subtract_object_int(op1, op2, 1)
static CYTHON_INLINE PyObject* __Pyx__PyNumber_Subtract_object_int(PyObject *op1, PyObject *op2, int inplace);
#endif


#if CYTHON_VECTORCALL
#define __Pyx_Object_VectorcallKwds PyObject_Vectorcall
CYTHON_UNUSED static int __Pyx_CheckVectorcallKwarg(PyObject *kwnames, Py_ssize_t i);
#else
#define __Pyx_Object_VectorcallKwds __Pyx_PyObject_FastCallDict
CYTHON_UNUSED static PyObject *__Pyx_MakeKwargDict(PyObject **keys, PyObject **values, Py_ssize_t n);
CYTHON_UNUSED static int __Pyx_CheckVectorcallKwarg(PyObject **kwnames, Py_ssize_t i);
#endif


#if CYTHON_VECTORCALL
#define __Pyx_Object_VectorcallMethodKwds PyObject_VectorcallMethod
#else
static PyObject *__Pyx_Object_VectorcallMethodKwds(PyObject *name, PyObject *const *args, size_t nargsf, PyObject *kwnames);
#endif


#define __Pyx_RaiseTypeErrorWithObjectType(message, obj)  __Pyx_RaiseErrorWithObjectType(PyExc_TypeError, message, obj)
#define __Pyx_RaiseErrorWithObjectType(exc_type, message, obj)  __Pyx_RaiseErrorWithType(exc_type, message, Py_TYPE(obj))
CYTHON_UNUSED
static void __Pyx_RaiseErrorWithType(PyObject* exc_type, const char* message, PyTypeObject *type_obj);


#if CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE PyObject *__Pyx_PyObject_GetItem(PyObject *obj, PyObject *key);
#else
#define __Pyx_PyObject_GetItem(obj, key)  PyObject_GetItem(obj, key)
#endif


#define __Pyx_PyObject_Unicode(obj)\
    (likely(PyUnicode_CheckExact(obj)) ? __Pyx_NewRef(obj) : PyObject_Str(obj))


static CYTHON_INLINE int __Pyx_ListComp_AppendAndDecref(PyObject* list, PyObject* x);


static CYTHON_INLINE PyObject* __Pyx_PyObject_GetSlice(
        PyObject* obj, Py_ssize_t cstart, Py_ssize_t cstop,
        PyObject** py_start, PyObject** py_stop, PyObject** py_slice,
        int has_cstart, int has_cstop, int wraparound);


CYTHON_UNUSED static PyObject *
__Pyx_PyList_FromArray(PyObject *const *src, Py_ssize_t n);





#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyList_GetSlice(PyObject* src, Py_ssize_t start, Py_ssize_t stop);
static CYTHON_INLINE PyObject* __Pyx_PyTuple_GetSlice(PyObject* src, Py_ssize_t start, Py_ssize_t stop);
#else
#define __Pyx_PyList_GetSlice(seq, start, stop)   PySequence_GetSlice(seq, start, stop)
#define __Pyx_PyTuple_GetSlice(seq, start, stop)  PySequence_GetSlice(seq, start, stop)
#endif


static CYTHON_INLINE void __Pyx_RaiseTooManyValuesError(Py_ssize_t expected);


static CYTHON_INLINE void __Pyx_RaiseNeedMoreValuesError(Py_ssize_t index);


static CYTHON_INLINE int __Pyx_IterFinish(void);


static int __Pyx_IternextUnpackEndCheck(PyObject *retval, Py_ssize_t expected);


static PyObject *__Pyx_AllocateExtensionType(PyTypeObject *t, int is_final);


#if CYTHON_VECTORCALL_TPNEW
typedef PyObject * (*__Pyx_tpnewvectorcallfunc)(PyTypeObject* o, PyObject *const *args, Py_ssize_t nargs, PyObject *kwnames);
static PyObject * __Pyx_CallTpnewAsVectorcall(__Pyx_tpnewvectorcallfunc f, PyTypeObject* o, PyObject *a, PyObject *k);
#endif


#if CYTHON_VECTORCALL_TPNEW
static PyObject *__Pyx_CallNewInitFromVectorcall(PyTypeObject *t, PyObject *const *args, size_t nargsf, PyObject *kwnames);
#endif


#if !CYTHON_USE_TYPE_SPECS
#define __Pyx_call_type_traverse(o, always_call, visit, arg) 0
#else
static int __Pyx_call_type_traverse(PyObject *o, int always_call, visitproc visit, void *arg);
#endif


static CYTHON_INLINE PyObject* __Pyx_PyObject_CallMethod0(PyObject* obj, PyObject* method_name);


#if !CYTHON_USE_TYPE_SLOTS
CYTHON_UNUSED static Py_ssize_t __Pyx_GetTypeDictOffset(PyObject *tp, int require_cython_valid_result);
#endif


#define __Pyx_RaiseTypeErrorWithObjectType1(message, arg, obj) __Pyx_RaiseErrorWithObjectType1(PyExc_TypeError, message, arg, obj)
#define __Pyx_RaiseErrorWithObjectType1(exc_type, message, arg, obj) __Pyx_RaiseErrorWithType1(exc_type, message, arg, Py_TYPE(obj))
CYTHON_UNUSED
static void __Pyx_RaiseErrorWithType1(PyObject* exc_type, const char* message, const char *arg, PyTypeObject *type_obj);


#if CYTHON_COMPILING_IN_CPYTHON || CYTHON_COMPILING_IN_LIMITED_API || CYTHON_USE_TYPE_SPECS
static int __Pyx_validate_bases_tuple(const char *type_name, int has_dictoffset, PyObject *bases);
#endif


CYTHON_UNUSED static int __Pyx_PyType_Ready(PyTypeObject *t);


#if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
#define __Pyx_HasAttr(o, n)  PyObject_HasAttrWithError(o, n)
#else
static CYTHON_INLINE int __Pyx_HasAttr(PyObject *, PyObject *);
#endif


static PyObject *__Pyx__Import(PyObject *name, PyObject *const *imported_names, Py_ssize_t len_imported_names, PyObject *qualname, PyObject *moddict, int level);


static CYTHON_INLINE PyObject *__Pyx_Import(PyObject *name, PyObject *const *imported_names, Py_ssize_t len_imported_names, PyObject *qualname, int level);


static PyObject* __Pyx_ImportFrom(PyObject* module, PyObject* name);


static CYTHON_INLINE PyObject *__Pyx_PyDict_SetDefault(PyObject *d, PyObject *key, PyObject *default_value);


#if ((CYTHON_COMPILING_IN_CPYTHON_FREETHREADING && PY_VERSION_HEX < 0x030F00a3) ||\
     __PYX_LIMITED_VERSION_HEX < 0x030d0000)
  static PyObject *__Pyx_PyImport_AddModuleRef(const char *name);
#else
  #define __Pyx_PyImport_AddModuleRef(name) PyImport_AddModuleRef(name)
#endif


static PyObject *__Pyx_FetchSharedCythonABIModule(void);


static int __Pyx_VerifyCachedType(PyObject *cached_type,
                               const char *name,
                               Py_ssize_t expected_basicsize);


static PyTypeObject* __Pyx_FetchCommonTypeFromSpec(PyTypeObject *metaclass, PyObject *module, PyType_Spec *spec, PyObject *bases);


static int __pyx_CommonTypesMetaclass_init(PyObject *module);
#define __Pyx_CommonTypesMetaclass_USED


#define __Pyx_CyFunction_USED
#if CYTHON_OPAQUE_SHARED_TYPES
#define __Pyx_as_CyFunctionObject(o) ((__pyx_CyFunctionObject *)PyObject_GetTypeData((o), __pyx_mstate_global->__pyx_CyFunctionType))
#else
#define __Pyx_as_CyFunctionObject(o) ((__pyx_CyFunctionObject *)o)
#endif
#define __Pyx_CYFUNCTION_STATICMETHOD  0x01
#define __Pyx_CYFUNCTION_CLASSMETHOD   0x02
#define __Pyx_CYFUNCTION_CCLASS        0x04
#define __Pyx_CYFUNCTION_COROUTINE     0x08
#define __Pyx_CyFunction_GetClosure(f)\
    ((__Pyx_as_CyFunctionObject(f))->func_closure)
#if CYTHON_COMPILING_IN_LIMITED_API
  #define __Pyx__CyFunction_GetClassObj(f)\
      ((f)->func_classobj)
#else
  #define __Pyx__CyFunction_GetClassObj(f)\
      ((PyObject*) ((PyCMethodObject *) (f))->mm_class)
#endif
#define __Pyx_CyFunction_GetClassObj(f)\
    __Pyx__CyFunction_GetClassObj(__Pyx_as_CyFunctionObject(f))
#define __Pyx_CyFunction_SetClassObj(f, classobj)\
    __Pyx__CyFunction_SetClassObj(__Pyx_as_CyFunctionObject(f), (classobj))
#define __Pyx_CyFunction_Defaults(type, f)\
    ((type *)((__Pyx_as_CyFunctionObject(f))->defaults))
#define __Pyx_CyFunction_SetDefaultsGetter(f, g)\
    (__Pyx_as_CyFunctionObject(f))->defaults_getter = (g)
typedef struct {
#if CYTHON_COMPILING_IN_LIMITED_API
#if !CYTHON_OPAQUE_OBJECTS
    PyObject_HEAD
#endif
    PyMethodDef *func_methoddef;
    PyObject *func_module;
#else
    PyCMethodObject func;
#endif
#if (CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY) && CYTHON_VECTORCALL
    __pyx_vectorcallfunc func_vectorcall;
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject *func_weakreflist;
#endif
#if PY_VERSION_HEX < 0x030C0000 || CYTHON_COMPILING_IN_LIMITED_API
    PyObject *func_dict;
#endif
    PyObject *func_name;
    PyObject *func_qualname;
    PyObject *func_doc;
    PyObject *func_globals;
    PyObject *func_code;
    PyObject *func_closure;
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject *func_classobj;
#endif
    PyObject *defaults;
    int flags;
    PyObject *defaults_tuple;
    PyObject *defaults_kwdict;
    PyObject *(*defaults_getter)(PyObject *);
    PyObject *func_annotations;
#if __PYX_LIMITED_VERSION_HEX < 0x030B0000
    PyObject *func_is_coroutine;
#endif
} __pyx_CyFunctionObject;
#undef __Pyx_CyOrPyCFunction_Check
#define __Pyx_CyFunction_Check(obj)  __Pyx_TypeCheck(obj, __pyx_mstate_global->__pyx_CyFunctionType)
#define __Pyx_CyOrPyCFunction_Check(obj)  __Pyx_TypeCheck2(obj, __pyx_mstate_global->__pyx_CyFunctionType, &PyCFunction_Type)
#define __Pyx_CyFunction_CheckExact(obj)  Py_IS_TYPE(obj, __pyx_mstate_global->__pyx_CyFunctionType)
static CYTHON_INLINE int __Pyx__IsSameCyOrCFunction(PyObject *func, void (*cfunc)(void));
#undef __Pyx_IsSameCFunction
#define __Pyx_IsSameCFunction(func, cfunc)   __Pyx__IsSameCyOrCFunction(func, cfunc)
static CYTHON_INLINE void __Pyx__CyFunction_SetClassObj(__pyx_CyFunctionObject* f, PyObject* classobj);
static CYTHON_INLINE PyObject *__Pyx_CyFunction_InitDefaults(PyObject *func,
                                                         PyTypeObject *defaults_type);
static CYTHON_INLINE void __Pyx_CyFunction_SetDefaultsTuple(PyObject *m,
                                                            PyObject *tuple);
static CYTHON_INLINE void __Pyx_CyFunction_SetDefaultsKwDict(PyObject *m,
                                                             PyObject *dict);
static CYTHON_INLINE void __Pyx_CyFunction_SetAnnotationsDict(PyObject *m,
                                                              PyObject *dict);
static int __pyx_CyFunction_init(PyObject *module);
#if CYTHON_VECTORCALL
#if CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY
#define __Pyx_CyFunction_func_vectorcall(f) ((f)->func_vectorcall)
#else
#define __Pyx_CyFunction_func_vectorcall(f) (((PyCFunctionObject*)f)->vectorcall)
#endif
#endif


static PyObject *__Pyx_PyMethod_New(PyObject *func, PyObject *self, PyObject *typ);


#if CYTHON_VECTORCALL
static CYTHON_INLINE PyObject *__Pyx_PyVectorcall_FastCallDict(PyObject *func, __pyx_vectorcallfunc vc, PyObject *const *args, size_t nargs, PyObject *kw);
#endif


static PyObject *__Pyx_CyFunction_Init(PyObject *op_in, PyMethodDef *ml,
                                      int flags, PyObject* qualname,
                                      PyObject *closure,
                                      PyObject *module, PyObject *globals,
                                      PyObject* code);
#if CYTHON_VECTORCALL
static PyObject * __Pyx_CyFunction_Vectorcall_NOARGS(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames);
static PyObject * __Pyx_CyFunction_Vectorcall_O(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames);
static PyObject * __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames);
static PyObject * __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS_METHOD(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames);
#endif


static PyObject *__Pyx_CyFunction_New(PyMethodDef *ml,
                                      int flags, PyObject* qualname,
                                      PyObject *closure,
                                      PyObject *module, PyObject *globals,
                                      PyObject* code);
static PyTypeObject *__Pyx_Get_CyFunction_Type(void);


#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX < 0x030d0000
#define __Pyx_SetNameInClass(ns, name, value)\
    (likely(PyDict_CheckExact(ns)) ? _PyDict_SetItem_KnownHash(ns, name, value, ((PyASCIIObject *) name)->hash) : PyObject_SetItem(ns, name, value))
#elif CYTHON_COMPILING_IN_CPYTHON
#define __Pyx_SetNameInClass(ns, name, value)\
    (likely(PyDict_CheckExact(ns)) ? PyDict_SetItem(ns, name, value) : PyObject_SetItem(ns, name, value))
#else
#define __Pyx_SetNameInClass(ns, name, value)  PyObject_SetItem(ns, name, value)
#endif


static PyObject *__Pyx_CalculateMetaclass(PyTypeObject *metaclass, PyObject *bases);


static CYTHON_INLINE PyObject* __Pyx_PyObject_Call2Args(PyObject* function, PyObject* arg1, PyObject* arg2);


#if CYTHON_USE_PYTYPE_LOOKUP && CYTHON_USE_TYPE_SLOTS
#define __Pyx_PyObject_LookupSpecialNoError(obj, attr_name)  __Pyx__PyObject_LookupSpecial(obj, attr_name, 0)
#define __Pyx_PyObject_LookupSpecial(obj, attr_name)  __Pyx__PyObject_LookupSpecial(obj, attr_name, 1)
static CYTHON_INLINE PyObject* __Pyx__PyObject_LookupSpecial(PyObject* obj, PyObject* attr_name, int with_error);
#else
#define __Pyx_PyObject_LookupSpecialNoError(o,n) __Pyx_PyObject_GetAttrStrNoError(o,n)
#define __Pyx_PyObject_LookupSpecial(o,n) __Pyx_PyObject_GetAttrStr(o,n)
#endif


static PyObject *__Pyx_Py3MetaclassPrepare(PyObject *metaclass, PyObject *bases, PyObject *name, PyObject *qualname,
                                           PyObject *mkw, PyObject *modname, PyObject *doc);
static PyObject *__Pyx_Py3ClassCreate(PyObject *metaclass, PyObject *name, PyObject *bases, PyObject *dict,
                                      PyObject *mkw, int calculate_metaclass, int allow_py2_metaclass);


#if CYTHON_CLINE_IN_TRACEBACK && CYTHON_CLINE_IN_TRACEBACK_RUNTIME
static int __Pyx_CLineForTraceback(PyThreadState *tstate, int c_line);
#else
#define __Pyx_CLineForTraceback(tstate, c_line)  (((CYTHON_CLINE_IN_TRACEBACK)) ? c_line : 0)
#endif


#if CYTHON_COMPILING_IN_LIMITED_API
typedef PyObject __Pyx_CachedCodeObjectType;
#else
typedef PyCodeObject __Pyx_CachedCodeObjectType;
#endif
typedef struct {
    __Pyx_CachedCodeObjectType* code_object;
    int code_line;
} __Pyx_CodeObjectCacheEntry;
struct __Pyx_CodeObjectCache {
    int count;
    int max_count;
    __Pyx_CodeObjectCacheEntry* entries;
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_atomic_int_type accessor_count;
  #endif
};
static int __pyx_bisect_code_objects(__Pyx_CodeObjectCacheEntry* entries, int count, int code_line);
static __Pyx_CachedCodeObjectType *__pyx_find_code_object(int code_line);
static void __pyx_insert_code_object(int code_line, __Pyx_CachedCodeObjectType* code_object);


static void __Pyx_AddTraceback(const char *funcname, int c_line,
                               int py_line, const char *filename);


#if !defined(__INTEL_COMPILER) && defined(__GNUC__) && (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 6))
#define __Pyx_HAS_GCC_DIAGNOSTIC
#endif


static CYTHON_INLINE PyObject* __Pyx_PyLong_From_long(long value);


static CYTHON_INLINE long __Pyx_PyLong_As_long(PyObject *);


static CYTHON_INLINE int __Pyx_PyLong_As_int(PyObject *);


#if __PYX_LIMITED_VERSION_HEX < 0x030b0000
static unsigned long __Pyx_cached_runtime_version = 0;
static void __Pyx_init_runtime_version(void);
#else
#define __Pyx_init_runtime_version()
#endif
static unsigned long __Pyx_get_runtime_version(void);


static int __Pyx_check_binary_version(unsigned long ct_version, unsigned long rt_version, int allow_newer);


static PyObject *__Pyx_DecompressString(const char *s, Py_ssize_t length, int algo);


static PyObject *__Pyx_DecompressString_LZSS(const char *s, size_t compressed_length, size_t uncompressed_length);


#if CYTHON_PEP489_MULTI_PHASE_INIT && CYTHON_USE_MODULE_STATE
#include <stdlib.h>
static PyObject *__Pyx_State_FindModule(void*);
static int __Pyx_State_AddModule(PyObject* module, void*);
static int __Pyx_State_RemoveModule(void*);
#elif CYTHON_USE_MODULE_STATE
#define __Pyx_State_FindModule PyState_FindModule
#define __Pyx_State_AddModule PyState_AddModule
#define __Pyx_State_RemoveModule PyState_RemoveModule
#endif



#if CYTHON_COMPILING_IN_LIMITED_API
    #if CYTHON_VECTORCALL
        #define __PYX_VECTORCALL_ABI_SUFFIX  "_vectorcall"
    #else
        #define __PYX_VECTORCALL_ABI_SUFFIX
    #endif
    #define __PYX_LIMITED_ABI_SUFFIX "limited" __PYX_VECTORCALL_ABI_SUFFIX __PYX_AM_SEND_ABI_SUFFIX
#else
    #define __PYX_LIMITED_ABI_SUFFIX
#endif
#if __PYX_HAS_PY_AM_SEND == 1
    #define __PYX_AM_SEND_ABI_SUFFIX
#elif __PYX_HAS_PY_AM_SEND == 2
    #define __PYX_AM_SEND_ABI_SUFFIX "amsendbackport"
#else
    #define __PYX_AM_SEND_ABI_SUFFIX "noamsend"
#endif
#ifndef __PYX_MONITORING_ABI_SUFFIX
    #define __PYX_MONITORING_ABI_SUFFIX
#endif
#if CYTHON_USE_TP_FINALIZE
    #define __PYX_TP_FINALIZE_ABI_SUFFIX
#else
    #define __PYX_TP_FINALIZE_ABI_SUFFIX "nofinalize"
#endif
#if CYTHON_USE_FREELISTS || !defined(__Pyx_AsyncGen_USED)
    #define __PYX_FREELISTS_ABI_SUFFIX
#else
    #define __PYX_FREELISTS_ABI_SUFFIX "nofreelists"
#endif
#if CYTHON_OPAQUE_OBJECTS && CYTHON_COMPILING_IN_LIMITED_API
    #define __PYX_OPAQUE_OBJECTS_ABI_SUFFIX "opaque"
#else
    #define __PYX_OPAQUE_OBJECTS_ABI_SUFFIX
#endif
#define CYTHON_ABI  __PYX_ABI_VERSION __PYX_LIMITED_ABI_SUFFIX __PYX_MONITORING_ABI_SUFFIX __PYX_TP_FINALIZE_ABI_SUFFIX __PYX_FREELISTS_ABI_SUFFIX __PYX_AM_SEND_ABI_SUFFIX __PYX_OPAQUE_OBJECTS_ABI_SUFFIX
#define __PYX_ABI_MODULE_NAME "_cython_" CYTHON_ABI
#define __PYX_TYPE_MODULE_PREFIX __PYX_ABI_MODULE_NAME "."





#define __Pyx_MODULE_NAME "cloze.template_docx"
extern int __pyx_module_is_main_cloze__template_docx;
int __pyx_module_is_main_cloze__template_docx = 0;



static PyObject *__pyx_builtin_enumerate;
static PyObject *__pyx_builtin_eval;
static PyObject *__pyx_builtin_zip;


static PyObject *__pyx_pf_5cloze_13template_docx_12TemplateDocx___init__(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_self, PyObject *__pyx_v_pattern, PyObject *__pyx_v_recurse); 
static PyObject *__pyx_pf_5cloze_13template_docx_12TemplateDocx_2__call__(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_self, PyObject *__pyx_v_template_path, PyObject *__pyx_v_save_path, PyObject *__pyx_v_env); 
static PyObject *__pyx_pf_5cloze_13template_docx_2__defaults__(CYTHON_UNUSED PyObject *__pyx_self); 
static PyObject *__pyx_pf_5cloze_13template_docx_12TemplateDocx_4replace_paragraph(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_self, PyObject *__pyx_v_paragraph, PyObject *__pyx_v_env); 
static PyObject *__pyx_pf_5cloze_13template_docx_12TemplateDocx_6concat_run(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_self, PyObject *__pyx_v_paragraph); 
static PyObject *__pyx_pf_5cloze_13template_docx_cell_format_painter(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_cell, PyObject *__pyx_v_from_cell); 
static PyObject *__pyx_tp_new__initialisation_5cloze_13template_docx___pyx_defaults(PyObject *o, 
#if CYTHON_VECTORCALL_TPNEW
    PyObject *const *args, Py_ssize_t nargs, PyObject *kwnames
#else
    PyObject *a, PyObject *k
#endif
); 
static PyObject *__pyx_tp_new_vectorcall_5cloze_13template_docx___pyx_defaults(PyTypeObject *t, 
#if CYTHON_VECTORCALL_TPNEW
    PyObject *const *args, Py_ssize_t nargs, PyObject *kwnames
#else
    PyObject *a, PyObject *k
#endif
); 
#if CYTHON_VECTORCALL_TPNEW
static PyObject *__pyx_tp_new_5cloze_13template_docx___pyx_defaults(PyTypeObject *t, PyObject *a, PyObject *k); 
#endif
#if !CYTHON_VECTORCALL_TPNEW
#define __pyx_tp_new_5cloze_13template_docx___pyx_defaults __pyx_tp_new_vectorcall_5cloze_13template_docx___pyx_defaults
#endif
#if CYTHON_VECTORCALL_TPNEW
static PyObject *__pyx_tp_vectorcall_5cloze_13template_docx___pyx_defaults(PyObject *t, PyObject *const *args, size_t nargsf, PyObject *kwnames); 
#endif



#ifndef CYTHON_SMALL_CODE
#if defined(__clang__)
    #define CYTHON_SMALL_CODE
#elif defined(__GNUC__) && (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 3))
    #define CYTHON_SMALL_CODE __attribute__((cold))
#else
    #define CYTHON_SMALL_CODE
#endif
#endif

#ifdef __cplusplus
namespace {
  #endif
  typedef struct {
    PyObject *__pyx_d;
    PyObject *__pyx_b;
    PyObject *__pyx_cython_runtime;
    PyObject *__pyx_empty_tuple;
    PyObject *__pyx_empty_bytes;
    PyObject *__pyx_empty_unicode;
    PyObject *__pyx_type_5cloze_13template_docx___pyx_defaults;
    PyTypeObject *__pyx_ptype_5cloze_13template_docx___pyx_defaults;
    __Pyx_CachedCFunction __pyx_umethod_PyDict_Type_items;
    __Pyx_CachedCFunction __pyx_umethod_PyDict_Type_pop;
    __Pyx_CachedCFunction __pyx_umethod_PyDict_Type_values;
    PyObject *__pyx_slice[1];
    PyObject *__pyx_tuple[4];
    PyObject *__pyx_codeobj_tab[5];
    PyObject *__pyx_string_tab[171];
    PyObject *__pyx_number_tab[3];


#if CYTHON_COMPILING_IN_LIMITED_API
PyObject *__Pyx_PyFrozenDictType;
#endif


PyTypeObject *__pyx_CommonTypesMetaclassType;


#if CYTHON_COMPILING_IN_LIMITED_API
PyObject *__Pyx_CachedMethodType;
#endif


PyTypeObject *__pyx_CyFunctionType;


struct __Pyx_CodeObjectCache __pyx_code_cache;


} __pyx_mstatetype;
#ifdef __cplusplus
} 
#endif

#if CYTHON_USE_MODULE_STATE
#ifdef __cplusplus
namespace {
extern struct PyModuleDef __pyx_moduledef;
} 
#else
static struct PyModuleDef __pyx_moduledef;
#endif

#define __pyx_mstate_global (__Pyx_PyModule_GetState(__Pyx_State_FindModule(&__pyx_moduledef)))

#define __pyx_m (__Pyx_State_FindModule(&__pyx_moduledef))
#else
static __pyx_mstatetype __pyx_mstate_global_static =
#ifdef __cplusplus
    {};
#else
    {0};
#endif
static __pyx_mstatetype * const __pyx_mstate_global = &__pyx_mstate_global_static;
#endif

#define __pyx_kp_u__8 __pyx_string_tab[0]
#define __pyx_kp_u_s __pyx_string_tab[1]
#define __pyx_kp_u__9 __pyx_string_tab[2]
#define __pyx_kp_u_docx __pyx_string_tab[3]
#define __pyx_kp_u__5 __pyx_string_tab[4]
#define __pyx_kp_u__7 __pyx_string_tab[5]
#define __pyx_kp_u__6 __pyx_string_tab[6]
#define __pyx_kp_u__2 __pyx_string_tab[7]
#define __pyx_kp_u__4 __pyx_string_tab[8]
#define __pyx_kp_u_cloze_utils __pyx_string_tab[9]
#define __pyx_kp_u_cloze_template_docx_py __pyx_string_tab[10]
#define __pyx_kp_u_disable __pyx_string_tab[11]
#define __pyx_kp_u_enable __pyx_string_tab[12]
#define __pyx_kp_u_gc __pyx_string_tab[13]
#define __pyx_kp_u_isenabled __pyx_string_tab[14]
#define __pyx_kp_u_pattern_must_be_or __pyx_string_tab[15]
#define __pyx_kp_u_save_path_must_be_endwith_docx_f __pyx_string_tab[16]
#define __pyx_kp_u_template_path_must_be_endwith_do __pyx_string_tab[17]
#define __pyx_kp_u_w_rFonts __pyx_string_tab[18]
#define __pyx_kp_u_w_shd __pyx_string_tab[19]
#define __pyx_kp_u_w_tcBorders __pyx_string_tab[20]
#define __pyx_kp_u__3 __pyx_string_tab[21]
#define __pyx_kp_u_ __pyx_string_tab[22]
#define __pyx_n_u_BytesIO __pyx_string_tab[23]
#define __pyx_n_u_DataFrame __pyx_string_tab[24]
#define __pyx_n_u_Document __pyx_string_tab[25]
#define __pyx_n_u_OxmlElement __pyx_string_tab[26]
#define __pyx_n_u_TemplateDocx __pyx_string_tab[27]
#define __pyx_n_u_TemplateDocx___call __pyx_string_tab[28]
#define __pyx_n_u_TemplateDocx___init __pyx_string_tab[29]
#define __pyx_n_u_TemplateDocx_concat_run __pyx_string_tab[30]
#define __pyx_n_u_TemplateDocx_replace_paragraph __pyx_string_tab[31]
#define __pyx_n_u__10 __pyx_string_tab[32]
#define __pyx_n_u_Pyx_PyDict_NextRef __pyx_string_tab[33]
#define __pyx_n_u_annotate __pyx_string_tab[34]
#define __pyx_n_u_call __pyx_string_tab[35]
#define __pyx_n_u_class_getitem __pyx_string_tab[36]
#define __pyx_n_u_doc __pyx_string_tab[37]
#define __pyx_n_u_func __pyx_string_tab[38]
#define __pyx_n_u_init __pyx_string_tab[39]
#define __pyx_n_u_main __pyx_string_tab[40]
#define __pyx_n_u_metaclass __pyx_string_tab[41]
#define __pyx_n_u_module __pyx_string_tab[42]
#define __pyx_n_u_name_2 __pyx_string_tab[43]
#define __pyx_n_u_prepare __pyx_string_tab[44]
#define __pyx_n_u_qualname __pyx_string_tab[45]
#define __pyx_n_u_test __pyx_string_tab[46]
#define __pyx_n_u_element __pyx_string_tab[47]
#define __pyx_n_u_is_coroutine __pyx_string_tab[48]
#define __pyx_n_u_placeholder_2 __pyx_string_tab[49]
#define __pyx_n_u_tc __pyx_string_tab[50]
#define __pyx_n_u_add_column __pyx_string_tab[51]
#define __pyx_n_u_add_picture __pyx_string_tab[52]
#define __pyx_n_u_add_row __pyx_string_tab[53]
#define __pyx_n_u_add_run __pyx_string_tab[54]
#define __pyx_n_u_alignment __pyx_string_tab[55]
#define __pyx_n_u_append __pyx_string_tab[56]
#define __pyx_n_u_asyncio_coroutines __pyx_string_tab[57]
#define __pyx_n_u_attr __pyx_string_tab[58]
#define __pyx_n_u_attrib __pyx_string_tab[59]
#define __pyx_n_u_back __pyx_string_tab[60]
#define __pyx_n_u_backward_add __pyx_string_tab[61]
#define __pyx_n_u_backward_placeholder __pyx_string_tab[62]
#define __pyx_n_u_bold __pyx_string_tab[63]
#define __pyx_n_u_border __pyx_string_tab[64]
#define __pyx_n_u_cell __pyx_string_tab[65]
#define __pyx_n_u_cell_2 __pyx_string_tab[66]
#define __pyx_n_u_cell_format_painter __pyx_string_tab[67]
#define __pyx_n_u_cells __pyx_string_tab[68]
#define __pyx_n_u_child __pyx_string_tab[69]
#define __pyx_n_u_cline_in_traceback __pyx_string_tab[70]
#define __pyx_n_u_cloze_template_docx __pyx_string_tab[71]
#define __pyx_n_u_color __pyx_string_tab[72]
#define __pyx_n_u_columns __pyx_string_tab[73]
#define __pyx_n_u_concat_run __pyx_string_tab[74]
#define __pyx_n_u_concated __pyx_string_tab[75]
#define __pyx_n_u_copy __pyx_string_tab[76]
#define __pyx_n_u_deepcopy __pyx_string_tab[77]
#define __pyx_n_u_doc_2 __pyx_string_tab[78]
#define __pyx_n_u_docx_2 __pyx_string_tab[79]
#define __pyx_n_u_docx_oxml __pyx_string_tab[80]
#define __pyx_n_u_docx_oxml_ns __pyx_string_tab[81]
#define __pyx_n_u_dst_para __pyx_string_tab[82]
#define __pyx_n_u_dst_rFonts __pyx_string_tab[83]
#define __pyx_n_u_dst_rPr __pyx_string_tab[84]
#define __pyx_n_u_dst_run __pyx_string_tab[85]
#define __pyx_n_u_dst_shd __pyx_string_tab[86]
#define __pyx_n_u_dst_tc __pyx_string_tab[87]
#define __pyx_n_u_dst_tcBorders __pyx_string_tab[88]
#define __pyx_n_u_dst_tcPr __pyx_string_tab[89]
#define __pyx_n_u_endswith __pyx_string_tab[90]
#define __pyx_n_u_enumerate __pyx_string_tab[91]
#define __pyx_n_u_env __pyx_string_tab[92]
#define __pyx_n_u_eval __pyx_string_tab[93]
#define __pyx_n_u_except_placeholders __pyx_string_tab[94]
#define __pyx_n_u_find __pyx_string_tab[95]
#define __pyx_n_u_findall __pyx_string_tab[96]
#define __pyx_n_u_font __pyx_string_tab[97]
#define __pyx_n_u_forward __pyx_string_tab[98]
#define __pyx_n_u_forward_add __pyx_string_tab[99]
#define __pyx_n_u_forward_placeholder __pyx_string_tab[100]
#define __pyx_n_u_from_cell __pyx_string_tab[101]
#define __pyx_n_u_get_or_add_rPr __pyx_string_tab[102]
#define __pyx_n_u_get_or_add_tcPr __pyx_string_tab[103]
#define __pyx_n_u_get_outer_frame_variables __pyx_string_tab[104]
#define __pyx_n_u_getparent __pyx_string_tab[105]
#define __pyx_n_u_i __pyx_string_tab[106]
#define __pyx_n_u_insert __pyx_string_tab[107]
#define __pyx_n_u_io __pyx_string_tab[108]
#define __pyx_n_u_is_dataframe __pyx_string_tab[109]
#define __pyx_n_u_italic __pyx_string_tab[110]
#define __pyx_n_u_items __pyx_string_tab[111]
#define __pyx_n_u_j __pyx_string_tab[112]
#define __pyx_n_u_k __pyx_string_tab[113]
#define __pyx_n_u_l __pyx_string_tab[114]
#define __pyx_n_u_name __pyx_string_tab[115]
#define __pyx_n_u_old_rFonts __pyx_string_tab[116]
#define __pyx_n_u_over __pyx_string_tab[117]
#define __pyx_n_u_pandas __pyx_string_tab[118]
#define __pyx_n_u_paragraph __pyx_string_tab[119]
#define __pyx_n_u_paragraphs __pyx_string_tab[120]
#define __pyx_n_u_pattern __pyx_string_tab[121]
#define __pyx_n_u_placeholder __pyx_string_tab[122]
#define __pyx_n_u_placeholders __pyx_string_tab[123]
#define __pyx_n_u_pop __pyx_string_tab[124]
#define __pyx_n_u_qn __pyx_string_tab[125]
#define __pyx_n_u_rPr __pyx_string_tab[126]
#define __pyx_n_u_re __pyx_string_tab[127]
#define __pyx_n_u_recurse __pyx_string_tab[128]
#define __pyx_n_u_remove __pyx_string_tab[129]
#define __pyx_n_u_replace __pyx_string_tab[130]
#define __pyx_n_u_replace_paragraph __pyx_string_tab[131]
#define __pyx_n_u_replaced __pyx_string_tab[132]
#define __pyx_n_u_rgb __pyx_string_tab[133]
#define __pyx_n_u_row __pyx_string_tab[134]
#define __pyx_n_u_rows __pyx_string_tab[135]
#define __pyx_n_u_run __pyx_string_tab[136]
#define __pyx_n_u_runs __pyx_string_tab[137]
#define __pyx_n_u_save __pyx_string_tab[138]
#define __pyx_n_u_save_path __pyx_string_tab[139]
#define __pyx_n_u_self __pyx_string_tab[140]
#define __pyx_n_u_set __pyx_string_tab[141]
#define __pyx_n_u_setdefault __pyx_string_tab[142]
#define __pyx_n_u_shadow __pyx_string_tab[143]
#define __pyx_n_u_shape __pyx_string_tab[144]
#define __pyx_n_u_size __pyx_string_tab[145]
#define __pyx_n_u_src_para __pyx_string_tab[146]
#define __pyx_n_u_src_rFonts __pyx_string_tab[147]
#define __pyx_n_u_src_run __pyx_string_tab[148]
#define __pyx_n_u_src_shd __pyx_string_tab[149]
#define __pyx_n_u_src_tc __pyx_string_tab[150]
#define __pyx_n_u_src_tcBorders __pyx_string_tab[151]
#define __pyx_n_u_src_tcPr __pyx_string_tab[152]
#define __pyx_n_u_strike __pyx_string_tab[153]
#define __pyx_n_u_sub __pyx_string_tab[154]
#define __pyx_n_u_table __pyx_string_tab[155]
#define __pyx_n_u_tables __pyx_string_tab[156]
#define __pyx_n_u_template_path __pyx_string_tab[157]
#define __pyx_n_u_text __pyx_string_tab[158]
#define __pyx_n_u_to_be_add __pyx_string_tab[159]
#define __pyx_n_u_underline __pyx_string_tab[160]
#define __pyx_n_u_utils __pyx_string_tab[161]
#define __pyx_n_u_values __pyx_string_tab[162]
#define __pyx_n_u_vertical_alignment __pyx_string_tab[163]
#define __pyx_n_u_width __pyx_string_tab[164]
#define __pyx_n_u_zip __pyx_string_tab[165]
#define __pyx_kp_b_iso88591_Ya_v_Q_HE_AQ_T_v_Q_HE_AQ_S_1A_q __pyx_string_tab[166]
#define __pyx_kp_b_iso88591_A_3ar_j_1_ARxq_A_q_4q_A8_a_cQUU __pyx_string_tab[167]
#define __pyx_kp_b_iso88591_A_7_A_1_Ba_1_AQ_Kq __pyx_string_tab[168]
#define __pyx_kp_b_iso88591_Q_A_G9A_81D_Q_q_b_A_E_YhauTWWXX __pyx_string_tab[169]
#define __pyx_kp_b_iso88591_1_IQj_y_A_haq_4s_1_A_M_A_d_Qa_7 __pyx_string_tab[170]
#define __pyx_int_0 __pyx_number_tab[0]
#define __pyx_int_neg_1 __pyx_number_tab[1]
#define __pyx_int_1 __pyx_number_tab[2]

#if CYTHON_USE_MODULE_STATE
static CYTHON_SMALL_CODE int __pyx_m_clear(PyObject *m) {
  __pyx_mstatetype *clear_module_state = __Pyx_PyModule_GetState(m);
  if (!clear_module_state) return 0;
  Py_CLEAR(clear_module_state->__pyx_d);
  Py_CLEAR(clear_module_state->__pyx_b);
  Py_CLEAR(clear_module_state->__pyx_cython_runtime);
  Py_CLEAR(clear_module_state->__pyx_empty_tuple);
  Py_CLEAR(clear_module_state->__pyx_empty_bytes);
  Py_CLEAR(clear_module_state->__pyx_empty_unicode);
  #if CYTHON_PEP489_MULTI_PHASE_INIT
  __Pyx_State_RemoveModule(NULL);
  #endif
  Py_CLEAR(clear_module_state->__pyx_ptype_5cloze_13template_docx___pyx_defaults);
  Py_CLEAR(clear_module_state->__pyx_type_5cloze_13template_docx___pyx_defaults);
  Py_CLEAR(clear_module_state->__pyx_umethod_PyDict_Type_items.method);
  Py_CLEAR(clear_module_state->__pyx_umethod_PyDict_Type_pop.method);
  Py_CLEAR(clear_module_state->__pyx_umethod_PyDict_Type_values.method);
  for (int i=0; i<1; ++i) { Py_CLEAR(clear_module_state->__pyx_slice[i]); }
  for (int i=0; i<4; ++i) { Py_CLEAR(clear_module_state->__pyx_tuple[i]); }
  for (int i=0; i<5; ++i) { Py_CLEAR(clear_module_state->__pyx_codeobj_tab[i]); }
  for (int i=0; i<171; ++i) { Py_CLEAR(clear_module_state->__pyx_string_tab[i]); }
  for (int i=0; i<3; ++i) { Py_CLEAR(clear_module_state->__pyx_number_tab[i]); }


Py_CLEAR(clear_module_state->__pyx_CommonTypesMetaclassType);


Py_CLEAR(clear_module_state->__pyx_CyFunctionType);


return 0;
}
#endif

#if CYTHON_USE_MODULE_STATE
static CYTHON_SMALL_CODE int __pyx_m_traverse(PyObject *m, visitproc visit, void *arg) {
  __pyx_mstatetype *traverse_module_state = __Pyx_PyModule_GetState(m);
  if (!traverse_module_state) return 0;
  Py_VISIT(traverse_module_state->__pyx_d);
  Py_VISIT(traverse_module_state->__pyx_b);
  Py_VISIT(traverse_module_state->__pyx_cython_runtime);
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_empty_tuple);
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_empty_bytes);
  __Pyx_VISIT_CONST(traverse_module_state->__pyx_empty_unicode);
  Py_VISIT(traverse_module_state->__pyx_ptype_5cloze_13template_docx___pyx_defaults);
  Py_VISIT(traverse_module_state->__pyx_type_5cloze_13template_docx___pyx_defaults);
  Py_VISIT(traverse_module_state->__pyx_umethod_PyDict_Type_items.method);
  Py_VISIT(traverse_module_state->__pyx_umethod_PyDict_Type_pop.method);
  Py_VISIT(traverse_module_state->__pyx_umethod_PyDict_Type_values.method);
  for (int i=0; i<1; ++i) { __Pyx_VISIT_CONST(traverse_module_state->__pyx_slice[i]); }
  for (int i=0; i<4; ++i) { __Pyx_VISIT_CONST(traverse_module_state->__pyx_tuple[i]); }
  for (int i=0; i<5; ++i) { __Pyx_VISIT_CONST(traverse_module_state->__pyx_codeobj_tab[i]); }
  for (int i=0; i<171; ++i) { __Pyx_VISIT_CONST(traverse_module_state->__pyx_string_tab[i]); }
  for (int i=0; i<3; ++i) { __Pyx_VISIT_CONST(traverse_module_state->__pyx_number_tab[i]); }


Py_VISIT(traverse_module_state->__pyx_CommonTypesMetaclassType);


Py_VISIT(traverse_module_state->__pyx_CyFunctionType);


return 0;
}
#endif





static PyObject *__pyx_pw_5cloze_13template_docx_12TemplateDocx_1__init__(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
PyDoc_STRVAR(__pyx_doc_5cloze_13template_docx_12TemplateDocx___init__, "\n        Initialize with a specific placeholder pattern.\n\n        :param pattren: placeholder pattern, must be \047{}\047 or \047{{}}\047.\n        :param recurse: recurse replace placeholder in replaced cell.\n        ");
static PyMethodDef __pyx_mdef_5cloze_13template_docx_12TemplateDocx_1__init__ = {"__init__", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_5cloze_13template_docx_12TemplateDocx_1__init__, __Pyx_METH_FASTCALL|METH_KEYWORDS, __pyx_doc_5cloze_13template_docx_12TemplateDocx___init__};
static PyObject *__pyx_pw_5cloze_13template_docx_12TemplateDocx_1__init__(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_self = 0;
  PyObject *__pyx_v_pattern = 0;
  PyObject *__pyx_v_recurse = 0;
  #if !CYTHON_VECTORCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[3] = {0,0,0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("__init__ (wrapper)", 0);
  #if !CYTHON_VECTORCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_self,&__pyx_mstate_global->__pyx_n_u_pattern,&__pyx_mstate_global->__pyx_n_u_recurse,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len < 0)) __PYX_ERR(0, 10, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  3:
        values[2] = __Pyx_ArgRef_FASTCALL(__pyx_args, 2);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[2])) __PYX_ERR(0, 10, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 10, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 10, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "__init__", 0) < (0)) __PYX_ERR(0, 10, __pyx_L3_error)
      if (!values[1]) values[1] = __Pyx_NewRef(((PyObject *)((PyObject*)__pyx_mstate_global->__pyx_kp_u_)));
      if (!values[2]) values[2] = __Pyx_NewRef(((PyObject *)((PyObject*)Py_False)));
      for (Py_ssize_t i = __pyx_nargs; i < 1; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("__init__", 0, 1, 3, i); __PYX_ERR(0, 10, __pyx_L3_error) }
      }
    } else {
      switch (__pyx_nargs) {
        case  3:
        values[2] = __Pyx_ArgRef_FASTCALL(__pyx_args, 2);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[2])) __PYX_ERR(0, 10, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 10, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 10, __pyx_L3_error)
        break;
        default: goto __pyx_L5_argtuple_error;
      }
      if (!values[1]) values[1] = __Pyx_NewRef(((PyObject *)((PyObject*)__pyx_mstate_global->__pyx_kp_u_)));
      if (!values[2]) values[2] = __Pyx_NewRef(((PyObject *)((PyObject*)Py_False)));
    }
    __pyx_v_self = values[0];
    __pyx_v_pattern = values[1];
    __pyx_v_recurse = values[2];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("__init__", 0, 1, 3, __pyx_nargs); __PYX_ERR(0, 10, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.__init__", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_5cloze_13template_docx_12TemplateDocx___init__(__pyx_self, __pyx_v_self, __pyx_v_pattern, __pyx_v_recurse);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_5cloze_13template_docx_12TemplateDocx___init__(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_self, PyObject *__pyx_v_pattern, PyObject *__pyx_v_recurse) {
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  int __pyx_t_1;
  PyObject *__pyx_t_2 = NULL;
  PyObject *__pyx_t_3 = NULL;
  size_t __pyx_t_4;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("__init__", 0);

  
  __pyx_t_1 = __Pyx_PyObject_CompareBoolEq_object_str(__pyx_v_pattern, __pyx_mstate_global->__pyx_kp_u_, Py_EQ); if (unlikely((__pyx_t_1 < 0))) __PYX_ERR(0, 17, __pyx_L1_error)
  if (__pyx_t_1) {


    
    if (__Pyx_PyObject_SetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern, __pyx_mstate_global->__pyx_kp_u__2) < (0)) __PYX_ERR(0, 18, __pyx_L1_error)

    
    goto __pyx_L3;
  }

  
  __pyx_t_1 = __Pyx_PyObject_CompareBoolEq_object_str(__pyx_v_pattern, __pyx_mstate_global->__pyx_kp_u__3, Py_EQ); if (unlikely((__pyx_t_1 < 0))) __PYX_ERR(0, 19, __pyx_L1_error)
  if (likely(__pyx_t_1)) {


    
    if (__Pyx_PyObject_SetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern, __pyx_mstate_global->__pyx_kp_u__4) < (0)) __PYX_ERR(0, 20, __pyx_L1_error)

    
    goto __pyx_L3;
  }

  
   {
    __pyx_t_3 = NULL;
    __pyx_t_4 = 1;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_3, __pyx_mstate_global->__pyx_kp_u_pattern_must_be_or};
      __pyx_t_2 = __Pyx_PyObject_FastCall((PyObject*)(((PyTypeObject*)PyExc_ValueError)), __pyx_callargs+__pyx_t_4, (2-__pyx_t_4) | (__pyx_t_4*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_3); __pyx_t_3 = 0;
      if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 22, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_2);
    }
    __Pyx_Raise(__pyx_t_2, 0, 0, 0);
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __PYX_ERR(0, 22, __pyx_L1_error)
  }
  __pyx_L3:;

  
  if (__Pyx_PyObject_SetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_recurse, __pyx_v_recurse) < (0)) __PYX_ERR(0, 23, __pyx_L1_error)

  

  
  __pyx_r = Py_None; __Pyx_INCREF(Py_None);
  goto __pyx_L0;
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_3);
  __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.__init__", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_5cloze_13template_docx_12TemplateDocx_3__call__(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
PyDoc_STRVAR(__pyx_doc_5cloze_13template_docx_12TemplateDocx_2__call__, "\n        Execute the template docx.\n        \n        :param template_path: path to docx template, must be endwith .docx file.\n        :param save_path: path to save docx, must be endwith .docx file.\n        :param env: Variables environment - a dict mapping varible names to pandas DataFrame, Series or BytesIO.\n        If not specified use local and global variables of the caller.\n        :return: except placeholders and save the docx to save_path.\n        ");
static PyMethodDef __pyx_mdef_5cloze_13template_docx_12TemplateDocx_3__call__ = {"__call__", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_5cloze_13template_docx_12TemplateDocx_3__call__, __Pyx_METH_FASTCALL|METH_KEYWORDS, __pyx_doc_5cloze_13template_docx_12TemplateDocx_2__call__};
static PyObject *__pyx_pw_5cloze_13template_docx_12TemplateDocx_3__call__(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_self = 0;
  PyObject *__pyx_v_template_path = 0;
  PyObject *__pyx_v_save_path = 0;
  PyObject *__pyx_v_env = 0;
  #if !CYTHON_VECTORCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[4] = {0,0,0,0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("__call__ (wrapper)", 0);
  #if !CYTHON_VECTORCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_self,&__pyx_mstate_global->__pyx_n_u_template_path,&__pyx_mstate_global->__pyx_n_u_save_path,&__pyx_mstate_global->__pyx_n_u_env,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len < 0)) __PYX_ERR(0, 25, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  4:
        values[3] = __Pyx_ArgRef_FASTCALL(__pyx_args, 3);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[3])) __PYX_ERR(0, 25, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  3:
        values[2] = __Pyx_ArgRef_FASTCALL(__pyx_args, 2);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[2])) __PYX_ERR(0, 25, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 25, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 25, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "__call__", 0) < (0)) __PYX_ERR(0, 25, __pyx_L3_error)
      if (!values[3]) values[3] = __Pyx_NewRef(((PyObject *)Py_None));
      for (Py_ssize_t i = __pyx_nargs; i < 3; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("__call__", 0, 3, 4, i); __PYX_ERR(0, 25, __pyx_L3_error) }
      }
    } else {
      switch (__pyx_nargs) {
        case  4:
        values[3] = __Pyx_ArgRef_FASTCALL(__pyx_args, 3);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[3])) __PYX_ERR(0, 25, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  3:
        values[2] = __Pyx_ArgRef_FASTCALL(__pyx_args, 2);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[2])) __PYX_ERR(0, 25, __pyx_L3_error)
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 25, __pyx_L3_error)
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 25, __pyx_L3_error)
        break;
        default: goto __pyx_L5_argtuple_error;
      }
      if (!values[3]) values[3] = __Pyx_NewRef(((PyObject *)Py_None));
    }
    __pyx_v_self = values[0];
    __pyx_v_template_path = values[1];
    __pyx_v_save_path = values[2];
    __pyx_v_env = values[3];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("__call__", 0, 3, 4, __pyx_nargs); __PYX_ERR(0, 25, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.__call__", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_5cloze_13template_docx_12TemplateDocx_2__call__(__pyx_self, __pyx_v_self, __pyx_v_template_path, __pyx_v_save_path, __pyx_v_env);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_5cloze_13template_docx_12TemplateDocx_2__call__(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_self, PyObject *__pyx_v_template_path, PyObject *__pyx_v_save_path, PyObject *__pyx_v_env) {
  PyObject *__pyx_v_doc = NULL;
  PyObject *__pyx_v_except_placeholders = NULL;
  PyObject *__pyx_v_paragraph = NULL;
  PyObject *__pyx_v_table = NULL;
  PyObject *__pyx_v_replaced = NULL;
  PyObject *__pyx_v_i = NULL;
  PyObject *__pyx_v_row = NULL;
  PyObject *__pyx_v_j = NULL;
  PyObject *__pyx_v_cell = NULL;
  PyObject *__pyx_v_placeholders = NULL;
  PyObject *__pyx_v_placeholder = NULL;
  PyObject *__pyx_v__placeholder_ = NULL;
  PyObject *__pyx_v_is_dataframe = NULL;
  PyObject *__pyx_v_values = NULL;
  CYTHON_UNUSED PyObject *__pyx_v__ = NULL;
  PyObject *__pyx_v_k = NULL;
  PyObject *__pyx_v_l = NULL;
  PyObject *__pyx_v_cell_ = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  size_t __pyx_t_3;
  int __pyx_t_4;
  PyObject *__pyx_t_5 = NULL;
  Py_ssize_t __pyx_t_6;
  PyObject *(*__pyx_t_7)(PyObject *);
  PyObject *__pyx_t_8 = NULL;
  Py_ssize_t __pyx_t_9;
  PyObject *(*__pyx_t_10)(PyObject *);
  PyObject *__pyx_t_11 = NULL;
  PyObject *__pyx_t_12 = NULL;
  Py_ssize_t __pyx_t_13;
  PyObject *(*__pyx_t_14)(PyObject *);
  int __pyx_t_15;
  int __pyx_t_16;
  PyObject *__pyx_t_17 = NULL;
  PyObject *__pyx_t_18 = NULL;
  PyObject *__pyx_t_19 = NULL;
  PyObject *__pyx_t_20 = NULL;
  Py_ssize_t __pyx_t_21;
  PyObject *(*__pyx_t_22)(PyObject *);
  PyObject *__pyx_t_23 = NULL;
  PyObject *__pyx_t_24 = NULL;
  PyObject *__pyx_t_25 = NULL;
  int __pyx_t_26;
  Py_ssize_t __pyx_t_27;
  PyObject *__pyx_t_28 = NULL;
  PyObject *(*__pyx_t_29)(PyObject *);
  PyObject *(*__pyx_t_30)(PyObject *);
  PyObject *__pyx_t_31 = NULL;
  PyObject *__pyx_t_32 = NULL;
  PyObject *__pyx_t_33 = NULL;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("__call__", 0);
  __Pyx_INCREF(__pyx_v_env);

  
  #ifndef CYTHON_WITHOUT_ASSERTIONS
  if (unlikely(__pyx_assertions_enabled())) {
    __pyx_t_2 = __pyx_v_template_path;
    __Pyx_INCREF(__pyx_t_2);
    __pyx_t_3 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_mstate_global->__pyx_kp_u_docx};
      __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_endswith, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 35, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    __pyx_t_4 = __Pyx_PyObject_IsTrue(__pyx_t_1); if (unlikely((__pyx_t_4 < 0))) __PYX_ERR(0, 35, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    if (unlikely(!__pyx_t_4)) {
      __Pyx_Raise(((PyObject *)(((PyTypeObject*)PyExc_AssertionError))), __pyx_mstate_global->__pyx_kp_u_template_path_must_be_endwith_do, 0, 0);
      __PYX_ERR(0, 35, __pyx_L1_error)
    }

  }
  #else
  if ((1)); else __PYX_ERR(0, 35, __pyx_L1_error)
  #endif

  
  #ifndef CYTHON_WITHOUT_ASSERTIONS
  if (unlikely(__pyx_assertions_enabled())) {
    __pyx_t_2 = __pyx_v_save_path;
    __Pyx_INCREF(__pyx_t_2);
    __pyx_t_3 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_mstate_global->__pyx_kp_u_docx};
      __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_endswith, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 36, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    __pyx_t_4 = __Pyx_PyObject_IsTrue(__pyx_t_1); if (unlikely((__pyx_t_4 < 0))) __PYX_ERR(0, 36, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    if (unlikely(!__pyx_t_4)) {
      __Pyx_Raise(((PyObject *)(((PyTypeObject*)PyExc_AssertionError))), __pyx_mstate_global->__pyx_kp_u_save_path_must_be_endwith_docx_f, 0, 0);
      __PYX_ERR(0, 36, __pyx_L1_error)
    }

  }
  #else
  if ((1)); else __PYX_ERR(0, 36, __pyx_L1_error)
  #endif

  
  __pyx_t_2 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_Document); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 38, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __pyx_t_3 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_5))) {
    __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_5);
    assert(__pyx_t_2);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
    __Pyx_INCREF(__pyx_t_2);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
    __pyx_t_3 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_v_template_path};
    __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_5, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 38, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_doc = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_4 = (__pyx_v_env == Py_None);
  if (__pyx_t_4) {


    
    __pyx_t_5 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_get_outer_frame_variables); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 41, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_3 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_2))) {
      __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_2);
      assert(__pyx_t_5);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_2);
      __Pyx_INCREF(__pyx_t_5);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_2, __pyx__function);
      __pyx_t_3 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_5, NULL};
      __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_2, __pyx_callargs+__pyx_t_3, (1-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
      __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 41, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    __Pyx_DECREF_SET(__pyx_v_env, __pyx_t_1);
    __pyx_t_1 = 0;

    
  }

  
  __pyx_t_1 = PyList_New(0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 43, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_v_except_placeholders = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_doc, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 46, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  if (likely(PyList_CheckExact(__pyx_t_1)) || PyTuple_CheckExact(__pyx_t_1)) {
    __pyx_t_2 = __pyx_t_1; __Pyx_INCREF(__pyx_t_2);
    __pyx_t_6 = 0;
    __pyx_t_7 = NULL;
  } else {
    __pyx_t_6 = -1; __pyx_t_2 = PyObject_GetIter(__pyx_t_1); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 46, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_7 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_2); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 46, __pyx_L1_error)
  }
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  for (;;) {
    if (likely(!__pyx_t_7)) {
      if (likely(PyList_CheckExact(__pyx_t_2))) {
        {
          Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_2);
          #if !CYTHON_ASSUME_SAFE_SIZE
          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 46, __pyx_L1_error)
          #endif
          if (__pyx_t_6 >= __pyx_temp) break;
        }
        __pyx_t_1 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_2, __pyx_t_6, __Pyx_ReferenceSharing_OwnStrongReference);
        ++__pyx_t_6;
      } else {
        {
          Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_2);
          #if !CYTHON_ASSUME_SAFE_SIZE
          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 46, __pyx_L1_error)
          #endif
          if (__pyx_t_6 >= __pyx_temp) break;
        }
        #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
        __pyx_t_1 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_2, __pyx_t_6));
        #else
        __pyx_t_1 = __Pyx_PySequence_ITEM(__pyx_t_2, __pyx_t_6);
        #endif
        ++__pyx_t_6;
      }
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 46, __pyx_L1_error)
    } else {
      __pyx_t_1 = __pyx_t_7(__pyx_t_2);
      if (unlikely(!__pyx_t_1)) {
        PyObject* exc_type = PyErr_Occurred();
        if (exc_type) {
          if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 46, __pyx_L1_error)
          PyErr_Clear();
        }
        break;
      }
    }
    __Pyx_GOTREF(__pyx_t_1);
    __Pyx_XDECREF_SET(__pyx_v_paragraph, __pyx_t_1);
    __pyx_t_1 = 0;

    
    __pyx_t_5 = __pyx_v_self;
    __Pyx_INCREF(__pyx_t_5);
    __pyx_t_3 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_v_paragraph};
      __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_concat_run, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 47, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    __Pyx_DECREF_SET(__pyx_v_paragraph, __pyx_t_1);
    __pyx_t_1 = 0;

    
    __pyx_t_5 = __pyx_v_self;
    __Pyx_INCREF(__pyx_t_5);
    __pyx_t_3 = 0;
    {
      PyObject *__pyx_callargs[3] = {__pyx_t_5, __pyx_v_paragraph, __pyx_v_env};
      __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_replace_paragraph, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 48, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    __pyx_t_5 = __Pyx_PyNumber_InPlaceAdd_object_object(__pyx_v_except_placeholders, __pyx_t_1); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 48, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_5);
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    __Pyx_DECREF_SET(__pyx_v_except_placeholders, __pyx_t_5);
    __pyx_t_5 = 0;

    
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_v_doc, __pyx_mstate_global->__pyx_n_u_tables); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 51, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  if (likely(PyList_CheckExact(__pyx_t_2)) || PyTuple_CheckExact(__pyx_t_2)) {
    __pyx_t_5 = __pyx_t_2; __Pyx_INCREF(__pyx_t_5);
    __pyx_t_6 = 0;
    __pyx_t_7 = NULL;
  } else {
    __pyx_t_6 = -1; __pyx_t_5 = PyObject_GetIter(__pyx_t_2); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 51, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_5);
    __pyx_t_7 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_5); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 51, __pyx_L1_error)
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  for (;;) {
    if (likely(!__pyx_t_7)) {
      if (likely(PyList_CheckExact(__pyx_t_5))) {
        {
          Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_5);
          #if !CYTHON_ASSUME_SAFE_SIZE
          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 51, __pyx_L1_error)
          #endif
          if (__pyx_t_6 >= __pyx_temp) break;
        }
        __pyx_t_2 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_5, __pyx_t_6, __Pyx_ReferenceSharing_OwnStrongReference);
        ++__pyx_t_6;
      } else {
        {
          Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_5);
          #if !CYTHON_ASSUME_SAFE_SIZE
          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 51, __pyx_L1_error)
          #endif
          if (__pyx_t_6 >= __pyx_temp) break;
        }
        #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
        __pyx_t_2 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_5, __pyx_t_6));
        #else
        __pyx_t_2 = __Pyx_PySequence_ITEM(__pyx_t_5, __pyx_t_6);
        #endif
        ++__pyx_t_6;
      }
      if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 51, __pyx_L1_error)
    } else {
      __pyx_t_2 = __pyx_t_7(__pyx_t_5);
      if (unlikely(!__pyx_t_2)) {
        PyObject* exc_type = PyErr_Occurred();
        if (exc_type) {
          if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 51, __pyx_L1_error)
          PyErr_Clear();
        }
        break;
      }
    }
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_XDECREF_SET(__pyx_v_table, __pyx_t_2);
    __pyx_t_2 = 0;

    
    __pyx_t_2 = PyList_New(0); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 52, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __Pyx_XDECREF_SET(__pyx_v_replaced, ((PyObject*)__pyx_t_2));
    __pyx_t_2 = 0;

    
    __Pyx_INCREF(__pyx_mstate_global->__pyx_int_0);
    __pyx_t_2 = __pyx_mstate_global->__pyx_int_0;
    __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_table, __pyx_mstate_global->__pyx_n_u_rows); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 53, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    if (likely(PyList_CheckExact(__pyx_t_1)) || PyTuple_CheckExact(__pyx_t_1)) {
      __pyx_t_8 = __pyx_t_1; __Pyx_INCREF(__pyx_t_8);
      __pyx_t_9 = 0;
      __pyx_t_10 = NULL;
    } else {
      __pyx_t_9 = -1; __pyx_t_8 = PyObject_GetIter(__pyx_t_1); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 53, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_8);
      __pyx_t_10 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_8); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 53, __pyx_L1_error)
    }
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    for (;;) {
      if (likely(!__pyx_t_10)) {
        if (likely(PyList_CheckExact(__pyx_t_8))) {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_8);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 53, __pyx_L1_error)
            #endif
            if (__pyx_t_9 >= __pyx_temp) break;
          }
          __pyx_t_1 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_8, __pyx_t_9, __Pyx_ReferenceSharing_OwnStrongReference);
          ++__pyx_t_9;
        } else {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_8);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 53, __pyx_L1_error)
            #endif
            if (__pyx_t_9 >= __pyx_temp) break;
          }
          #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
          __pyx_t_1 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_8, __pyx_t_9));
          #else
          __pyx_t_1 = __Pyx_PySequence_ITEM(__pyx_t_8, __pyx_t_9);
          #endif
          ++__pyx_t_9;
        }
        if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 53, __pyx_L1_error)
      } else {
        __pyx_t_1 = __pyx_t_10(__pyx_t_8);
        if (unlikely(!__pyx_t_1)) {
          PyObject* exc_type = PyErr_Occurred();
          if (exc_type) {
            if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 53, __pyx_L1_error)
            PyErr_Clear();
          }
          break;
        }
      }
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_XDECREF_SET(__pyx_v_row, __pyx_t_1);
      __pyx_t_1 = 0;
      __Pyx_INCREF(__pyx_t_2);
      __Pyx_XDECREF_SET(__pyx_v_i, __pyx_t_2);
      __pyx_t_1 = __Pyx_PyLong_AddObjC(__pyx_t_2, __pyx_mstate_global->__pyx_int_1, 1, 0, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 53, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_DECREF(__pyx_t_2);
      __pyx_t_2 = __pyx_t_1;
      __pyx_t_1 = 0;

      
      __Pyx_INCREF(__pyx_mstate_global->__pyx_int_0);
      __pyx_t_1 = __pyx_mstate_global->__pyx_int_0;
      __pyx_t_11 = __Pyx_PyObject_GetAttrStr(__pyx_v_row, __pyx_mstate_global->__pyx_n_u_cells); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 54, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_11);
      if (likely(PyList_CheckExact(__pyx_t_11)) || PyTuple_CheckExact(__pyx_t_11)) {
        __pyx_t_12 = __pyx_t_11; __Pyx_INCREF(__pyx_t_12);
        __pyx_t_13 = 0;
        __pyx_t_14 = NULL;
      } else {
        __pyx_t_13 = -1; __pyx_t_12 = PyObject_GetIter(__pyx_t_11); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 54, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_12);
        __pyx_t_14 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_12); if (unlikely(!__pyx_t_14)) __PYX_ERR(0, 54, __pyx_L1_error)
      }
      __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
      for (;;) {
        if (likely(!__pyx_t_14)) {
          if (likely(PyList_CheckExact(__pyx_t_12))) {
            {
              Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_12);
              #if !CYTHON_ASSUME_SAFE_SIZE
              if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 54, __pyx_L1_error)
              #endif
              if (__pyx_t_13 >= __pyx_temp) break;
            }
            __pyx_t_11 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_12, __pyx_t_13, __Pyx_ReferenceSharing_OwnStrongReference);
            ++__pyx_t_13;
          } else {
            {
              Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_12);
              #if !CYTHON_ASSUME_SAFE_SIZE
              if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 54, __pyx_L1_error)
              #endif
              if (__pyx_t_13 >= __pyx_temp) break;
            }
            #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
            __pyx_t_11 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_12, __pyx_t_13));
            #else
            __pyx_t_11 = __Pyx_PySequence_ITEM(__pyx_t_12, __pyx_t_13);
            #endif
            ++__pyx_t_13;
          }
          if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 54, __pyx_L1_error)
        } else {
          __pyx_t_11 = __pyx_t_14(__pyx_t_12);
          if (unlikely(!__pyx_t_11)) {
            PyObject* exc_type = PyErr_Occurred();
            if (exc_type) {
              if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 54, __pyx_L1_error)
              PyErr_Clear();
            }
            break;
          }
        }
        __Pyx_GOTREF(__pyx_t_11);
        __Pyx_XDECREF_SET(__pyx_v_cell, __pyx_t_11);
        __pyx_t_11 = 0;
        __Pyx_INCREF(__pyx_t_1);
        __Pyx_XDECREF_SET(__pyx_v_j, __pyx_t_1);
        __pyx_t_11 = __Pyx_PyLong_AddObjC(__pyx_t_1, __pyx_mstate_global->__pyx_int_1, 1, 0, 0); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 54, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_11);
        __Pyx_DECREF(__pyx_t_1);
        __pyx_t_1 = __pyx_t_11;
        __pyx_t_11 = 0;

        
        __pyx_t_11 = PyTuple_New(2); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 55, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_11);
        __Pyx_INCREF(__pyx_v_i);
        __Pyx_GIVEREF(__pyx_v_i);
        if (__Pyx_PyTuple_SET_ITEM(__pyx_t_11, 0, __pyx_v_i) != (0)) __PYX_ERR(0, 55, __pyx_L1_error);
        __Pyx_INCREF(__pyx_v_j);
        __Pyx_GIVEREF(__pyx_v_j);
        if (__Pyx_PyTuple_SET_ITEM(__pyx_t_11, 1, __pyx_v_j) != (0)) __PYX_ERR(0, 55, __pyx_L1_error);
        __pyx_t_15 = (__Pyx_PySequence_ContainsTF(__pyx_t_11, __pyx_v_replaced, Py_EQ)); if (unlikely((__pyx_t_15 < 0))) __PYX_ERR(0, 55, __pyx_L1_error)
        __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
        if (__pyx_t_15) {

        } else {

          __pyx_t_4 = __pyx_t_15;

          goto __pyx_L14_bool_binop_done;
        }
        __pyx_t_11 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_recurse); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 55, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_11);
        __pyx_t_15 = __Pyx_PyObject_IsTrue(__pyx_t_11); if (unlikely((__pyx_t_15 < 0))) __PYX_ERR(0, 55, __pyx_L1_error)
        __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
        __pyx_t_16 = (!__pyx_t_15);



        __pyx_t_4 = __pyx_t_16;

        __pyx_L14_bool_binop_done:;
        if (__pyx_t_4) {


          
          goto __pyx_L11_continue;

          
        }

        
        __pyx_t_17 = NULL;
        __Pyx_GetModuleGlobalName(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 58, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_18);
        __pyx_t_19 = __Pyx_PyObject_GetAttrStr(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_findall); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 58, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_19);
        __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
        __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 58, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_18);
        __pyx_t_20 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 58, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_20);
        __pyx_t_3 = 1;
        #if CYTHON_UNPACK_METHODS
        if (unlikely(PyMethod_Check(__pyx_t_19))) {
          __pyx_t_17 = PyMethod_GET_SELF(__pyx_t_19);
          assert(__pyx_t_17);
          PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_19);
          __Pyx_INCREF(__pyx_t_17);
          __Pyx_INCREF(__pyx__function);
          __Pyx_DECREF_SET(__pyx_t_19, __pyx__function);
          __pyx_t_3 = 0;
        }
        #endif
        {
          PyObject *__pyx_callargs[3] = {__pyx_t_17, __pyx_t_18, __pyx_t_20};
          __pyx_t_11 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_19, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_17); __pyx_t_17 = 0;
          __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
          __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
          __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
          if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 58, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_11);
        }
        __Pyx_XDECREF_SET(__pyx_v_placeholders, __pyx_t_11);
        __pyx_t_11 = 0;

        
        if (likely(PyList_CheckExact(__pyx_v_placeholders)) || PyTuple_CheckExact(__pyx_v_placeholders)) {
          __pyx_t_11 = __pyx_v_placeholders; __Pyx_INCREF(__pyx_t_11);
          __pyx_t_21 = 0;
          __pyx_t_22 = NULL;
        } else {
          __pyx_t_21 = -1; __pyx_t_11 = PyObject_GetIter(__pyx_v_placeholders); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 59, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_11);
          __pyx_t_22 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_11); if (unlikely(!__pyx_t_22)) __PYX_ERR(0, 59, __pyx_L1_error)
        }
        for (;;) {
          if (likely(!__pyx_t_22)) {
            if (likely(PyList_CheckExact(__pyx_t_11))) {
              {
                Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_11);
                #if !CYTHON_ASSUME_SAFE_SIZE
                if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 59, __pyx_L1_error)
                #endif
                if (__pyx_t_21 >= __pyx_temp) break;
              }
              __pyx_t_19 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_11, __pyx_t_21, __Pyx_ReferenceSharing_OwnStrongReference);
              ++__pyx_t_21;
            } else {
              {
                Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_11);
                #if !CYTHON_ASSUME_SAFE_SIZE
                if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 59, __pyx_L1_error)
                #endif
                if (__pyx_t_21 >= __pyx_temp) break;
              }
              #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
              __pyx_t_19 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_11, __pyx_t_21));
              #else
              __pyx_t_19 = __Pyx_PySequence_ITEM(__pyx_t_11, __pyx_t_21);
              #endif
              ++__pyx_t_21;
            }
            if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 59, __pyx_L1_error)
          } else {
            __pyx_t_19 = __pyx_t_22(__pyx_t_11);
            if (unlikely(!__pyx_t_19)) {
              PyObject* exc_type = PyErr_Occurred();
              if (exc_type) {
                if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 59, __pyx_L1_error)
                PyErr_Clear();
              }
              break;
            }
          }
          __Pyx_GOTREF(__pyx_t_19);
          __Pyx_XDECREF_SET(__pyx_v_placeholder, __pyx_t_19);
          __pyx_t_19 = 0;

          
          __pyx_t_20 = NULL;
          __Pyx_GetModuleGlobalName(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 60, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_18);
          __pyx_t_17 = __Pyx_PyObject_GetAttrStr(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_sub); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 60, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_17);
          __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
          __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 60, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_18);
          __pyx_t_3 = 1;
          #if CYTHON_UNPACK_METHODS
          if (unlikely(PyMethod_Check(__pyx_t_17))) {
            __pyx_t_20 = PyMethod_GET_SELF(__pyx_t_17);
            assert(__pyx_t_20);
            PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_17);
            __Pyx_INCREF(__pyx_t_20);
            __Pyx_INCREF(__pyx__function);
            __Pyx_DECREF_SET(__pyx_t_17, __pyx__function);
            __pyx_t_3 = 0;
          }
          #endif
          {
            PyObject *__pyx_callargs[4] = {__pyx_t_20, __pyx_mstate_global->__pyx_kp_u__6, __pyx_mstate_global->__pyx_kp_u_s, __pyx_t_18};
            __pyx_t_19 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_17, __pyx_callargs+__pyx_t_3, (4-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_20); __pyx_t_20 = 0;
            __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
            __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
            if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 60, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_19);
          }
          __pyx_t_17 = __Pyx_PyObject_GetAttrStr(__pyx_t_19, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 60, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_17);
          __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
          __pyx_t_19 = __Pyx_PyObject_Call(__pyx_t_17, __pyx_mstate_global->__pyx_tuple[0], NULL); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 60, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_19);
          __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
          __pyx_t_17 = PyNumber_Remainder(__pyx_t_19, __pyx_v_placeholder); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 60, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_17);
          __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
          __Pyx_XDECREF_SET(__pyx_v__placeholder_, __pyx_t_17);
          __pyx_t_17 = 0;

          
          __pyx_t_17 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 62, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_17);
          __pyx_t_4 = __Pyx_PyObject_CompareBoolEq_object_object(__pyx_v__placeholder_, __pyx_t_17, Py_EQ); if (unlikely((__pyx_t_4 < 0))) __PYX_ERR(0, 62, __pyx_L1_error)
          __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
          if (__pyx_t_4) {


            
            {
              __Pyx_PyThreadState_declare
              __Pyx_PyThreadState_assign
              __Pyx_ExceptionSave(&__pyx_t_23, &__pyx_t_24, &__pyx_t_25);
              __Pyx_XGOTREF(__pyx_t_23);
              __Pyx_XGOTREF(__pyx_t_24);
              __Pyx_XGOTREF(__pyx_t_25);
               {

                
                __pyx_t_19 = NULL;
                __pyx_t_18 = __Pyx_GetItemInt(__pyx_v_placeholders, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 64, __pyx_L19_error)
                __Pyx_GOTREF(__pyx_t_18);
                __pyx_t_3 = 1;
                {
                  PyObject *__pyx_callargs[3] = {__pyx_t_19, __pyx_t_18, __pyx_v_env};
                  __pyx_t_17 = __Pyx_PyObject_FastCall((PyObject*)__pyx_builtin_eval, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                  if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 64, __pyx_L19_error)
                  __Pyx_GOTREF(__pyx_t_17);
                }
                __Pyx_GetModuleGlobalName(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_pandas); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 64, __pyx_L19_error)
                __Pyx_GOTREF(__pyx_t_18);
                __pyx_t_19 = __Pyx_PyObject_GetAttrStr(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_DataFrame); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 64, __pyx_L19_error)
                __Pyx_GOTREF(__pyx_t_19);
                __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                __pyx_t_4 = PyObject_IsInstance(__pyx_t_17, __pyx_t_19); if (unlikely(__pyx_t_4 == ((int)-1))) __PYX_ERR(0, 64, __pyx_L19_error)
                __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
                __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
                __pyx_t_19 = __Pyx_PyBool_FromLong(__pyx_t_4); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 64, __pyx_L19_error)
                __Pyx_GOTREF(__pyx_t_19);

                __Pyx_XDECREF_SET(__pyx_v_is_dataframe, __pyx_t_19);
                __pyx_t_19 = 0;

                
              }
              __Pyx_XDECREF(__pyx_t_23); __pyx_t_23 = 0;
              __Pyx_XDECREF(__pyx_t_24); __pyx_t_24 = 0;
              __Pyx_XDECREF(__pyx_t_25); __pyx_t_25 = 0;
              goto __pyx_L26_try_end;
              __pyx_L19_error:;
              __Pyx_XDECREF(__pyx_t_17); __pyx_t_17 = 0;
              __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
              __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
              __Pyx_XDECREF(__pyx_t_20); __pyx_t_20 = 0;

              
               {
                __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.__call__", __pyx_clineno, __pyx_lineno, __pyx_filename);
                if (__Pyx_GetException(&__pyx_t_19, &__pyx_t_17, &__pyx_t_18) < 0) __PYX_ERR(0, 65, __pyx_L21_except_error)
                __Pyx_XGOTREF(__pyx_t_19);
                __Pyx_XGOTREF(__pyx_t_17);
                __Pyx_XGOTREF(__pyx_t_18);

                
                __Pyx_INCREF(Py_None);
                __Pyx_XDECREF_SET(__pyx_v_is_dataframe, Py_None);

                
                __pyx_t_26 = __Pyx_PyObject_Append(__pyx_v_except_placeholders, __pyx_v_placeholder); if (unlikely(__pyx_t_26 == ((int)-1))) __PYX_ERR(0, 67, __pyx_L21_except_error)

                __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
                __Pyx_XDECREF(__pyx_t_17); __pyx_t_17 = 0;
                __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
                goto __pyx_L20_exception_handled;
              }

              
              __pyx_L21_except_error:;
              __Pyx_XGIVEREF(__pyx_t_23);
              __Pyx_XGIVEREF(__pyx_t_24);
              __Pyx_XGIVEREF(__pyx_t_25);
              __Pyx_ExceptionReset(__pyx_t_23, __pyx_t_24, __pyx_t_25);
              goto __pyx_L1_error;
              __pyx_L20_exception_handled:;
              __Pyx_XGIVEREF(__pyx_t_23);
              __Pyx_XGIVEREF(__pyx_t_24);
              __Pyx_XGIVEREF(__pyx_t_25);
              __Pyx_ExceptionReset(__pyx_t_23, __pyx_t_24, __pyx_t_25);
              __pyx_L26_try_end:;
            }

            
            __pyx_t_4 = __Pyx_PyObject_IsTrue(__pyx_v_is_dataframe); if (unlikely((__pyx_t_4 < 0))) __PYX_ERR(0, 69, __pyx_L1_error)
            if (__pyx_t_4) {


              
              __pyx_t_17 = NULL;
              __pyx_t_19 = __Pyx_GetItemInt(__pyx_v_placeholders, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 70, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_19);
              __pyx_t_3 = 1;
              {
                PyObject *__pyx_callargs[3] = {__pyx_t_17, __pyx_t_19, __pyx_v_env};
                __pyx_t_18 = __Pyx_PyObject_FastCall((PyObject*)__pyx_builtin_eval, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                __Pyx_XDECREF(__pyx_t_17); __pyx_t_17 = 0;
                __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
                if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 70, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_18);
              }
              __pyx_t_19 = __Pyx_PyObject_GetAttrStr(__pyx_t_18, __pyx_mstate_global->__pyx_n_u_values); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 70, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_19);
              __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
              __Pyx_XDECREF_SET(__pyx_v_values, __pyx_t_19);
              __pyx_t_19 = 0;

              
              __pyx_t_18 = NULL;
              __pyx_t_17 = __Pyx_PyObject_GetAttrStr(__pyx_v_values, __pyx_mstate_global->__pyx_n_u_shape); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 71, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_17);
              __pyx_t_20 = __Pyx_GetItemInt(__pyx_t_17, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 71, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_20);
              __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
              __pyx_t_17 = __Pyx_PyObject_GetAttrStr(__pyx_v_table, __pyx_mstate_global->__pyx_n_u_rows); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 71, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_17);
              __pyx_t_27 = PyObject_Length(__pyx_t_17); if (unlikely(__pyx_t_27 == ((Py_ssize_t)-1))) __PYX_ERR(0, 71, __pyx_L1_error)
              __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
              __pyx_t_17 = PyLong_FromSsize_t(__pyx_t_27); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 71, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_17);

              __pyx_t_28 = __Pyx_PyNumber_Subtract_object_int(__pyx_t_20, __pyx_t_17); if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 71, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_28);
              __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
              __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
              __pyx_t_17 = __Pyx_PyNumber_Add_object_object(__pyx_t_28, __pyx_v_i); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 71, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_17);
              __Pyx_DECREF(__pyx_t_28); __pyx_t_28 = 0;
              __pyx_t_3 = 1;
              {
                PyObject *__pyx_callargs[2] = {__pyx_t_18, __pyx_t_17};
                __pyx_t_19 = __Pyx_PyObject_FastCall((PyObject*)(&PyRange_Type), __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
                __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
                if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 71, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_19);
              }
              __pyx_t_17 = PyObject_GetIter(__pyx_t_19); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 71, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_17);
              __pyx_t_29 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_17); if (unlikely(!__pyx_t_29)) __PYX_ERR(0, 71, __pyx_L1_error)
              __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
              for (;;) {
                {
                  __pyx_t_19 = __pyx_t_29(__pyx_t_17);
                  if (unlikely(!__pyx_t_19)) {
                    PyObject* exc_type = PyErr_Occurred();
                    if (exc_type) {
                      if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 71, __pyx_L1_error)
                      PyErr_Clear();
                    }
                    break;
                  }
                }
                __Pyx_GOTREF(__pyx_t_19);
                __Pyx_XDECREF_SET(__pyx_v__, __pyx_t_19);
                __pyx_t_19 = 0;

                
                __pyx_t_18 = __pyx_v_table;
                __Pyx_INCREF(__pyx_t_18);
                __pyx_t_3 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_18, NULL};
                  __pyx_t_19 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_add_row, __pyx_callargs+__pyx_t_3, (1-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
                  if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 72, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_19);
                }
                __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;

                
              }
              __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;

              
              __pyx_t_19 = NULL;
              __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_v_values, __pyx_mstate_global->__pyx_n_u_shape); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 73, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_18);
              __pyx_t_28 = __Pyx_GetItemInt(__pyx_t_18, 1, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 73, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_28);
              __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
              __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_v_table, __pyx_mstate_global->__pyx_n_u_columns); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 73, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_18);
              __pyx_t_27 = PyObject_Length(__pyx_t_18); if (unlikely(__pyx_t_27 == ((Py_ssize_t)-1))) __PYX_ERR(0, 73, __pyx_L1_error)
              __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
              __pyx_t_18 = PyLong_FromSsize_t(__pyx_t_27); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 73, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_18);

              __pyx_t_20 = __Pyx_PyNumber_Subtract_object_int(__pyx_t_28, __pyx_t_18); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 73, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_20);
              __Pyx_DECREF(__pyx_t_28); __pyx_t_28 = 0;
              __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
              __pyx_t_18 = __Pyx_PyNumber_Add_object_object(__pyx_t_20, __pyx_v_j); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 73, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_18);
              __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
              __pyx_t_3 = 1;
              {
                PyObject *__pyx_callargs[2] = {__pyx_t_19, __pyx_t_18};
                __pyx_t_17 = __Pyx_PyObject_FastCall((PyObject*)(&PyRange_Type), __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
                __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 73, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_17);
              }
              __pyx_t_18 = PyObject_GetIter(__pyx_t_17); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 73, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_18);
              __pyx_t_29 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_18); if (unlikely(!__pyx_t_29)) __PYX_ERR(0, 73, __pyx_L1_error)
              __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
              for (;;) {
                {
                  __pyx_t_17 = __pyx_t_29(__pyx_t_18);
                  if (unlikely(!__pyx_t_17)) {
                    PyObject* exc_type = PyErr_Occurred();
                    if (exc_type) {
                      if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 73, __pyx_L1_error)
                      PyErr_Clear();
                    }
                    break;
                  }
                }
                __Pyx_GOTREF(__pyx_t_17);
                __Pyx_XDECREF_SET(__pyx_v__, __pyx_t_17);
                __pyx_t_17 = 0;

                
                __pyx_t_19 = __pyx_v_table;
                __Pyx_INCREF(__pyx_t_19);
                __pyx_t_20 = __Pyx_PyObject_GetAttrStr(__pyx_v_table, __pyx_mstate_global->__pyx_n_u_columns); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 74, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_20);
                __pyx_t_28 = __Pyx_GetItemInt(__pyx_t_20, -1L, long, 1, __Pyx_PyLong_From_long, 1, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 74, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_28);
                __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
                __pyx_t_20 = __Pyx_PyObject_GetAttrStr(__pyx_t_28, __pyx_mstate_global->__pyx_n_u_width); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 74, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_20);
                __Pyx_DECREF(__pyx_t_28); __pyx_t_28 = 0;
                __pyx_t_3 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_19, __pyx_t_20};
                  #if CYTHON_VECTORCALL
                  __pyx_t_28 = __pyx_mstate_global->__pyx_tuple[1];
                  if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 74, __pyx_L1_error)
                  __Pyx_INCREF(__pyx_t_28);
                  #else
                  {
                    PyObject *__pyx_temp[1] = {__pyx_mstate_global->__pyx_n_u_width};
                    __pyx_t_28 = __Pyx_MakeKwargDict(__pyx_temp, __pyx_callargs+1, 1);
                    if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 74, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_28);
                  }
                  #endif
                  __pyx_t_17 = __Pyx_Object_VectorcallMethodKwds((PyObject*)__pyx_mstate_global->__pyx_n_u_add_column, __pyx_callargs+__pyx_t_3, (1-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET), __pyx_t_28);
                  __Pyx_XDECREF(__pyx_t_19); __pyx_t_19 = 0;
                  __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
                  __Pyx_DECREF(__pyx_t_28); __pyx_t_28 = 0;
                  if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 74, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_17);
                }
                __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;

                
              }
              __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;

              
              __pyx_t_17 = NULL;
              __pyx_t_28 = __Pyx_PyObject_GetAttrStr(__pyx_v_values, __pyx_mstate_global->__pyx_n_u_shape); if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 76, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_28);
              __pyx_t_20 = __Pyx_GetItemInt(__pyx_t_28, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 76, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_20);
              __Pyx_DECREF(__pyx_t_28); __pyx_t_28 = 0;
              __pyx_t_3 = 1;
              {
                PyObject *__pyx_callargs[2] = {__pyx_t_17, __pyx_t_20};
                __pyx_t_18 = __Pyx_PyObject_FastCall((PyObject*)(&PyRange_Type), __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                __Pyx_XDECREF(__pyx_t_17); __pyx_t_17 = 0;
                __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
                if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 76, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_18);
              }
              __pyx_t_20 = PyObject_GetIter(__pyx_t_18); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 76, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_20);
              __pyx_t_29 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_20); if (unlikely(!__pyx_t_29)) __PYX_ERR(0, 76, __pyx_L1_error)
              __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
              for (;;) {
                {
                  __pyx_t_18 = __pyx_t_29(__pyx_t_20);
                  if (unlikely(!__pyx_t_18)) {
                    PyObject* exc_type = PyErr_Occurred();
                    if (exc_type) {
                      if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 76, __pyx_L1_error)
                      PyErr_Clear();
                    }
                    break;
                  }
                }
                __Pyx_GOTREF(__pyx_t_18);
                __Pyx_XDECREF_SET(__pyx_v_k, __pyx_t_18);
                __pyx_t_18 = 0;

                
                __pyx_t_17 = NULL;
                __pyx_t_28 = __Pyx_PyObject_GetAttrStr(__pyx_v_values, __pyx_mstate_global->__pyx_n_u_shape); if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 77, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_28);
                __pyx_t_19 = __Pyx_GetItemInt(__pyx_t_28, 1, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 77, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_19);
                __Pyx_DECREF(__pyx_t_28); __pyx_t_28 = 0;
                __pyx_t_3 = 1;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_17, __pyx_t_19};
                  __pyx_t_18 = __Pyx_PyObject_FastCall((PyObject*)(&PyRange_Type), __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_17); __pyx_t_17 = 0;
                  __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
                  if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 77, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_18);
                }
                __pyx_t_19 = PyObject_GetIter(__pyx_t_18); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 77, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_19);
                __pyx_t_30 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_19); if (unlikely(!__pyx_t_30)) __PYX_ERR(0, 77, __pyx_L1_error)
                __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                for (;;) {
                  {
                    __pyx_t_18 = __pyx_t_30(__pyx_t_19);
                    if (unlikely(!__pyx_t_18)) {
                      PyObject* exc_type = PyErr_Occurred();
                      if (exc_type) {
                        if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 77, __pyx_L1_error)
                        PyErr_Clear();
                      }
                      break;
                    }
                  }
                  __Pyx_GOTREF(__pyx_t_18);
                  __Pyx_XDECREF_SET(__pyx_v_l, __pyx_t_18);
                  __pyx_t_18 = 0;

                  
                  __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_v_table, __pyx_mstate_global->__pyx_n_u_rows); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 78, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_18);
                  __pyx_t_17 = __Pyx_PyNumber_Add_object_object(__pyx_v_i, __pyx_v_k); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 78, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_17);
                  __pyx_t_28 = __Pyx_PyObject_GetItem(__pyx_t_18, __pyx_t_17); if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 78, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_28);
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                  __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
                  __pyx_t_17 = __Pyx_PyObject_GetAttrStr(__pyx_t_28, __pyx_mstate_global->__pyx_n_u_cells); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 78, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_17);
                  __Pyx_DECREF(__pyx_t_28); __pyx_t_28 = 0;
                  __pyx_t_28 = __Pyx_PyNumber_Add_object_object(__pyx_v_j, __pyx_v_l); if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 78, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_28);
                  __pyx_t_18 = __Pyx_PyObject_GetItem(__pyx_t_17, __pyx_t_28); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 78, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_18);
                  __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
                  __Pyx_DECREF(__pyx_t_28); __pyx_t_28 = 0;
                  __Pyx_XDECREF_SET(__pyx_v_cell_, __pyx_t_18);
                  __pyx_t_18 = 0;

                  
                  __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell_, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 79, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_18);
                  __pyx_t_28 = __Pyx_GetItemInt(__pyx_t_18, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_28)) __PYX_ERR(0, 79, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_28);
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                  __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_t_28, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 79, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_18);
                  __Pyx_DECREF(__pyx_t_28); __pyx_t_28 = 0;
                  __pyx_t_27 = PyObject_Length(__pyx_t_18); if (unlikely(__pyx_t_27 == ((Py_ssize_t)-1))) __PYX_ERR(0, 79, __pyx_L1_error)
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                  __pyx_t_4 = (__pyx_t_27 == 0);


                  if (__pyx_t_4) {


                    
                    __pyx_t_28 = NULL;
                    __Pyx_GetModuleGlobalName(__pyx_t_17, __pyx_mstate_global->__pyx_n_u_cell_format_painter); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 80, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_17);
                    __pyx_t_3 = 1;
                    #if CYTHON_UNPACK_METHODS
                    if (unlikely(PyMethod_Check(__pyx_t_17))) {
                      __pyx_t_28 = PyMethod_GET_SELF(__pyx_t_17);
                      assert(__pyx_t_28);
                      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_17);
                      __Pyx_INCREF(__pyx_t_28);
                      __Pyx_INCREF(__pyx__function);
                      __Pyx_DECREF_SET(__pyx_t_17, __pyx__function);
                      __pyx_t_3 = 0;
                    }
                    #endif
                    {
                      PyObject *__pyx_callargs[3] = {__pyx_t_28, __pyx_v_cell_, __pyx_v_cell};
                      __pyx_t_18 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_17, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                      __Pyx_XDECREF(__pyx_t_28); __pyx_t_28 = 0;
                      __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
                      if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 80, __pyx_L1_error)
                      __Pyx_GOTREF(__pyx_t_18);
                    }
                    __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;

                    
                    __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell_, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_18);
                    __pyx_t_17 = __Pyx_GetItemInt(__pyx_t_18, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_17);
                    __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                    __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_t_17, __pyx_mstate_global->__pyx_n_u_element); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_18);
                    __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
                    __pyx_t_28 = NULL;
                    __Pyx_GetModuleGlobalName(__pyx_t_31, __pyx_mstate_global->__pyx_n_u_copy); if (unlikely(!__pyx_t_31)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_31);
                    __pyx_t_32 = __Pyx_PyObject_GetAttrStr(__pyx_t_31, __pyx_mstate_global->__pyx_n_u_deepcopy); if (unlikely(!__pyx_t_32)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_32);
                    __Pyx_DECREF(__pyx_t_31); __pyx_t_31 = 0;
                    __pyx_t_31 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_31)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_31);
                    __pyx_t_33 = __Pyx_GetItemInt(__pyx_t_31, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_33)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_33);
                    __Pyx_DECREF(__pyx_t_31); __pyx_t_31 = 0;
                    __pyx_t_31 = __Pyx_PyObject_GetAttrStr(__pyx_t_33, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_31)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_31);
                    __Pyx_DECREF(__pyx_t_33); __pyx_t_33 = 0;
                    __pyx_t_33 = __Pyx_GetItemInt(__pyx_t_31, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_33)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_33);
                    __Pyx_DECREF(__pyx_t_31); __pyx_t_31 = 0;
                    __pyx_t_31 = __Pyx_PyObject_GetAttrStr(__pyx_t_33, __pyx_mstate_global->__pyx_n_u_element); if (unlikely(!__pyx_t_31)) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_GOTREF(__pyx_t_31);
                    __Pyx_DECREF(__pyx_t_33); __pyx_t_33 = 0;
                    __pyx_t_3 = 1;
                    #if CYTHON_UNPACK_METHODS
                    if (unlikely(PyMethod_Check(__pyx_t_32))) {
                      __pyx_t_28 = PyMethod_GET_SELF(__pyx_t_32);
                      assert(__pyx_t_28);
                      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_32);
                      __Pyx_INCREF(__pyx_t_28);
                      __Pyx_INCREF(__pyx__function);
                      __Pyx_DECREF_SET(__pyx_t_32, __pyx__function);
                      __pyx_t_3 = 0;
                    }
                    #endif
                    {
                      PyObject *__pyx_callargs[2] = {__pyx_t_28, __pyx_t_31};
                      __pyx_t_17 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_32, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                      __Pyx_XDECREF(__pyx_t_28); __pyx_t_28 = 0;
                      __Pyx_DECREF(__pyx_t_31); __pyx_t_31 = 0;
                      __Pyx_DECREF(__pyx_t_32); __pyx_t_32 = 0;
                      if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 84, __pyx_L1_error)
                      __Pyx_GOTREF(__pyx_t_17);
                    }
                    __pyx_t_26 = __Pyx_PyObject_Append(__pyx_t_18, __pyx_t_17); if (unlikely(__pyx_t_26 == ((int)-1))) __PYX_ERR(0, 84, __pyx_L1_error)
                    __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                    __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;


                    
                  }

                  
                  __pyx_t_17 = PyTuple_New(2); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 86, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_17);
                  __Pyx_INCREF(__pyx_v_k);
                  __Pyx_GIVEREF(__pyx_v_k);
                  if (__Pyx_PyTuple_SET_ITEM(__pyx_t_17, 0, __pyx_v_k) != (0)) __PYX_ERR(0, 86, __pyx_L1_error);
                  __Pyx_INCREF(__pyx_v_l);
                  __Pyx_GIVEREF(__pyx_v_l);
                  if (__Pyx_PyTuple_SET_ITEM(__pyx_t_17, 1, __pyx_v_l) != (0)) __PYX_ERR(0, 86, __pyx_L1_error);
                  __pyx_t_18 = __Pyx_PyObject_GetItem(__pyx_v_values, __pyx_t_17); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 86, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_18);
                  __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
                  __pyx_t_17 = __Pyx_PyObject_Unicode(__pyx_t_18); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 86, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_17);
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                  __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell_, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 86, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_18);
                  __pyx_t_32 = __Pyx_GetItemInt(__pyx_t_18, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_32)) __PYX_ERR(0, 86, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_32);
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                  __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_t_32, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 86, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_18);
                  __Pyx_DECREF(__pyx_t_32); __pyx_t_32 = 0;
                  __pyx_t_32 = __Pyx_GetItemInt(__pyx_t_18, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_32)) __PYX_ERR(0, 86, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_32);
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
                  if (__Pyx_PyObject_SetAttrStr(__pyx_t_32, __pyx_mstate_global->__pyx_n_u_text, __pyx_t_17) < (0)) __PYX_ERR(0, 86, __pyx_L1_error)
                  __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
                  __Pyx_DECREF(__pyx_t_32); __pyx_t_32 = 0;

                  
                  __pyx_t_32 = __Pyx_PyNumber_Add_object_object(__pyx_v_i, __pyx_v_k); if (unlikely(!__pyx_t_32)) __PYX_ERR(0, 87, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_32);
                  __pyx_t_17 = __Pyx_PyNumber_Add_object_object(__pyx_v_j, __pyx_v_l); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 87, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_17);
                  __pyx_t_18 = PyTuple_New(2); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 87, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_18);
                  __Pyx_GIVEREF(__pyx_t_32);
                  if (__Pyx_PyTuple_SET_ITEM(__pyx_t_18, 0, __pyx_t_32) != (0)) __PYX_ERR(0, 87, __pyx_L1_error);
                  __Pyx_GIVEREF(__pyx_t_17);
                  if (__Pyx_PyTuple_SET_ITEM(__pyx_t_18, 1, __pyx_t_17) != (0)) __PYX_ERR(0, 87, __pyx_L1_error);
                  __pyx_t_32 = 0;
                  __pyx_t_17 = 0;
                  __pyx_t_26 = __Pyx_PyList_Append(__pyx_v_replaced, __pyx_t_18); if (unlikely(__pyx_t_26 == ((int)-1))) __PYX_ERR(0, 87, __pyx_L1_error)
                  __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;


                  
                }
                __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;

                
              }
              __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;

              
              goto __pyx_L29;
            }

            
             {
              __pyx_t_20 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 89, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_20);
              if (likely(PyList_CheckExact(__pyx_t_20)) || PyTuple_CheckExact(__pyx_t_20)) {
                __pyx_t_19 = __pyx_t_20; __Pyx_INCREF(__pyx_t_19);
                __pyx_t_27 = 0;
                __pyx_t_29 = NULL;
              } else {
                __pyx_t_27 = -1; __pyx_t_19 = PyObject_GetIter(__pyx_t_20); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 89, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_19);
                __pyx_t_29 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_19); if (unlikely(!__pyx_t_29)) __PYX_ERR(0, 89, __pyx_L1_error)
              }
              __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
              for (;;) {
                if (likely(!__pyx_t_29)) {
                  if (likely(PyList_CheckExact(__pyx_t_19))) {
                    {
                      Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_19);
                      #if !CYTHON_ASSUME_SAFE_SIZE
                      if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 89, __pyx_L1_error)
                      #endif
                      if (__pyx_t_27 >= __pyx_temp) break;
                    }
                    __pyx_t_20 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_19, __pyx_t_27, __Pyx_ReferenceSharing_OwnStrongReference);
                    ++__pyx_t_27;
                  } else {
                    {
                      Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_19);
                      #if !CYTHON_ASSUME_SAFE_SIZE
                      if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 89, __pyx_L1_error)
                      #endif
                      if (__pyx_t_27 >= __pyx_temp) break;
                    }
                    #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                    __pyx_t_20 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_19, __pyx_t_27));
                    #else
                    __pyx_t_20 = __Pyx_PySequence_ITEM(__pyx_t_19, __pyx_t_27);
                    #endif
                    ++__pyx_t_27;
                  }
                  if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 89, __pyx_L1_error)
                } else {
                  __pyx_t_20 = __pyx_t_29(__pyx_t_19);
                  if (unlikely(!__pyx_t_20)) {
                    PyObject* exc_type = PyErr_Occurred();
                    if (exc_type) {
                      if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 89, __pyx_L1_error)
                      PyErr_Clear();
                    }
                    break;
                  }
                }
                __Pyx_GOTREF(__pyx_t_20);
                __Pyx_XDECREF_SET(__pyx_v_paragraph, __pyx_t_20);
                __pyx_t_20 = 0;

                
                __pyx_t_18 = __pyx_v_self;
                __Pyx_INCREF(__pyx_t_18);
                __pyx_t_3 = 0;
                {
                  PyObject *__pyx_callargs[2] = {__pyx_t_18, __pyx_v_paragraph};
                  __pyx_t_20 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_concat_run, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
                  if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 90, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_20);
                }
                __Pyx_DECREF_SET(__pyx_v_paragraph, __pyx_t_20);
                __pyx_t_20 = 0;

                
                __pyx_t_18 = __pyx_v_self;
                __Pyx_INCREF(__pyx_t_18);
                __pyx_t_3 = 0;
                {
                  PyObject *__pyx_callargs[3] = {__pyx_t_18, __pyx_v_paragraph, __pyx_v_env};
                  __pyx_t_20 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_replace_paragraph, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                  __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
                  if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 91, __pyx_L1_error)
                  __Pyx_GOTREF(__pyx_t_20);
                }
                __pyx_t_18 = __Pyx_PyNumber_InPlaceAdd_object_object(__pyx_v_except_placeholders, __pyx_t_20); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 91, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_18);
                __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
                __Pyx_DECREF_SET(__pyx_v_except_placeholders, __pyx_t_18);
                __pyx_t_18 = 0;

                
              }
              __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
            }
            __pyx_L29:;

            
            goto __pyx_L18;
          }

          
           {
            __pyx_t_19 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 93, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_19);
            if (likely(PyList_CheckExact(__pyx_t_19)) || PyTuple_CheckExact(__pyx_t_19)) {
              __pyx_t_18 = __pyx_t_19; __Pyx_INCREF(__pyx_t_18);
              __pyx_t_27 = 0;
              __pyx_t_29 = NULL;
            } else {
              __pyx_t_27 = -1; __pyx_t_18 = PyObject_GetIter(__pyx_t_19); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 93, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_18);
              __pyx_t_29 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_18); if (unlikely(!__pyx_t_29)) __PYX_ERR(0, 93, __pyx_L1_error)
            }
            __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
            for (;;) {
              if (likely(!__pyx_t_29)) {
                if (likely(PyList_CheckExact(__pyx_t_18))) {
                  {
                    Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_18);
                    #if !CYTHON_ASSUME_SAFE_SIZE
                    if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 93, __pyx_L1_error)
                    #endif
                    if (__pyx_t_27 >= __pyx_temp) break;
                  }
                  __pyx_t_19 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_18, __pyx_t_27, __Pyx_ReferenceSharing_OwnStrongReference);
                  ++__pyx_t_27;
                } else {
                  {
                    Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_18);
                    #if !CYTHON_ASSUME_SAFE_SIZE
                    if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 93, __pyx_L1_error)
                    #endif
                    if (__pyx_t_27 >= __pyx_temp) break;
                  }
                  #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                  __pyx_t_19 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_18, __pyx_t_27));
                  #else
                  __pyx_t_19 = __Pyx_PySequence_ITEM(__pyx_t_18, __pyx_t_27);
                  #endif
                  ++__pyx_t_27;
                }
                if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 93, __pyx_L1_error)
              } else {
                __pyx_t_19 = __pyx_t_29(__pyx_t_18);
                if (unlikely(!__pyx_t_19)) {
                  PyObject* exc_type = PyErr_Occurred();
                  if (exc_type) {
                    if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 93, __pyx_L1_error)
                    PyErr_Clear();
                  }
                  break;
                }
              }
              __Pyx_GOTREF(__pyx_t_19);
              __Pyx_XDECREF_SET(__pyx_v_paragraph, __pyx_t_19);
              __pyx_t_19 = 0;

              
              __pyx_t_20 = __pyx_v_self;
              __Pyx_INCREF(__pyx_t_20);
              __pyx_t_3 = 0;
              {
                PyObject *__pyx_callargs[2] = {__pyx_t_20, __pyx_v_paragraph};
                __pyx_t_19 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_concat_run, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                __Pyx_XDECREF(__pyx_t_20); __pyx_t_20 = 0;
                if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 94, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_19);
              }
              __Pyx_DECREF_SET(__pyx_v_paragraph, __pyx_t_19);
              __pyx_t_19 = 0;

              
              __pyx_t_20 = __pyx_v_self;
              __Pyx_INCREF(__pyx_t_20);
              __pyx_t_3 = 0;
              {
                PyObject *__pyx_callargs[3] = {__pyx_t_20, __pyx_v_paragraph, __pyx_v_env};
                __pyx_t_19 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_replace_paragraph, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
                __Pyx_XDECREF(__pyx_t_20); __pyx_t_20 = 0;
                if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 95, __pyx_L1_error)
                __Pyx_GOTREF(__pyx_t_19);
              }
              __pyx_t_20 = __Pyx_PyNumber_InPlaceAdd_object_object(__pyx_v_except_placeholders, __pyx_t_19); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 95, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_20);
              __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
              __Pyx_DECREF_SET(__pyx_v_except_placeholders, __pyx_t_20);
              __pyx_t_20 = 0;

              
            }
            __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
          }
          __pyx_L18:;

          
        }
        __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;

        
        __pyx_L11_continue:;
      }
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

      
    }
    __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

    
  }
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;

  
  __pyx_t_2 = __pyx_v_doc;
  __Pyx_INCREF(__pyx_t_2);
  __pyx_t_3 = 0;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_v_save_path};
    __pyx_t_5 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_save, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 98, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_5);
  }
  __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;

  
  {
    PyObject *__pyx_temp;
    {
      __pyx_temp = __pyx_r;
      __Pyx_INCREF(__pyx_v_except_placeholders);
      __pyx_r = __pyx_v_except_placeholders;
    }
    __Pyx_XDECREF(__pyx_temp);
  }
  goto __pyx_L0;

  

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_8);
  __Pyx_XDECREF(__pyx_t_11);
  __Pyx_XDECREF(__pyx_t_12);
  __Pyx_XDECREF(__pyx_t_17);
  __Pyx_XDECREF(__pyx_t_18);
  __Pyx_XDECREF(__pyx_t_19);
  __Pyx_XDECREF(__pyx_t_20);
  __Pyx_XDECREF(__pyx_t_28);
  __Pyx_XDECREF(__pyx_t_31);
  __Pyx_XDECREF(__pyx_t_32);
  __Pyx_XDECREF(__pyx_t_33);
  __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.__call__", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_doc);
  __Pyx_XDECREF(__pyx_v_except_placeholders);
  __Pyx_XDECREF(__pyx_v_paragraph);
  __Pyx_XDECREF(__pyx_v_table);
  __Pyx_XDECREF(__pyx_v_replaced);
  __Pyx_XDECREF(__pyx_v_i);
  __Pyx_XDECREF(__pyx_v_row);
  __Pyx_XDECREF(__pyx_v_j);
  __Pyx_XDECREF(__pyx_v_cell);
  __Pyx_XDECREF(__pyx_v_placeholders);
  __Pyx_XDECREF(__pyx_v_placeholder);
  __Pyx_XDECREF(__pyx_v__placeholder_);
  __Pyx_XDECREF(__pyx_v_is_dataframe);
  __Pyx_XDECREF(__pyx_v_values);
  __Pyx_XDECREF(__pyx_v__);
  __Pyx_XDECREF(__pyx_v_k);
  __Pyx_XDECREF(__pyx_v_l);
  __Pyx_XDECREF(__pyx_v_cell_);
  __Pyx_XDECREF(__pyx_v_env);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}



static PyObject *__pyx_pf_5cloze_13template_docx_2__defaults__(CYTHON_UNUSED PyObject *__pyx_self) {
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("__defaults__", 0);
  __pyx_t_1 = PyTuple_New(1); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 102, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_INCREF(__Pyx_CyFunction_Defaults(struct __pyx_defaults, __pyx_self)->arg0);
  __Pyx_GIVEREF(__Pyx_CyFunction_Defaults(struct __pyx_defaults, __pyx_self)->arg0);
  if (__Pyx_PyTuple_SET_ITEM(__pyx_t_1, 0, __Pyx_CyFunction_Defaults(struct __pyx_defaults, __pyx_self)->arg0) != (0)) __PYX_ERR(0, 102, __pyx_L1_error);
  __pyx_t_2 = PyTuple_New(2); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 102, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_GIVEREF(__pyx_t_1);
  if (__Pyx_PyTuple_SET_ITEM(__pyx_t_2, 0, __pyx_t_1) != (0)) __PYX_ERR(0, 102, __pyx_L1_error);
  __Pyx_INCREF(Py_None);
  __Pyx_GIVEREF(Py_None);
  if (__Pyx_PyTuple_SET_ITEM(__pyx_t_2, 1, Py_None) != (0)) __PYX_ERR(0, 102, __pyx_L1_error);
  __pyx_t_1 = 0;
  {
    PyObject *__pyx_temp;
    {
      __pyx_temp = __pyx_r;
      __pyx_r = __pyx_t_2;
    }
    __Pyx_XDECREF(__pyx_temp);
  }
  __pyx_t_2 = 0;
  goto __pyx_L0;

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_AddTraceback("cloze.template_docx.__defaults__", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}


static PyObject *__pyx_pw_5cloze_13template_docx_12TemplateDocx_5replace_paragraph(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_5cloze_13template_docx_12TemplateDocx_5replace_paragraph = {"replace_paragraph", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_5cloze_13template_docx_12TemplateDocx_5replace_paragraph, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_5cloze_13template_docx_12TemplateDocx_5replace_paragraph(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_self = 0;
  PyObject *__pyx_v_paragraph = 0;
  PyObject *__pyx_v_env = 0;
  #if !CYTHON_VECTORCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[3] = {0,0,0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("replace_paragraph (wrapper)", 0);
  #if !CYTHON_VECTORCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_self,&__pyx_mstate_global->__pyx_n_u_paragraph,&__pyx_mstate_global->__pyx_n_u_env,0};
    struct __pyx_defaults *__pyx_dynamic_args = __Pyx_CyFunction_Defaults(struct __pyx_defaults, __pyx_self);
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len < 0)) __PYX_ERR(0, 102, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  3:
        values[2] = __Pyx_ArgRef_FASTCALL(__pyx_args, 2);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[2])) __PYX_ERR(0, 102, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 102, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 102, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "replace_paragraph", 0) < (0)) __PYX_ERR(0, 102, __pyx_L3_error)
      if (!values[2]) values[2] = __Pyx_NewRef(__pyx_dynamic_args->arg0);
      for (Py_ssize_t i = __pyx_nargs; i < 2; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("replace_paragraph", 0, 2, 3, i); __PYX_ERR(0, 102, __pyx_L3_error) }
      }
    } else {
      switch (__pyx_nargs) {
        case  3:
        values[2] = __Pyx_ArgRef_FASTCALL(__pyx_args, 2);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[2])) __PYX_ERR(0, 102, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 102, __pyx_L3_error)
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 102, __pyx_L3_error)
        break;
        default: goto __pyx_L5_argtuple_error;
      }
      if (!values[2]) values[2] = __Pyx_NewRef(__pyx_dynamic_args->arg0);
    }
    __pyx_v_self = values[0];
    __pyx_v_paragraph = values[1];
    __pyx_v_env = values[2];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("replace_paragraph", 0, 2, 3, __pyx_nargs); __PYX_ERR(0, 102, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.replace_paragraph", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_5cloze_13template_docx_12TemplateDocx_4replace_paragraph(__pyx_self, __pyx_v_self, __pyx_v_paragraph, __pyx_v_env);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_5cloze_13template_docx_12TemplateDocx_4replace_paragraph(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_self, PyObject *__pyx_v_paragraph, PyObject *__pyx_v_env) {
  PyObject *__pyx_v_except_placeholders = NULL;
  PyObject *__pyx_v_run = NULL;
  PyObject *__pyx_v_placeholders = NULL;
  PyObject *__pyx_v_placeholder = NULL;
  PyObject *__pyx_v__placeholder_ = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  Py_ssize_t __pyx_t_3;
  PyObject *(*__pyx_t_4)(PyObject *);
  PyObject *__pyx_t_5 = NULL;
  PyObject *__pyx_t_6 = NULL;
  PyObject *__pyx_t_7 = NULL;
  PyObject *__pyx_t_8 = NULL;
  size_t __pyx_t_9;
  Py_ssize_t __pyx_t_10;
  PyObject *(*__pyx_t_11)(PyObject *);
  PyObject *__pyx_t_12 = NULL;
  PyObject *__pyx_t_13 = NULL;
  PyObject *__pyx_t_14 = NULL;
  int __pyx_t_15;
  PyObject *__pyx_t_16 = NULL;
  int __pyx_t_17;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("replace_paragraph", 0);

  
  __pyx_t_1 = PyList_New(0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 103, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_v_except_placeholders = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 104, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  if (likely(PyList_CheckExact(__pyx_t_1)) || PyTuple_CheckExact(__pyx_t_1)) {
    __pyx_t_2 = __pyx_t_1; __Pyx_INCREF(__pyx_t_2);
    __pyx_t_3 = 0;
    __pyx_t_4 = NULL;
  } else {
    __pyx_t_3 = -1; __pyx_t_2 = PyObject_GetIter(__pyx_t_1); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 104, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_4 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_2); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 104, __pyx_L1_error)
  }
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  for (;;) {
    if (likely(!__pyx_t_4)) {
      if (likely(PyList_CheckExact(__pyx_t_2))) {
        {
          Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_2);
          #if !CYTHON_ASSUME_SAFE_SIZE
          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 104, __pyx_L1_error)
          #endif
          if (__pyx_t_3 >= __pyx_temp) break;
        }
        __pyx_t_1 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_2, __pyx_t_3, __Pyx_ReferenceSharing_OwnStrongReference);
        ++__pyx_t_3;
      } else {
        {
          Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_2);
          #if !CYTHON_ASSUME_SAFE_SIZE
          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 104, __pyx_L1_error)
          #endif
          if (__pyx_t_3 >= __pyx_temp) break;
        }
        #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
        __pyx_t_1 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_2, __pyx_t_3));
        #else
        __pyx_t_1 = __Pyx_PySequence_ITEM(__pyx_t_2, __pyx_t_3);
        #endif
        ++__pyx_t_3;
      }
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 104, __pyx_L1_error)
    } else {
      __pyx_t_1 = __pyx_t_4(__pyx_t_2);
      if (unlikely(!__pyx_t_1)) {
        PyObject* exc_type = PyErr_Occurred();
        if (exc_type) {
          if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 104, __pyx_L1_error)
          PyErr_Clear();
        }
        break;
      }
    }
    __Pyx_GOTREF(__pyx_t_1);
    __Pyx_XDECREF_SET(__pyx_v_run, __pyx_t_1);
    __pyx_t_1 = 0;

    
    __pyx_t_5 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 106, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_6);
    __pyx_t_7 = __Pyx_PyObject_GetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_findall); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 106, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_7);
    __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
    __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 106, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_6);
    __pyx_t_8 = __Pyx_PyObject_GetAttrStr(__pyx_v_run, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 106, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_8);
    __pyx_t_9 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_7))) {
      __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_7);
      assert(__pyx_t_5);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_7);
      __Pyx_INCREF(__pyx_t_5);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_7, __pyx__function);
      __pyx_t_9 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[3] = {__pyx_t_5, __pyx_t_6, __pyx_t_8};
      __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_7, __pyx_callargs+__pyx_t_9, (3-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
      __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
      __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 106, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    __Pyx_XDECREF_SET(__pyx_v_placeholders, __pyx_t_1);
    __pyx_t_1 = 0;

    
    if (likely(PyList_CheckExact(__pyx_v_placeholders)) || PyTuple_CheckExact(__pyx_v_placeholders)) {
      __pyx_t_1 = __pyx_v_placeholders; __Pyx_INCREF(__pyx_t_1);
      __pyx_t_10 = 0;
      __pyx_t_11 = NULL;
    } else {
      __pyx_t_10 = -1; __pyx_t_1 = PyObject_GetIter(__pyx_v_placeholders); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 107, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __pyx_t_11 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_1); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 107, __pyx_L1_error)
    }
    for (;;) {
      if (likely(!__pyx_t_11)) {
        if (likely(PyList_CheckExact(__pyx_t_1))) {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_1);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 107, __pyx_L1_error)
            #endif
            if (__pyx_t_10 >= __pyx_temp) break;
          }
          __pyx_t_7 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_1, __pyx_t_10, __Pyx_ReferenceSharing_OwnStrongReference);
          ++__pyx_t_10;
        } else {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_1);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 107, __pyx_L1_error)
            #endif
            if (__pyx_t_10 >= __pyx_temp) break;
          }
          #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
          __pyx_t_7 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_1, __pyx_t_10));
          #else
          __pyx_t_7 = __Pyx_PySequence_ITEM(__pyx_t_1, __pyx_t_10);
          #endif
          ++__pyx_t_10;
        }
        if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 107, __pyx_L1_error)
      } else {
        __pyx_t_7 = __pyx_t_11(__pyx_t_1);
        if (unlikely(!__pyx_t_7)) {
          PyObject* exc_type = PyErr_Occurred();
          if (exc_type) {
            if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 107, __pyx_L1_error)
            PyErr_Clear();
          }
          break;
        }
      }
      __Pyx_GOTREF(__pyx_t_7);
      __Pyx_XDECREF_SET(__pyx_v_placeholder, __pyx_t_7);
      __pyx_t_7 = 0;

      
      __pyx_t_8 = NULL;
      __Pyx_GetModuleGlobalName(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 108, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_sub); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 108, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_5);
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
      __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 108, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      __pyx_t_9 = 1;
      #if CYTHON_UNPACK_METHODS
      if (unlikely(PyMethod_Check(__pyx_t_5))) {
        __pyx_t_8 = PyMethod_GET_SELF(__pyx_t_5);
        assert(__pyx_t_8);
        PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
        __Pyx_INCREF(__pyx_t_8);
        __Pyx_INCREF(__pyx__function);
        __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
        __pyx_t_9 = 0;
      }
      #endif
      {
        PyObject *__pyx_callargs[4] = {__pyx_t_8, __pyx_mstate_global->__pyx_kp_u__6, __pyx_mstate_global->__pyx_kp_u_s, __pyx_t_6};
        __pyx_t_7 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_5, __pyx_callargs+__pyx_t_9, (4-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
        __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
        __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
        if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 108, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_7);
      }
      __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 108, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_5);
      __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
      __pyx_t_7 = __Pyx_PyObject_Call(__pyx_t_5, __pyx_mstate_global->__pyx_tuple[0], NULL); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 108, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_7);
      __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
      __pyx_t_5 = PyNumber_Remainder(__pyx_t_7, __pyx_v_placeholder); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 108, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_5);
      __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
      __Pyx_XDECREF_SET(__pyx_v__placeholder_, __pyx_t_5);
      __pyx_t_5 = 0;

      
      {
        __Pyx_PyThreadState_declare
        __Pyx_PyThreadState_assign
        __Pyx_ExceptionSave(&__pyx_t_12, &__pyx_t_13, &__pyx_t_14);
        __Pyx_XGOTREF(__pyx_t_12);
        __Pyx_XGOTREF(__pyx_t_13);
        __Pyx_XGOTREF(__pyx_t_14);
         {

          
          __pyx_t_7 = NULL;
          __pyx_t_9 = 1;
          {
            PyObject *__pyx_callargs[3] = {__pyx_t_7, __pyx_v_placeholder, __pyx_v_env};
            __pyx_t_5 = __Pyx_PyObject_FastCall((PyObject*)__pyx_builtin_eval, __pyx_callargs+__pyx_t_9, (3-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
            if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 116, __pyx_L7_error)
            __Pyx_GOTREF(__pyx_t_5);
          }
          __Pyx_GetModuleGlobalName(__pyx_t_7, __pyx_mstate_global->__pyx_n_u_BytesIO); if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 116, __pyx_L7_error)
          __Pyx_GOTREF(__pyx_t_7);
          __pyx_t_15 = PyObject_IsInstance(__pyx_t_5, __pyx_t_7); if (unlikely(__pyx_t_15 == ((int)-1))) __PYX_ERR(0, 116, __pyx_L7_error)
          __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
          __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
          if (__pyx_t_15) {


            
            __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_run, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 117, __pyx_L7_error)
            __Pyx_GOTREF(__pyx_t_6);
            __pyx_t_5 = __pyx_t_6;
            __Pyx_INCREF(__pyx_t_5);
            __pyx_t_9 = 0;
            {
              PyObject *__pyx_callargs[3] = {__pyx_t_5, __pyx_v__placeholder_, __pyx_mstate_global->__pyx_kp_u__8};
              __pyx_t_7 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_replace, __pyx_callargs+__pyx_t_9, (3-__pyx_t_9) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
              __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
              __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
              if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 117, __pyx_L7_error)
              __Pyx_GOTREF(__pyx_t_7);
            }
            if (__Pyx_PyObject_SetAttrStr(__pyx_v_run, __pyx_mstate_global->__pyx_n_u_text, __pyx_t_7) < (0)) __PYX_ERR(0, 117, __pyx_L7_error)
            __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;

            
            __pyx_t_6 = __pyx_v_run;
            __Pyx_INCREF(__pyx_t_6);
            __pyx_t_8 = NULL;
            __pyx_t_9 = 1;
            {
              PyObject *__pyx_callargs[3] = {__pyx_t_8, __pyx_v_placeholder, __pyx_v_env};
              __pyx_t_5 = __Pyx_PyObject_FastCall((PyObject*)__pyx_builtin_eval, __pyx_callargs+__pyx_t_9, (3-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
              __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;
              if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 118, __pyx_L7_error)
              __Pyx_GOTREF(__pyx_t_5);
            }
            __pyx_t_9 = 0;
            {
              PyObject *__pyx_callargs[2] = {__pyx_t_6, __pyx_t_5};
              __pyx_t_7 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_add_picture, __pyx_callargs+__pyx_t_9, (2-__pyx_t_9) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
              __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
              __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
              if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 118, __pyx_L7_error)
              __Pyx_GOTREF(__pyx_t_7);
            }
            __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;

            
            goto __pyx_L15;
          }

          
           {
            __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_run, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 120, __pyx_L7_error)
            __Pyx_GOTREF(__pyx_t_6);
            __pyx_t_5 = __pyx_t_6;
            __Pyx_INCREF(__pyx_t_5);
            __pyx_t_16 = NULL;
            __pyx_t_9 = 1;
            {
              PyObject *__pyx_callargs[3] = {__pyx_t_16, __pyx_v_placeholder, __pyx_v_env};
              __pyx_t_8 = __Pyx_PyObject_FastCall((PyObject*)__pyx_builtin_eval, __pyx_callargs+__pyx_t_9, (3-__pyx_t_9) | (__pyx_t_9*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
              __Pyx_XDECREF(__pyx_t_16); __pyx_t_16 = 0;
              if (unlikely(!__pyx_t_8)) __PYX_ERR(0, 120, __pyx_L7_error)
              __Pyx_GOTREF(__pyx_t_8);
            }
            __pyx_t_16 = __Pyx_PyObject_Unicode(__pyx_t_8); if (unlikely(!__pyx_t_16)) __PYX_ERR(0, 120, __pyx_L7_error)
            __Pyx_GOTREF(__pyx_t_16);
            __Pyx_DECREF(__pyx_t_8); __pyx_t_8 = 0;
            __pyx_t_9 = 0;
            {
              PyObject *__pyx_callargs[3] = {__pyx_t_5, __pyx_v__placeholder_, __pyx_t_16};
              __pyx_t_7 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_replace, __pyx_callargs+__pyx_t_9, (3-__pyx_t_9) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
              __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
              __Pyx_DECREF(__pyx_t_16); __pyx_t_16 = 0;
              __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
              if (unlikely(!__pyx_t_7)) __PYX_ERR(0, 120, __pyx_L7_error)
              __Pyx_GOTREF(__pyx_t_7);
            }
            if (__Pyx_PyObject_SetAttrStr(__pyx_v_run, __pyx_mstate_global->__pyx_n_u_text, __pyx_t_7) < (0)) __PYX_ERR(0, 120, __pyx_L7_error)
            __Pyx_DECREF(__pyx_t_7); __pyx_t_7 = 0;
          }
          __pyx_L15:;

          
        }
        __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
        __Pyx_XDECREF(__pyx_t_13); __pyx_t_13 = 0;
        __Pyx_XDECREF(__pyx_t_14); __pyx_t_14 = 0;
        goto __pyx_L14_try_end;
        __pyx_L7_error:;
        __Pyx_XDECREF(__pyx_t_16); __pyx_t_16 = 0;
        __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
        __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
        __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
        __Pyx_XDECREF(__pyx_t_8); __pyx_t_8 = 0;

        
         {
          __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.replace_paragraph", __pyx_clineno, __pyx_lineno, __pyx_filename);
          if (__Pyx_GetException(&__pyx_t_7, &__pyx_t_6, &__pyx_t_16) < 0) __PYX_ERR(0, 121, __pyx_L9_except_error)
          __Pyx_XGOTREF(__pyx_t_7);
          __Pyx_XGOTREF(__pyx_t_6);
          __Pyx_XGOTREF(__pyx_t_16);

          
          __pyx_t_17 = __Pyx_PyList_Append(__pyx_v_except_placeholders, __pyx_v_placeholder); if (unlikely(__pyx_t_17 == ((int)-1))) __PYX_ERR(0, 122, __pyx_L9_except_error)

          __Pyx_XDECREF(__pyx_t_7); __pyx_t_7 = 0;
          __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
          __Pyx_XDECREF(__pyx_t_16); __pyx_t_16 = 0;
          goto __pyx_L8_exception_handled;
        }

        
        __pyx_L9_except_error:;
        __Pyx_XGIVEREF(__pyx_t_12);
        __Pyx_XGIVEREF(__pyx_t_13);
        __Pyx_XGIVEREF(__pyx_t_14);
        __Pyx_ExceptionReset(__pyx_t_12, __pyx_t_13, __pyx_t_14);
        goto __pyx_L1_error;
        __pyx_L8_exception_handled:;
        __Pyx_XGIVEREF(__pyx_t_12);
        __Pyx_XGIVEREF(__pyx_t_13);
        __Pyx_XGIVEREF(__pyx_t_14);
        __Pyx_ExceptionReset(__pyx_t_12, __pyx_t_13, __pyx_t_14);
        __pyx_L14_try_end:;
      }

      
    }
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

    
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  {
    PyObject *__pyx_temp;
    {
      __pyx_temp = __pyx_r;
      __Pyx_INCREF(__pyx_v_except_placeholders);
      __pyx_r = __pyx_v_except_placeholders;
    }
    __Pyx_XDECREF(__pyx_temp);
  }
  goto __pyx_L0;

  

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_6);
  __Pyx_XDECREF(__pyx_t_7);
  __Pyx_XDECREF(__pyx_t_8);
  __Pyx_XDECREF(__pyx_t_16);
  __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.replace_paragraph", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_except_placeholders);
  __Pyx_XDECREF(__pyx_v_run);
  __Pyx_XDECREF(__pyx_v_placeholders);
  __Pyx_XDECREF(__pyx_v_placeholder);
  __Pyx_XDECREF(__pyx_v__placeholder_);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_5cloze_13template_docx_12TemplateDocx_7concat_run(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
static PyMethodDef __pyx_mdef_5cloze_13template_docx_12TemplateDocx_7concat_run = {"concat_run", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_5cloze_13template_docx_12TemplateDocx_7concat_run, __Pyx_METH_FASTCALL|METH_KEYWORDS, 0};
static PyObject *__pyx_pw_5cloze_13template_docx_12TemplateDocx_7concat_run(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_self = 0;
  PyObject *__pyx_v_paragraph = 0;
  #if !CYTHON_VECTORCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[2] = {0,0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("concat_run (wrapper)", 0);
  #if !CYTHON_VECTORCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_self,&__pyx_mstate_global->__pyx_n_u_paragraph,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len < 0)) __PYX_ERR(0, 224, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 224, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 224, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "concat_run", 0) < (0)) __PYX_ERR(0, 224, __pyx_L3_error)
      for (Py_ssize_t i = __pyx_nargs; i < 2; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("concat_run", 1, 2, 2, i); __PYX_ERR(0, 224, __pyx_L3_error) }
      }
    } else if (unlikely(__pyx_nargs != 2)) {
      goto __pyx_L5_argtuple_error;
    } else {
      values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
      if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 224, __pyx_L3_error)
      values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
      if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 224, __pyx_L3_error)
    }
    __pyx_v_self = values[0];
    __pyx_v_paragraph = values[1];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("concat_run", 1, 2, 2, __pyx_nargs); __PYX_ERR(0, 224, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.concat_run", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_5cloze_13template_docx_12TemplateDocx_6concat_run(__pyx_self, __pyx_v_self, __pyx_v_paragraph);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_5cloze_13template_docx_12TemplateDocx_6concat_run(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_self, PyObject *__pyx_v_paragraph) {
  PyObject *__pyx_v_forward_placeholder = NULL;
  PyObject *__pyx_v_backward_placeholder = NULL;
  PyObject *__pyx_v_forward_add = NULL;
  PyObject *__pyx_v_backward_add = NULL;
  PyObject *__pyx_v_to_be_add = NULL;
  PyObject *__pyx_v_concated = NULL;
  PyObject *__pyx_v_over = NULL;
  PyObject *__pyx_v_i = NULL;
  PyObject *__pyx_v_back = NULL;
  PyObject *__pyx_v_forward = NULL;
  Py_ssize_t __pyx_7genexpr__pyx_v_i;
  PyObject *__pyx_8genexpr1__pyx_v_run = NULL;
  Py_ssize_t __pyx_8genexpr2__pyx_v_i;
  PyObject *__pyx_8genexpr3__pyx_v_run = NULL;
  PyObject *__pyx_8genexpr4__pyx_v_i = NULL;
  PyObject *__pyx_8genexpr4__pyx_v_j = NULL;
  PyObject *__pyx_8genexpr5__pyx_v_i = NULL;
  PyObject *__pyx_8genexpr5__pyx_v_j = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  PyObject *__pyx_t_3 = NULL;
  PyObject *__pyx_t_4 = NULL;
  PyObject *__pyx_t_5 = NULL;
  size_t __pyx_t_6;
  Py_ssize_t __pyx_t_7;
  int __pyx_t_8;
  Py_ssize_t __pyx_t_9;
  Py_ssize_t __pyx_t_10;
  PyObject *__pyx_t_11 = NULL;
  PyObject *__pyx_t_12 = NULL;
  PyObject *__pyx_t_13 = NULL;
  Py_ssize_t __pyx_t_14;
  PyObject *(*__pyx_t_15)(PyObject *);
  PyObject *__pyx_t_16 = NULL;
  PyObject *__pyx_t_17 = NULL;
  PyObject *__pyx_t_18 = NULL;
  PyObject *__pyx_t_19 = NULL;
  PyObject *__pyx_t_20 = NULL;
  PyObject *__pyx_t_21 = NULL;
  PyObject *__pyx_t_22 = NULL;
  PyObject *(*__pyx_t_23)(PyObject *);
  int __pyx_t_24;
  int __pyx_t_25;
  int __pyx_t_26;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("concat_run", 0);

  
  __pyx_t_2 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 227, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_findall); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 227, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
  __pyx_t_3 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 227, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_3);
  __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 227, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __pyx_t_6 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_4))) {
    __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_4);
    assert(__pyx_t_2);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_4);
    __Pyx_INCREF(__pyx_t_2);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_4, __pyx__function);
    __pyx_t_6 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[3] = {__pyx_t_2, __pyx_t_3, __pyx_t_5};
    __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_4, __pyx_callargs+__pyx_t_6, (3-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 227, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_t_7 = PyObject_Length(__pyx_t_1); if (unlikely(__pyx_t_7 == ((Py_ssize_t)-1))) __PYX_ERR(0, 227, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_t_8 = (__pyx_t_7 == 0);


  if (__pyx_t_8) {


    
    {
      PyObject *__pyx_temp;
      {
        __pyx_temp = __pyx_r;
        __Pyx_INCREF(__pyx_v_paragraph);
        __pyx_r = __pyx_v_paragraph;
      }
      __Pyx_XDECREF(__pyx_temp);
    }
    goto __pyx_L0;

    
  }

  
  { 
    __pyx_t_1 = PyList_New(0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 233, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);

    
    __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 238, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_4);
    __pyx_t_7 = PyObject_Length(__pyx_t_4); if (unlikely(__pyx_t_7 == ((Py_ssize_t)-1))) __PYX_ERR(0, 238, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    __pyx_t_9 = __pyx_t_7;

    for (__pyx_t_10 = 0; __pyx_t_10 < __pyx_t_9; __pyx_t_10+=1) {
      __pyx_7genexpr__pyx_v_i = __pyx_t_10;

      
      __pyx_t_5 = NULL;
      __Pyx_GetModuleGlobalName(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 233, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
      __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_t_3, __pyx_mstate_global->__pyx_n_u_findall); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 233, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_2);
      __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
      __pyx_t_3 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 233, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);

      
      { 
        __pyx_t_11 = PyList_New(0); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 234, __pyx_L8_error)
        __Pyx_GOTREF(__pyx_t_11);

        
        __pyx_t_12 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 237, __pyx_L8_error)
        __Pyx_GOTREF(__pyx_t_12);
        __pyx_t_13 = __Pyx_PyObject_GetSlice(__pyx_t_12, 0, (__pyx_7genexpr__pyx_v_i + 1), NULL, NULL, NULL, 0, 1, 1); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 237, __pyx_L8_error)
        __Pyx_GOTREF(__pyx_t_13);
        __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
        if (likely(PyList_CheckExact(__pyx_t_13)) || PyTuple_CheckExact(__pyx_t_13)) {
          __pyx_t_12 = __pyx_t_13; __Pyx_INCREF(__pyx_t_12);
          __pyx_t_14 = 0;
          __pyx_t_15 = NULL;
        } else {
          __pyx_t_14 = -1; __pyx_t_12 = PyObject_GetIter(__pyx_t_13); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 237, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_12);
          __pyx_t_15 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_12); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 237, __pyx_L8_error)
        }
        __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
        for (;;) {
          if (likely(!__pyx_t_15)) {
            if (likely(PyList_CheckExact(__pyx_t_12))) {
              {
                Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_12);
                #if !CYTHON_ASSUME_SAFE_SIZE
                if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 237, __pyx_L8_error)
                #endif
                if (__pyx_t_14 >= __pyx_temp) break;
              }
              __pyx_t_13 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_12, __pyx_t_14, __Pyx_ReferenceSharing_OwnStrongReference);
              ++__pyx_t_14;
            } else {
              {
                Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_12);
                #if !CYTHON_ASSUME_SAFE_SIZE
                if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 237, __pyx_L8_error)
                #endif
                if (__pyx_t_14 >= __pyx_temp) break;
              }
              #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
              __pyx_t_13 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_12, __pyx_t_14));
              #else
              __pyx_t_13 = __Pyx_PySequence_ITEM(__pyx_t_12, __pyx_t_14);
              #endif
              ++__pyx_t_14;
            }
            if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 237, __pyx_L8_error)
          } else {
            __pyx_t_13 = __pyx_t_15(__pyx_t_12);
            if (unlikely(!__pyx_t_13)) {
              PyObject* exc_type = PyErr_Occurred();
              if (exc_type) {
                if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 237, __pyx_L8_error)
                PyErr_Clear();
              }
              break;
            }
          }
          __Pyx_GOTREF(__pyx_t_13);
          __Pyx_XDECREF_SET(__pyx_8genexpr1__pyx_v_run, __pyx_t_13);
          __pyx_t_13 = 0;

          
          __pyx_t_16 = NULL;
          __Pyx_GetModuleGlobalName(__pyx_t_17, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 234, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_17);
          __pyx_t_18 = __Pyx_PyObject_GetAttrStr(__pyx_t_17, __pyx_mstate_global->__pyx_n_u_sub); if (unlikely(!__pyx_t_18)) __PYX_ERR(0, 234, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_18);
          __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
          __pyx_t_17 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 234, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_17);

          
          __pyx_t_20 = NULL;
          __Pyx_GetModuleGlobalName(__pyx_t_21, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_21)) __PYX_ERR(0, 235, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_21);
          __pyx_t_22 = __Pyx_PyObject_GetAttrStr(__pyx_t_21, __pyx_mstate_global->__pyx_n_u_sub); if (unlikely(!__pyx_t_22)) __PYX_ERR(0, 235, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_22);
          __Pyx_DECREF(__pyx_t_21); __pyx_t_21 = 0;
          __pyx_t_21 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_21)) __PYX_ERR(0, 235, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_21);
          __pyx_t_6 = 1;
          #if CYTHON_UNPACK_METHODS
          if (unlikely(PyMethod_Check(__pyx_t_22))) {
            __pyx_t_20 = PyMethod_GET_SELF(__pyx_t_22);
            assert(__pyx_t_20);
            PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_22);
            __Pyx_INCREF(__pyx_t_20);
            __Pyx_INCREF(__pyx__function);
            __Pyx_DECREF_SET(__pyx_t_22, __pyx__function);
            __pyx_t_6 = 0;
          }
          #endif
          {
            PyObject *__pyx_callargs[4] = {__pyx_t_20, __pyx_mstate_global->__pyx_kp_u__6, __pyx_mstate_global->__pyx_kp_u__8, __pyx_t_21};
            __pyx_t_19 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_22, __pyx_callargs+__pyx_t_6, (4-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_20); __pyx_t_20 = 0;
            __Pyx_DECREF(__pyx_t_21); __pyx_t_21 = 0;
            __Pyx_DECREF(__pyx_t_22); __pyx_t_22 = 0;
            if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 235, __pyx_L8_error)
            __Pyx_GOTREF(__pyx_t_19);
          }
          __pyx_t_22 = __Pyx_PyObject_GetAttrStr(__pyx_t_19, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_22)) __PYX_ERR(0, 235, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_22);
          __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
          __pyx_t_19 = __Pyx_PyObject_Call(__pyx_t_22, __pyx_mstate_global->__pyx_tuple[0], NULL); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 235, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_19);
          __Pyx_DECREF(__pyx_t_22); __pyx_t_22 = 0;

          
          __pyx_t_22 = __Pyx_PyObject_GetAttrStr(__pyx_8genexpr1__pyx_v_run, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_22)) __PYX_ERR(0, 236, __pyx_L8_error)
          __Pyx_GOTREF(__pyx_t_22);
          __pyx_t_6 = 1;
          #if CYTHON_UNPACK_METHODS
          if (unlikely(PyMethod_Check(__pyx_t_18))) {
            __pyx_t_16 = PyMethod_GET_SELF(__pyx_t_18);
            assert(__pyx_t_16);
            PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_18);
            __Pyx_INCREF(__pyx_t_16);
            __Pyx_INCREF(__pyx__function);
            __Pyx_DECREF_SET(__pyx_t_18, __pyx__function);
            __pyx_t_6 = 0;
          }
          #endif
          {
            PyObject *__pyx_callargs[4] = {__pyx_t_16, __pyx_t_17, __pyx_t_19, __pyx_t_22};
            __pyx_t_13 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_18, __pyx_callargs+__pyx_t_6, (4-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_16); __pyx_t_16 = 0;
            __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
            __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
            __Pyx_DECREF(__pyx_t_22); __pyx_t_22 = 0;
            __Pyx_DECREF(__pyx_t_18); __pyx_t_18 = 0;
            if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 234, __pyx_L8_error)
            __Pyx_GOTREF(__pyx_t_13);
          }
          __Pyx_GIVEREF(__pyx_t_13);
          if (unlikely(__Pyx_ListComp_AppendAndDecref(__pyx_t_11, __pyx_t_13))) __PYX_ERR(0, 234, __pyx_L8_error)
          __pyx_t_13 = 0;

          
        }
        __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
        __Pyx_XDECREF(__pyx_8genexpr1__pyx_v_run); __pyx_8genexpr1__pyx_v_run = 0;
        goto __pyx_L12_exit_scope;
        __pyx_L8_error:;
        __Pyx_XDECREF(__pyx_8genexpr1__pyx_v_run); __pyx_8genexpr1__pyx_v_run = 0;
        goto __pyx_L1_error;
        __pyx_L12_exit_scope:;
      } 

      
      __pyx_t_12 = PyUnicode_Join(__pyx_mstate_global->__pyx_kp_u__8, __pyx_t_11); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 234, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_12);
      __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
      __pyx_t_6 = 1;
      #if CYTHON_UNPACK_METHODS
      if (unlikely(PyMethod_Check(__pyx_t_2))) {
        __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_2);
        assert(__pyx_t_5);
        PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_2);
        __Pyx_INCREF(__pyx_t_5);
        __Pyx_INCREF(__pyx__function);
        __Pyx_DECREF_SET(__pyx_t_2, __pyx__function);
        __pyx_t_6 = 0;
      }
      #endif
      {
        PyObject *__pyx_callargs[3] = {__pyx_t_5, __pyx_t_3, __pyx_t_12};
        __pyx_t_4 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_2, __pyx_callargs+__pyx_t_6, (3-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
        __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
        __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
        __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
        if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 233, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_4);
      }
      __Pyx_GIVEREF(__pyx_t_4);
      if (unlikely(__Pyx_ListComp_AppendAndDecref(__pyx_t_1, __pyx_t_4))) __PYX_ERR(0, 233, __pyx_L1_error)
      __pyx_t_4 = 0;
    }


  } 
  __pyx_v_forward_placeholder = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  { 
    __pyx_t_1 = PyList_New(0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 239, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);

    
    __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 244, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_4);
    __pyx_t_7 = PyObject_Length(__pyx_t_4); if (unlikely(__pyx_t_7 == ((Py_ssize_t)-1))) __PYX_ERR(0, 244, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    __pyx_t_9 = __pyx_t_7;

    for (__pyx_t_10 = 0; __pyx_t_10 < __pyx_t_9; __pyx_t_10+=1) {
      __pyx_8genexpr2__pyx_v_i = __pyx_t_10;

      
      __pyx_t_2 = NULL;
      __Pyx_GetModuleGlobalName(__pyx_t_12, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 239, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_12);
      __pyx_t_3 = __Pyx_PyObject_GetAttrStr(__pyx_t_12, __pyx_mstate_global->__pyx_n_u_findall); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 239, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      __pyx_t_12 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 239, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_12);

      
      { 
        __pyx_t_5 = PyList_New(0); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 240, __pyx_L17_error)
        __Pyx_GOTREF(__pyx_t_5);

        
        __pyx_t_11 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 243, __pyx_L17_error)
        __Pyx_GOTREF(__pyx_t_11);
        __pyx_t_13 = __Pyx_PyObject_GetSlice(__pyx_t_11, __pyx_8genexpr2__pyx_v_i, 0, NULL, NULL, NULL, 1, 0, 1); if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 243, __pyx_L17_error)
        __Pyx_GOTREF(__pyx_t_13);
        __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
        if (likely(PyList_CheckExact(__pyx_t_13)) || PyTuple_CheckExact(__pyx_t_13)) {
          __pyx_t_11 = __pyx_t_13; __Pyx_INCREF(__pyx_t_11);
          __pyx_t_14 = 0;
          __pyx_t_15 = NULL;
        } else {
          __pyx_t_14 = -1; __pyx_t_11 = PyObject_GetIter(__pyx_t_13); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 243, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_11);
          __pyx_t_15 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_11); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 243, __pyx_L17_error)
        }
        __Pyx_DECREF(__pyx_t_13); __pyx_t_13 = 0;
        for (;;) {
          if (likely(!__pyx_t_15)) {
            if (likely(PyList_CheckExact(__pyx_t_11))) {
              {
                Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_11);
                #if !CYTHON_ASSUME_SAFE_SIZE
                if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 243, __pyx_L17_error)
                #endif
                if (__pyx_t_14 >= __pyx_temp) break;
              }
              __pyx_t_13 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_11, __pyx_t_14, __Pyx_ReferenceSharing_OwnStrongReference);
              ++__pyx_t_14;
            } else {
              {
                Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_11);
                #if !CYTHON_ASSUME_SAFE_SIZE
                if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 243, __pyx_L17_error)
                #endif
                if (__pyx_t_14 >= __pyx_temp) break;
              }
              #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
              __pyx_t_13 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_11, __pyx_t_14));
              #else
              __pyx_t_13 = __Pyx_PySequence_ITEM(__pyx_t_11, __pyx_t_14);
              #endif
              ++__pyx_t_14;
            }
            if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 243, __pyx_L17_error)
          } else {
            __pyx_t_13 = __pyx_t_15(__pyx_t_11);
            if (unlikely(!__pyx_t_13)) {
              PyObject* exc_type = PyErr_Occurred();
              if (exc_type) {
                if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 243, __pyx_L17_error)
                PyErr_Clear();
              }
              break;
            }
          }
          __Pyx_GOTREF(__pyx_t_13);
          __Pyx_XDECREF_SET(__pyx_8genexpr3__pyx_v_run, __pyx_t_13);
          __pyx_t_13 = 0;

          
          __pyx_t_18 = NULL;
          __Pyx_GetModuleGlobalName(__pyx_t_22, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_22)) __PYX_ERR(0, 240, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_22);
          __pyx_t_19 = __Pyx_PyObject_GetAttrStr(__pyx_t_22, __pyx_mstate_global->__pyx_n_u_sub); if (unlikely(!__pyx_t_19)) __PYX_ERR(0, 240, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_19);
          __Pyx_DECREF(__pyx_t_22); __pyx_t_22 = 0;
          __pyx_t_22 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_22)) __PYX_ERR(0, 240, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_22);

          
          __pyx_t_16 = NULL;
          __Pyx_GetModuleGlobalName(__pyx_t_21, __pyx_mstate_global->__pyx_n_u_re); if (unlikely(!__pyx_t_21)) __PYX_ERR(0, 241, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_21);
          __pyx_t_20 = __Pyx_PyObject_GetAttrStr(__pyx_t_21, __pyx_mstate_global->__pyx_n_u_sub); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 241, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_20);
          __Pyx_DECREF(__pyx_t_21); __pyx_t_21 = 0;
          __pyx_t_21 = __Pyx_PyObject_GetAttrStr(__pyx_v_self, __pyx_mstate_global->__pyx_n_u_pattern); if (unlikely(!__pyx_t_21)) __PYX_ERR(0, 241, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_21);
          __pyx_t_6 = 1;
          #if CYTHON_UNPACK_METHODS
          if (unlikely(PyMethod_Check(__pyx_t_20))) {
            __pyx_t_16 = PyMethod_GET_SELF(__pyx_t_20);
            assert(__pyx_t_16);
            PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_20);
            __Pyx_INCREF(__pyx_t_16);
            __Pyx_INCREF(__pyx__function);
            __Pyx_DECREF_SET(__pyx_t_20, __pyx__function);
            __pyx_t_6 = 0;
          }
          #endif
          {
            PyObject *__pyx_callargs[4] = {__pyx_t_16, __pyx_mstate_global->__pyx_kp_u__6, __pyx_mstate_global->__pyx_kp_u__8, __pyx_t_21};
            __pyx_t_17 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_20, __pyx_callargs+__pyx_t_6, (4-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_16); __pyx_t_16 = 0;
            __Pyx_DECREF(__pyx_t_21); __pyx_t_21 = 0;
            __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
            if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 241, __pyx_L17_error)
            __Pyx_GOTREF(__pyx_t_17);
          }
          __pyx_t_20 = __Pyx_PyObject_GetAttrStr(__pyx_t_17, __pyx_mstate_global->__pyx_n_u_replace); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 241, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_20);
          __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
          __pyx_t_17 = __Pyx_PyObject_Call(__pyx_t_20, __pyx_mstate_global->__pyx_tuple[0], NULL); if (unlikely(!__pyx_t_17)) __PYX_ERR(0, 241, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_17);
          __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;

          
          __pyx_t_20 = __Pyx_PyObject_GetAttrStr(__pyx_8genexpr3__pyx_v_run, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_20)) __PYX_ERR(0, 242, __pyx_L17_error)
          __Pyx_GOTREF(__pyx_t_20);
          __pyx_t_6 = 1;
          #if CYTHON_UNPACK_METHODS
          if (unlikely(PyMethod_Check(__pyx_t_19))) {
            __pyx_t_18 = PyMethod_GET_SELF(__pyx_t_19);
            assert(__pyx_t_18);
            PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_19);
            __Pyx_INCREF(__pyx_t_18);
            __Pyx_INCREF(__pyx__function);
            __Pyx_DECREF_SET(__pyx_t_19, __pyx__function);
            __pyx_t_6 = 0;
          }
          #endif
          {
            PyObject *__pyx_callargs[4] = {__pyx_t_18, __pyx_t_22, __pyx_t_17, __pyx_t_20};
            __pyx_t_13 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_19, __pyx_callargs+__pyx_t_6, (4-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_18); __pyx_t_18 = 0;
            __Pyx_DECREF(__pyx_t_22); __pyx_t_22 = 0;
            __Pyx_DECREF(__pyx_t_17); __pyx_t_17 = 0;
            __Pyx_DECREF(__pyx_t_20); __pyx_t_20 = 0;
            __Pyx_DECREF(__pyx_t_19); __pyx_t_19 = 0;
            if (unlikely(!__pyx_t_13)) __PYX_ERR(0, 240, __pyx_L17_error)
            __Pyx_GOTREF(__pyx_t_13);
          }
          __Pyx_GIVEREF(__pyx_t_13);
          if (unlikely(__Pyx_ListComp_AppendAndDecref(__pyx_t_5, __pyx_t_13))) __PYX_ERR(0, 240, __pyx_L17_error)
          __pyx_t_13 = 0;

          
        }
        __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
        __Pyx_XDECREF(__pyx_8genexpr3__pyx_v_run); __pyx_8genexpr3__pyx_v_run = 0;
        goto __pyx_L21_exit_scope;
        __pyx_L17_error:;
        __Pyx_XDECREF(__pyx_8genexpr3__pyx_v_run); __pyx_8genexpr3__pyx_v_run = 0;
        goto __pyx_L1_error;
        __pyx_L21_exit_scope:;
      } 

      
      __pyx_t_11 = PyUnicode_Join(__pyx_mstate_global->__pyx_kp_u__8, __pyx_t_5); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 240, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_11);
      __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
      __pyx_t_6 = 1;
      #if CYTHON_UNPACK_METHODS
      if (unlikely(PyMethod_Check(__pyx_t_3))) {
        __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_3);
        assert(__pyx_t_2);
        PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_3);
        __Pyx_INCREF(__pyx_t_2);
        __Pyx_INCREF(__pyx__function);
        __Pyx_DECREF_SET(__pyx_t_3, __pyx__function);
        __pyx_t_6 = 0;
      }
      #endif
      {
        PyObject *__pyx_callargs[3] = {__pyx_t_2, __pyx_t_12, __pyx_t_11};
        __pyx_t_4 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_3, __pyx_callargs+__pyx_t_6, (3-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
        __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
        __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
        __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
        if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 239, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_4);
      }
      __Pyx_GIVEREF(__pyx_t_4);
      if (unlikely(__Pyx_ListComp_AppendAndDecref(__pyx_t_1, __pyx_t_4))) __PYX_ERR(0, 239, __pyx_L1_error)
      __pyx_t_4 = 0;
    }


  } 
  __pyx_v_backward_placeholder = ((PyObject*)__pyx_t_1);
  __pyx_t_1 = 0;

  
  __pyx_t_1 = __Pyx_GetItemInt_List(__pyx_v_forward_placeholder, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 245, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_t_7 = PyObject_Length(__pyx_t_1); if (unlikely(__pyx_t_7 == ((Py_ssize_t)-1))) __PYX_ERR(0, 245, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_t_1 = __Pyx_PyBool_FromLong((__pyx_t_7 > 0)); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 245, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);

  __pyx_t_4 = PyList_New(1); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 245, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  __Pyx_GIVEREF(__pyx_t_1);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_4, 0, __pyx_t_1) != (0)) __PYX_ERR(0, 245, __pyx_L1_error);
  __pyx_t_1 = 0;
  { 
    __pyx_t_1 = PyList_New(0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 245, __pyx_L24_error)
    __Pyx_GOTREF(__pyx_t_1);
    __pyx_t_11 = NULL;
    __pyx_t_12 = __Pyx_PyList_GetSlice(__pyx_v_forward_placeholder, 1, PY_SSIZE_T_MAX); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 245, __pyx_L24_error)
    __Pyx_GOTREF(__pyx_t_12);
    __pyx_t_2 = __Pyx_PyList_GetSlice(__pyx_v_forward_placeholder, 0, -1L); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 245, __pyx_L24_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_6 = 1;
    {
      PyObject *__pyx_callargs[3] = {__pyx_t_11, __pyx_t_12, __pyx_t_2};
      __pyx_t_3 = __Pyx_PyObject_FastCall((PyObject*)__pyx_builtin_zip, __pyx_callargs+__pyx_t_6, (3-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_11); __pyx_t_11 = 0;
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
      if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 245, __pyx_L24_error)
      __Pyx_GOTREF(__pyx_t_3);
    }
    if (likely(PyList_CheckExact(__pyx_t_3)) || PyTuple_CheckExact(__pyx_t_3)) {
      __pyx_t_2 = __pyx_t_3; __Pyx_INCREF(__pyx_t_2);
      __pyx_t_7 = 0;
      __pyx_t_15 = NULL;
    } else {
      __pyx_t_7 = -1; __pyx_t_2 = PyObject_GetIter(__pyx_t_3); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 245, __pyx_L24_error)
      __Pyx_GOTREF(__pyx_t_2);
      __pyx_t_15 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_2); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 245, __pyx_L24_error)
    }
    __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
    for (;;) {
      if (likely(!__pyx_t_15)) {
        if (likely(PyList_CheckExact(__pyx_t_2))) {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_2);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 245, __pyx_L24_error)
            #endif
            if (__pyx_t_7 >= __pyx_temp) break;
          }
          __pyx_t_3 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_2, __pyx_t_7, __Pyx_ReferenceSharing_OwnStrongReference);
          ++__pyx_t_7;
        } else {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_2);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 245, __pyx_L24_error)
            #endif
            if (__pyx_t_7 >= __pyx_temp) break;
          }
          #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
          __pyx_t_3 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_2, __pyx_t_7));
          #else
          __pyx_t_3 = __Pyx_PySequence_ITEM(__pyx_t_2, __pyx_t_7);
          #endif
          ++__pyx_t_7;
        }
        if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 245, __pyx_L24_error)
      } else {
        __pyx_t_3 = __pyx_t_15(__pyx_t_2);
        if (unlikely(!__pyx_t_3)) {
          PyObject* exc_type = PyErr_Occurred();
          if (exc_type) {
            if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 245, __pyx_L24_error)
            PyErr_Clear();
          }
          break;
        }
      }
      __Pyx_GOTREF(__pyx_t_3);
      if ((likely(PyTuple_CheckExact(__pyx_t_3))) || (PyList_CheckExact(__pyx_t_3))) {
        PyObject* sequence = __pyx_t_3;
        Py_ssize_t size = __Pyx_PySequence_SIZE(sequence);
        if (unlikely(size != 2)) {
          if (size > 2) __Pyx_RaiseTooManyValuesError(2);
          else if (size >= 0) __Pyx_RaiseNeedMoreValuesError(size);
          __PYX_ERR(0, 245, __pyx_L24_error)
        }
        #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
        if (likely(PyTuple_CheckExact(sequence))) {
          __pyx_t_12 = PyTuple_GET_ITEM(sequence, 0);
          __Pyx_INCREF(__pyx_t_12);
          __pyx_t_11 = PyTuple_GET_ITEM(sequence, 1);
          __Pyx_INCREF(__pyx_t_11);
        } else {
          __pyx_t_12 = __Pyx_PyList_GET_ITEM_REF(sequence, 0, __Pyx_ReferenceSharing_SharedReference);
          if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 245, __pyx_L24_error)
          __Pyx_XGOTREF(__pyx_t_12);
          __pyx_t_11 = __Pyx_PyList_GET_ITEM_REF(sequence, 1, __Pyx_ReferenceSharing_SharedReference);
          if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 245, __pyx_L24_error)
          __Pyx_XGOTREF(__pyx_t_11);
        }
        #else
        __pyx_t_12 = __Pyx_PySequence_ITEM(sequence, 0); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 245, __pyx_L24_error)
        __Pyx_GOTREF(__pyx_t_12);
        __pyx_t_11 = __Pyx_PySequence_ITEM(sequence, 1); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 245, __pyx_L24_error)
        __Pyx_GOTREF(__pyx_t_11);
        #endif
        __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
      } else {
        Py_ssize_t index = -1;
        __pyx_t_5 = PyObject_GetIter(__pyx_t_3); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 245, __pyx_L24_error)
        __Pyx_GOTREF(__pyx_t_5);
        __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
        __pyx_t_23 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_5);
        index = 0; __pyx_t_12 = __pyx_t_23(__pyx_t_5); if (unlikely(!__pyx_t_12)) goto __pyx_L27_unpacking_failed;
        __Pyx_GOTREF(__pyx_t_12);
        index = 1; __pyx_t_11 = __pyx_t_23(__pyx_t_5); if (unlikely(!__pyx_t_11)) goto __pyx_L27_unpacking_failed;
        __Pyx_GOTREF(__pyx_t_11);
        if (__Pyx_IternextUnpackEndCheck(__pyx_t_23(__pyx_t_5), 2) < (0)) __PYX_ERR(0, 245, __pyx_L24_error)
        __pyx_t_23 = NULL;
        __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
        goto __pyx_L28_unpacking_done;
        __pyx_L27_unpacking_failed:;
        __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
        __pyx_t_23 = NULL;
        if (__Pyx_IterFinish() == 0) __Pyx_RaiseNeedMoreValuesError(index);
        __PYX_ERR(0, 245, __pyx_L24_error)
        __pyx_L28_unpacking_done:;
      }
      __Pyx_XDECREF_SET(__pyx_8genexpr4__pyx_v_i, __pyx_t_12);
      __pyx_t_12 = 0;
      __Pyx_XDECREF_SET(__pyx_8genexpr4__pyx_v_j, __pyx_t_11);
      __pyx_t_11 = 0;
      __pyx_t_9 = PyObject_Length(__pyx_8genexpr4__pyx_v_i); if (unlikely(__pyx_t_9 == ((Py_ssize_t)-1))) __PYX_ERR(0, 245, __pyx_L24_error)
      __pyx_t_10 = PyObject_Length(__pyx_8genexpr4__pyx_v_j); if (unlikely(__pyx_t_10 == ((Py_ssize_t)-1))) __PYX_ERR(0, 245, __pyx_L24_error)
      __pyx_t_3 = __Pyx_PyBool_FromLong((__pyx_t_9 > __pyx_t_10)); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 245, __pyx_L24_error)
      __Pyx_GOTREF(__pyx_t_3);


      __Pyx_GIVEREF(__pyx_t_3);
      if (unlikely(__Pyx_ListComp_AppendAndDecref(__pyx_t_1, __pyx_t_3))) __PYX_ERR(0, 245, __pyx_L24_error)
      __pyx_t_3 = 0;
    }
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_XDECREF(__pyx_8genexpr4__pyx_v_i); __pyx_8genexpr4__pyx_v_i = 0;
    __Pyx_XDECREF(__pyx_8genexpr4__pyx_v_j); __pyx_8genexpr4__pyx_v_j = 0;
    goto __pyx_L30_exit_scope;
    __pyx_L24_error:;
    __Pyx_XDECREF(__pyx_8genexpr4__pyx_v_i); __pyx_8genexpr4__pyx_v_i = 0;
    __Pyx_XDECREF(__pyx_8genexpr4__pyx_v_j); __pyx_8genexpr4__pyx_v_j = 0;
    goto __pyx_L1_error;
    __pyx_L30_exit_scope:;
  } 
  __pyx_t_2 = PyNumber_Add(__pyx_t_4, __pyx_t_1); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 245, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_v_forward_add = ((PyObject*)__pyx_t_2);
  __pyx_t_2 = 0;

  
  { 
    __pyx_t_2 = PyList_New(0); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 246, __pyx_L33_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_4 = NULL;
    __pyx_t_3 = __Pyx_PyList_GetSlice(__pyx_v_backward_placeholder, 1, PY_SSIZE_T_MAX); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 246, __pyx_L33_error)
    __Pyx_GOTREF(__pyx_t_3);
    __pyx_t_11 = __Pyx_PyList_GetSlice(__pyx_v_backward_placeholder, 0, -1L); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 246, __pyx_L33_error)
    __Pyx_GOTREF(__pyx_t_11);
    __pyx_t_6 = 1;
    {
      PyObject *__pyx_callargs[3] = {__pyx_t_4, __pyx_t_3, __pyx_t_11};
      __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_builtin_zip, __pyx_callargs+__pyx_t_6, (3-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
      __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
      __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 246, __pyx_L33_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    if (likely(PyList_CheckExact(__pyx_t_1)) || PyTuple_CheckExact(__pyx_t_1)) {
      __pyx_t_11 = __pyx_t_1; __Pyx_INCREF(__pyx_t_11);
      __pyx_t_7 = 0;
      __pyx_t_15 = NULL;
    } else {
      __pyx_t_7 = -1; __pyx_t_11 = PyObject_GetIter(__pyx_t_1); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 246, __pyx_L33_error)
      __Pyx_GOTREF(__pyx_t_11);
      __pyx_t_15 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_11); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 246, __pyx_L33_error)
    }
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    for (;;) {
      if (likely(!__pyx_t_15)) {
        if (likely(PyList_CheckExact(__pyx_t_11))) {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_11);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 246, __pyx_L33_error)
            #endif
            if (__pyx_t_7 >= __pyx_temp) break;
          }
          __pyx_t_1 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_11, __pyx_t_7, __Pyx_ReferenceSharing_OwnStrongReference);
          ++__pyx_t_7;
        } else {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_11);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 246, __pyx_L33_error)
            #endif
            if (__pyx_t_7 >= __pyx_temp) break;
          }
          #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
          __pyx_t_1 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_11, __pyx_t_7));
          #else
          __pyx_t_1 = __Pyx_PySequence_ITEM(__pyx_t_11, __pyx_t_7);
          #endif
          ++__pyx_t_7;
        }
        if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 246, __pyx_L33_error)
      } else {
        __pyx_t_1 = __pyx_t_15(__pyx_t_11);
        if (unlikely(!__pyx_t_1)) {
          PyObject* exc_type = PyErr_Occurred();
          if (exc_type) {
            if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 246, __pyx_L33_error)
            PyErr_Clear();
          }
          break;
        }
      }
      __Pyx_GOTREF(__pyx_t_1);
      if ((likely(PyTuple_CheckExact(__pyx_t_1))) || (PyList_CheckExact(__pyx_t_1))) {
        PyObject* sequence = __pyx_t_1;
        Py_ssize_t size = __Pyx_PySequence_SIZE(sequence);
        if (unlikely(size != 2)) {
          if (size > 2) __Pyx_RaiseTooManyValuesError(2);
          else if (size >= 0) __Pyx_RaiseNeedMoreValuesError(size);
          __PYX_ERR(0, 246, __pyx_L33_error)
        }
        #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
        if (likely(PyTuple_CheckExact(sequence))) {
          __pyx_t_3 = PyTuple_GET_ITEM(sequence, 0);
          __Pyx_INCREF(__pyx_t_3);
          __pyx_t_4 = PyTuple_GET_ITEM(sequence, 1);
          __Pyx_INCREF(__pyx_t_4);
        } else {
          __pyx_t_3 = __Pyx_PyList_GET_ITEM_REF(sequence, 0, __Pyx_ReferenceSharing_SharedReference);
          if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 246, __pyx_L33_error)
          __Pyx_XGOTREF(__pyx_t_3);
          __pyx_t_4 = __Pyx_PyList_GET_ITEM_REF(sequence, 1, __Pyx_ReferenceSharing_SharedReference);
          if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 246, __pyx_L33_error)
          __Pyx_XGOTREF(__pyx_t_4);
        }
        #else
        __pyx_t_3 = __Pyx_PySequence_ITEM(sequence, 0); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 246, __pyx_L33_error)
        __Pyx_GOTREF(__pyx_t_3);
        __pyx_t_4 = __Pyx_PySequence_ITEM(sequence, 1); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 246, __pyx_L33_error)
        __Pyx_GOTREF(__pyx_t_4);
        #endif
        __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      } else {
        Py_ssize_t index = -1;
        __pyx_t_12 = PyObject_GetIter(__pyx_t_1); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 246, __pyx_L33_error)
        __Pyx_GOTREF(__pyx_t_12);
        __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
        __pyx_t_23 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_12);
        index = 0; __pyx_t_3 = __pyx_t_23(__pyx_t_12); if (unlikely(!__pyx_t_3)) goto __pyx_L36_unpacking_failed;
        __Pyx_GOTREF(__pyx_t_3);
        index = 1; __pyx_t_4 = __pyx_t_23(__pyx_t_12); if (unlikely(!__pyx_t_4)) goto __pyx_L36_unpacking_failed;
        __Pyx_GOTREF(__pyx_t_4);
        if (__Pyx_IternextUnpackEndCheck(__pyx_t_23(__pyx_t_12), 2) < (0)) __PYX_ERR(0, 246, __pyx_L33_error)
        __pyx_t_23 = NULL;
        __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
        goto __pyx_L37_unpacking_done;
        __pyx_L36_unpacking_failed:;
        __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
        __pyx_t_23 = NULL;
        if (__Pyx_IterFinish() == 0) __Pyx_RaiseNeedMoreValuesError(index);
        __PYX_ERR(0, 246, __pyx_L33_error)
        __pyx_L37_unpacking_done:;
      }
      __Pyx_XDECREF_SET(__pyx_8genexpr5__pyx_v_i, __pyx_t_3);
      __pyx_t_3 = 0;
      __Pyx_XDECREF_SET(__pyx_8genexpr5__pyx_v_j, __pyx_t_4);
      __pyx_t_4 = 0;
      __pyx_t_10 = PyObject_Length(__pyx_8genexpr5__pyx_v_j); if (unlikely(__pyx_t_10 == ((Py_ssize_t)-1))) __PYX_ERR(0, 246, __pyx_L33_error)
      __pyx_t_9 = PyObject_Length(__pyx_8genexpr5__pyx_v_i); if (unlikely(__pyx_t_9 == ((Py_ssize_t)-1))) __PYX_ERR(0, 246, __pyx_L33_error)
      __pyx_t_1 = __Pyx_PyBool_FromLong((__pyx_t_10 > __pyx_t_9)); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 246, __pyx_L33_error)
      __Pyx_GOTREF(__pyx_t_1);


      __Pyx_GIVEREF(__pyx_t_1);
      if (unlikely(__Pyx_ListComp_AppendAndDecref(__pyx_t_2, __pyx_t_1))) __PYX_ERR(0, 246, __pyx_L33_error)
      __pyx_t_1 = 0;
    }
    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
    __Pyx_XDECREF(__pyx_8genexpr5__pyx_v_i); __pyx_8genexpr5__pyx_v_i = 0;
    __Pyx_XDECREF(__pyx_8genexpr5__pyx_v_j); __pyx_8genexpr5__pyx_v_j = 0;
    goto __pyx_L39_exit_scope;
    __pyx_L33_error:;
    __Pyx_XDECREF(__pyx_8genexpr5__pyx_v_i); __pyx_8genexpr5__pyx_v_i = 0;
    __Pyx_XDECREF(__pyx_8genexpr5__pyx_v_j); __pyx_8genexpr5__pyx_v_j = 0;
    goto __pyx_L1_error;
    __pyx_L39_exit_scope:;
  } 
  __pyx_t_11 = __Pyx_GetItemInt_List(__pyx_v_backward_placeholder, -1L, long, 1, __Pyx_PyLong_From_long, 1, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 246, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_11);
  __pyx_t_7 = PyObject_Length(__pyx_t_11); if (unlikely(__pyx_t_7 == ((Py_ssize_t)-1))) __PYX_ERR(0, 246, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
  __pyx_t_11 = __Pyx_PyBool_FromLong((__pyx_t_7 > 0)); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 246, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_11);

  __pyx_t_1 = PyList_New(1); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 246, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __Pyx_GIVEREF(__pyx_t_11);
  if (__Pyx_PyList_SET_ITEM(__pyx_t_1, 0, __pyx_t_11) != (0)) __PYX_ERR(0, 246, __pyx_L1_error);
  __pyx_t_11 = 0;
  __pyx_t_11 = PyNumber_Add(__pyx_t_2, __pyx_t_1); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 246, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_11);
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  __pyx_v_backward_add = ((PyObject*)__pyx_t_11);
  __pyx_t_11 = 0;

  
  __Pyx_INCREF(__pyx_mstate_global->__pyx_int_0);
  __pyx_v_to_be_add = __pyx_mstate_global->__pyx_int_0;

  
  __pyx_t_11 = PyList_New(0); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 271, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_11);
  __pyx_v_concated = ((PyObject*)__pyx_t_11);
  __pyx_t_11 = 0;

  
  __Pyx_INCREF(Py_None);
  __pyx_v_over = Py_None;

  
  __Pyx_INCREF(__pyx_mstate_global->__pyx_int_0);
  __pyx_t_11 = __pyx_mstate_global->__pyx_int_0;
  __pyx_t_2 = NULL;
  __pyx_t_6 = 1;
  {
    PyObject *__pyx_callargs[3] = {__pyx_t_2, __pyx_v_backward_add, __pyx_v_forward_add};
    __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_builtin_zip, __pyx_callargs+__pyx_t_6, (3-__pyx_t_6) | (__pyx_t_6*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 273, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  if (likely(PyList_CheckExact(__pyx_t_1)) || PyTuple_CheckExact(__pyx_t_1)) {
    __pyx_t_2 = __pyx_t_1; __Pyx_INCREF(__pyx_t_2);
    __pyx_t_7 = 0;
    __pyx_t_15 = NULL;
  } else {
    __pyx_t_7 = -1; __pyx_t_2 = PyObject_GetIter(__pyx_t_1); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 273, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
    __pyx_t_15 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_2); if (unlikely(!__pyx_t_15)) __PYX_ERR(0, 273, __pyx_L1_error)
  }
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
  for (;;) {
    if (likely(!__pyx_t_15)) {
      if (likely(PyList_CheckExact(__pyx_t_2))) {
        {
          Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_2);
          #if !CYTHON_ASSUME_SAFE_SIZE
          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 273, __pyx_L1_error)
          #endif
          if (__pyx_t_7 >= __pyx_temp) break;
        }
        __pyx_t_1 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_2, __pyx_t_7, __Pyx_ReferenceSharing_OwnStrongReference);
        ++__pyx_t_7;
      } else {
        {
          Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_2);
          #if !CYTHON_ASSUME_SAFE_SIZE
          if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 273, __pyx_L1_error)
          #endif
          if (__pyx_t_7 >= __pyx_temp) break;
        }
        #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
        __pyx_t_1 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_2, __pyx_t_7));
        #else
        __pyx_t_1 = __Pyx_PySequence_ITEM(__pyx_t_2, __pyx_t_7);
        #endif
        ++__pyx_t_7;
      }
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 273, __pyx_L1_error)
    } else {
      __pyx_t_1 = __pyx_t_15(__pyx_t_2);
      if (unlikely(!__pyx_t_1)) {
        PyObject* exc_type = PyErr_Occurred();
        if (exc_type) {
          if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 273, __pyx_L1_error)
          PyErr_Clear();
        }
        break;
      }
    }
    __Pyx_GOTREF(__pyx_t_1);
    if ((likely(PyTuple_CheckExact(__pyx_t_1))) || (PyList_CheckExact(__pyx_t_1))) {
      PyObject* sequence = __pyx_t_1;
      Py_ssize_t size = __Pyx_PySequence_SIZE(sequence);
      if (unlikely(size != 2)) {
        if (size > 2) __Pyx_RaiseTooManyValuesError(2);
        else if (size >= 0) __Pyx_RaiseNeedMoreValuesError(size);
        __PYX_ERR(0, 273, __pyx_L1_error)
      }
      #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
      if (likely(PyTuple_CheckExact(sequence))) {
        __pyx_t_4 = PyTuple_GET_ITEM(sequence, 0);
        __Pyx_INCREF(__pyx_t_4);
        __pyx_t_3 = PyTuple_GET_ITEM(sequence, 1);
        __Pyx_INCREF(__pyx_t_3);
      } else {
        __pyx_t_4 = __Pyx_PyList_GET_ITEM_REF(sequence, 0, __Pyx_ReferenceSharing_SharedReference);
        if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 273, __pyx_L1_error)
        __Pyx_XGOTREF(__pyx_t_4);
        __pyx_t_3 = __Pyx_PyList_GET_ITEM_REF(sequence, 1, __Pyx_ReferenceSharing_SharedReference);
        if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 273, __pyx_L1_error)
        __Pyx_XGOTREF(__pyx_t_3);
      }
      #else
      __pyx_t_4 = __Pyx_PySequence_ITEM(sequence, 0); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 273, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_3 = __Pyx_PySequence_ITEM(sequence, 1); if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 273, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
      #endif
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    } else {
      Py_ssize_t index = -1;
      __pyx_t_12 = PyObject_GetIter(__pyx_t_1); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 273, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_12);
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      __pyx_t_23 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_12);
      index = 0; __pyx_t_4 = __pyx_t_23(__pyx_t_12); if (unlikely(!__pyx_t_4)) goto __pyx_L42_unpacking_failed;
      __Pyx_GOTREF(__pyx_t_4);
      index = 1; __pyx_t_3 = __pyx_t_23(__pyx_t_12); if (unlikely(!__pyx_t_3)) goto __pyx_L42_unpacking_failed;
      __Pyx_GOTREF(__pyx_t_3);
      if (__Pyx_IternextUnpackEndCheck(__pyx_t_23(__pyx_t_12), 2) < (0)) __PYX_ERR(0, 273, __pyx_L1_error)
      __pyx_t_23 = NULL;
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      goto __pyx_L43_unpacking_done;
      __pyx_L42_unpacking_failed:;
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      __pyx_t_23 = NULL;
      if (__Pyx_IterFinish() == 0) __Pyx_RaiseNeedMoreValuesError(index);
      __PYX_ERR(0, 273, __pyx_L1_error)
      __pyx_L43_unpacking_done:;
    }
    __Pyx_XDECREF_SET(__pyx_v_back, __pyx_t_4);
    __pyx_t_4 = 0;
    __Pyx_XDECREF_SET(__pyx_v_forward, __pyx_t_3);
    __pyx_t_3 = 0;
    __Pyx_INCREF(__pyx_t_11);
    __Pyx_XDECREF_SET(__pyx_v_i, __pyx_t_11);
    __pyx_t_1 = __Pyx_PyLong_AddObjC(__pyx_t_11, __pyx_mstate_global->__pyx_int_1, 1, 0, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 273, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __Pyx_DECREF(__pyx_t_11);
    __pyx_t_11 = __pyx_t_1;
    __pyx_t_1 = 0;

    
    __pyx_t_24 = __Pyx_PyObject_IsTrue(__pyx_v_back); if (unlikely((__pyx_t_24 < 0))) __PYX_ERR(0, 276, __pyx_L1_error)
    if (__pyx_t_24) {

    } else {

      __pyx_t_8 = __pyx_t_24;

      goto __pyx_L45_bool_binop_done;
    }
    __pyx_t_24 = __Pyx_PyObject_IsTrue(__pyx_v_forward); if (unlikely((__pyx_t_24 < 0))) __PYX_ERR(0, 276, __pyx_L1_error)
    __pyx_t_25 = (!__pyx_t_24);



    __pyx_t_8 = __pyx_t_25;

    __pyx_L45_bool_binop_done:;
    if (__pyx_t_8) {


      
      __Pyx_INCREF(__pyx_v_i);
      __Pyx_DECREF_SET(__pyx_v_to_be_add, __pyx_v_i);

      
      __Pyx_INCREF(Py_False);
      __Pyx_DECREF_SET(__pyx_v_over, Py_False);

      
      goto __pyx_L44;
    }

    
    __pyx_t_25 = __Pyx_PyObject_IsTrue(__pyx_v_forward); if (unlikely((__pyx_t_25 < 0))) __PYX_ERR(0, 279, __pyx_L1_error)
    if (__pyx_t_25) {

    } else {

      __pyx_t_8 = __pyx_t_25;

      goto __pyx_L47_bool_binop_done;
    }
    __pyx_t_25 = __Pyx_PyObject_IsTrue(__pyx_v_back); if (unlikely((__pyx_t_25 < 0))) __PYX_ERR(0, 279, __pyx_L1_error)
    __pyx_t_24 = (!__pyx_t_25);



    __pyx_t_8 = __pyx_t_24;

    __pyx_L47_bool_binop_done:;
    if (__pyx_t_8) {


      
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 280, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_INCREF(__pyx_v_to_be_add);
      __pyx_t_3 = __pyx_v_to_be_add;
      __pyx_t_4 = __Pyx_PyObject_GetItem(__pyx_t_1, __pyx_t_3); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 280, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_12 = __Pyx_PyObject_GetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 280, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_12);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 280, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_5 = __Pyx_PyObject_GetItem(__pyx_t_4, __pyx_v_i); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 280, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_5);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 280, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
      __pyx_t_5 = __Pyx_PyNumber_InPlaceAdd_object_object(__pyx_t_12, __pyx_t_4); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 280, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_5);
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetItem(__pyx_t_1, __pyx_t_3); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 280, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_text, __pyx_t_5) < (0)) __PYX_ERR(0, 280, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

      
      __pyx_t_26 = __Pyx_PyList_Append(__pyx_v_concated, __pyx_v_i); if (unlikely(__pyx_t_26 == ((int)-1))) __PYX_ERR(0, 281, __pyx_L1_error)


      
      __pyx_t_1 = __Pyx_PyLong_AddObjC(__pyx_v_i, __pyx_mstate_global->__pyx_int_1, 1, 0, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 282, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_DECREF_SET(__pyx_v_to_be_add, __pyx_t_1);
      __pyx_t_1 = 0;

      
      __Pyx_INCREF(Py_True);
      __Pyx_DECREF_SET(__pyx_v_over, Py_True);

      
      goto __pyx_L44;
    }

    
    __pyx_t_24 = __Pyx_PyObject_IsTrue(__pyx_v_back); if (unlikely((__pyx_t_24 < 0))) __PYX_ERR(0, 284, __pyx_L1_error)
    __pyx_t_25 = (!__pyx_t_24);


    if (__pyx_t_25) {

    } else {

      __pyx_t_8 = __pyx_t_25;

      goto __pyx_L49_bool_binop_done;
    }
    __pyx_t_25 = __Pyx_PyObject_IsTrue(__pyx_v_forward); if (unlikely((__pyx_t_25 < 0))) __PYX_ERR(0, 284, __pyx_L1_error)
    __pyx_t_24 = (!__pyx_t_25);


    if (__pyx_t_24) {

    } else {

      __pyx_t_8 = __pyx_t_24;

      goto __pyx_L49_bool_binop_done;
    }
    __pyx_t_24 = (__pyx_v_over == Py_True);

    __pyx_t_8 = __pyx_t_24;

    __pyx_L49_bool_binop_done:;
    if (__pyx_t_8) {


      
      __Pyx_INCREF(Py_None);
      __Pyx_DECREF_SET(__pyx_v_over, Py_None);

      
      goto __pyx_L44;
    }

    
    __pyx_t_8 = (__pyx_v_over == Py_False);
    if (__pyx_t_8) {


      
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 287, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_INCREF(__pyx_v_to_be_add);
      __pyx_t_3 = __pyx_v_to_be_add;
      __pyx_t_4 = __Pyx_PyObject_GetItem(__pyx_t_1, __pyx_t_3); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 287, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_5 = __Pyx_PyObject_GetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 287, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_5);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 287, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_12 = __Pyx_PyObject_GetItem(__pyx_t_4, __pyx_v_i); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 287, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_12);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_t_12, __pyx_mstate_global->__pyx_n_u_text); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 287, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      __pyx_t_12 = __Pyx_PyNumber_InPlaceAdd_object_object(__pyx_t_5, __pyx_t_4); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 287, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_12);
      __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetItem(__pyx_t_1, __pyx_t_3); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 287, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_text, __pyx_t_12) < (0)) __PYX_ERR(0, 287, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

      
      __pyx_t_26 = __Pyx_PyList_Append(__pyx_v_concated, __pyx_v_i); if (unlikely(__pyx_t_26 == ((int)-1))) __PYX_ERR(0, 288, __pyx_L1_error)


      
      goto __pyx_L44;
    }

    
     {
    }
    __pyx_L44:;

    
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
  __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;

  
  __pyx_t_11 = __Pyx_PyObject_GetItem(__pyx_v_concated, __pyx_mstate_global->__pyx_slice[0]); if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 293, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_11);
  __pyx_t_2 = __pyx_t_11; __Pyx_INCREF(__pyx_t_2);
  __pyx_t_7 = 0;
  __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;
  for (;;) {
    {
      Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_2);
      #if !CYTHON_ASSUME_SAFE_SIZE
      if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 293, __pyx_L1_error)
      #endif
      if (__pyx_t_7 >= __pyx_temp) break;
    }
    __pyx_t_11 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_2, __pyx_t_7, __Pyx_ReferenceSharing_OwnStrongReference);
    ++__pyx_t_7;
    if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 293, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_11);
    __Pyx_XDECREF_SET(__pyx_v_i, __pyx_t_11);
    __pyx_t_11 = 0;

    
    __pyx_t_12 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 294, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_12);
    __pyx_t_5 = __Pyx_PyObject_GetItem(__pyx_t_12, __pyx_v_i); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 294, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_5);
    __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
    __pyx_t_12 = __Pyx_PyObject_GetAttrStr(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_element); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 294, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_12);
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    __pyx_t_4 = __pyx_t_12;
    __Pyx_INCREF(__pyx_t_4);
    __pyx_t_6 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_4, NULL};
      __pyx_t_3 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_getparent, __pyx_callargs+__pyx_t_6, (1-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      if (unlikely(!__pyx_t_3)) __PYX_ERR(0, 294, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_3);
    }
    __pyx_t_1 = __pyx_t_3;
    __Pyx_INCREF(__pyx_t_1);
    __pyx_t_12 = __Pyx_PyObject_GetAttrStr(__pyx_v_paragraph, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 294, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_12);
    __pyx_t_4 = __Pyx_PyObject_GetItem(__pyx_t_12, __pyx_v_i); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 294, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_4);
    __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
    __pyx_t_12 = __Pyx_PyObject_GetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_element); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 294, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_12);
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    __pyx_t_6 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_1, __pyx_t_12};
      __pyx_t_11 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_remove, __pyx_callargs+__pyx_t_6, (2-__pyx_t_6) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_1); __pyx_t_1 = 0;
      __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
      __Pyx_DECREF(__pyx_t_3); __pyx_t_3 = 0;
      if (unlikely(!__pyx_t_11)) __PYX_ERR(0, 294, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_11);
    }
    __Pyx_DECREF(__pyx_t_11); __pyx_t_11 = 0;

    
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  {
    PyObject *__pyx_temp;
    {
      __pyx_temp = __pyx_r;
      __Pyx_INCREF(__pyx_v_paragraph);
      __pyx_r = __pyx_v_paragraph;
    }
    __Pyx_XDECREF(__pyx_temp);
  }
  goto __pyx_L0;

  

  
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_3);
  __Pyx_XDECREF(__pyx_t_4);
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_11);
  __Pyx_XDECREF(__pyx_t_12);
  __Pyx_XDECREF(__pyx_t_13);
  __Pyx_XDECREF(__pyx_t_16);
  __Pyx_XDECREF(__pyx_t_17);
  __Pyx_XDECREF(__pyx_t_18);
  __Pyx_XDECREF(__pyx_t_19);
  __Pyx_XDECREF(__pyx_t_20);
  __Pyx_XDECREF(__pyx_t_21);
  __Pyx_XDECREF(__pyx_t_22);
  __Pyx_AddTraceback("cloze.template_docx.TemplateDocx.concat_run", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_forward_placeholder);
  __Pyx_XDECREF(__pyx_v_backward_placeholder);
  __Pyx_XDECREF(__pyx_v_forward_add);
  __Pyx_XDECREF(__pyx_v_backward_add);
  __Pyx_XDECREF(__pyx_v_to_be_add);
  __Pyx_XDECREF(__pyx_v_concated);
  __Pyx_XDECREF(__pyx_v_over);
  __Pyx_XDECREF(__pyx_v_i);
  __Pyx_XDECREF(__pyx_v_back);
  __Pyx_XDECREF(__pyx_v_forward);

  __Pyx_XDECREF(__pyx_8genexpr1__pyx_v_run);

  __Pyx_XDECREF(__pyx_8genexpr3__pyx_v_run);
  __Pyx_XDECREF(__pyx_8genexpr4__pyx_v_i);
  __Pyx_XDECREF(__pyx_8genexpr4__pyx_v_j);
  __Pyx_XDECREF(__pyx_8genexpr5__pyx_v_i);
  __Pyx_XDECREF(__pyx_8genexpr5__pyx_v_j);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}




static PyObject *__pyx_pw_5cloze_13template_docx_1cell_format_painter(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
); 
PyDoc_STRVAR(__pyx_doc_5cloze_13template_docx_cell_format_painter, "\345\260\206\346\272\220\345\215\225\345\205\203\346\240\274\347\232\204\346\211\200\346\234\211\346\240\274\345\274\217\345\244\215\345\210\266\345\210\260\347\233\256\346\240\207\345\215\225\345\205\203\346\240\274");
static PyMethodDef __pyx_mdef_5cloze_13template_docx_1cell_format_painter = {"cell_format_painter", (PyCFunction)(void(*)(void))(__Pyx_PyCFunction_FastCallWithKeywords)__pyx_pw_5cloze_13template_docx_1cell_format_painter, __Pyx_METH_FASTCALL|METH_KEYWORDS, __pyx_doc_5cloze_13template_docx_cell_format_painter};
static PyObject *__pyx_pw_5cloze_13template_docx_1cell_format_painter(PyObject *__pyx_self, 
#if CYTHON_VECTORCALL
PyObject *const *__pyx_args, Py_ssize_t __pyx_nargs, PyObject *__pyx_kwds
#else
PyObject *__pyx_args, PyObject *__pyx_kwds
#endif
) {
  PyObject *__pyx_v_cell = 0;
  PyObject *__pyx_v_from_cell = 0;
  #if !CYTHON_VECTORCALL
  CYTHON_UNUSED Py_ssize_t __pyx_nargs;
  #endif
  CYTHON_UNUSED PyObject *const *__pyx_kwvalues;
  PyObject* values[2] = {0,0};
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  PyObject *__pyx_r = 0;
  __Pyx_RefNannyDeclarations
  __Pyx_RefNannySetupContext("cell_format_painter (wrapper)", 0);
  #if !CYTHON_VECTORCALL
  #if CYTHON_ASSUME_SAFE_SIZE
  __pyx_nargs = PyTuple_GET_SIZE(__pyx_args);
  #else
  __pyx_nargs = PyTuple_Size(__pyx_args); if (unlikely(__pyx_nargs < 0)) return NULL;
  #endif
  #endif
  __pyx_kwvalues = __Pyx_KwValues_FASTCALL(__pyx_args, __pyx_nargs);
  {
    PyObject ** const __pyx_pyargnames[] = {&__pyx_mstate_global->__pyx_n_u_cell,&__pyx_mstate_global->__pyx_n_u_from_cell,0};
    const Py_ssize_t __pyx_kwds_len = (__pyx_kwds) ? __Pyx_NumKwargs_FASTCALL(__pyx_kwds) : 0;
    if (unlikely(__pyx_kwds_len < 0)) __PYX_ERR(0, 300, __pyx_L3_error)
    if (__pyx_kwds_len > 0) {
      switch (__pyx_nargs) {
        case  2:
        values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 300, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  1:
        values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
        if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 300, __pyx_L3_error)
        CYTHON_FALLTHROUGH;
        case  0: break;
        default: goto __pyx_L5_argtuple_error;
      }
      const Py_ssize_t kwd_pos_args = __pyx_nargs;
      if (__Pyx_ParseKeywords(__pyx_kwds, __pyx_kwvalues, __pyx_pyargnames, 0, values, kwd_pos_args, __pyx_kwds_len, "cell_format_painter", 0) < (0)) __PYX_ERR(0, 300, __pyx_L3_error)
      for (Py_ssize_t i = __pyx_nargs; i < 2; i++) {
        if (unlikely(!values[i])) { __Pyx_RaiseArgtupleInvalid("cell_format_painter", 1, 2, 2, i); __PYX_ERR(0, 300, __pyx_L3_error) }
      }
    } else if (unlikely(__pyx_nargs != 2)) {
      goto __pyx_L5_argtuple_error;
    } else {
      values[0] = __Pyx_ArgRef_FASTCALL(__pyx_args, 0);
      if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[0])) __PYX_ERR(0, 300, __pyx_L3_error)
      values[1] = __Pyx_ArgRef_FASTCALL(__pyx_args, 1);
      if (!CYTHON_ASSUME_SAFE_MACROS && unlikely(!values[1])) __PYX_ERR(0, 300, __pyx_L3_error)
    }
    __pyx_v_cell = values[0];
    __pyx_v_from_cell = values[1];
  }
  goto __pyx_L6_skip;
  __pyx_L5_argtuple_error:;
  __Pyx_RaiseArgtupleInvalid("cell_format_painter", 1, 2, 2, __pyx_nargs); __PYX_ERR(0, 300, __pyx_L3_error)
  __pyx_L6_skip:;
  goto __pyx_L4_argument_unpacking_done;
  __pyx_L3_error:;
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_AddTraceback("cloze.template_docx.cell_format_painter", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __Pyx_RefNannyFinishContext();
  return NULL;
  __pyx_L4_argument_unpacking_done:;
  __pyx_r = __pyx_pf_5cloze_13template_docx_cell_format_painter(__pyx_self, __pyx_v_cell, __pyx_v_from_cell);

  
  for (Py_ssize_t __pyx_temp=0; __pyx_temp < (Py_ssize_t)(sizeof(values)/sizeof(values[0])); ++__pyx_temp) {
    Py_XDECREF(values[__pyx_temp]);
  }
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}

static PyObject *__pyx_pf_5cloze_13template_docx_cell_format_painter(CYTHON_UNUSED PyObject *__pyx_self, PyObject *__pyx_v_cell, PyObject *__pyx_v_from_cell) {
  PyObject *__pyx_v_src_tc = NULL;
  PyObject *__pyx_v_src_tcPr = NULL;
  PyObject *__pyx_v_src_tcBorders = NULL;
  PyObject *__pyx_v_dst_tc = NULL;
  PyObject *__pyx_v_dst_tcPr = NULL;
  PyObject *__pyx_v_dst_tcBorders = NULL;
  PyObject *__pyx_v_child = NULL;
  PyObject *__pyx_v_border = NULL;
  PyObject *__pyx_v_src_para = NULL;
  PyObject *__pyx_v_dst_para = NULL;
  PyObject *__pyx_v_src_run = NULL;
  PyObject *__pyx_v_dst_run = NULL;
  PyObject *__pyx_v_src_rFonts = NULL;
  PyObject *__pyx_v_dst_rFonts = NULL;
  PyObject *__pyx_v_attr = NULL;
  PyObject *__pyx_v_dst_rPr = NULL;
  PyObject *__pyx_v_old_rFonts = NULL;
  PyObject *__pyx_v_src_shd = NULL;
  PyObject *__pyx_v_dst_shd = NULL;
  PyObject *__pyx_r = NULL;
  __Pyx_RefNannyDeclarations
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  size_t __pyx_t_3;
  PyObject *__pyx_t_4 = NULL;
  PyObject *__pyx_t_5 = NULL;
  PyObject *__pyx_t_6 = NULL;
  int __pyx_t_7;
  int __pyx_t_8;
  Py_ssize_t __pyx_t_9;
  PyObject *(*__pyx_t_10)(PyObject *);
  int __pyx_t_11;
  PyObject *__pyx_t_12 = NULL;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannySetupContext("cell_format_painter", 0);

  
  __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_from_cell, __pyx_mstate_global->__pyx_n_u_tc); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 303, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_v_src_tc = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_2 = __pyx_v_src_tc;
  __Pyx_INCREF(__pyx_t_2);
  __pyx_t_3 = 0;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, NULL};
    __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_get_or_add_tcPr, __pyx_callargs+__pyx_t_3, (1-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 304, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_src_tcPr = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_2 = __pyx_v_src_tcPr;
  __Pyx_INCREF(__pyx_t_2);
  __pyx_t_5 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_qn); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 305, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_6);
  __pyx_t_3 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_6))) {
    __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_6);
    assert(__pyx_t_5);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_6);
    __Pyx_INCREF(__pyx_t_5);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_6, __pyx__function);
    __pyx_t_3 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_mstate_global->__pyx_kp_u_w_tcBorders};
    __pyx_t_4 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_6, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
    __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
    if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 305, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_4);
  }
  __pyx_t_3 = 0;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_t_4};
    __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_find, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 305, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_src_tcBorders = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell, __pyx_mstate_global->__pyx_n_u_tc); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 307, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  __pyx_v_dst_tc = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_4 = __pyx_v_dst_tc;
  __Pyx_INCREF(__pyx_t_4);
  __pyx_t_3 = 0;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_4, NULL};
    __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_get_or_add_tcPr, __pyx_callargs+__pyx_t_3, (1-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 308, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_dst_tcPr = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_4 = __pyx_v_dst_tcPr;
  __Pyx_INCREF(__pyx_t_4);
  __pyx_t_6 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_qn); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 309, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __pyx_t_3 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_5))) {
    __pyx_t_6 = PyMethod_GET_SELF(__pyx_t_5);
    assert(__pyx_t_6);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_5);
    __Pyx_INCREF(__pyx_t_6);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_5, __pyx__function);
    __pyx_t_3 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_6, __pyx_mstate_global->__pyx_kp_u_w_tcBorders};
    __pyx_t_2 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_5, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
    __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
    if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 309, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_2);
  }
  __pyx_t_3 = 0;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_4, __pyx_t_2};
    __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_find, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 309, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_dst_tcBorders = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_7 = (__pyx_v_dst_tcBorders == Py_None);
  if (__pyx_t_7) {


    
    __pyx_t_2 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_OxmlElement); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 311, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_4);
    __pyx_t_3 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_4))) {
      __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_4);
      assert(__pyx_t_2);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_4);
      __Pyx_INCREF(__pyx_t_2);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_4, __pyx__function);
      __pyx_t_3 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_mstate_global->__pyx_kp_u_w_tcBorders};
      __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_4, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 311, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    __Pyx_DECREF_SET(__pyx_v_dst_tcBorders, __pyx_t_1);
    __pyx_t_1 = 0;

    
    __pyx_t_8 = __Pyx_PyObject_Append(__pyx_v_dst_tcPr, __pyx_v_dst_tcBorders); if (unlikely(__pyx_t_8 == ((int)-1))) __PYX_ERR(0, 312, __pyx_L1_error)


    
    goto __pyx_L3;
  }

  
   {
    __pyx_t_1 = PySequence_List(__pyx_v_dst_tcBorders); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 315, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __pyx_t_4 = __pyx_t_1; __Pyx_INCREF(__pyx_t_4);
    __pyx_t_9 = 0;
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    for (;;) {
      {
        Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_4);
        #if !CYTHON_ASSUME_SAFE_SIZE
        if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 315, __pyx_L1_error)
        #endif
        if (__pyx_t_9 >= __pyx_temp) break;
      }
      __pyx_t_1 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_4, __pyx_t_9, __Pyx_ReferenceSharing_OwnStrongReference);
      ++__pyx_t_9;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 315, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_XDECREF_SET(__pyx_v_child, __pyx_t_1);
      __pyx_t_1 = 0;

      
      __pyx_t_2 = __pyx_v_dst_tcBorders;
      __Pyx_INCREF(__pyx_t_2);
      __pyx_t_3 = 0;
      {
        PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_v_child};
        __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_remove, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
        if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 316, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_1);
      }
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

      
    }
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
  }
  __pyx_L3:;

  
  __pyx_t_7 = (__pyx_v_src_tcBorders != Py_None);
  if (__pyx_t_7) {


    
    if (likely(PyList_CheckExact(__pyx_v_src_tcBorders)) || PyTuple_CheckExact(__pyx_v_src_tcBorders)) {
      __pyx_t_4 = __pyx_v_src_tcBorders; __Pyx_INCREF(__pyx_t_4);
      __pyx_t_9 = 0;
      __pyx_t_10 = NULL;
    } else {
      __pyx_t_9 = -1; __pyx_t_4 = PyObject_GetIter(__pyx_v_src_tcBorders); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 319, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_10 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_4); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 319, __pyx_L1_error)
    }
    for (;;) {
      if (likely(!__pyx_t_10)) {
        if (likely(PyList_CheckExact(__pyx_t_4))) {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_4);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 319, __pyx_L1_error)
            #endif
            if (__pyx_t_9 >= __pyx_temp) break;
          }
          __pyx_t_1 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_4, __pyx_t_9, __Pyx_ReferenceSharing_OwnStrongReference);
          ++__pyx_t_9;
        } else {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_4);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 319, __pyx_L1_error)
            #endif
            if (__pyx_t_9 >= __pyx_temp) break;
          }
          #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
          __pyx_t_1 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_4, __pyx_t_9));
          #else
          __pyx_t_1 = __Pyx_PySequence_ITEM(__pyx_t_4, __pyx_t_9);
          #endif
          ++__pyx_t_9;
        }
        if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 319, __pyx_L1_error)
      } else {
        __pyx_t_1 = __pyx_t_10(__pyx_t_4);
        if (unlikely(!__pyx_t_1)) {
          PyObject* exc_type = PyErr_Occurred();
          if (exc_type) {
            if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 319, __pyx_L1_error)
            PyErr_Clear();
          }
          break;
        }
      }
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_XDECREF_SET(__pyx_v_border, __pyx_t_1);
      __pyx_t_1 = 0;

      
      __pyx_t_2 = NULL;
      __Pyx_GetModuleGlobalName(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_copy); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 320, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_5);
      __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_t_5, __pyx_mstate_global->__pyx_n_u_deepcopy); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 320, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      __Pyx_DECREF(__pyx_t_5); __pyx_t_5 = 0;
      __pyx_t_3 = 1;
      #if CYTHON_UNPACK_METHODS
      if (unlikely(PyMethod_Check(__pyx_t_6))) {
        __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_6);
        assert(__pyx_t_2);
        PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_6);
        __Pyx_INCREF(__pyx_t_2);
        __Pyx_INCREF(__pyx__function);
        __Pyx_DECREF_SET(__pyx_t_6, __pyx__function);
        __pyx_t_3 = 0;
      }
      #endif
      {
        PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_v_border};
        __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_6, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
        __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
        if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 320, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_1);
      }
      __pyx_t_8 = __Pyx_PyObject_Append(__pyx_v_dst_tcBorders, __pyx_t_1); if (unlikely(__pyx_t_8 == ((int)-1))) __PYX_ERR(0, 320, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;


      
    }
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

    
  }

  
  __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_from_cell, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  __pyx_t_7 = __Pyx_PyObject_IsTrue(__pyx_t_4); if (unlikely((__pyx_t_7 < 0))) __PYX_ERR(0, 323, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
  if (__pyx_t_7) {


    
    __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_from_cell, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 324, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_4);
    __pyx_t_1 = __Pyx_GetItemInt(__pyx_t_4, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 324, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    __pyx_v_src_para = __pyx_t_1;
    __pyx_t_1 = 0;

    
    __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_cell, __pyx_mstate_global->__pyx_n_u_paragraphs); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 325, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    __pyx_t_4 = __Pyx_GetItemInt(__pyx_t_1, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 325, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_4);
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    __pyx_v_dst_para = __pyx_t_4;
    __pyx_t_4 = 0;

    
    __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_para, __pyx_mstate_global->__pyx_n_u_alignment); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 326, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_4);
    if (__Pyx_PyObject_SetAttrStr(__pyx_v_dst_para, __pyx_mstate_global->__pyx_n_u_alignment, __pyx_t_4) < (0)) __PYX_ERR(0, 326, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

    
    __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_para, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 329, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_4);
    __pyx_t_7 = __Pyx_PyObject_IsTrue(__pyx_t_4); if (unlikely((__pyx_t_7 < 0))) __PYX_ERR(0, 329, __pyx_L1_error)
    __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    if (__pyx_t_7) {


      
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_para, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 330, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_1 = __Pyx_GetItemInt(__pyx_t_4, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 330, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_v_src_run = __pyx_t_1;
      __pyx_t_1 = 0;

      
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_para, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 332, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __pyx_t_7 = __Pyx_PyObject_IsTrue(__pyx_t_1); if (unlikely((__pyx_t_7 < 0))) __PYX_ERR(0, 332, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      __pyx_t_11 = (!__pyx_t_7);


      if (__pyx_t_11) {


        
        __pyx_t_4 = __pyx_v_dst_para;
        __Pyx_INCREF(__pyx_t_4);
        __pyx_t_3 = 0;
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_4, NULL};
          __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_add_run, __pyx_callargs+__pyx_t_3, (1-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
          if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 333, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_1);
        }
        __pyx_v_dst_run = __pyx_t_1;
        __pyx_t_1 = 0;

        
        goto __pyx_L13;
      }

      
       {
        __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_para, __pyx_mstate_global->__pyx_n_u_runs); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 335, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_1);
        __pyx_t_4 = __Pyx_GetItemInt(__pyx_t_1, 0, long, 1, __Pyx_PyLong_From_long, 0, 1, 1, __Pyx_ReferenceSharing_OwnStrongReference); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 335, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_4);
        __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
        __pyx_v_dst_run = __pyx_t_4;
        __pyx_t_4 = 0;
      }
      __pyx_L13:;

      
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 337, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_name); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 337, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 337, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_name, __pyx_t_1) < (0)) __PYX_ERR(0, 337, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

      
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 338, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_size); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 338, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 338, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_size, __pyx_t_1) < (0)) __PYX_ERR(0, 338, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

      
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 339, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_bold); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 339, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 339, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_bold, __pyx_t_1) < (0)) __PYX_ERR(0, 339, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

      
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 340, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_italic); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 340, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 340, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_italic, __pyx_t_1) < (0)) __PYX_ERR(0, 340, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

      
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 341, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_underline); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 341, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 341, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_underline, __pyx_t_1) < (0)) __PYX_ERR(0, 341, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

      
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 342, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_t_4, __pyx_mstate_global->__pyx_n_u_color); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 342, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_rgb); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 342, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 342, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
      __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_color); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 342, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_rgb, __pyx_t_4) < (0)) __PYX_ERR(0, 342, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;

      
      __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 343, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_strike); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 343, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
      __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 343, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_strike, __pyx_t_4) < (0)) __PYX_ERR(0, 343, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;

      
      __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 344, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_shadow); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 344, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
      __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_run, __pyx_mstate_global->__pyx_n_u_font); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 344, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      if (__Pyx_PyObject_SetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_shadow, __pyx_t_4) < (0)) __PYX_ERR(0, 344, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;

      
      __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_element); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 347, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_rPr); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 347, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
      __pyx_t_11 = (__pyx_t_4 != Py_None);
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      if (__pyx_t_11) {


        
        __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_run, __pyx_mstate_global->__pyx_n_u_element); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 348, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_1);
        __pyx_t_2 = __Pyx_PyObject_GetAttrStr(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_rPr); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 348, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_2);
        __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
        __pyx_t_6 = __pyx_t_2;
        __Pyx_INCREF(__pyx_t_6);
        __pyx_t_5 = NULL;
        __Pyx_GetModuleGlobalName(__pyx_t_12, __pyx_mstate_global->__pyx_n_u_qn); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 348, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_12);
        __pyx_t_3 = 1;
        #if CYTHON_UNPACK_METHODS
        if (unlikely(PyMethod_Check(__pyx_t_12))) {
          __pyx_t_5 = PyMethod_GET_SELF(__pyx_t_12);
          assert(__pyx_t_5);
          PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_12);
          __Pyx_INCREF(__pyx_t_5);
          __Pyx_INCREF(__pyx__function);
          __Pyx_DECREF_SET(__pyx_t_12, __pyx__function);
          __pyx_t_3 = 0;
        }
        #endif
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_5, __pyx_mstate_global->__pyx_kp_u_w_rFonts};
          __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_12, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_5); __pyx_t_5 = 0;
          __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
          if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 348, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_1);
        }
        __pyx_t_3 = 0;
        {
          PyObject *__pyx_callargs[2] = {__pyx_t_6, __pyx_t_1};
          __pyx_t_4 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_find, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
          __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
          __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
          __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
          if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 348, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_4);
        }
        __pyx_v_src_rFonts = __pyx_t_4;
        __pyx_t_4 = 0;

        
        __pyx_t_11 = (__pyx_v_src_rFonts != Py_None);
        if (__pyx_t_11) {


          
          __pyx_t_2 = NULL;
          __Pyx_GetModuleGlobalName(__pyx_t_1, __pyx_mstate_global->__pyx_n_u_OxmlElement); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 350, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_1);
          __pyx_t_3 = 1;
          #if CYTHON_UNPACK_METHODS
          if (unlikely(PyMethod_Check(__pyx_t_1))) {
            __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_1);
            assert(__pyx_t_2);
            PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_1);
            __Pyx_INCREF(__pyx_t_2);
            __Pyx_INCREF(__pyx__function);
            __Pyx_DECREF_SET(__pyx_t_1, __pyx__function);
            __pyx_t_3 = 0;
          }
          #endif
          {
            PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_mstate_global->__pyx_kp_u_w_rFonts};
            __pyx_t_4 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_1, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
            __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
            if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 350, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_4);
          }
          __pyx_v_dst_rFonts = __pyx_t_4;
          __pyx_t_4 = 0;

          
          __pyx_t_4 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_rFonts, __pyx_mstate_global->__pyx_n_u_attrib); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 351, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_4);
          if (likely(PyList_CheckExact(__pyx_t_4)) || PyTuple_CheckExact(__pyx_t_4)) {
            __pyx_t_1 = __pyx_t_4; __Pyx_INCREF(__pyx_t_1);
            __pyx_t_9 = 0;
            __pyx_t_10 = NULL;
          } else {
            __pyx_t_9 = -1; __pyx_t_1 = PyObject_GetIter(__pyx_t_4); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 351, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_1);
            __pyx_t_10 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_1); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 351, __pyx_L1_error)
          }
          __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
          for (;;) {
            if (likely(!__pyx_t_10)) {
              if (likely(PyList_CheckExact(__pyx_t_1))) {
                {
                  Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_1);
                  #if !CYTHON_ASSUME_SAFE_SIZE
                  if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 351, __pyx_L1_error)
                  #endif
                  if (__pyx_t_9 >= __pyx_temp) break;
                }
                __pyx_t_4 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_1, __pyx_t_9, __Pyx_ReferenceSharing_OwnStrongReference);
                ++__pyx_t_9;
              } else {
                {
                  Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_1);
                  #if !CYTHON_ASSUME_SAFE_SIZE
                  if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 351, __pyx_L1_error)
                  #endif
                  if (__pyx_t_9 >= __pyx_temp) break;
                }
                #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                __pyx_t_4 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_1, __pyx_t_9));
                #else
                __pyx_t_4 = __Pyx_PySequence_ITEM(__pyx_t_1, __pyx_t_9);
                #endif
                ++__pyx_t_9;
              }
              if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 351, __pyx_L1_error)
            } else {
              __pyx_t_4 = __pyx_t_10(__pyx_t_1);
              if (unlikely(!__pyx_t_4)) {
                PyObject* exc_type = PyErr_Occurred();
                if (exc_type) {
                  if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 351, __pyx_L1_error)
                  PyErr_Clear();
                }
                break;
              }
            }
            __Pyx_GOTREF(__pyx_t_4);
            __Pyx_XDECREF_SET(__pyx_v_attr, __pyx_t_4);
            __pyx_t_4 = 0;

            
            __pyx_t_2 = __pyx_v_dst_rFonts;
            __Pyx_INCREF(__pyx_t_2);
            __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_rFonts, __pyx_mstate_global->__pyx_n_u_attrib); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 352, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_6);
            __pyx_t_12 = __Pyx_PyObject_GetItem(__pyx_t_6, __pyx_v_attr); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 352, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_12);
            __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
            __pyx_t_3 = 0;
            {
              PyObject *__pyx_callargs[3] = {__pyx_t_2, __pyx_v_attr, __pyx_t_12};
              __pyx_t_4 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_set, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
              __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
              __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
              if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 352, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_4);
            }
            __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

            
          }
          __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

          
          __pyx_t_12 = __Pyx_PyObject_GetAttrStr(__pyx_v_dst_run, __pyx_mstate_global->__pyx_n_u_element); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 353, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_12);
          __pyx_t_4 = __pyx_t_12;
          __Pyx_INCREF(__pyx_t_4);
          __pyx_t_3 = 0;
          {
            PyObject *__pyx_callargs[2] = {__pyx_t_4, NULL};
            __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_get_or_add_rPr, __pyx_callargs+__pyx_t_3, (1-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
            __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
            if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 353, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_1);
          }
          __pyx_v_dst_rPr = __pyx_t_1;
          __pyx_t_1 = 0;

          
          __pyx_t_12 = __pyx_v_dst_rPr;
          __Pyx_INCREF(__pyx_t_12);
          __pyx_t_2 = NULL;
          __Pyx_GetModuleGlobalName(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_qn); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 355, __pyx_L1_error)
          __Pyx_GOTREF(__pyx_t_6);
          __pyx_t_3 = 1;
          #if CYTHON_UNPACK_METHODS
          if (unlikely(PyMethod_Check(__pyx_t_6))) {
            __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_6);
            assert(__pyx_t_2);
            PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_6);
            __Pyx_INCREF(__pyx_t_2);
            __Pyx_INCREF(__pyx__function);
            __Pyx_DECREF_SET(__pyx_t_6, __pyx__function);
            __pyx_t_3 = 0;
          }
          #endif
          {
            PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_mstate_global->__pyx_kp_u_w_rFonts};
            __pyx_t_4 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_6, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
            __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
            if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 355, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_4);
          }
          __pyx_t_3 = 0;
          {
            PyObject *__pyx_callargs[2] = {__pyx_t_12, __pyx_t_4};
            __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_find, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
            __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
            if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 355, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_1);
          }
          __pyx_v_old_rFonts = __pyx_t_1;
          __pyx_t_1 = 0;

          
          __pyx_t_11 = (__pyx_v_old_rFonts != Py_None);
          if (__pyx_t_11) {


            
            __pyx_t_4 = __pyx_v_dst_rPr;
            __Pyx_INCREF(__pyx_t_4);
            __pyx_t_3 = 0;
            {
              PyObject *__pyx_callargs[2] = {__pyx_t_4, __pyx_v_old_rFonts};
              __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_remove, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
              __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
              if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 357, __pyx_L1_error)
              __Pyx_GOTREF(__pyx_t_1);
            }
            __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

            
          }

          
          __pyx_t_4 = __pyx_v_dst_rPr;
          __Pyx_INCREF(__pyx_t_4);
          __pyx_t_3 = 0;
          {
            PyObject *__pyx_callargs[3] = {__pyx_t_4, __pyx_mstate_global->__pyx_int_0, __pyx_v_dst_rFonts};
            __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_insert, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
            __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
            if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 358, __pyx_L1_error)
            __Pyx_GOTREF(__pyx_t_1);
          }
          __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

          
        }

        
      }

      
    }

    
  }

  
  __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_from_cell, __pyx_mstate_global->__pyx_n_u_vertical_alignment); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 361, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_1);
  if (__Pyx_PyObject_SetAttrStr(__pyx_v_cell, __pyx_mstate_global->__pyx_n_u_vertical_alignment, __pyx_t_1) < (0)) __PYX_ERR(0, 361, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

  
  __pyx_t_4 = __pyx_v_src_tcPr;
  __Pyx_INCREF(__pyx_t_4);
  __pyx_t_6 = NULL;
  __Pyx_GetModuleGlobalName(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_qn); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 364, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  __pyx_t_3 = 1;
  #if CYTHON_UNPACK_METHODS
  if (unlikely(PyMethod_Check(__pyx_t_2))) {
    __pyx_t_6 = PyMethod_GET_SELF(__pyx_t_2);
    assert(__pyx_t_6);
    PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_2);
    __Pyx_INCREF(__pyx_t_6);
    __Pyx_INCREF(__pyx__function);
    __Pyx_DECREF_SET(__pyx_t_2, __pyx__function);
    __pyx_t_3 = 0;
  }
  #endif
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_6, __pyx_mstate_global->__pyx_kp_u_w_shd};
    __pyx_t_12 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_2, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_6); __pyx_t_6 = 0;
    __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
    if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 364, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_12);
  }
  __pyx_t_3 = 0;
  {
    PyObject *__pyx_callargs[2] = {__pyx_t_4, __pyx_t_12};
    __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_find, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
    __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
    __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
    if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 364, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
  }
  __pyx_v_src_shd = __pyx_t_1;
  __pyx_t_1 = 0;

  
  __pyx_t_11 = (__pyx_v_src_shd != Py_None);
  if (__pyx_t_11) {


    
    __pyx_t_12 = __pyx_v_dst_tcPr;
    __Pyx_INCREF(__pyx_t_12);
    __pyx_t_2 = NULL;
    __Pyx_GetModuleGlobalName(__pyx_t_6, __pyx_mstate_global->__pyx_n_u_qn); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 366, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_6);
    __pyx_t_3 = 1;
    #if CYTHON_UNPACK_METHODS
    if (unlikely(PyMethod_Check(__pyx_t_6))) {
      __pyx_t_2 = PyMethod_GET_SELF(__pyx_t_6);
      assert(__pyx_t_2);
      PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_6);
      __Pyx_INCREF(__pyx_t_2);
      __Pyx_INCREF(__pyx__function);
      __Pyx_DECREF_SET(__pyx_t_6, __pyx__function);
      __pyx_t_3 = 0;
    }
    #endif
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_2, __pyx_mstate_global->__pyx_kp_u_w_shd};
      __pyx_t_4 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_6, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_2); __pyx_t_2 = 0;
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
      if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 366, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
    }
    __pyx_t_3 = 0;
    {
      PyObject *__pyx_callargs[2] = {__pyx_t_12, __pyx_t_4};
      __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_find, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
      __Pyx_XDECREF(__pyx_t_12); __pyx_t_12 = 0;
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
      if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 366, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_1);
    }
    __pyx_v_dst_shd = __pyx_t_1;
    __pyx_t_1 = 0;

    
    __pyx_t_11 = (__pyx_v_dst_shd == Py_None);
    if (__pyx_t_11) {


      
      __pyx_t_4 = NULL;
      __Pyx_GetModuleGlobalName(__pyx_t_12, __pyx_mstate_global->__pyx_n_u_OxmlElement); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 368, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_12);
      __pyx_t_3 = 1;
      #if CYTHON_UNPACK_METHODS
      if (unlikely(PyMethod_Check(__pyx_t_12))) {
        __pyx_t_4 = PyMethod_GET_SELF(__pyx_t_12);
        assert(__pyx_t_4);
        PyObject* __pyx__function = PyMethod_GET_FUNCTION(__pyx_t_12);
        __Pyx_INCREF(__pyx_t_4);
        __Pyx_INCREF(__pyx__function);
        __Pyx_DECREF_SET(__pyx_t_12, __pyx__function);
        __pyx_t_3 = 0;
      }
      #endif
      {
        PyObject *__pyx_callargs[2] = {__pyx_t_4, __pyx_mstate_global->__pyx_kp_u_w_shd};
        __pyx_t_1 = __Pyx_PyObject_FastCall((PyObject*)__pyx_t_12, __pyx_callargs+__pyx_t_3, (2-__pyx_t_3) | (__pyx_t_3*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
        __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;
        if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 368, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_1);
      }
      __Pyx_DECREF_SET(__pyx_v_dst_shd, __pyx_t_1);
      __pyx_t_1 = 0;

      
      __pyx_t_8 = __Pyx_PyObject_Append(__pyx_v_dst_tcPr, __pyx_v_dst_shd); if (unlikely(__pyx_t_8 == ((int)-1))) __PYX_ERR(0, 369, __pyx_L1_error)


      
    }

    
    __pyx_t_1 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_shd, __pyx_mstate_global->__pyx_n_u_attrib); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 370, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_t_1);
    if (likely(PyList_CheckExact(__pyx_t_1)) || PyTuple_CheckExact(__pyx_t_1)) {
      __pyx_t_12 = __pyx_t_1; __Pyx_INCREF(__pyx_t_12);
      __pyx_t_9 = 0;
      __pyx_t_10 = NULL;
    } else {
      __pyx_t_9 = -1; __pyx_t_12 = PyObject_GetIter(__pyx_t_1); if (unlikely(!__pyx_t_12)) __PYX_ERR(0, 370, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_12);
      __pyx_t_10 = (CYTHON_COMPILING_IN_LIMITED_API) ? PyIter_Next : __Pyx_PyObject_GetIterNextFunc(__pyx_t_12); if (unlikely(!__pyx_t_10)) __PYX_ERR(0, 370, __pyx_L1_error)
    }
    __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;
    for (;;) {
      if (likely(!__pyx_t_10)) {
        if (likely(PyList_CheckExact(__pyx_t_12))) {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyList_GET_SIZE(__pyx_t_12);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 370, __pyx_L1_error)
            #endif
            if (__pyx_t_9 >= __pyx_temp) break;
          }
          __pyx_t_1 = __Pyx_PyList_GET_ITEM_REF(__pyx_t_12, __pyx_t_9, __Pyx_ReferenceSharing_OwnStrongReference);
          ++__pyx_t_9;
        } else {
          {
            Py_ssize_t __pyx_temp = __Pyx_PyTuple_GET_SIZE(__pyx_t_12);
            #if !CYTHON_ASSUME_SAFE_SIZE
            if (unlikely((__pyx_temp < 0))) __PYX_ERR(0, 370, __pyx_L1_error)
            #endif
            if (__pyx_t_9 >= __pyx_temp) break;
          }
          #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
          __pyx_t_1 = __Pyx_NewRef(PyTuple_GET_ITEM(__pyx_t_12, __pyx_t_9));
          #else
          __pyx_t_1 = __Pyx_PySequence_ITEM(__pyx_t_12, __pyx_t_9);
          #endif
          ++__pyx_t_9;
        }
        if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 370, __pyx_L1_error)
      } else {
        __pyx_t_1 = __pyx_t_10(__pyx_t_12);
        if (unlikely(!__pyx_t_1)) {
          PyObject* exc_type = PyErr_Occurred();
          if (exc_type) {
            if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration))) __PYX_ERR(0, 370, __pyx_L1_error)
            PyErr_Clear();
          }
          break;
        }
      }
      __Pyx_GOTREF(__pyx_t_1);
      __Pyx_XDECREF_SET(__pyx_v_attr, __pyx_t_1);
      __pyx_t_1 = 0;

      
      __pyx_t_4 = __pyx_v_dst_shd;
      __Pyx_INCREF(__pyx_t_4);
      __pyx_t_6 = __Pyx_PyObject_GetAttrStr(__pyx_v_src_shd, __pyx_mstate_global->__pyx_n_u_attrib); if (unlikely(!__pyx_t_6)) __PYX_ERR(0, 371, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_6);
      __pyx_t_2 = __Pyx_PyObject_GetItem(__pyx_t_6, __pyx_v_attr); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 371, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_2);
      __Pyx_DECREF(__pyx_t_6); __pyx_t_6 = 0;
      __pyx_t_3 = 0;
      {
        PyObject *__pyx_callargs[3] = {__pyx_t_4, __pyx_v_attr, __pyx_t_2};
        __pyx_t_1 = __Pyx_PyObject_FastCallMethod((PyObject*)__pyx_mstate_global->__pyx_n_u_set, __pyx_callargs+__pyx_t_3, (3-__pyx_t_3) | (1*__Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET));
        __Pyx_XDECREF(__pyx_t_4); __pyx_t_4 = 0;
        __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;
        if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 371, __pyx_L1_error)
        __Pyx_GOTREF(__pyx_t_1);
      }
      __Pyx_DECREF(__pyx_t_1); __pyx_t_1 = 0;

      
    }
    __Pyx_DECREF(__pyx_t_12); __pyx_t_12 = 0;

    
  }

  

  
  __pyx_r = Py_None; __Pyx_INCREF(Py_None);
  goto __pyx_L0;
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_1);
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_4);
  __Pyx_XDECREF(__pyx_t_5);
  __Pyx_XDECREF(__pyx_t_6);
  __Pyx_XDECREF(__pyx_t_12);
  __Pyx_AddTraceback("cloze.template_docx.cell_format_painter", __pyx_clineno, __pyx_lineno, __pyx_filename);
  __pyx_r = NULL;
  __pyx_L0:;
  __Pyx_XDECREF(__pyx_v_src_tc);
  __Pyx_XDECREF(__pyx_v_src_tcPr);
  __Pyx_XDECREF(__pyx_v_src_tcBorders);
  __Pyx_XDECREF(__pyx_v_dst_tc);
  __Pyx_XDECREF(__pyx_v_dst_tcPr);
  __Pyx_XDECREF(__pyx_v_dst_tcBorders);
  __Pyx_XDECREF(__pyx_v_child);
  __Pyx_XDECREF(__pyx_v_border);
  __Pyx_XDECREF(__pyx_v_src_para);
  __Pyx_XDECREF(__pyx_v_dst_para);
  __Pyx_XDECREF(__pyx_v_src_run);
  __Pyx_XDECREF(__pyx_v_dst_run);
  __Pyx_XDECREF(__pyx_v_src_rFonts);
  __Pyx_XDECREF(__pyx_v_dst_rFonts);
  __Pyx_XDECREF(__pyx_v_attr);
  __Pyx_XDECREF(__pyx_v_dst_rPr);
  __Pyx_XDECREF(__pyx_v_old_rFonts);
  __Pyx_XDECREF(__pyx_v_src_shd);
  __Pyx_XDECREF(__pyx_v_dst_shd);
  __Pyx_XGIVEREF(__pyx_r);
  __Pyx_RefNannyFinishContext();
  return __pyx_r;
}


static PyObject *__pyx_tp_new__initialisation_5cloze_13template_docx___pyx_defaults(PyObject *o, 
#if CYTHON_VECTORCALL_TPNEW
    CYTHON_UNUSED PyObject *const *args, CYTHON_UNUSED Py_ssize_t nargs, CYTHON_UNUSED PyObject *kwnames
#else
    CYTHON_UNUSED PyObject *a, CYTHON_UNUSED PyObject *k
#endif
) {
  return o;
}

static PyObject *__pyx_tp_new_vectorcall_5cloze_13template_docx___pyx_defaults(PyTypeObject *t, 
#if CYTHON_VECTORCALL_TPNEW
    PyObject *const *args, Py_ssize_t nargs, PyObject *kwnames
#else
    PyObject *a, PyObject *k
#endif
) {
  PyObject *o;
  o = __Pyx_AllocateExtensionType(t, 1);
  if (unlikely(!o)) return 0;
  return __pyx_tp_new__initialisation_5cloze_13template_docx___pyx_defaults(o, 
#if CYTHON_VECTORCALL_TPNEW
    args, nargs, kwnames
#else
    a, k
#endif
);
}

#if CYTHON_VECTORCALL_TPNEW
static PyObject *__pyx_tp_new_5cloze_13template_docx___pyx_defaults(PyTypeObject *t, PyObject *a, PyObject *k) {
  return __Pyx_CallTpnewAsVectorcall(__pyx_tp_new_vectorcall_5cloze_13template_docx___pyx_defaults, t, a, k);
}
#endif

#if CYTHON_VECTORCALL_TPNEW
static PyObject *__pyx_tp_vectorcall_5cloze_13template_docx___pyx_defaults(PyObject *t, PyObject *const *args, size_t nargsf, PyObject *kwnames) {
  if (unlikely((PyTypeObject*)t != __pyx_mstate_global->__pyx_ptype_5cloze_13template_docx___pyx_defaults || __Pyx_PyType_HasFeature((PyTypeObject*)t, Py_TPFLAGS_IS_ABSTRACT))) {
    return __Pyx_CallNewInitFromVectorcall((PyTypeObject*)t, args, nargsf, kwnames);
  }
  Py_ssize_t nargs = PyVectorcall_NARGS(nargsf);
  PyObject *o = __pyx_tp_new_vectorcall_5cloze_13template_docx___pyx_defaults((PyTypeObject*)t, args, nargs, kwnames);
  return o;
}
#endif

static void __pyx_tp_dealloc_5cloze_13template_docx___pyx_defaults(PyObject *o) {
  struct __pyx_defaults *p = (struct __pyx_defaults *)o;
  #if CYTHON_USE_TP_FINALIZE
  if (unlikely(__Pyx_PyObject_GetSlot(o, tp_finalize, destructor)) && !__Pyx_PyObject_GC_IsFinalized(o)) {
    if (__Pyx_PyObject_GetSlot(o, tp_dealloc, destructor) == __pyx_tp_dealloc_5cloze_13template_docx___pyx_defaults) {
      if (PyObject_CallFinalizerFromDealloc(o)) return;
    }
  }
  #endif
  PyObject_GC_UnTrack(o);
  Py_CLEAR(p->arg0);
  PyTypeObject *tp = Py_TYPE(o);
  #if CYTHON_USE_TYPE_SLOTS
  (*tp->tp_free)(o);
  #else
  {
    freefunc tp_free = (freefunc)PyType_GetSlot(tp, Py_tp_free);
    if (tp_free) tp_free(o);
  }
  #endif
  #if CYTHON_USE_TYPE_SPECS
  Py_DECREF(tp);
  #endif
}

static int __pyx_tp_traverse_5cloze_13template_docx___pyx_defaults(PyObject *o, visitproc v, void *a) {
  int e;
  struct __pyx_defaults *p = (struct __pyx_defaults *)o;
  {
    e = __Pyx_call_type_traverse(o, 1, v, a);
    if (e) return e;
  }
  if (p->arg0) {
    e = (*v)(p->arg0, a); if (e) return e;
  }
  return 0;
}

static int __pyx_tp_clear_5cloze_13template_docx___pyx_defaults(PyObject *o) {
  PyObject* tmp;
  struct __pyx_defaults *p = (struct __pyx_defaults *)o;
  tmp = ((PyObject*)p->arg0);
  p->arg0 = Py_None; Py_INCREF(Py_None);
  Py_XDECREF(tmp);
  return 0;
}
#if CYTHON_USE_TYPE_SPECS
static PyType_Slot __pyx_type_5cloze_13template_docx___pyx_defaults_slots[] = {
  {Py_tp_dealloc, (void *)__pyx_tp_dealloc_5cloze_13template_docx___pyx_defaults},
  {Py_tp_traverse, (void *)__pyx_tp_traverse_5cloze_13template_docx___pyx_defaults},
  {Py_tp_clear, (void *)__pyx_tp_clear_5cloze_13template_docx___pyx_defaults},
  {Py_tp_new, (void *)__pyx_tp_new_5cloze_13template_docx___pyx_defaults},
  #if (!CYTHON_COMPILING_IN_PYPY || PYPY_VERSION_NUM >= 0x07030800) && (!CYTHON_COMPILING_IN_LIMITED_API || __PYX_LIMITED_VERSION_HEX >= 0x030E0000)
  #if CYTHON_VECTORCALL_TPNEW
  {Py_tp_vectorcall, (void *)__pyx_tp_vectorcall_5cloze_13template_docx___pyx_defaults},
  #endif
  #endif
  {0, 0},
};
static PyType_Spec __pyx_type_5cloze_13template_docx___pyx_defaults_spec = {
  "cloze.template_docx.__pyx_defaults",
  sizeof(struct __pyx_defaults),
  0,
  Py_TPFLAGS_DEFAULT|Py_TPFLAGS_HAVE_VERSION_TAG|Py_TPFLAGS_HAVE_GC,
  __pyx_type_5cloze_13template_docx___pyx_defaults_slots,
};
#else

static PyTypeObject __pyx_type_5cloze_13template_docx___pyx_defaults = {
  PyVarObject_HEAD_INIT(0, 0)
  "cloze.template_docx.""__pyx_defaults", 
  sizeof(struct __pyx_defaults), 
  0, 
  __pyx_tp_dealloc_5cloze_13template_docx___pyx_defaults, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  Py_TPFLAGS_DEFAULT|Py_TPFLAGS_HAVE_VERSION_TAG|Py_TPFLAGS_HAVE_GC, 
  0, 
  __pyx_tp_traverse_5cloze_13template_docx___pyx_defaults, 
  __pyx_tp_clear_5cloze_13template_docx___pyx_defaults, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  #if !CYTHON_USE_TYPE_SPECS
  0, 
  #endif
  0, 
  0, 
  __pyx_tp_new_5cloze_13template_docx___pyx_defaults, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  0, 
  #if CYTHON_USE_TP_FINALIZE
  0, 
  #else
  NULL, 
  #endif
  #if (!CYTHON_COMPILING_IN_PYPY || PYPY_VERSION_NUM >= 0x07030800) && (!CYTHON_COMPILING_IN_LIMITED_API || __PYX_LIMITED_VERSION_HEX >= 0x030E0000)
  #if CYTHON_VECTORCALL_TPNEW
  __pyx_tp_vectorcall_5cloze_13template_docx___pyx_defaults, 
  #else
  NULL, 
  #endif
  #endif
  #if __PYX_NEED_TP_PRINT_SLOT == 1
  0, 
  #endif
  #if PY_VERSION_HEX >= 0x030C0000
  0, 
  #endif
  #if PY_VERSION_HEX >= 0x030d00A4
  0, 
  #endif
  #if CYTHON_COMPILING_IN_PYPY && PY_VERSION_HEX < 0x030a0000
  0, 
  #endif
};
#endif

static PyMethodDef __pyx_methods[] = {
  {0, 0, 0, 0}
};

static CYTHON_SMALL_CODE int __Pyx_InitCachedBuiltins(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_InitCachedConstants(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_InitGlobals(void); 
static CYTHON_SMALL_CODE int __Pyx_InitAfterSharedUtility(void); 
static CYTHON_SMALL_CODE int __Pyx_InitConstants(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_Global_init_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_Variable_export_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_Function_export_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_Exttype___pyx_defaults(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_Type_import_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_Variable_import_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_modinit_Function_import_code(__pyx_mstatetype *__pyx_mstate); 
static CYTHON_SMALL_CODE int __Pyx_CreateCodeObjects(__pyx_mstatetype *__pyx_mstate); 


static int __Pyx_modinit_Global_init_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_Global_init_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_Variable_export_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_Variable_export_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_Function_export_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_Function_export_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_Exttype___pyx_defaults(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_Exttype___pyx_defaults", 0);
  
  #if CYTHON_USE_TYPE_SPECS
  __pyx_mstate->__pyx_ptype_5cloze_13template_docx___pyx_defaults = (PyTypeObject *) __Pyx_PyType_FromModuleAndSpec(__pyx_m, &__pyx_type_5cloze_13template_docx___pyx_defaults_spec, NULL); if (unlikely(!__pyx_mstate->__pyx_ptype_5cloze_13template_docx___pyx_defaults)) __PYX_ERR(0, 102, __pyx_L1_error)
  #else
  __pyx_mstate->__pyx_ptype_5cloze_13template_docx___pyx_defaults = &__pyx_type_5cloze_13template_docx___pyx_defaults;
  #endif
  #if !CYTHON_COMPILING_IN_LIMITED_API
  #endif
  #if !CYTHON_USE_TYPE_SPECS
  if (__Pyx_PyType_Ready(__pyx_mstate->__pyx_ptype_5cloze_13template_docx___pyx_defaults) < (0)) __PYX_ERR(0, 102, __pyx_L1_error)
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030E0000
  PyUnstable_Object_EnableDeferredRefcount((PyObject*)__pyx_mstate->__pyx_ptype_5cloze_13template_docx___pyx_defaults);
  #endif
  #if !CYTHON_COMPILING_IN_LIMITED_API
  if ((CYTHON_USE_TYPE_SLOTS && CYTHON_USE_PYTYPE_LOOKUP) && likely(!__pyx_mstate->__pyx_ptype_5cloze_13template_docx___pyx_defaults->tp_dictoffset && __pyx_mstate->__pyx_ptype_5cloze_13template_docx___pyx_defaults->tp_getattro == PyObject_GenericGetAttr)) {
    __pyx_mstate->__pyx_ptype_5cloze_13template_docx___pyx_defaults->tp_getattro = PyObject_GenericGetAttr;
  }
  #endif
  __Pyx_RefNannyFinishContext();
  return 0;
  __pyx_L1_error:;
  __Pyx_RefNannyFinishContext();
  return -1;
}

static int __Pyx_modinit_Type_import_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_Type_import_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_Variable_import_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_Variable_import_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

static int __Pyx_modinit_Function_import_code(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_modinit_Function_import_code", 0);
  
  __Pyx_RefNannyFinishContext();
  return 0;
}

#if CYTHON_PEP489_MULTI_PHASE_INIT
static PyObject* __pyx_pymod_create(PyObject *spec, PyModuleDef *def); 
static int __pyx_pymod_exec_template_docx(PyObject* module); 
static PyModuleDef_Slot __pyx_moduledef_slots[] = {
  {Py_mod_create, (void*)__pyx_pymod_create},
  {Py_mod_exec, (void*)__pyx_pymod_exec_template_docx},
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
  {Py_mod_gil, __Pyx_FREETHREADING_COMPATIBLE},
  #endif
  #if PY_VERSION_HEX >= 0x030C0000 && CYTHON_USE_MODULE_STATE
  {Py_mod_multiple_interpreters, Py_MOD_MULTIPLE_INTERPRETERS_NOT_SUPPORTED},
  #endif
  {0, NULL}
};
#endif

#ifdef __cplusplus
namespace {
  struct PyModuleDef __pyx_moduledef =
  #else
  static struct PyModuleDef __pyx_moduledef =
  #endif
  {
      PyModuleDef_HEAD_INIT,
      "template_docx",
      0, 
    #if CYTHON_USE_MODULE_STATE
      sizeof(__pyx_mstatetype), 
    #else
      (CYTHON_PEP489_MULTI_PHASE_INIT) ? 0 : -1, 
    #endif
      __pyx_methods ,
    #if CYTHON_PEP489_MULTI_PHASE_INIT
      __pyx_moduledef_slots, 
    #else
      NULL, 
    #endif
    #if CYTHON_USE_MODULE_STATE
      __pyx_m_traverse, 
      __pyx_m_clear, 
      NULL 
    #else
      NULL, 
      NULL, 
      NULL 
    #endif
  };
  #ifdef __cplusplus
} 
#endif


#ifndef CYTHON_NO_PYINIT_EXPORT
  #define __Pyx_PyMODINIT_FUNC PyMODINIT_FUNC
#else
  #ifdef __cplusplus
  #define __Pyx_PyMODINIT_FUNC extern "C" PyObject *
  #else
  #define __Pyx_PyMODINIT_FUNC PyObject *
  #endif
#endif

__Pyx_PyMODINIT_FUNC PyInit_template_docx(void) CYTHON_SMALL_CODE; 
__Pyx_PyMODINIT_FUNC PyInit_template_docx(void)
#if CYTHON_PEP489_MULTI_PHASE_INIT
{
  return PyModuleDef_Init(&__pyx_moduledef);
}

#if CYTHON_COMPILING_IN_LIMITED_API && (__PYX_LIMITED_VERSION_HEX < 0x030A0000 &&\
      (defined(_WIN32) || defined(WIN32) || defined(MS_WINDOWS)))
static PY_INT64_T __Pyx_GetCurrentInterpreterId(void) {
    {
        PyObject *module = PyImport_ImportModule("_interpreters"); // 3.13+ I think
        if (!module) {
            if (!PyErr_ExceptionMatches(PyExc_Exception)) {
                goto bad; // BaseException
            }
            PyErr_Clear(); // just try the 3.8-3.12 version
            module = PyImport_ImportModule("_xxsubinterpreters");
            if (!module) goto bad;
        }
        PyObject *current = PyObject_CallMethod(module, "get_current", NULL);
        Py_DECREF(module);
        if (!current) goto bad;
        if (PyTuple_Check(current)) {
            PyObject *new_current = PySequence_GetItem(current, 0);
            Py_DECREF(current);
            current = new_current;
            if (!new_current) goto bad;
        }
        long long as_c_int = PyLong_AsLongLong(current);
        Py_DECREF(current);
        return as_c_int;
    }
  bad:
    PySys_WriteStderr("__Pyx_GetCurrentInterpreterId failed. Try setting the C define CYTHON_PEP489_MULTI_PHASE_INIT=0\n");
    return -1;
}
#endif
#if !CYTHON_USE_MODULE_STATE
static CYTHON_SMALL_CODE int __Pyx_check_single_interpreter(void) {
    static PY_INT64_T main_interpreter_id = -1;
#if CYTHON_COMPILING_IN_GRAAL && defined(GRAALPY_VERSION_NUM) && GRAALPY_VERSION_NUM > 0x19000000
    PY_INT64_T current_id = GraalPyInterpreterState_GetIDFromThreadState(PyThreadState_Get());
#elif CYTHON_COMPILING_IN_GRAAL
    PY_INT64_T current_id = PyInterpreterState_GetIDFromThreadState(PyThreadState_Get());
#elif CYTHON_COMPILING_IN_LIMITED_API && (__PYX_LIMITED_VERSION_HEX < 0x030A0000 &&\
      (defined(_WIN32) || defined(WIN32) || defined(MS_WINDOWS)))
    PY_INT64_T current_id = __Pyx_GetCurrentInterpreterId();
#elif CYTHON_COMPILING_IN_LIMITED_API
    PY_INT64_T current_id = PyInterpreterState_GetID(PyInterpreterState_Get());
#else
    PY_INT64_T current_id = PyInterpreterState_GetID(PyThreadState_Get()->interp);
#endif
    if (unlikely(current_id == -1)) {
        return -1;
    }
    if (main_interpreter_id == -1) {
        main_interpreter_id = current_id;
        return 0;
    } else if (unlikely(main_interpreter_id != current_id)) {
        PyErr_SetString(
            PyExc_ImportError,
            "Interpreter change detected - this module can only be loaded into one interpreter per process.");
        return -1;
    }
    return 0;
}
#endif
static CYTHON_SMALL_CODE int __Pyx_copy_spec_to_module(PyObject *spec, PyObject *moddict, const char* from_name, const char* to_name, int allow_none)
{
    PyObject *value = PyObject_GetAttrString(spec, from_name);
    int result = 0;
    if (likely(value)) {
        if (allow_none || value != Py_None) {
            result = PyDict_SetItemString(moddict, to_name, value);
        }
        Py_DECREF(value);
    } else if (PyErr_ExceptionMatches(PyExc_AttributeError)) {
        PyErr_Clear();
    } else {
        result = -1;
    }
    return result;
}
static CYTHON_SMALL_CODE PyObject* __pyx_pymod_create(PyObject *spec, PyModuleDef *def) {
    PyObject *module = NULL, *moddict, *modname;
    CYTHON_UNUSED_VAR(def);
    #if !CYTHON_USE_MODULE_STATE
    if (__Pyx_check_single_interpreter())
        return NULL;
    #endif
    if (__pyx_m)
        return __Pyx_NewRef(__pyx_m);
    modname = PyObject_GetAttrString(spec, "name");
    if (unlikely(!modname)) goto bad;
    module = PyModule_NewObject(modname);
    Py_DECREF(modname);
    if (unlikely(!module)) goto bad;
    moddict = PyModule_GetDict(module);
    if (unlikely(!moddict)) goto bad;
    if (unlikely(__Pyx_copy_spec_to_module(spec, moddict, "loader", "__loader__", 1) < 0)) goto bad;
    if (unlikely(__Pyx_copy_spec_to_module(spec, moddict, "origin", "__file__", 1) < 0)) goto bad;
    if (unlikely(__Pyx_copy_spec_to_module(spec, moddict, "parent", "__package__", 1) < 0)) goto bad;
    if (unlikely(__Pyx_copy_spec_to_module(spec, moddict, "submodule_search_locations", "__path__", 0) < 0)) goto bad;
    return module;
bad:
    Py_XDECREF(module);
    return NULL;
}


static CYTHON_SMALL_CODE int __pyx_pymod_exec_template_docx(PyObject *__pyx_pyinit_module)
#endif
{
  int stringtab_initialized = 0;
  #if CYTHON_USE_MODULE_STATE
  int pystate_addmodule_run = 0;
  #endif
  __pyx_mstatetype *__pyx_mstate = NULL;
  PyObject *__pyx_t_1 = NULL;
  PyObject *__pyx_t_2 = NULL;
  Py_ssize_t __pyx_t_3;
  PyObject *__pyx_t_4 = NULL;
  PyObject *__pyx_t_5 = NULL;
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  __Pyx_RefNannyDeclarations
  #if CYTHON_PEP489_MULTI_PHASE_INIT
  if (__pyx_m) {
    if (__pyx_m == __pyx_pyinit_module) return 0;
    PyErr_SetString(PyExc_RuntimeError, "Module 'template_docx' has already been imported. Re-initialisation is not supported.");
    return -1;
  }
  #else
  if (__pyx_m) return __Pyx_NewRef(__pyx_m);
  #endif
  
  #if CYTHON_PEP489_MULTI_PHASE_INIT
  __pyx_t_1 = __pyx_pyinit_module;
  Py_INCREF(__pyx_t_1);
  #else
  __pyx_t_1 = PyModule_Create(&__pyx_moduledef); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 1, __pyx_L1_error)
  #endif
  #if CYTHON_USE_MODULE_STATE
  {
    int add_module_result = __Pyx_State_AddModule(__pyx_t_1, &__pyx_moduledef);
    __pyx_t_1 = 0; 
    if (unlikely((add_module_result < 0))) __PYX_ERR(0, 1, __pyx_L1_error)
    pystate_addmodule_run = 1;
  }
  #else
  __pyx_m = __pyx_t_1;
  #endif
  #if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
  PyUnstable_Module_SetGIL(__pyx_m, Py_MOD_GIL_USED);
  #endif
  __pyx_mstate = __pyx_mstate_global;
  CYTHON_UNUSED_VAR(__pyx_t_1);
  __pyx_mstate->__pyx_d = PyModule_GetDict(__pyx_m); if (unlikely(!__pyx_mstate->__pyx_d)) __PYX_ERR(0, 1, __pyx_L1_error)
  Py_INCREF(__pyx_mstate->__pyx_d);
  __pyx_mstate->__pyx_b = __Pyx_PyImport_AddModuleRef(__Pyx_BUILTIN_MODULE_NAME); if (unlikely(!__pyx_mstate->__pyx_b)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_cython_runtime = __Pyx_PyImport_AddModuleRef("cython_runtime"); if (unlikely(!__pyx_mstate->__pyx_cython_runtime)) __PYX_ERR(0, 1, __pyx_L1_error)
  if (PyObject_SetAttrString(__pyx_m, "__builtins__", __pyx_mstate->__pyx_b) < 0) __PYX_ERR(0, 1, __pyx_L1_error)
  
  #if CYTHON_REFNANNY
  __Pyx_RefNanny = __Pyx_RefNannyImportAPI("refnanny");
  if (!__Pyx_RefNanny) {
    if (PyErr_ExceptionMatches(PyExc_Exception)) {
      PyErr_Clear();
      __Pyx_RefNanny = __Pyx_RefNannyImportAPI("Cython.Runtime.refnanny");
    }
    if (!__Pyx_RefNanny)
        Py_FatalError("failed to import 'refnanny' module");
  }
  #endif
  
__Pyx_RefNannySetupContext("PyInit_template_docx", 0);
  __Pyx_init_runtime_version();
  if (__Pyx_check_binary_version(__PYX_LIMITED_VERSION_HEX, __Pyx_get_runtime_version(), CYTHON_COMPILING_IN_LIMITED_API) < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_empty_tuple = PyTuple_New(0); if (unlikely(!__pyx_mstate->__pyx_empty_tuple)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_empty_bytes = PyBytes_FromStringAndSize("", 0); if (unlikely(!__pyx_mstate->__pyx_empty_bytes)) __PYX_ERR(0, 1, __pyx_L1_error)
  __pyx_mstate->__pyx_empty_unicode = PyUnicode_FromStringAndSize("", 0); if (unlikely(!__pyx_mstate->__pyx_empty_unicode)) __PYX_ERR(0, 1, __pyx_L1_error)
  
  
  if (__Pyx_InitConstants(__pyx_mstate) < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
  stringtab_initialized = 1;
  if (__Pyx_InitGlobals() < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
  if (__pyx_module_is_main_cloze__template_docx) {
    if (PyObject_SetAttr(__pyx_m, __pyx_mstate_global->__pyx_n_u_name_2, __pyx_mstate_global->__pyx_n_u_main) < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
  }
  {
    PyObject *modules = PyImport_GetModuleDict(); if (unlikely(!modules)) __PYX_ERR(0, 1, __pyx_L1_error)
    if (!PyDict_GetItemString(modules, "cloze.template_docx")) {
      if (unlikely((PyDict_SetItemString(modules, "cloze.template_docx", __pyx_m) < 0))) __PYX_ERR(0, 1, __pyx_L1_error)
    }
  }
  
  if (__Pyx_InitCachedBuiltins(__pyx_mstate) < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
  
  if (__Pyx_InitCachedConstants(__pyx_mstate) < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
  if (__Pyx_CreateCodeObjects(__pyx_mstate) < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
  
  (void)__Pyx_modinit_Global_init_code(__pyx_mstate);
  (void)__Pyx_modinit_Variable_export_code(__pyx_mstate);
  (void)__Pyx_modinit_Function_export_code(__pyx_mstate);
  
  if (unlikely((__Pyx_modinit_Exttype___pyx_defaults(__pyx_mstate) < 0))) __PYX_ERR(0, 1, __pyx_L1_error)
  (void)__Pyx_modinit_Type_import_code(__pyx_mstate);
  (void)__Pyx_modinit_Variable_import_code(__pyx_mstate);
  (void)__Pyx_modinit_Function_import_code(__pyx_mstate);
  if (__Pyx_InitAfterSharedUtility() < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
  

  
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_Document};
    __pyx_t_1 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_docx_2, __pyx_imported_names, 1, NULL, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 1, __pyx_L1_error)
  }
  __pyx_t_2 = __pyx_t_1;
  __Pyx_GOTREF(__pyx_t_2);
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_Document};
    __pyx_t_3 = 0; {
      __pyx_t_4 = __Pyx_ImportFrom(__pyx_t_2, __pyx_imported_names[__pyx_t_3]); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 1, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_imported_names[__pyx_t_3], __pyx_t_4) < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    }
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_1 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_re, 0, 0, NULL, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 2, __pyx_L1_error)
  __pyx_t_2 = __pyx_t_1;
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_re, __pyx_t_2) < (0)) __PYX_ERR(0, 2, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_BytesIO};
    __pyx_t_1 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_io, __pyx_imported_names, 1, NULL, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 3, __pyx_L1_error)
  }
  __pyx_t_2 = __pyx_t_1;
  __Pyx_GOTREF(__pyx_t_2);
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_BytesIO};
    __pyx_t_3 = 0; {
      __pyx_t_4 = __Pyx_ImportFrom(__pyx_t_2, __pyx_imported_names[__pyx_t_3]); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 3, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_imported_names[__pyx_t_3], __pyx_t_4) < (0)) __PYX_ERR(0, 3, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    }
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_get_outer_frame_variables};
    __pyx_t_1 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_utils, __pyx_imported_names, 1, __pyx_mstate_global->__pyx_kp_u_cloze_utils, 1); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 4, __pyx_L1_error)
  }
  __pyx_t_2 = __pyx_t_1;
  __Pyx_GOTREF(__pyx_t_2);
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_get_outer_frame_variables};
    __pyx_t_3 = 0; {
      __pyx_t_4 = __Pyx_ImportFrom(__pyx_t_2, __pyx_imported_names[__pyx_t_3]); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 4, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_imported_names[__pyx_t_3], __pyx_t_4) < (0)) __PYX_ERR(0, 4, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    }
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_1 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_pandas, 0, 0, NULL, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 5, __pyx_L1_error)
  __pyx_t_2 = __pyx_t_1;
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_pandas, __pyx_t_2) < (0)) __PYX_ERR(0, 5, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_1 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_copy, 0, 0, NULL, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 6, __pyx_L1_error)
  __pyx_t_2 = __pyx_t_1;
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_copy, __pyx_t_2) < (0)) __PYX_ERR(0, 6, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_Py3MetaclassPrepare((PyObject *) NULL, __pyx_mstate_global->__pyx_empty_tuple, __pyx_mstate_global->__pyx_n_u_TemplateDocx, __pyx_mstate_global->__pyx_n_u_TemplateDocx, (PyObject *) NULL, __pyx_mstate_global->__pyx_n_u_cloze_template_docx, (PyObject *) NULL); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 9, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);

  
  __pyx_t_4 = __Pyx_CyFunction_New(&__pyx_mdef_5cloze_13template_docx_12TemplateDocx_1__init__, 0, __pyx_mstate_global->__pyx_n_u_TemplateDocx___init, NULL, __pyx_mstate_global->__pyx_n_u_cloze_template_docx, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[0])); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 10, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030E0000
  PyUnstable_Object_EnableDeferredRefcount(__pyx_t_4);
  #endif
  __Pyx_CyFunction_SetDefaultsTuple(__pyx_t_4, __pyx_mstate_global->__pyx_tuple[2]);
  if (__Pyx_SetNameInClass(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_init, __pyx_t_4) < (0)) __PYX_ERR(0, 10, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

  
  __pyx_t_4 = __Pyx_CyFunction_New(&__pyx_mdef_5cloze_13template_docx_12TemplateDocx_3__call__, 0, __pyx_mstate_global->__pyx_n_u_TemplateDocx___call, NULL, __pyx_mstate_global->__pyx_n_u_cloze_template_docx, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[1])); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 25, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030E0000
  PyUnstable_Object_EnableDeferredRefcount(__pyx_t_4);
  #endif
  __Pyx_CyFunction_SetDefaultsTuple(__pyx_t_4, __pyx_mstate_global->__pyx_tuple[3]);
  if (__Pyx_SetNameInClass(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_call, __pyx_t_4) < (0)) __PYX_ERR(0, 25, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

  
  __pyx_t_4 = __Pyx_CyFunction_New(&__pyx_mdef_5cloze_13template_docx_12TemplateDocx_5replace_paragraph, 0, __pyx_mstate_global->__pyx_n_u_TemplateDocx_replace_paragraph, NULL, __pyx_mstate_global->__pyx_n_u_cloze_template_docx, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[2])); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 102, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030E0000
  PyUnstable_Object_EnableDeferredRefcount(__pyx_t_4);
  #endif
  if (!__Pyx_CyFunction_InitDefaults(__pyx_t_4, __pyx_mstate_global->__pyx_ptype_5cloze_13template_docx___pyx_defaults)) __PYX_ERR(0, 102, __pyx_L1_error)
  __pyx_t_5 = __Pyx_PyDict_NewPresized(0); if (unlikely(!__pyx_t_5)) __PYX_ERR(0, 102, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_5);
  __Pyx_CyFunction_Defaults(struct __pyx_defaults, __pyx_t_4)->arg0 = __pyx_t_5;
  __Pyx_GIVEREF(__pyx_t_5);
  __pyx_t_5 = 0;
  __Pyx_CyFunction_SetDefaultsGetter(__pyx_t_4, __pyx_pf_5cloze_13template_docx_2__defaults__);
  if (__Pyx_SetNameInClass(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_replace_paragraph, __pyx_t_4) < (0)) __PYX_ERR(0, 102, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

  
  __pyx_t_4 = __Pyx_CyFunction_New(&__pyx_mdef_5cloze_13template_docx_12TemplateDocx_7concat_run, 0, __pyx_mstate_global->__pyx_n_u_TemplateDocx_concat_run, NULL, __pyx_mstate_global->__pyx_n_u_cloze_template_docx, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[3])); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 224, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030E0000
  PyUnstable_Object_EnableDeferredRefcount(__pyx_t_4);
  #endif
  if (__Pyx_SetNameInClass(__pyx_t_2, __pyx_mstate_global->__pyx_n_u_concat_run, __pyx_t_4) < (0)) __PYX_ERR(0, 224, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;

  
  __pyx_t_4 = __Pyx_Py3ClassCreate(((PyObject*)&PyType_Type), __pyx_mstate_global->__pyx_n_u_TemplateDocx, __pyx_mstate_global->__pyx_empty_tuple, __pyx_t_2, NULL, 0, 0); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 9, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_4);
  #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030E0000
  PyUnstable_Object_EnableDeferredRefcount(__pyx_t_4);
  #endif
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_TemplateDocx, __pyx_t_4) < (0)) __PYX_ERR(0, 9, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_qn};
    __pyx_t_1 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_docx_oxml_ns, __pyx_imported_names, 1, NULL, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 297, __pyx_L1_error)
  }
  __pyx_t_2 = __pyx_t_1;
  __Pyx_GOTREF(__pyx_t_2);
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_qn};
    __pyx_t_3 = 0; {
      __pyx_t_4 = __Pyx_ImportFrom(__pyx_t_2, __pyx_imported_names[__pyx_t_3]); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 297, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_imported_names[__pyx_t_3], __pyx_t_4) < (0)) __PYX_ERR(0, 297, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    }
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_OxmlElement};
    __pyx_t_1 = __Pyx_Import(__pyx_mstate_global->__pyx_n_u_docx_oxml, __pyx_imported_names, 1, NULL, 0); if (unlikely(!__pyx_t_1)) __PYX_ERR(0, 298, __pyx_L1_error)
  }
  __pyx_t_2 = __pyx_t_1;
  __Pyx_GOTREF(__pyx_t_2);
  {
    PyObject* const __pyx_imported_names[] = {__pyx_mstate_global->__pyx_n_u_OxmlElement};
    __pyx_t_3 = 0; {
      __pyx_t_4 = __Pyx_ImportFrom(__pyx_t_2, __pyx_imported_names[__pyx_t_3]); if (unlikely(!__pyx_t_4)) __PYX_ERR(0, 298, __pyx_L1_error)
      __Pyx_GOTREF(__pyx_t_4);
      if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_imported_names[__pyx_t_3], __pyx_t_4) < (0)) __PYX_ERR(0, 298, __pyx_L1_error)
      __Pyx_DECREF(__pyx_t_4); __pyx_t_4 = 0;
    }
  }
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_CyFunction_New(&__pyx_mdef_5cloze_13template_docx_1cell_format_painter, 0, __pyx_mstate_global->__pyx_n_u_cell_format_painter, NULL, __pyx_mstate_global->__pyx_n_u_cloze_template_docx, __pyx_mstate_global->__pyx_d, ((PyObject *)__pyx_mstate_global->__pyx_codeobj_tab[4])); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 300, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030E0000
  PyUnstable_Object_EnableDeferredRefcount(__pyx_t_2);
  #endif
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_cell_format_painter, __pyx_t_2) < (0)) __PYX_ERR(0, 300, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  
  __pyx_t_2 = __Pyx_PyDict_NewPresized(0); if (unlikely(!__pyx_t_2)) __PYX_ERR(0, 1, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_t_2);
  if (PyDict_SetItem(__pyx_mstate_global->__pyx_d, __pyx_mstate_global->__pyx_n_u_test, __pyx_t_2) < (0)) __PYX_ERR(0, 1, __pyx_L1_error)
  __Pyx_DECREF(__pyx_t_2); __pyx_t_2 = 0;

  

  goto __pyx_L0;
  __pyx_L1_error:;
  __Pyx_XDECREF(__pyx_t_2);
  __Pyx_XDECREF(__pyx_t_4);
  __Pyx_XDECREF(__pyx_t_5);
  if (__pyx_m) {
    if (__pyx_mstate->__pyx_d && stringtab_initialized) {
      __Pyx_AddTraceback("init cloze.template_docx", __pyx_clineno, __pyx_lineno, __pyx_filename);
    }
    #if !CYTHON_USE_MODULE_STATE
    Py_CLEAR(__pyx_m);
    #else
    Py_DECREF(__pyx_m);
    if (pystate_addmodule_run) {
      PyObject *tp, *value, *tb;
      __Pyx_PyErr_FetchException(&tp, &value, &tb);
      __Pyx_State_RemoveModule(&__pyx_moduledef);
      __Pyx_PyErr_RestoreException(tp, value, tb);
    }
    #endif
  } else if (!PyErr_Occurred()) {
    PyErr_SetString(PyExc_ImportError, "init cloze.template_docx");
  }
  __pyx_L0:;
  __Pyx_RefNannyFinishContext();
  #if CYTHON_PEP489_MULTI_PHASE_INIT
  return (__pyx_m != NULL) ? 0 : -1;
  #else
  return __pyx_m;
  #endif
}



static int __Pyx_InitCachedBuiltins(__pyx_mstatetype *__pyx_mstate) {
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __pyx_builtin_enumerate = __Pyx_GetBuiltinName(__pyx_mstate->__pyx_n_u_enumerate); if (!__pyx_builtin_enumerate) __PYX_ERR(0, 53, __pyx_L1_error)
  __pyx_builtin_eval = __Pyx_GetBuiltinName(__pyx_mstate->__pyx_n_u_eval); if (!__pyx_builtin_eval) __PYX_ERR(0, 64, __pyx_L1_error)
  __pyx_builtin_zip = __Pyx_GetBuiltinName(__pyx_mstate->__pyx_n_u_zip); if (!__pyx_builtin_zip) __PYX_ERR(0, 273, __pyx_L1_error)

  
  __pyx_mstate->__pyx_umethod_PyDict_Type_items.type = (PyObject*)&PyDict_Type;
  __pyx_mstate->__pyx_umethod_PyDict_Type_items.method_name = &__pyx_mstate->__pyx_n_u_items;
  __pyx_mstate->__pyx_umethod_PyDict_Type_pop.type = (PyObject*)&PyDict_Type;
  __pyx_mstate->__pyx_umethod_PyDict_Type_pop.method_name = &__pyx_mstate->__pyx_n_u_pop;
  __pyx_mstate->__pyx_umethod_PyDict_Type_values.type = (PyObject*)&PyDict_Type;
  __pyx_mstate->__pyx_umethod_PyDict_Type_values.method_name = &__pyx_mstate->__pyx_n_u_values;
  return 0;
  __pyx_L1_error:;
  return -1;
}


static int __Pyx_InitCachedConstants(__pyx_mstatetype *__pyx_mstate) {
  __Pyx_RefNannyDeclarations
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  CYTHON_UNUSED_VAR(__pyx_mstate);
  __Pyx_RefNannySetupContext("__Pyx_InitCachedConstants", 0);

  
  {
    PyObject* __pyx_temp[2] = {__pyx_mstate_global->__pyx_kp_u__7, __pyx_mstate_global->__pyx_kp_u__8};
    __pyx_mstate_global->__pyx_tuple[0] = __Pyx_PyTuple_FromArray(__pyx_temp, 2); if (unlikely(!__pyx_mstate_global->__pyx_tuple[0])) __PYX_ERR(0, 60, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[0]);
  }
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[0]);

  
  {
    PyObject* __pyx_temp[1] = {__pyx_mstate_global->__pyx_n_u_width};
    __pyx_mstate_global->__pyx_tuple[1] = __Pyx_PyTuple_FromArray(__pyx_temp, 1); if (unlikely(!__pyx_mstate_global->__pyx_tuple[1])) __PYX_ERR(0, 74, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[1]);
  }
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[1]);

  
  __pyx_mstate_global->__pyx_slice[0] = PySlice_New(Py_None, Py_None, __pyx_mstate_global->__pyx_int_neg_1); if (unlikely(!__pyx_mstate_global->__pyx_slice[0])) __PYX_ERR(0, 293, __pyx_L1_error)
  __Pyx_GOTREF(__pyx_mstate_global->__pyx_slice[0]);
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_slice[0]);

  
  {
    PyObject* __pyx_temp[2] = {((PyObject*)__pyx_mstate_global->__pyx_kp_u_), ((PyObject*)Py_False)};
    __pyx_mstate_global->__pyx_tuple[2] = __Pyx_PyTuple_FromArray(__pyx_temp, 2); if (unlikely(!__pyx_mstate_global->__pyx_tuple[2])) __PYX_ERR(0, 10, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[2]);
  }
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[2]);

  
  {
    PyObject* __pyx_temp[1] = {Py_None};
    __pyx_mstate_global->__pyx_tuple[3] = __Pyx_PyTuple_FromArray(__pyx_temp, 1); if (unlikely(!__pyx_mstate_global->__pyx_tuple[3])) __PYX_ERR(0, 25, __pyx_L1_error)
    __Pyx_GOTREF(__pyx_mstate_global->__pyx_tuple[3]);
  }
  __Pyx_GIVEREF(__pyx_mstate_global->__pyx_tuple[3]);
  #if CYTHON_IMMORTAL_CONSTANTS
  {
    PyObject **table = __pyx_mstate->__pyx_tuple;
    for (Py_ssize_t i=0; i<4; ++i) {
      #if PY_VERSION_HEX >= 0x030F0000
      PyUnstable_SetImmortal(table[i]);
      #elif CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
      if ((PY_SSIZE_T_MAX <= _Py_IMMORTAL_REFCNT_LOCAL)) break;
      #if PY_VERSION_HEX < 0x030E0000
      if (_Py_IsOwnedByCurrentThread(table[i]) && Py_REFCNT(table[i]) == 1)
      #else
      if (PyUnstable_Object_IsUniquelyReferenced(table[i]))
      #endif
      {
        Py_SET_REFCNT(table[i], ((Py_ssize_t)_Py_IMMORTAL_REFCNT_LOCAL + 1));
      }
      #else
      if ((PY_SSIZE_T_MAX < _Py_IMMORTAL_INITIAL_REFCNT)) break;
      Py_SET_REFCNT(table[i], _Py_IMMORTAL_INITIAL_REFCNT);
      #endif
    }
  }
  #endif
  #if CYTHON_IMMORTAL_CONSTANTS
  {
    PyObject **table = __pyx_mstate->__pyx_slice;
    for (Py_ssize_t i=0; i<1; ++i) {
      #if PY_VERSION_HEX >= 0x030F0000
      PyUnstable_SetImmortal(table[i]);
      #elif CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
      if ((PY_SSIZE_T_MAX <= _Py_IMMORTAL_REFCNT_LOCAL)) break;
      #if PY_VERSION_HEX < 0x030E0000
      if (_Py_IsOwnedByCurrentThread(table[i]) && Py_REFCNT(table[i]) == 1)
      #else
      if (PyUnstable_Object_IsUniquelyReferenced(table[i]))
      #endif
      {
        Py_SET_REFCNT(table[i], ((Py_ssize_t)_Py_IMMORTAL_REFCNT_LOCAL + 1));
      }
      #else
      if ((PY_SSIZE_T_MAX < _Py_IMMORTAL_INITIAL_REFCNT)) break;
      Py_SET_REFCNT(table[i], _Py_IMMORTAL_INITIAL_REFCNT);
      #endif
    }
  }
  #endif
  __Pyx_RefNannyFinishContext();
  return 0;
  __pyx_L1_error:;
  __Pyx_RefNannyFinishContext();
  return -1;
}


static int __Pyx_InitConstants(__pyx_mstatetype *__pyx_mstate) {
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  CYTHON_UNUSED_VAR(__pyx_mstate);
  {
    const struct { const unsigned int length: 6; } str_length_index[] = {{0},{2},{1},{5},{1},{1},{11},{13},{17},{11},{22},{7},{6},{2},{9},{30},{37},{41},{8},{5},{11},{4},{2},{7},{9},{8},{11},{12},{21},{21},{23},{30},{1},{20},{12},{8},{17},{7},{8},{8},{8},{13},{10},{8},{11},{12},{8},{8},{13},{13},{3},{10},{11},{7},{7},{9},{6},{18},{4},{6},{4},{12},{20},{4},{6},{4},{5},{19},{5},{5},{18},{19},{5},{7},{10},{8},{4},{8},{3},{4},{9},{12},{8},{10},{7},{7},{7},{6},{13},{8},{8},{9},{3},{4},{19},{4},{7},{4},{7},{11},{19},{9},{14},{15},{25},{9},{1},{6},{2},{12},{6},{5},{1},{1},{1},{4},{10},{4},{6},{9},{10},{7},{11},{12},{3},{2},{3},{2},{7},{6},{7},{17},{8},{3},{3},{4},{3},{4},{4},{9},{4},{3},{10},{6},{5},{4},{8},{10},{7},{7},{6},{13},{8},{6},{3},{5},{6},{13},{4},{9},{9},{5},{6},{18},{5},{3}};
    const struct { const unsigned int length: 10; } bytes_length_index[] = {{584},{625},{55},{171},{668}};
    #ifndef CYTHON_COMPRESS_STRINGS
      #define CYTHON_COMPRESS_STRINGS 90
    #endif
    #if (CYTHON_COMPRESS_STRINGS) == 1 
static const char cstring[] = "x\332\205UKW\333X\022\306\016\t\206@\300\306\004\230<\332&\320@\3500\355\000\tI\272O\216\211iB\047=\301<CB\242\226\345\013V\"K\266\036<\302\320\223\245\227Z\336\245\226Zj\251\245\226^j\251\245\177\002?a\276+\021\206d\246\247\317\261Tu\257\352\326\255\372\352\253\362\2306=]V\204\303\247;;\023o\337OL\276\233z\2723\271s\014\375\370\004\372\344\316\311\316\361\327\313\023AR>\221iC\027%-T\377\256\223jM\342u\3021G\323\265\243\262\250\361%\211\020\231\275\367\004Q\213\264r\215\327u\242\312\231\252\241\351\231\022\311\214\037\237\214g\024\025\362\370\344d\\\343\367\t\007\223\312\371w\"\227\017D\254\303\0003\273\242D\246\317\257\372+\303\203\307\352/\212\254k\007\217\265J\371\340\261.,(j\231\250\032\273\352\370d\341H\047\332\362\253\002\257\363\277\250|\225\024\024\301\250\022Y\177uX\225\026%\302\324\365\263\233\360\351\360\242>\315q\002/I\034\367\315\246(\213\3727\233\202\"\013\274\316\251\206\374\325\266J\240\013,\005\225\337S\371Z\205\343\270\225\243C<\005Q\320\271\177\220C}\225\354r\034/\313\212\316r\345\276\\\t)\361\232\306\355\021]\004\022l\003\0313\261k\310\241\214\242\340\270*/\312\241$:\037\235a\013\245lH\241;\03193YC,\274\032\252u\203\227\276l\003\034\346\205DHp\242\306\t\212\252\240\3422\242f\261W\024\t`\302P\340\313e|\224\214\252\314\264\032\0220T\302TU9\010\205!\363\222\270\0473G|\255\206J\361\332\221,\210\312\364\271K\r\264P\331#\226J\274\360\221=\007\274Z\346p\374\\\277pk\t\357RXL\201H\022{\270\360\265\253\250U\240]C\346z\364M\023*\242T\026$\0266\340\300%\002a\036#\002\177\305Z\244\240\250Q\036\332\177\312\026i\244,( 5!\265P*\002;\020R]\001]\316\225iY+kzXU&#\372\205\332\212\032\nCf\002tdB\027\242\367\031-\243\305\212\n|4Fe\"\203\217\000\005M\264O\366y\211\034\n\244\246_\204A\333\025\3452{\300\214]\\\205\364\031Rg\202\201\367E\275phWU\252!Z`\020\247\250\\X\241\025\365\302\212\005\021.\r\200\310\355\262\346\340\366yUd\r\254\341\003\243\213\254\213\242\254\021U\027\025P\243\214&\n\355D\035\225\026\0301\265\017\037C.\341\3163\034\224}\242\326xV\374s\326\237+\332""\331\\\270\020\347\305<kJ\255.#H\225\250D0T\334K\252\314]\324E\377\325Lg\033eu\257\004\n\342\247\001x\37446_\316g\214F\244]\215\350\370\225\311.oH\272V\341\313\260\255\3605\242\211\237\210\246\n\241K&\243\014B\rn PB&t!z\237\2250Z\254\250\032\210\374\221hFIg\230\205/\355\253\261\245\243\301u\205+\021\0068HAT\306\320p\236\242\322\006\321\366\031\264\350x\356\274s\016\304\262^\371$\326>\307N\257\264]\276\326\3306\371\240\275\267\261\357\017\214Y\305\240=m>\247\213V\322\032\261\362V\261\325\336\323X7\223\177\372=h\357\370\374\207\271FcAb\210^\265rV>H\364\231\035f\2352\347\235=\215es\235&i6\350\036\246\203V\314J\266\302\003[\024v\335\215_q\363\331\207\264\265m\363v\235E\224\370|d\302_\277\371\210\276\260\352v\250\316\232\307V\326\3121\347=\364\265Ud\316\273\033\363f.\350\276nV(a7\267\272{\033\2729OsA\337\337\350\2045ag[\2412\306\234\264\272\373\3159\232\260:,\303\316\007\177\261\350\262\306\355\001\233\217\026=\326\226\275\350$\243\305\025\272\027.\257;\365\377az\266@p=}\215\003S\244\206\265d#\234[t\313Z\266\327\235\001\207wT7\351f\203\276~\363\t\\\025\203t\326\272a\347m(C\210\241\313\316\006C#\326\250\305[\373\366\033\347\300\345\335z\220\276\r\313m[q\213-X\017\332\227\355\242]rb\010)=\010X\306\355d0\364\035=\300\031\330\336\240\017\001\324\214\305\202\270\334\351\047nS\321\nQ\355mTLBst\201\362\264\316\312v\210\010\371 \2212\047\350\030\255[\361\010\337\253\000u\206\225\345\272\371\021EF\341\322\346\022\216\205\365z\316T\226\352,\n\034A\201\320?\347\243j\3144\370\206j\016\241\334\243\364\203\335\351\014\272qd\n\353\334iW[\347-\232\247\253\364\020\265h\007\314\023w\3551\273\216$R\316\254Sw\333\335|0\377\330\035E\276\377j\n~q\303\337x\357\277\337\365w\367\374=\311\227\252\301\374\0237\027\344\346\234-w\331\333h\2164\363\315b\223\017ne\255\001\213\3309\373\031|u\272\311 q\213\026i\311J\3301;\rL\047\247\3549\006\2243\342\024\334\230\233v\213\301\243\047\356\254[\367z\233\232\277\272\351or>\207+*~\245\352W\345\340\321O\210\343\376\003g\317\335\366H3\327\314\007\267G@\037""\360\302^\203\237a\244\223H\233y\306w\177\370\207\263\335\224\223s\362\316\032\374\247\334\234\373\014\316/y\263\236\332\034`\211\254\372\253\304\047H\344\203\377\341\344\264\255\355\217X>\016\221\217/\304\203\304\200Y4\005\3005\002h\326\320\003\375V\301\216\003\027\315\311\3723K^\275\331\356\277\374\335\377]\360\205(F\321\027\031\0308/\307\026\230\233\205x\201\211B|\211\211\245\370s&\236\307\227\343\247?\266u\366\233\2106\211\336M\3644\212\254z\317\032\206\371\322\352\264\223\366\0350\250\352\346\"\236\032f\201\266\243\276\350\025\360\0221\005\311a\232\246\353V2\350\033\246\003\240\313\047{\020\350\016\2408\252\207\315!\332\001\276\304\302\003!3\242C\003\346\006\n_F\337\215\332\304\231q\370\263\375\353,\307\377\357\212\361\243\247\261\010\356\244i1\350f\236\262\364>\335\266>8qg\034\r3\351\3155c\315T\023\004\355m\324\375\366A\363\304\312\237^c\254{h\216\230h\333>\363*\250\331\2236\027\030y\303U\253;e\336\005\264a\362/L\034\273\007N$nF\\^\302x\301\310\030\246):\217\351Q\260\273\234;N\221\035\355E\177\364\335\006\215\3321\3418g\021\274\331\366*M\276i\370\353[\376\326k\377\3656\256N\246X\373}B\217\260n\375\2473\347\306\202\241\033\364\001\252\270h\017\201s\323^\270\361S\304x{\307M\266\276\371~\311\313y\005\344u\323\337\330l\245\307\255\0036\001[Q\2069\047y\232n\353\354k\234\320e\253\010 b,\365#\332\211\013\357\332\371V\342\032\372\2317a~\2651\333\320P\353\356\224\237\232\262s-\226`4{\177\243\375\310\025\235\\\246S\360\001\\\262V\332\037{\210\206\353\362\262_\3463\033\336\335\254RH=n\216\323a\014\2029L\335>\206e\205\215\017\373\022\206\030\346S\234\336\001O;\321Z\353N\032X\r\r\263\201\224\262\346\321\201\005\247\213\265/3\353\305\034\032\372\336*\205is\356\242\227\366\266\233\025\177\023\330\355\370;\3508p\232gX\374\014\266\217bv\336\274\025d\356a\334\205s\300\335i&\233w\232\033\376*\003\272\225a5\313\3148\017\335\254\233k\335\374\016\265\311\214[:n|\211\216\353w\013@93\nH1w\355}g\023-\270\000vi^\026\224\271\202\242\325\203\321I\206\367\237[u\206m\272\306\354n\240\2237""\3359/\321\214\263!\323\372\346L>\030\235\300\370\335p\262\316\003\367::=\026LL\203\354\250=\233\352\356}w\023%\315{E\217\017&\246\354\031\0344\234\027\260\213{\337\303c6\370\341)\026W<\3764\321v\357\276s\003\331\256\272G\315\216f\335_Y\367\327\337\371\3570\365J~\211\r#_\256\3715\3037\366\375\375C\377\360\2505q\317~\033\316\2309/\346\245\274\007\315~\014\301M\177\r\3470\307\266\202\211\037\235\216\350\317\005a\024\331\037\007\213\376\267\260P\243\323v\331\231b\273\301\350#7\355\377\374\212\335\370\306\177\363\266u3c\365\240\234\200\347.j\3611\374s\312\3149\353\376\243\027\030\200\277\302s4\334\347\314\230\231\014\271\371oQ/\251.";
    PyObject *data = __Pyx_DecompressString(cstring, 2254, 1);
    #define __Pyx_DecompressString_LZSS_UNUSED
    if (unlikely(!data)) __PYX_ERR(0, 1, __pyx_L1_error)
    const char* const bytes = __Pyx_PyBytes_AsString(data);
    #if !CYTHON_ASSUME_SAFE_MACROS
    if (likely(bytes)); else { Py_DECREF(data); __PYX_ERR(0, 1, __pyx_L1_error) }
    #endif
    #elif (CYTHON_COMPRESS_STRINGS) > 0 && (CYTHON_COMPRESS_STRINGS) <= 90 
static const char cstring[] = "\377%s..docx\377?\\\\([^()\177]+?\\)\\{\t\000\373{}\t\000)\\}\\{\376\001\013}cloze.\337utils\006\002/t\377emplate_\376E\001.pydisa\337bleen\002\001gc\373is\004\003dpatt\377ern must\377 be \047{}\047\367 or\005\000{}}\047_save_ \000h\027\006\377endwith ~\234\002 file.b\006\376\t\035w:rFont\377sw:shdw:\377tcBorder\373s{h\000{}Byt\377esIOData\377FrameDoc\377umentOxm/lEle\007\001T\316\004\030\000\375x\000\t.__cal\367l__\006\014init\376\006\014concat_\267run4\nre\253 c\376\350\001ragraph\277___Pyx\001\000D\377ict_Next\377Ref__ann\313ot\323!_k\005x\000la\177ss_geti\362 x5\000\357!\003\001func\013\001~\200\003__main\033\001\237metac/\002b\000m_odule2\001n\361\000\332:\001p\211\000ar\016\002qucal\017\005\232 \311\000_e\204#\377_is_coro\372\357@n\237@laceh\373ol\312 __tca{dd\032\000lumn\006\001\335p\276\000ure\021\001ro\375w\002\002unalig\335n\332!app\320@as\277yncio.J\006s\372\224`r\000\001ibbac}k\000\001ward_X\000\252\003\006pl\007by\000b\310Bc\327ell\000\001_\000\002fo\213rm\353 p\367\000\343`\030\001s\377childcli\014\264\000\214 tr\267\000^\001\273\204\003\251\204\n\237color\002\000\305\000s\374\255G\273Cedcopyodeep\003\002oc\254\205\001\362\346\204\002o\254`\000\006.nsd\177st_para\004\001l\371c\005\002Pr\014\002un\034\0017shd#\001tc\000\003\220\204\004\316\r\003Pre!\000\360\204\001en\367ume\222 eenv\377evalexce\371pZ\000\363\047sfind\376\000\001allfont\300\374\000\262!\000\004\271!\003\005\261(frsom\251\"\277`_or\337!o_rPr\003\010tc\010\004\277uter_f\231\205\001_/vari\315\206\001s\365`\334\000\377entiinse\357rtio\230`dat\255a#\002it\347@c\225\204\001s\323jk\307b\243`_\201\206\003ov\377erpandas\210\234!\361\204\002\000\006s\221\207\004\331H\344Hs\337popqn\242\000re\337recuru\000em\360K\001\300\205\003\274\205\016\327\205\004drgb\377rowrowsr?unruns\334\207\001\333\207\006\177selfset\000\000\377defaults\367had)\000hape\177sizesrc\305B\340\004\001\303\207\003\005\002D\000\026\000shd\306\034\001tc\000\003\323\207\004\r\003Pr\377strikesu\323bt\201\211\001\000\002s\252\210""\nte\177xtto_be\336\204\001\306\222`er\236\204\001\313\211\002\347@ue\375s\251 tical_\376\261\205\006widthzi\377p\200\001\360\006\000\005\016\377\210Y\220a\330\004\017\210\377v\320\025%\240Q\330\004\377\024\220H\230E\240\021\240\377\"\240A\240Q\340\004\r\357\210T\220\021\007\026\330\004\007\377\200~\220S\230\001\330\010\377\030\230\013\2401\240A\330\177\010\020\220\007\220q\230Y\001\377\t\r\210I\220T\230\021\377\230!\330\014\031\230\027\240o\001\240\021\340,\002W\230%\000\347\014\210Jw\000\022\004\024\240Y\357\250a\250q\216\001\010\200y\375\220M\000\023\2209\230K\240\373q\250\006\0024\220{\240!\373\2401Y\001\r\230X\240Q\376\267\000\t\014\2108\2201\330\277\014\026\220h\230ev\001\340\377\014\017\210t\2208\2301\377\330\020\032\230(\240(\250\353!\340\004\002%A\001\340\014\023\377\2205\230\010\240\007\240u\347\250A\330\000\n\010\017\n\240\047\357\250\025\250a!\003\r\240W\357\250E\260\021.\003\006\230g\016\n\002\026\260q?\003\036\n1\004\324 \377\r\020\210w\220i\230u\367\240G\250\214\000\035\230W\240\377I\250T\260\025\260a\260\377r\270\021\270!\330\020\023\373\220;H\000Q\330\024!\240\257\033\250A\250\006\000\030\233\000\n\377\250!\330\030\"\240$\240\377a\240v\250Z\260w\270\277a\270q\330\024\036r\000Y\337\250o\270Q\340+\000\027\250\177\005\250Q\250b\260\001\220\000\373\024\027\224 \047\250\021\330\030\347\037\230w1\000)\000\033\2307\356\246 3\240a\330A\t\320\010\357\036\230i\240\321\"\017\210h\377\220e\2301\230B\230a\353\230q\263Ax\237\000a\330\010\377\022\220(\230%\230q\240\325\002\332#\013\322 3\223A\026\2209k\202`\266@\024\220G4\000\253B\211H\007\001\271!4\336@\205#\270\000\200\375A\210C3\210a\210r\220\375\030\354@$\230j\250\t\260\347\027\270\002\347\000\365 1\360\n\377\000\t\035\230A\230R\230\365x\316@\004\376 (*\250%\373\250q\302\000\022\2604\260q\377\270\004\270A\3308:\270\375$\355\000\177\310c\320QU\377\320U^\320^f\320f\377g\320gl\320lm\330\3778;\2701\33015\260\377W\270I\300U\310\"\310\377A\310Q\310a\330\035!\377\240\025\240e\2501\250C\376I\000\t\270\021\330\010\035""\230\377Q\230b\240\010\250\001\250\275\024\321 )+\2505\245!\260\377\"\260D\270\001\270\024\270\377Q\3309;\2704\270q\377\300\017\310s\320RV\320\357V_\320_`\000h\320h\177m\320mn\3309<\205\000\37726\260g\270Y\300e\377\3101\310A\330\036\"\240\255%\256a\250S\356 \031\266@\010w\024\220A\354\204\001\320\031,\264@\376\022\001\022\2601\260A\260S\276]\000\022\2701\270CZ\000\003\277\3004\300r\310\025\305\001R\337\320Re\320e\306\000j\320\377j}\360\000\000~\001A\375\002\004\000A\002B\002\330\010\377\025\220Q\220c\230\021\230\375\"\230 S\240\001\240\023\240\367D\250\002\225 s\260!\320\3773G\300q\310\004\320L\277`\320`c\320c\236\003is\320i\211!D\000n\001BC\001wB\002DJ\001D\002GQ\001\367G\002HX\001H\002I\002\377\3600\000\t\023\220!\330\367\010\021\220\222 \r\210Q\330\377\010\014\210C\210u\220L\277\240\t\250\021\250#\277`m\373\2701\242\204\003u\220D\230\004\273\230A\261\205\001!\330\020\221\000\330\377\021\031\230\024\230T\240\021\337\330\020\031\230\025\254`z\250\377\027\260\t\270\025\270a\270\273r\300\022\000\030\230\007\255`\001\370,\002\225b/\003\025\220U\230$\377\230d\240(\250$\250e/\2603\260aF\004\026\340\001-\033\356\234a\r\210E\271`\024\230Q\373\330\014F\001!\2302\230Y\377\240j\260\002\260\047\270\021\377\270)\3005\310\001\310\022\377\3101\330\010\017\210q\320\377\004\027\220}\240A\360\016\377\000\t\014\2107\220\"\220\377A\330\014\020\220\013\2301\237\330\r\024\220B\320\207\001\t\002\340\317\014\022\220*\363`\370\002K\220\3264\000-\250\206 \034\366\207\003G\220\3779\230A\340\014\031\230\022\357\2308\2401\367 \n\260#\375\260z\000\020\220\017\230q\330\373\020\036\304`\004\240A\240_\373\260E\265`Y\300h\310a\377\310u\320TW\320WX\367\320XYx\000\021\022\330\024\337\027\220z\240\021\251\206\002|\260\3775\270\001\330\030\033\2306\376\303@E\250\030\260\021\260.\365\300\014\002<\354\204\003\250\\\270\021}\340\021\014\003\3001\300D\325\000\377\034\320UV\340\024\047\240\365w\376\210\001\340\334\0031\260\021\360\377\024\000\t\020\210}\230I\353\240Q\206 \001\367\001y\230\t\377\240\021""\240*\250A\340\010\377\016\210h\220a\220q\340\277\010\013\2104\210s\351@\014\377\022\320\022+\2501\340\010\374\336\000\233\211\001\r\210M\230\023\230\335A\235\211\001d\230+A\000a\330\377\014!\240\024\320%7\260_q\270\n\300!\036\003I\270\212\002\374\360 \366\002\002\220\047\230\031\240O!\2405\250\334@\310!h\273\207\001\377\250\003\2501\330\024\030\230\337\002\230#\230S\276`\024\250\267T\260\024\251 \030\031\215\210\001\022\377\2408\2501\250D\260\n\374\273\206\001#\001\017\240q\330\030&\377\240b\250\004\250A\250_\377\270E\300\024\300Y\310h\373\320V\271 \\\320\\_\320\337_`\320`a\210!=\250\375\002\251`a\330\034\035\330 \367-\250Z\202\207\003\270\\\310\021\277\310#\310U\320R\345!\340\376\026\000Q\330 3\2607\270\377!\2701\340\034\037\230q\377\330 \047\240t\2501\250\177L\270\001\270\023\270D\343 \357 $\240E\254\212\001\250v\260\377V\2701\270B\270a\270\327s\300!\260`\006\262@q\330\353$)\214A\330\r\026\t\320Q\357R\320RS$\001\033\260A\276@\0005\300\010\310\002\341\207\001\340\376K\014A\330$(\250\005\250\377U\260!\2606\270\026\270=q\337@(.\250e\370A\322\212\001\357\2702\270V\320@A\300Q\377\300a\330(+\2503\250\377a\250u\260K\270q\300\367\002\300&O\000!\330,?\377\270q\300\006\300a\360\010\377\000-2\260\033\270A\270\377R\270y\310\007\310q\320\377PT\320T]\320]^\337\320^b\320b\211\210\001\320n\377p\320pu\320uv\320\377vx\320xy\340(-\373\250[\337\207\0025\300\001\300\022\377\3006\310\023\310A\310V\353\320S5\000V\331 \330(0\223\260\007\327\213\003\204\000Q\265\213\001\272\001M\376\244B$.\250d\260+\270\376\023\000\330$9\270\024\320=\375On\001Z\320Z[\340\034\377 \240\r\250T\260\021\330\277 *\250$\250k\230\214\002 \3775\260T\3209K\3101\363\310J\263@\345\215\0035\220\001\220\001\021\227\204\002";
    PyObject *data = __Pyx_DecompressString_LZSS(cstring, 2906, 3557);
    #define __Pyx_DecompressString_UNUSED
    if (unlikely(!data)) __PYX_ERR(0, 1, __pyx_L1_error)
    const char* const bytes = __Pyx_PyBytes_AsString(data);
    #if !CYTHON_ASSUME_SAFE_MACROS
    if (likely(bytes)); else { Py_DECREF(data); __PYX_ERR(0, 1, __pyx_L1_error) }
    #endif
    #else 
static const char bytes[] = "%s..docx?\\\\([^()]+?\\)\\{([^{}]+?)\\}\\{\\{([^{}]+?)\\}\\}cloze.utilscloze/template_docx.pydisableenablegcisenabledpattern must be \047{}\047 or \047{{}}\047save_path must be endwith .docx file.template_path must be endwith .docx file.w:rFontsw:shdw:tcBorders{{}}{}BytesIODataFrameDocumentOxmlElementTemplateDocxTemplateDocx.__call__TemplateDocx.__init__TemplateDocx.concat_runTemplateDocx.replace_paragraph___Pyx_PyDict_NextRef__annotate____call____class_getitem____doc____func____init____main____metaclass____module____name____prepare____qualname____test___element_is_coroutine_placeholder__tcadd_columnadd_pictureadd_rowadd_runalignmentappendasyncio.coroutinesattrattribbackbackward_addbackward_placeholderboldbordercellcell_cell_format_paintercellschildcline_in_tracebackcloze.template_docxcolorcolumnsconcat_runconcatedcopydeepcopydocdocxdocx.oxmldocx.oxml.nsdst_paradst_rFontsdst_rPrdst_rundst_shddst_tcdst_tcBordersdst_tcPrendswithenumerateenvevalexcept_placeholdersfindfindallfontforwardforward_addforward_placeholderfrom_cellget_or_add_rPrget_or_add_tcPrget_outer_frame_variablesgetparentiinsertiois_dataframeitalicitemsjklnameold_rFontsoverpandasparagraphparagraphspatternplaceholderplaceholderspopqnrPrrerecurseremovereplacereplace_paragraphreplacedrgbrowrowsrunrunssavesave_pathselfsetsetdefaultshadowshapesizesrc_parasrc_rFontssrc_runsrc_shdsrc_tcsrc_tcBorderssrc_tcPrstrikesubtabletablestemplate_pathtextto_be_addunderlineutilsvaluesvertical_alignmentwidthzip\200\001\360\006\000\005\016\210Y\220a\330\004\017\210v\320\025%\240Q\330\004\024\220H\230E\240\021\240\"\240A\240Q\340\004\r\210T\220\021\330\004\017\210v\320\025%\240Q\330\004\024\220H\230E\240\021\240\"\240A\240Q\330\004\007\200~\220S\230\001\330\010\030\230\013\2401\240A\330\010\020\220\007\220q\230\001\360\006\000\t\r\210I\220T\230\021\230!\330\014\031\230\027\240\001\240\021\340\004\007\200~\220W\230A\330\010\014\210J\220a\330\014\031\230\027\240\001\240\024\240Y\250a\250q\360\006\000\005\010\200y\220\001\330\010""\023\2209\230K\240q\250\001\330\010\023\2204\220{\240!\2401\330\010\020\220\r\230X\240Q\360\006\000\t\014\2108\2201\330\014\026\220h\230e\2401\240A\340\014\017\210t\2208\2301\330\020\032\230(\240(\250!\340\020\032\230(\240%\240q\250\001\340\014\023\2205\230\010\240\007\240u\250A\330\014\023\2205\230\010\240\007\240u\250A\330\014\023\2205\230\010\240\007\240u\250A\330\014\023\2205\230\n\240\047\250\025\250a\330\014\023\2205\230\r\240W\250E\260\021\330\014\023\2205\230\006\230g\240W\250E\260\026\260q\330\014\023\2205\230\n\240\047\250\025\250a\330\014\023\2205\230\n\240\047\250\025\250a\360\006\000\r\020\210w\220i\230u\240G\2501\330\020\035\230W\240I\250T\260\025\260a\260r\270\021\270!\330\020\023\220;\230g\240Q\330\024!\240\033\250A\250Q\330\024\030\230\010\240\n\250!\330\030\"\240$\240a\240v\250Z\260w\270a\270q\330\024\036\230g\240Y\250o\270Q\340\024!\240\027\250\005\250Q\250b\260\001\260\021\330\024\027\220{\240\047\250\021\330\030\037\230w\240a\240q\330\024\033\2307\240!\2403\240a\360\006\000\005\t\320\010\036\230i\240q\360\006\000\005\017\210h\220e\2301\230B\230a\230q\330\004\007\200x\210w\220a\330\010\022\220(\230%\230q\240\002\240!\2401\330\010\013\2108\2203\220a\330\014\026\220k\240\021\240!\330\014\024\220G\2301\230A\330\010\014\210H\220G\2301\330\014\023\2204\220q\230\006\230g\240W\250A\250Q\200A\360\006\000\t\014\2103\210a\210r\220\030\230\021\230$\230j\250\t\260\027\270\002\270!\330\014\023\2201\360\n\000\t\035\230A\230R\230x\240q\250\004\250A\330(*\250%\250q\260\001\260\022\2604\260q\270\004\270A\3308:\270$\270a\270\177\310c\320QU\320U^\320^f\320fg\320gl\320lm\3308;\2701\33015\260W\270I\300U\310\"\310A\310Q\310a\330\035!\240\025\240e\2501\250C\250q\260\t\270\021\330\010\035\230Q\230b\240\010\250\001\250\024\250Q\330)+\2505\260\001\260\021\260\"\260D\270\001\270\024\270Q\3309;\2704\270q\300\017\310s\320RV\320V_\320_g\320gh\320hm\320mn\3309<\270A\33026\260g\270Y\300e\3101\310A\330\036\"\240%\240u\250A\250S\260\001\260\031\270!\330\010\024\220A\220S\230\001""\320\031,\250A\250S\260\001\260\022\2601\260A\260S\270\001\270\022\2701\270C\270q\300\003\3004\300r\310\025\310c\320QR\320Re\320ef\320fj\320j}\360\000\000~\001A\002\360\000\000A\002B\002\330\010\025\220Q\220c\230\021\230\"\230A\230S\240\001\240\023\240D\250\002\250%\250s\260!\3203G\300q\310\004\320L`\320`c\320cg\320gh\320hi\320il\320lm\360\000\000n\001B\002\360\000\000B\002D\002\360\000\000D\002G\002\360\000\000G\002H\002\360\000\000H\002I\002\3600\000\t\023\220!\330\010\021\220\021\330\010\r\210Q\330\010\014\210C\210u\220L\240\t\250\021\250#\250Q\250m\2701\360\006\000\r\020\210u\220D\230\004\230A\330\020\032\230!\330\020\025\220Q\330\021\031\230\024\230T\240\021\330\020\031\230\025\230a\230z\250\027\260\t\270\025\270a\270r\300\021\330\020\030\230\007\230q\240\001\330\020\032\230!\2301\230A\330\020\025\220Q\330\021\025\220U\230$\230d\240(\250$\250e\2603\260a\330\020\025\220Q\330\021\026\220c\230\021\330\020\031\230\025\230a\230z\250\027\260\t\270\025\270a\270r\300\021\330\020\030\230\007\230q\240\001\360\n\000\t\r\210E\220\030\230\024\230Q\330\014\025\220U\230!\2302\230Y\240j\260\002\260\047\270\021\270)\3005\310\001\310\022\3101\330\010\017\210q\320\004\027\220}\240A\360\016\000\t\014\2107\220\"\220A\330\014\020\220\013\2301\330\r\024\220B\220a\330\014\020\220\013\2301\340\014\022\220*\230A\230Q\330\010\014\210K\220q\320\004-\250Q\330\010\034\230A\330\010\014\210G\2209\230A\340\014\031\230\022\2308\2401\240D\250\n\260#\260Q\330\014\020\220\017\230q\330\020\036\230b\240\004\240A\240_\260E\270\024\270Y\300h\310a\310u\320TW\320WX\320XY\360\016\000\021\022\330\024\027\220z\240\021\240$\240a\240|\2605\270\001\330\030\033\2306\240\023\240E\250\030\260\021\260.\300\001\330\030\033\230<\240q\250\004\250A\250\\\270\021\340\030\033\2306\240\023\240E\250\030\260\021\260.\300\003\3001\300D\310\001\310\034\320UV\340\024\047\240w\250a\250q\340\010\017\210q\320\0041\260\021\360\024\000\t\020\210}\230I\240Q\240j\260\001\330\010\017\210y\230\t\240\021\240*\250A\340\010\016\210h""\220a\220q\340\010\013\2104\210s\220!\330\014\022\320\022+\2501\340\010\034\230A\360\006\000\t\r\210M\230\023\230A\330\014\026\220d\230+\240Q\240a\330\014!\240\024\320%7\260q\270\n\300!\360\006\000\t\r\210I\220S\230\001\330\014\025\220Q\330\014\020\220\002\220\047\230\031\240!\2405\250\001\330\020\024\220B\220h\230i\240q\250\003\2501\330\024\030\230\002\230#\230S\240\t\250\024\250T\260\024\260Q\330\030\031\340\024!\240\022\2408\2501\250D\260\n\270$\270a\330\024\030\230\017\240q\330\030&\240b\250\004\250A\250_\270E\300\024\300Y\310h\320VW\320W\\\320\\_\320_`\320`a\340\030\033\230=\250\002\250$\250a\330\034\035\330 -\250Z\260q\270\004\270A\270\\\310\021\310#\310U\320RX\320XY\340 -\250Q\330 3\2607\270!\2701\340\034\037\230q\330 \047\240t\2501\250L\270\001\270\023\270D\300\001\330 $\240E\250\025\250a\250v\260V\2701\270B\270a\270s\300!\3005\310\006\310a\310q\330$)\250\030\260\021\330 $\240E\250\025\250a\250v\260V\2701\270B\270a\270s\300!\3005\310\t\320QR\320RS\330$)\250\033\260A\260V\2705\300\010\310\002\310\"\310A\340 $\240E\250\025\250a\250v\260V\2701\270A\330$(\250\005\250U\260!\2606\270\026\270q\300\001\330(.\250e\2605\270\001\270\021\270!\2702\270V\3001\300A\300Q\300a\330(+\2503\250a\250u\260K\270q\300\002\300&\310\002\310!\330,?\270q\300\006\300a\360\010\000-2\260\033\270A\270R\270y\310\007\310q\320PT\320T]\320]^\320^b\320bm\320mn\320np\320pu\320uv\320vx\320xy\340(-\250[\270\001\270\022\2705\300\001\300\022\3006\310\023\310A\310V\320ST\320TV\320VW\330(0\260\007\260r\270\021\270!\2702\270Q\270a\270q\340 $\240M\260\024\260Q\330$.\250d\260+\270Q\270a\330$9\270\024\320=O\310q\320PZ\320Z[\340\034 \240\r\250T\260\021\330 *\250$\250k\270\021\270!\330 5\260T\3209K\3101\310J\320VW\360\006\000\t\014\2105\220\001\220\021\340\010\017\210q";
    PyObject *data = NULL;
    #define __Pyx_DecompressString_UNUSED
    #define __Pyx_DecompressString_LZSS_UNUSED
    #endif
    PyObject **stringtab = __pyx_mstate->__pyx_string_tab;
    Py_ssize_t pos = 0;
    for (int i = 0; i < 166; i++) {
      Py_ssize_t bytes_length = str_length_index[i].length;
      PyObject *string = PyUnicode_DecodeUTF8(bytes + pos, bytes_length, NULL);
      if (likely(string) && i >= 23) PyUnicode_InternInPlace(&string);
      if (unlikely(!string)) {
        Py_XDECREF(data);
        __PYX_ERR(0, 1, __pyx_L1_error)
      }
      stringtab[i] = string;
      pos += bytes_length;
    }
    for (int i = 166; i < 171; i++) {
      Py_ssize_t bytes_length = bytes_length_index[i-166].length;
      PyObject *string = PyBytes_FromStringAndSize(bytes + pos, bytes_length);
      stringtab[i] = string;
      pos += bytes_length;
      if (unlikely(!string)) {
        Py_XDECREF(data);
        __PYX_ERR(0, 1, __pyx_L1_error)
      }
    }
    Py_XDECREF(data);
    for (Py_ssize_t i = 0; i < 171; i++) {
      if (unlikely(PyObject_Hash(stringtab[i]) == -1)) {
        __PYX_ERR(0, 1, __pyx_L1_error)
      }
    }
    #if CYTHON_IMMORTAL_CONSTANTS
    {
      PyObject **table = stringtab + 166;
      for (Py_ssize_t i=0; i<5; ++i) {
        #if PY_VERSION_HEX >= 0x030F0000
        PyUnstable_SetImmortal(table[i]);
        #elif CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
        if ((PY_SSIZE_T_MAX <= _Py_IMMORTAL_REFCNT_LOCAL)) break;
        #if PY_VERSION_HEX < 0x030E0000
        if (_Py_IsOwnedByCurrentThread(table[i]) && Py_REFCNT(table[i]) == 1)
        #else
        if (PyUnstable_Object_IsUniquelyReferenced(table[i]))
        #endif
        {
          Py_SET_REFCNT(table[i], ((Py_ssize_t)_Py_IMMORTAL_REFCNT_LOCAL + 1));
        }
        #else
        if ((PY_SSIZE_T_MAX < _Py_IMMORTAL_INITIAL_REFCNT)) break;
        Py_SET_REFCNT(table[i], _Py_IMMORTAL_INITIAL_REFCNT);
        #endif
      }
    }
    #endif
  }
  {
    PyObject **numbertab = __pyx_mstate->__pyx_number_tab + 0;
    int8_t const cint_constants_1[] = {0,-1,1};
    for (int i = 0; i < 3; i++) {
      numbertab[i] = PyLong_FromLong(cint_constants_1[i - 0]);
      if (unlikely(!numbertab[i])) __PYX_ERR(0, 1, __pyx_L1_error)
    }
  }
  #if CYTHON_IMMORTAL_CONSTANTS
  {
    PyObject **table = __pyx_mstate->__pyx_number_tab;
    for (Py_ssize_t i=0; i<3; ++i) {
      #if PY_VERSION_HEX >= 0x030F0000
      PyUnstable_SetImmortal(table[i]);
      #elif CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
      if ((PY_SSIZE_T_MAX <= _Py_IMMORTAL_REFCNT_LOCAL)) break;
      #if PY_VERSION_HEX < 0x030E0000
      if (_Py_IsOwnedByCurrentThread(table[i]) && Py_REFCNT(table[i]) == 1)
      #else
      if (PyUnstable_Object_IsUniquelyReferenced(table[i]))
      #endif
      {
        Py_SET_REFCNT(table[i], ((Py_ssize_t)_Py_IMMORTAL_REFCNT_LOCAL + 1));
      }
      #else
      if ((PY_SSIZE_T_MAX < _Py_IMMORTAL_INITIAL_REFCNT)) break;
      Py_SET_REFCNT(table[i], _Py_IMMORTAL_INITIAL_REFCNT);
      #endif
    }
  }
  #endif
  return 0;
  __pyx_L1_error:;
  return -1;
}

#ifdef __cplusplus
namespace {
#endif
typedef struct {
    unsigned int argcount : 3;
    unsigned int num_posonly_args : 1;
    unsigned int num_kwonly_args : 1;
    unsigned int nlocals : 5;
    unsigned int flags : 10;
    unsigned int first_line : 9;
} __Pyx_PyCode_New_function_description;
#ifdef __cplusplus
} 
#endif

static PyObject* __Pyx_PyCode_New(
        const __Pyx_PyCode_New_function_description descr,
        PyObject * const *varnames,
        PyObject *filename,
        PyObject *funcname,
        PyObject *line_table,
        PyObject *tuple_dedup_map
);


static int __Pyx_CreateCodeObjects(__pyx_mstatetype *__pyx_mstate) {
  PyObject* tuple_dedup_map = PyDict_New();
  if (unlikely(!tuple_dedup_map)) return -1;
  {
    const __Pyx_PyCode_New_function_description descr = {3, 0, 0, 3, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 10};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_self, __pyx_mstate->__pyx_n_u_pattern, __pyx_mstate->__pyx_n_u_recurse};
    __pyx_mstate_global->__pyx_codeobj_tab[0] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_cloze_template_docx_py, __pyx_mstate->__pyx_n_u_init, __pyx_mstate->__pyx_kp_b_iso88591_A_7_A_1_Ba_1_AQ_Kq, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[0])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {4, 0, 0, 22, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 25};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_self, __pyx_mstate->__pyx_n_u_template_path, __pyx_mstate->__pyx_n_u_save_path, __pyx_mstate->__pyx_n_u_env, __pyx_mstate->__pyx_n_u_doc_2, __pyx_mstate->__pyx_n_u_except_placeholders, __pyx_mstate->__pyx_n_u_paragraph, __pyx_mstate->__pyx_n_u_table, __pyx_mstate->__pyx_n_u_replaced, __pyx_mstate->__pyx_n_u_i, __pyx_mstate->__pyx_n_u_row, __pyx_mstate->__pyx_n_u_j, __pyx_mstate->__pyx_n_u_cell, __pyx_mstate->__pyx_n_u_placeholders, __pyx_mstate->__pyx_n_u_placeholder, __pyx_mstate->__pyx_n_u_placeholder_2, __pyx_mstate->__pyx_n_u_is_dataframe, __pyx_mstate->__pyx_n_u_values, __pyx_mstate->__pyx_n_u__10, __pyx_mstate->__pyx_n_u_k, __pyx_mstate->__pyx_n_u_l, __pyx_mstate->__pyx_n_u_cell_2};
    __pyx_mstate_global->__pyx_codeobj_tab[1] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_cloze_template_docx_py, __pyx_mstate->__pyx_n_u_call, __pyx_mstate->__pyx_kp_b_iso88591_1_IQj_y_A_haq_4s_1_A_M_A_d_Qa_7, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[1])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {3, 0, 0, 8, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 102};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_self, __pyx_mstate->__pyx_n_u_paragraph, __pyx_mstate->__pyx_n_u_env, __pyx_mstate->__pyx_n_u_except_placeholders, __pyx_mstate->__pyx_n_u_run, __pyx_mstate->__pyx_n_u_placeholders, __pyx_mstate->__pyx_n_u_placeholder, __pyx_mstate->__pyx_n_u_placeholder_2};
    __pyx_mstate_global->__pyx_codeobj_tab[2] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_cloze_template_docx_py, __pyx_mstate->__pyx_n_u_replace_paragraph, __pyx_mstate->__pyx_kp_b_iso88591_Q_A_G9A_81D_Q_q_b_A_E_YhauTWWXX, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[2])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {2, 0, 0, 20, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 224};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_self, __pyx_mstate->__pyx_n_u_paragraph, __pyx_mstate->__pyx_n_u_forward_placeholder, __pyx_mstate->__pyx_n_u_backward_placeholder, __pyx_mstate->__pyx_n_u_forward_add, __pyx_mstate->__pyx_n_u_backward_add, __pyx_mstate->__pyx_n_u_to_be_add, __pyx_mstate->__pyx_n_u_concated, __pyx_mstate->__pyx_n_u_over, __pyx_mstate->__pyx_n_u_i, __pyx_mstate->__pyx_n_u_back, __pyx_mstate->__pyx_n_u_forward, __pyx_mstate->__pyx_n_u_i, __pyx_mstate->__pyx_n_u_run, __pyx_mstate->__pyx_n_u_i, __pyx_mstate->__pyx_n_u_run, __pyx_mstate->__pyx_n_u_i, __pyx_mstate->__pyx_n_u_j, __pyx_mstate->__pyx_n_u_i, __pyx_mstate->__pyx_n_u_j};
    __pyx_mstate_global->__pyx_codeobj_tab[3] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_cloze_template_docx_py, __pyx_mstate->__pyx_n_u_concat_run, __pyx_mstate->__pyx_kp_b_iso88591_A_3ar_j_1_ARxq_A_q_4q_A8_a_cQUU, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[3])) goto bad;
  }
  {
    const __Pyx_PyCode_New_function_description descr = {2, 0, 0, 21, (unsigned int)(CO_OPTIMIZED|CO_NEWLOCALS), 300};
    PyObject* const varnames[] = {__pyx_mstate->__pyx_n_u_cell, __pyx_mstate->__pyx_n_u_from_cell, __pyx_mstate->__pyx_n_u_src_tc, __pyx_mstate->__pyx_n_u_src_tcPr, __pyx_mstate->__pyx_n_u_src_tcBorders, __pyx_mstate->__pyx_n_u_dst_tc, __pyx_mstate->__pyx_n_u_dst_tcPr, __pyx_mstate->__pyx_n_u_dst_tcBorders, __pyx_mstate->__pyx_n_u_child, __pyx_mstate->__pyx_n_u_border, __pyx_mstate->__pyx_n_u_src_para, __pyx_mstate->__pyx_n_u_dst_para, __pyx_mstate->__pyx_n_u_src_run, __pyx_mstate->__pyx_n_u_dst_run, __pyx_mstate->__pyx_n_u_src_rFonts, __pyx_mstate->__pyx_n_u_dst_rFonts, __pyx_mstate->__pyx_n_u_attr, __pyx_mstate->__pyx_n_u_dst_rPr, __pyx_mstate->__pyx_n_u_old_rFonts, __pyx_mstate->__pyx_n_u_src_shd, __pyx_mstate->__pyx_n_u_dst_shd};
    __pyx_mstate_global->__pyx_codeobj_tab[4] = __Pyx_PyCode_New(descr, varnames, __pyx_mstate->__pyx_kp_u_cloze_template_docx_py, __pyx_mstate->__pyx_n_u_cell_format_painter, __pyx_mstate->__pyx_kp_b_iso88591_Ya_v_Q_HE_AQ_T_v_Q_HE_AQ_S_1A_q, tuple_dedup_map); if (unlikely(!__pyx_mstate_global->__pyx_codeobj_tab[4])) goto bad;
  }
  Py_DECREF(tuple_dedup_map);
  return 0;
  bad:
  Py_DECREF(tuple_dedup_map);
  return -1;
}


static int __Pyx_InitGlobals(void) {
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  
  if (likely(__Pyx_init_co_variables() == 0 && __Pyx_init_tpflags_variables() == 0)); else
  
  if (unlikely(PyErr_Occurred())) __PYX_ERR(0, 1, __pyx_L1_error)

  
  if (likely(__Pyx_init_assertions_enabled() == 0)); else
  
  if (unlikely(PyErr_Occurred())) __PYX_ERR(0, 1, __pyx_L1_error)

  
  #if CYTHON_COMPILING_IN_LIMITED_API
  {
      PyObject *builtins = PyEval_GetBuiltins(); // borrowed
      if (likely(builtins)) {
          PyObject *type_name = PyUnicode_FromStringAndSize("frozendict", sizeof("frozendict")-1);
          if (likely(type_name)) {
              PyObject *frozendict_type = PyObject_GetItem(builtins, type_name);
              Py_DECREF(type_name);
              if (!frozendict_type && PyErr_ExceptionMatches(PyExc_KeyError)) {
                  PyErr_Clear();
                  frozendict_type = (PyObject*) &PyDict_Type;
                  Py_INCREF(frozendict_type);
              }
              __pyx_mstate_global->__Pyx_PyFrozenDictType = frozendict_type;
          }
      }
  } // error handling follows
  #endif
  
  if (unlikely(PyErr_Occurred())) __PYX_ERR(0, 1, __pyx_L1_error)

  
  if (likely(__pyx_CommonTypesMetaclass_init(__pyx_m) == 0)); else
  
  if (unlikely(PyErr_Occurred())) __PYX_ERR(0, 1, __pyx_L1_error)

  
  #if CYTHON_COMPILING_IN_LIMITED_API
  {
      PyObject *typesModule=NULL;
      typesModule = PyImport_ImportModule("types");
      if (typesModule) {
          __pyx_mstate_global->__Pyx_CachedMethodType = PyObject_GetAttrString(typesModule, "MethodType");
          Py_DECREF(typesModule);
      }
  } // error handling follows
  #endif
  
  if (unlikely(PyErr_Occurred())) __PYX_ERR(0, 1, __pyx_L1_error)

  return 0;
  __pyx_L1_error:;
  return -1;
}


static int __Pyx_InitAfterSharedUtility(void) {
  int __pyx_lineno = 0;
  const char *__pyx_filename = NULL;
  int __pyx_clineno = 0;
  
  if (likely(__pyx_CyFunction_init(__pyx_m) == 0)); else
  
  if (unlikely(PyErr_Occurred())) __PYX_ERR(0, 1, __pyx_L1_error)

  return 0;
  __pyx_L1_error:;
  return -1;
}




#ifdef _MSC_VER
#pragma warning( push )

#pragma warning( disable : 4127 )
#endif







#if CYTHON_REFNANNY
static __Pyx_RefNannyAPIStruct *__Pyx_RefNannyImportAPI(const char *modname) {
    PyObject *m = NULL, *p = NULL;
    void *r = NULL;
    m = PyImport_ImportModule(modname);
    if (!m) goto end;
    p = PyObject_GetAttrString(m, "RefNannyAPI");
    if (!p) goto end;
    r = PyLong_AsVoidPtr(p);
end:
    Py_XDECREF(p);
    Py_XDECREF(m);
    return (__Pyx_RefNannyAPIStruct *)r;
}
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static int __Pyx_InBases(PyTypeObject *a, PyTypeObject *b) {
    while (a) {
        a = __Pyx_PyType_GetSlot(a, tp_base, PyTypeObject*);
        if (a == b)
            return 1;
    }
    return b == &PyBaseObject_Type;
}
static CYTHON_INLINE int __Pyx_IsSubtype(PyTypeObject *a, PyTypeObject *b) {
    PyObject *mro;
    if (a == b) return 1;
    mro = a->tp_mro;
    if (likely(mro)) {
        Py_ssize_t i, n;
        n = PyTuple_GET_SIZE(mro);
        for (i = 0; i < n; i++) {
            if (PyTuple_GET_ITEM(mro, i) == (PyObject *)b)
                return 1;
        }
        return 0;
    }
    return __Pyx_InBases(a, b);
}
static CYTHON_INLINE int __Pyx_IsAnySubtype2(PyTypeObject *cls, PyTypeObject *a, PyTypeObject *b) {
    PyObject *mro;
    if (cls == a || cls == b) return 1;
    mro = cls->tp_mro;
    if (likely(mro)) {
        Py_ssize_t i, n;
        n = PyTuple_GET_SIZE(mro);
        for (i = 0; i < n; i++) {
            PyObject *base = PyTuple_GET_ITEM(mro, i);
            if (base == (PyObject *)a || base == (PyObject *)b)
                return 1;
        }
        return 0;
    }
    return __Pyx_InBases(cls, a) || __Pyx_InBases(cls, b);
}
#endif


#if CYTHON_FAST_THREAD_STATE
static CYTHON_INLINE void __Pyx_ErrRestoreInState(PyThreadState *tstate, PyObject *type, PyObject *value, PyObject *tb) {
#if PY_VERSION_HEX >= 0x030C00A6
    PyObject *tmp_value;
    assert(type == NULL || (value != NULL && type == (PyObject*) Py_TYPE(value)));
    if (value) {
        #if CYTHON_COMPILING_IN_CPYTHON
        if (unlikely(((PyBaseExceptionObject*) value)->traceback != tb))
        #endif
            PyException_SetTraceback(value, tb);
    }
    tmp_value = tstate->current_exception;
    tstate->current_exception = value;
    Py_XDECREF(tmp_value);
    Py_XDECREF(type);
    Py_XDECREF(tb);
#else
    PyObject *tmp_type, *tmp_value, *tmp_tb;
    tmp_type = tstate->curexc_type;
    tmp_value = tstate->curexc_value;
    tmp_tb = tstate->curexc_traceback;
    tstate->curexc_type = type;
    tstate->curexc_value = value;
    tstate->curexc_traceback = tb;
    Py_XDECREF(tmp_type);
    Py_XDECREF(tmp_value);
    Py_XDECREF(tmp_tb);
#endif
}
static CYTHON_INLINE void __Pyx_ErrFetchInState(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb) {
#if PY_VERSION_HEX >= 0x030C00A6
    PyObject* exc_value;
    exc_value = tstate->current_exception;
    tstate->current_exception = 0;
    *value = exc_value;
    *type = NULL;
    *tb = NULL;
    if (exc_value) {
        *type = (PyObject*) Py_TYPE(exc_value);
        Py_INCREF(*type);
        #if CYTHON_COMPILING_IN_CPYTHON
        *tb = ((PyBaseExceptionObject*) exc_value)->traceback;
        Py_XINCREF(*tb);
        #else
        *tb = PyException_GetTraceback(exc_value);
        #endif
    }
#else
    *type = tstate->curexc_type;
    *value = tstate->curexc_value;
    *tb = tstate->curexc_traceback;
    tstate->curexc_type = 0;
    tstate->curexc_value = 0;
    tstate->curexc_traceback = 0;
#endif
}
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE int __Pyx_inner_PyErr_GivenExceptionMatches2(PyObject *err, PyObject* exc_type1, PyObject *exc_type2) {
    if (exc_type1) {
        return __Pyx_IsAnySubtype2((PyTypeObject*)err, (PyTypeObject*)exc_type1, (PyTypeObject*)exc_type2);
    } else {
        return __Pyx_IsSubtype((PyTypeObject*)err, (PyTypeObject*)exc_type2);
    }
}
static int __Pyx_PyErr_GivenExceptionMatchesTuple(PyObject *exc_type, PyObject *tuple) {
    Py_ssize_t i, n;
    assert(PyExceptionClass_Check(exc_type));
    n = PyTuple_GET_SIZE(tuple);
    for (i=0; i<n; i++) {
        if (exc_type == PyTuple_GET_ITEM(tuple, i)) return 1;
    }
    for (i=0; i<n; i++) {
        PyObject *t = PyTuple_GET_ITEM(tuple, i);
        if (likely(PyExceptionClass_Check(t))) {
            if (__Pyx_inner_PyErr_GivenExceptionMatches2(exc_type, NULL, t)) return 1;
        } else {
        }
    }
    return 0;
}
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches(PyObject *err, PyObject* exc_type) {
    if (likely(err == exc_type)) return 1;
    if (likely(PyExceptionClass_Check(err))) {
        if (likely(PyExceptionClass_Check(exc_type))) {
            return __Pyx_inner_PyErr_GivenExceptionMatches2(err, NULL, exc_type);
        } else if (likely(PyTuple_Check(exc_type))) {
            return __Pyx_PyErr_GivenExceptionMatchesTuple(err, exc_type);
        } else {
        }
    }
    return PyErr_GivenExceptionMatches(err, exc_type);
}
static CYTHON_INLINE int __Pyx_PyErr_GivenExceptionMatches2(PyObject *err, PyObject *exc_type1, PyObject *exc_type2) {
    assert(PyExceptionClass_Check(exc_type1));
    assert(PyExceptionClass_Check(exc_type2));
    if (likely(err == exc_type1 || err == exc_type2)) return 1;
    if (likely(PyExceptionClass_Check(err))) {
        return __Pyx_inner_PyErr_GivenExceptionMatches2(err, exc_type1, exc_type2);
    }
    return (PyErr_GivenExceptionMatches(err, exc_type1) || PyErr_GivenExceptionMatches(err, exc_type2));
}
#endif


#if CYTHON_FAST_THREAD_STATE
static int __Pyx_PyErr_ExceptionMatchesTuple(PyObject *exc_type, PyObject *tuple) {
    Py_ssize_t i, n;
    n = PyTuple_GET_SIZE(tuple);
    for (i=0; i<n; i++) {
        if (exc_type == PyTuple_GET_ITEM(tuple, i)) return 1;
    }
    for (i=0; i<n; i++) {
        if (__Pyx_PyErr_GivenExceptionMatches(exc_type, PyTuple_GET_ITEM(tuple, i))) return 1;
    }
    return 0;
}
static CYTHON_INLINE int __Pyx_PyErr_ExceptionMatchesInState(PyThreadState* tstate, PyObject* err) {
    int result;
    PyObject *exc_type;
#if PY_VERSION_HEX >= 0x030C00A6
    PyObject *current_exception = tstate->current_exception;
    if (unlikely(!current_exception)) return 0;
    exc_type = (PyObject*) Py_TYPE(current_exception);
    if (exc_type == err) return 1;
#else
    exc_type = tstate->curexc_type;
    if (exc_type == err) return 1;
    if (unlikely(!exc_type)) return 0;
#endif
    #if CYTHON_AVOID_BORROWED_REFS
    Py_INCREF(exc_type);
    #endif
    if (unlikely(PyTuple_Check(err))) {
        result = __Pyx_PyErr_ExceptionMatchesTuple(exc_type, err);
    } else {
        result = __Pyx_PyErr_GivenExceptionMatches(exc_type, err);
    }
    #if CYTHON_AVOID_BORROWED_REFS
    Py_DECREF(exc_type);
    #endif
    return result;
}
#endif


#if CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE PyObject* __Pyx_PyObject_GetAttrStr(PyObject* obj, PyObject* attr_name) {
    PyTypeObject* tp = Py_TYPE(obj);
    if (likely(tp->tp_getattro))
        return tp->tp_getattro(obj, attr_name);
    return PyObject_GetAttr(obj, attr_name);
}
#endif


#if __PYX_LIMITED_VERSION_HEX < 0x030d0000
static void __Pyx_PyObject_GetAttrStr_ClearAttributeError(void) {
    __Pyx_PyThreadState_declare
    __Pyx_PyThreadState_assign
    if (likely(__Pyx_PyErr_ExceptionMatches(PyExc_AttributeError)))
        __Pyx_PyErr_Clear();
}
#endif
static CYTHON_INLINE PyObject* __Pyx_PyObject_GetAttrStrNoError(PyObject* obj, PyObject* attr_name) {
    PyObject *result;
#if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
    (void) PyObject_GetOptionalAttr(obj, attr_name, &result);
    return result;
#else
#if CYTHON_COMPILING_IN_CPYTHON && CYTHON_USE_TYPE_SLOTS
    PyTypeObject* tp = Py_TYPE(obj);
    if (likely(tp->tp_getattro == PyObject_GenericGetAttr)) {
        return _PyObject_GenericGetAttrWithDict(obj, attr_name, NULL, 1);
    }
#endif
    result = __Pyx_PyObject_GetAttrStr(obj, attr_name);
    if (unlikely(!result)) {
        __Pyx_PyObject_GetAttrStr_ClearAttributeError();
    }
    return result;
#endif
}


static PyObject *__Pyx_GetBuiltinName(PyObject *name) {
    PyObject* result = __Pyx_PyObject_GetAttrStrNoError(__pyx_mstate_global->__pyx_b, name);
    if (unlikely(!result) && !PyErr_Occurred()) {
        PyErr_Format(PyExc_NameError,
            "name '%U' is not defined", name);
    }
    return result;
}


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE void __Pyx_copy_object_array(PyObject *const *CYTHON_RESTRICT src, PyObject** CYTHON_RESTRICT dest, Py_ssize_t length) {
    PyObject *v;
    Py_ssize_t i;
    for (i = 0; i < length; i++) {
        v = dest[i] = src[i];
        Py_INCREF(v);
    }
}
#endif


#if !(PY_VERSION_HEX >= 0x030F0000 && !CYTHON_COMPILING_IN_LIMITED_API)
CYTHON_UNUSED static PyObject *
__Pyx_PyTuple_FromArray(PyObject *const *src, Py_ssize_t n) {
    if (n <= 0) {
        return __Pyx_NewRef(__pyx_mstate_global->__pyx_empty_tuple);
    }
    PyObject *res = PyTuple_New(n);
    if (unlikely(res == NULL)) return NULL;
    #if CYTHON_COMPILING_IN_CPYTHON
    __Pyx_copy_object_array(src, ((PyTupleObject*)res)->ob_item, n);
    #else
    Py_ssize_t i;
    for (i = 0; i < n; i++) {
        Py_INCREF(src[i]);
        if (unlikely(__Pyx_PyTuple_SET_ITEM(res, i, src[i]) < (0))) {
            Py_DECREF(res);
            return NULL;
        }
    }
    #endif
    return res;
}
#endif


#ifndef __Pyx_DEFINED_PyObject_CompareStrStrBoolEq
#define __Pyx_DEFINED_PyObject_CompareStrStrBoolEq
static CYTHON_INLINE int __Pyx_PyObject_CompareStrStrBoolEq(PyObject* s1, PyObject* s2) {
    #if __PYX_LIMITED_VERSION_HEX >= 0x030e0000
    int result = PyUnicode_Equal(s1, s2);
    #if !CYTHON_COMPILING_IN_CPYTHON
    if (unlikely(result == -1)) return -1;
    #endif
    if (result == 0) goto __pyx_return_false; else goto __pyx_return_true;
    #else
    int result = PyUnicode_Compare(s1, s2);
    if (unlikely((result == -1) && PyErr_Occurred())) return -1;
    if (result == 0) goto __pyx_return_true; else goto __pyx_return_false;
    #endif
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
static CYTHON_INLINE int __Pyx_PyObject_CompareBoolEq_str_str(PyObject *op1, PyObject *op2, int pyop) {
    CYTHON_UNUSED_VAR(pyop);
    if (unlikely(op1 == Py_None)) {
        if (op2 == Py_None) goto __pyx_return_true; else goto __pyx_return_false;
    }
    if (unlikely(op2 == Py_None)) {
        if (op1 == Py_None) goto __pyx_return_true; else goto __pyx_return_false;
    }
    
    if (likely(op1 != Py_None)) {
        if (op1 == op2) goto __pyx_return_true;
        if (likely(op2 != Py_None)) {
            return __Pyx_PyObject_CompareStrStrBoolEq(op1, op2);
        }
        goto __pyx_richcmp;
    }
    
    if ((0)) goto __pyx_richcmp;
    if ((0)) goto __pyx_return_true;
    if ((0)) goto __pyx_return_false;
__pyx_richcmp:
    return __Pyx_PyObject_RichCompareBool(op1, op2, Py_EQ);
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}


#if CYTHON_VECTORCALL
static CYTHON_INLINE PyObject * __Pyx_GetKwValue_FASTCALL(PyObject *kwnames, PyObject *const *kwvalues, PyObject *s)
{
    Py_ssize_t i, n = __Pyx_PyTuple_GET_SIZE(kwnames);
    #if !CYTHON_ASSUME_SAFE_SIZE
    if (unlikely(n == -1)) return NULL;
    #endif
    for (i = 0; i < n; i++)
    {
        PyObject *namei = __Pyx_PyTuple_GET_ITEM(kwnames, i);
        #if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely(!namei)) return NULL;
        #endif
        if (s == namei) return kwvalues[i];
    }
    for (i = 0; i < n; i++)
    {
        PyObject *namei = __Pyx_PyTuple_GET_ITEM(kwnames, i);
        #if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely(!namei)) return NULL;
        #endif
        int eq = __Pyx_PyUnicode_Equals(s, namei);
        if (unlikely(eq != 0)) {
            if (unlikely(eq < 0)) return NULL;
            return kwvalues[i];
        }
    }
    return NULL;
}
#if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030d0000 || CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL
CYTHON_UNUSED static PyObject *__Pyx_KwargsAsDict_FASTCALL(PyObject *kwnames, PyObject *const *kwvalues) {
    Py_ssize_t i, nkwargs;
    PyObject *dict;
#if !CYTHON_ASSUME_SAFE_SIZE
    nkwargs = PyTuple_Size(kwnames);
    if (unlikely(nkwargs < 0)) return NULL;
#else
    nkwargs = PyTuple_GET_SIZE(kwnames);
#endif
    dict = PyDict_New();
    if (unlikely(!dict))
        return NULL;
    for (i=0; i<nkwargs; i++) {
#if !CYTHON_ASSUME_SAFE_MACROS
        PyObject *key = PyTuple_GetItem(kwnames, i);
        if (!key) goto bad;
#else
        PyObject *key = PyTuple_GET_ITEM(kwnames, i);
#endif
        if (unlikely(PyDict_SetItem(dict, key, kwvalues[i]) < 0))
            goto bad;
    }
    return dict;
bad:
    Py_DECREF(dict);
    return NULL;
}
#endif
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyObject_Call(PyObject *func, PyObject *arg, PyObject *kw) {
    PyObject *result;
    ternaryfunc call = Py_TYPE(func)->tp_call;
    if (unlikely(!call))
        return PyObject_Call(func, arg, kw);
    if (unlikely(Py_EnterRecursiveCall(" while calling a Python object")))
        return NULL;
    result = (*call)(func, arg, kw);
    Py_LeaveRecursiveCall();
    if (unlikely(!result) && unlikely(!PyErr_Occurred())) {
        PyErr_SetString(
            PyExc_SystemError,
            "NULL result without error in PyObject_Call");
    }
    return result;
}
#endif


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_PyObject_CallMethO(PyObject *func, PyObject *arg) {
    PyObject *self, *result;
    PyCFunction cfunc;
    cfunc = __Pyx_CyOrPyCFunction_GET_FUNCTION(func);
    self = __Pyx_CyOrPyCFunction_GET_SELF(func);
    if (unlikely(Py_EnterRecursiveCall(" while calling a Python object")))
        return NULL;
    result = cfunc(self, arg);
    Py_LeaveRecursiveCall();
    if (unlikely(!result) && unlikely(!PyErr_Occurred())) {
        PyErr_SetString(
            PyExc_SystemError,
            "NULL result without error in PyObject_Call");
    }
    return result;
}
#endif


#if CYTHON_COMPILING_IN_LIMITED_API
static PyObject* __Pyx_PyObject_FastCall_fallback(PyObject *func, PyObject * const*args, size_t nargs, PyObject *kwargs) {
    PyObject *argstuple;
    PyObject *result = 0;
    size_t i;
    argstuple = PyTuple_New((Py_ssize_t)nargs);
    if (unlikely(!argstuple)) return NULL;
    for (i = 0; i < nargs; i++) {
        Py_INCREF(args[i]);
        if (__Pyx_PyTuple_SET_ITEM(argstuple, (Py_ssize_t)i, args[i]) != (0)) goto bad;
    }
    result = __Pyx_PyObject_Call(func, argstuple, kwargs);
  bad:
    Py_DECREF(argstuple);
    return result;
}
#endif
#if CYTHON_VECTORCALL && !(CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY)
  #if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE vectorcallfunc __Pyx_PyVectorcall_Function(PyObject *callable) {
    PyTypeObject *tp = Py_TYPE(callable);
    #if defined(__Pyx_CyFunction_USED)
    if (__Pyx_CyFunction_CheckExact(callable)) {
        return __Pyx_CyFunction_func_vectorcall(callable);
    }
    #endif
    if (!PyType_HasFeature(tp, Py_TPFLAGS_HAVE_VECTORCALL)) {
        return NULL;
    }
    assert(PyCallable_Check(callable));
    Py_ssize_t offset = tp->tp_vectorcall_offset;
    assert(offset > 0);
    vectorcallfunc ptr;
    memcpy(&ptr, (char *) callable + offset, sizeof(ptr));
    return ptr;
}
  #else
    #define __Pyx_PyVectorcall_Function(callable) PyVectorcall_Function(callable)
  #endif
#endif
static CYTHON_INLINE PyObject* __Pyx_PyObject_FastCallDict(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwargs) {
    Py_ssize_t nargs = __Pyx_PyVectorcall_NARGS(nargsf);
#if CYTHON_COMPILING_IN_CPYTHON
    if (nargs == 0 && kwargs == NULL) {
        if (__Pyx_CyOrPyCFunction_Check(func) && likely( __Pyx_CyOrPyCFunction_GET_FLAGS(func) & METH_NOARGS))
            return __Pyx_PyObject_CallMethO(func, NULL);
    }
    else if (nargs == 1 && kwargs == NULL) {
        if (__Pyx_CyOrPyCFunction_Check(func) && likely( __Pyx_CyOrPyCFunction_GET_FLAGS(func) & METH_O))
            return __Pyx_PyObject_CallMethO(func, args[0]);
    }
#endif
    if (kwargs == NULL) {
        #if CYTHON_VECTORCALL
          #if CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY
            return PyObject_Vectorcall(func, args, nargsf, NULL);
          #else
            vectorcallfunc f = __Pyx_PyVectorcall_Function(func);
            if (f) {
                return f(func, args, nargsf, NULL);
            }
          #endif
        #endif
    }
    if (nargs == 0) {
        return __Pyx_PyObject_Call(func, __pyx_mstate_global->__pyx_empty_tuple, kwargs);
    }
    #if CYTHON_COMPILING_IN_LIMITED_API
    return __Pyx_PyObject_FastCall_fallback(func, args, (size_t)nargs, kwargs);
    #elif CYTHON_COMPILING_IN_PYPY
    return PyObject_VectorcallDict(func, args, (size_t) nargs, kwargs);
    #else
    return PyObject_VectorcallDict(func, args, nargsf, kwargs);
    #endif
}


static CYTHON_INLINE PyObject* __Pyx_PyObject_CallOneArg(PyObject *func, PyObject *arg) {
    PyObject *args[2] = {NULL, arg};
    return __Pyx_PyObject_FastCall(func, args+1, 1 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET);
}


static CYTHON_INLINE int __Pyx_IgnoreGivenException(PyObject *given_exception, PyObject *ignorable_exception) {
    if (PyErr_GivenExceptionMatches(given_exception ? given_exception : PyErr_Occurred(), ignorable_exception)) {
        PyErr_Clear();
        return 1;
    }
    return 0;
}


#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030C0000
static PyObject *__Pyx_SelflessCall(PyObject *method, PyObject *args, PyObject *kwargs) {
    PyObject *result;
    PyObject *selfless_args = PyTuple_GetSlice(args, 1, PyTuple_Size(args));
    if (unlikely(!selfless_args)) return NULL;
    result = PyObject_Call(method, selfless_args, kwargs);
    Py_DECREF(selfless_args);
    return result;
}
#else
static PyObject *__Pyx_SelflessCall(PyObject *method, PyObject *const *args, Py_ssize_t nargs, PyObject *kwnames) {
    return PyObject_Vectorcall(method, args ? args+1 : NULL, nargs ? (size_t) nargs-1 : 0, kwnames);
}
#endif
static PyMethodDef __Pyx_UnboundCMethod_Def = {
     "CythonUnboundCMethod",
     __PYX_REINTERPRET_FUNCION(PyCFunction, __Pyx_SelflessCall),
#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030C0000
     METH_VARARGS | METH_KEYWORDS,
#else
     METH_FASTCALL | METH_KEYWORDS,
#endif
     NULL
};
static int __Pyx_TryUnpackUnboundCMethod(__Pyx_CachedCFunction* target) {
    PyObject *method, *result=NULL;
    method = __Pyx_PyObject_GetAttrStr(target->type, *target->method_name);
    if (unlikely(!method))
        return -1;
    result = method;
#if CYTHON_COMPILING_IN_CPYTHON
    if (likely(__Pyx_TypeCheck(method, &PyMethodDescr_Type)))
    {
        PyMethodDescrObject *descr = (PyMethodDescrObject*) method;
        target->func = descr->d_method->ml_meth;
        target->flag = descr->d_method->ml_flags & ~(METH_CLASS | METH_STATIC | METH_COEXIST);
    } else
#endif
#if CYTHON_COMPILING_IN_PYPY
#else
    if (PyCFunction_Check(method))
#endif
    {
        PyObject *self;
        int self_found;
#if CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY
        self = PyObject_GetAttrString(method, "__self__");
        if (!self && !__Pyx_IgnoreException(PyExc_AttributeError)) {
            return -1;
        }
#else
        self = PyCFunction_GET_SELF(method);
#endif
        self_found = (self && self != Py_None);
#if CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY
        Py_XDECREF(self);
#endif
        if (self_found) {
            PyObject *unbound_method = PyCFunction_New(&__Pyx_UnboundCMethod_Def, method);
            if (unlikely(!unbound_method)) return -1;
            Py_DECREF(method);
            result = unbound_method;
        }
    }
#if !CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    if (unlikely(target->method)) {
        Py_DECREF(result);
    } else
#endif
    target->method = result;
    return 0;
}


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject* __Pyx_CallUnboundCMethod0(__Pyx_CachedCFunction* cfunc, PyObject* self) {
    int was_initialized = __Pyx_CachedCFunction_GetAndSetInitializing(cfunc);
    if (likely(was_initialized == 2 && cfunc->func)) {
        if (likely(cfunc->flag == METH_NOARGS))
            return __Pyx_CallCFunction(cfunc, self, NULL);
        if (likely(cfunc->flag == METH_FASTCALL))
            return __Pyx_CallCFunctionFast(cfunc, self, NULL, 0);
        if (cfunc->flag == (METH_FASTCALL | METH_KEYWORDS))
            return __Pyx_CallCFunctionFastWithKeywords(cfunc, self, NULL, 0, NULL);
        if (likely(cfunc->flag == (METH_VARARGS | METH_KEYWORDS)))
            return __Pyx_CallCFunctionWithKeywords(cfunc, self, __pyx_mstate_global->__pyx_empty_tuple, NULL);
        if (cfunc->flag == METH_VARARGS)
            return __Pyx_CallCFunction(cfunc, self, __pyx_mstate_global->__pyx_empty_tuple);
        return __Pyx__CallUnboundCMethod0(cfunc, self);
    }
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    else if (unlikely(was_initialized == 1)) {
        __Pyx_CachedCFunction tmp_cfunc = {
#ifndef __cplusplus
            0
#endif
        };
        tmp_cfunc.type = cfunc->type;
        tmp_cfunc.method_name = cfunc->method_name;
        return __Pyx__CallUnboundCMethod0(&tmp_cfunc, self);
    }
#endif
    PyObject *result = __Pyx__CallUnboundCMethod0(cfunc, self);
    __Pyx_CachedCFunction_SetFinishedInitializing(cfunc);
    return result;
}
#endif
static PyObject* __Pyx__CallUnboundCMethod0(__Pyx_CachedCFunction* cfunc, PyObject* self) {
    PyObject *result;
    if (unlikely(!cfunc->method) && unlikely(__Pyx_TryUnpackUnboundCMethod(cfunc) < 0)) return NULL;
    result = __Pyx_PyObject_CallOneArg(cfunc->method, self);
    return result;
}


static CYTHON_INLINE PyObject* __Pyx_PyDict_Items(PyObject* d) {
    return __Pyx_CallUnboundCMethod0(&__pyx_mstate_global->__pyx_umethod_PyDict_Type_items, d);
}


static CYTHON_INLINE PyObject* __Pyx_PyDict_Values(PyObject* d) {
    return __Pyx_CallUnboundCMethod0(&__pyx_mstate_global->__pyx_umethod_PyDict_Type_values, d);
}


#if CYTHON_AVOID_BORROWED_REFS
static int __Pyx_PyDict_NextRef(PyObject *p, PyObject **ppos, PyObject **pkey, PyObject **pvalue) {
    PyObject *next = NULL;
    if (!*ppos) {
        if (pvalue) {
            PyObject *dictview = pkey ? __Pyx_PyDict_Items(p) : __Pyx_PyDict_Values(p);
            if (unlikely(!dictview)) goto bad;
            *ppos = PyObject_GetIter(dictview);
            Py_DECREF(dictview);
        } else {
            *ppos = PyObject_GetIter(p);
        }
        if (unlikely(!*ppos)) goto bad;
    }
    next = PyIter_Next(*ppos);
    if (!next) {
        if (PyErr_Occurred()) goto bad;
        return 0;
    }
    if (pkey && pvalue) {
        *pkey = __Pyx_PySequence_ITEM(next, 0);
        if (unlikely(*pkey)) goto bad;
        *pvalue = __Pyx_PySequence_ITEM(next, 1);
        if (unlikely(*pvalue)) goto bad;
        Py_DECREF(next);
    } else if (pkey) {
        *pkey = next;
    } else {
        assert(pvalue);
        *pvalue = next;
    }
    return 1;
  bad:
    Py_XDECREF(next);
#if !CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX >= 0x030d0000
    PyErr_FormatUnraisable("Exception ignored in __Pyx_PyDict_NextRef");
#else
    PyErr_WriteUnraisable(__pyx_mstate_global->__pyx_n_u_Pyx_PyDict_NextRef);
#endif
    if (pkey) *pkey = NULL;
    if (pvalue) *pvalue = NULL;
    return 0;
}
#else // !CYTHON_AVOID_BORROWED_REFS
static int __Pyx_PyDict_NextRef(PyObject *p, Py_ssize_t *ppos, PyObject **pkey, PyObject **pvalue) {
    int result = PyDict_Next(p, ppos, pkey, pvalue);
    if (likely(result == 1)) {
        if (pkey) Py_INCREF(*pkey);
        if (pvalue) Py_INCREF(*pvalue);
    }
    return result;
}
#endif


static void __Pyx_RaiseDoubleKeywordsError(
    const char* func_name,
    PyObject* kw_name)
{
    PyErr_Format(PyExc_TypeError,
        "%s() got multiple values for keyword argument '%U'", func_name, kw_name);
}


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE PyObject *__Pyx_CallUnboundCMethod2(__Pyx_CachedCFunction *cfunc, PyObject *self, PyObject *arg1, PyObject *arg2) {
    int was_initialized = __Pyx_CachedCFunction_GetAndSetInitializing(cfunc);
    if (likely(was_initialized == 2 && cfunc->func)) {
        PyObject *args[2] = {arg1, arg2};
        if (cfunc->flag == METH_FASTCALL) {
            return __Pyx_CallCFunctionFast(cfunc, self, args, 2);
        }
        if (cfunc->flag == (METH_FASTCALL | METH_KEYWORDS))
            return __Pyx_CallCFunctionFastWithKeywords(cfunc, self, args, 2, NULL);
    }
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    else if (unlikely(was_initialized == 1)) {
        __Pyx_CachedCFunction tmp_cfunc = {
#ifndef __cplusplus
            0
#endif
        };
        tmp_cfunc.type = cfunc->type;
        tmp_cfunc.method_name = cfunc->method_name;
        return __Pyx__CallUnboundCMethod2(&tmp_cfunc, self, arg1, arg2);
    }
#endif
    PyObject *result = __Pyx__CallUnboundCMethod2(cfunc, self, arg1, arg2);
    __Pyx_CachedCFunction_SetFinishedInitializing(cfunc);
    return result;
}
#endif
static PyObject* __Pyx__CallUnboundCMethod2(__Pyx_CachedCFunction* cfunc, PyObject* self, PyObject* arg1, PyObject* arg2){
    if (unlikely(!cfunc->func && !cfunc->method) && unlikely(__Pyx_TryUnpackUnboundCMethod(cfunc) < 0)) return NULL;
#if CYTHON_COMPILING_IN_CPYTHON
    if (cfunc->func && (cfunc->flag & METH_VARARGS)) {
        PyObject *result = NULL;
        PyObject *args = PyTuple_New(2);
        if (unlikely(!args)) return NULL;
        Py_INCREF(arg1);
        PyTuple_SET_ITEM(args, 0, arg1);
        Py_INCREF(arg2);
        PyTuple_SET_ITEM(args, 1, arg2);
        if (cfunc->flag & METH_KEYWORDS)
            result = __Pyx_CallCFunctionWithKeywords(cfunc, self, args, NULL);
        else
            result = __Pyx_CallCFunction(cfunc, self, args);
        Py_DECREF(args);
        return result;
    }
#endif
    {
        PyObject *args[4] = {NULL, self, arg1, arg2};
        return __Pyx_PyObject_FastCall(cfunc->method, args+1, 3 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET);
    }
}


static int __Pyx_ValidateDuplicatePosArgs(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    const char* function_name)
{
    PyObject ** const *name = argnames;
    while (name != first_kw_arg) {
        PyObject *key = **name;
        int found = PyDict_Contains(kwds, key);
        if (unlikely(found)) {
            if (found == 1) __Pyx_RaiseDoubleKeywordsError(function_name, key);
            goto bad;
        }
        name++;
    }
    return 0;
bad:
    return -1;
}
#if CYTHON_USE_UNICODE_INTERNALS
static CYTHON_INLINE int __Pyx_UnicodeKeywordsEqual(PyObject *s1, PyObject *s2) {
    int kind;
    Py_ssize_t len = PyUnicode_GET_LENGTH(s1);
    if (len != PyUnicode_GET_LENGTH(s2)) return 0;
    kind = PyUnicode_KIND(s1);
    if (kind != PyUnicode_KIND(s2)) return 0;
    const void *data1 = PyUnicode_DATA(s1);
    const void *data2 = PyUnicode_DATA(s2);
    return (memcmp(data1, data2, (size_t) len * (size_t) kind) == 0);
}
#endif
static int __Pyx_MatchKeywordArg_str(
    PyObject *key,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    size_t *index_found,
    const char *function_name)
{
    PyObject ** const *name;
    #if CYTHON_USE_UNICODE_INTERNALS
    Py_hash_t key_hash = ((PyASCIIObject*)key)->hash;
    if (unlikely(key_hash == -1)) {
        key_hash = PyObject_Hash(key);
        if (unlikely(key_hash == -1))
            goto bad;
    }
    #endif
    name = first_kw_arg;
    while (*name) {
        PyObject *name_str = **name;
        #if CYTHON_USE_UNICODE_INTERNALS
        if (key_hash == ((PyASCIIObject*)name_str)->hash && __Pyx_UnicodeKeywordsEqual(name_str, key)) {
            *index_found = (size_t) (name - argnames);
            return 1;
        }
        #else
        #if CYTHON_ASSUME_SAFE_SIZE
        if (PyUnicode_GET_LENGTH(name_str) == PyUnicode_GET_LENGTH(key))
        #endif
        {
            int cmp = PyUnicode_Compare(name_str, key);
            if (cmp < 0 && unlikely(PyErr_Occurred())) goto bad;
            if (cmp == 0) {
                *index_found = (size_t) (name - argnames);
                return 1;
            }
        }
        #endif
        name++;
    }
    name = argnames;
    while (name != first_kw_arg) {
        PyObject *name_str = **name;
        #if CYTHON_USE_UNICODE_INTERNALS
        if (unlikely(key_hash == ((PyASCIIObject*)name_str)->hash)) {
            if (__Pyx_UnicodeKeywordsEqual(name_str, key))
                goto arg_passed_twice;
        }
        #else
        #if CYTHON_ASSUME_SAFE_SIZE
        if (PyUnicode_GET_LENGTH(name_str) == PyUnicode_GET_LENGTH(key))
        #endif
        {
            if (unlikely(name_str == key)) goto arg_passed_twice;
            int cmp = PyUnicode_Compare(name_str, key);
            if (cmp < 0 && unlikely(PyErr_Occurred())) goto bad;
            if (cmp == 0) goto arg_passed_twice;
        }
        #endif
        name++;
    }
    return 0;
arg_passed_twice:
    __Pyx_RaiseDoubleKeywordsError(function_name, key);
    goto bad;
bad:
    return -1;
}
static int __Pyx_MatchKeywordArg_nostr(
    PyObject *key,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    size_t *index_found,
    const char *function_name)
{
    PyObject ** const *name;
    if (unlikely(!PyUnicode_Check(key))) goto invalid_keyword_type;
    name = first_kw_arg;
    while (*name) {
        int cmp = PyObject_RichCompareBool(**name, key, Py_EQ);
        if (cmp == 1) {
            *index_found = (size_t) (name - argnames);
            return 1;
        }
        if (unlikely(cmp == -1)) goto bad;
        name++;
    }
    name = argnames;
    while (name != first_kw_arg) {
        int cmp = PyObject_RichCompareBool(**name, key, Py_EQ);
        if (unlikely(cmp != 0)) {
            if (cmp == 1) goto arg_passed_twice;
            else goto bad;
        }
        name++;
    }
    return 0;
arg_passed_twice:
    __Pyx_RaiseDoubleKeywordsError(function_name, key);
    goto bad;
invalid_keyword_type:
    PyErr_Format(PyExc_TypeError,
        "%.200s() keywords must be strings", function_name);
    goto bad;
bad:
    return -1;
}
static CYTHON_INLINE int __Pyx_MatchKeywordArg(
    PyObject *key,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    size_t *index_found,
    const char *function_name)
{
    return likely(PyUnicode_CheckExact(key)) ?
        __Pyx_MatchKeywordArg_str(key, argnames, first_kw_arg, index_found, function_name) :
        __Pyx_MatchKeywordArg_nostr(key, argnames, first_kw_arg, index_found, function_name);
}
static void __Pyx_RejectUnknownKeyword(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject ** const *first_kw_arg,
    const char *function_name)
{
    #if CYTHON_AVOID_BORROWED_REFS
    PyObject *pos = NULL;
    #else
    Py_ssize_t pos = 0;
    #endif
    PyObject *key = NULL;
    __Pyx_BEGIN_CRITICAL_SECTION(kwds);
    #if CYTHON_AVOID_BORROWED_REFS
    while (__Pyx_PyDict_NextRef(kwds, &pos, &key, NULL))
    #else
    (void) __Pyx_PyDict_NextRef;
    while (PyDict_Next(kwds, &pos, &key, NULL))
    #endif
    {
        PyObject** const *name = first_kw_arg;
        while (*name && (**name != key)) name++;
        if (!*name) {
            size_t index_found = 0;
            int cmp = __Pyx_MatchKeywordArg(key, argnames, first_kw_arg, &index_found, function_name);
            if (cmp != 1) {
                if (cmp == 0) {
                    PyErr_Format(PyExc_TypeError,
                        "%s() got an unexpected keyword argument '%U'",
                        function_name, key);
                }
                #if CYTHON_AVOID_BORROWED_REFS
                Py_DECREF(key);
                #endif
                break;
            }
        }
        #if CYTHON_AVOID_BORROWED_REFS
        Py_DECREF(key);
        #endif
    }
    __Pyx_END_CRITICAL_SECTION();
    #if CYTHON_AVOID_BORROWED_REFS
    Py_XDECREF(pos);
    #endif
    assert(PyErr_Occurred());
}
static int __Pyx_ParseKeywordDict(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject *values[],
    Py_ssize_t num_pos_args,
    Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs)
{
    PyObject** const *name;
    PyObject** const *first_kw_arg = argnames + num_pos_args;
    Py_ssize_t extracted = 0;
#if !CYTHON_COMPILING_IN_PYPY || defined(PyArg_ValidateKeywordArguments)
    if (unlikely(!PyArg_ValidateKeywordArguments(kwds))) return -1;
#endif
    name = first_kw_arg;
    while (*name && num_kwargs > extracted) {
        PyObject * key = **name;
        PyObject *value;
        int found = 0;
        #if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
        found = PyDict_GetItemRef(kwds, key, &value);
        #else
        value = PyDict_GetItemWithError(kwds, key);
        if (value) {
            Py_INCREF(value);
            found = 1;
        } else {
            if (unlikely(PyErr_Occurred())) goto bad;
        }
        #endif
        if (found) {
            if (unlikely(found < 0)) goto bad;
            values[name-argnames] = value;
            extracted++;
        }
        name++;
    }
    if (num_kwargs > extracted) {
        if (ignore_unknown_kwargs) {
            if (unlikely(__Pyx_ValidateDuplicatePosArgs(kwds, argnames, first_kw_arg, function_name) == -1))
                goto bad;
        } else {
            __Pyx_RejectUnknownKeyword(kwds, argnames, first_kw_arg, function_name);
            goto bad;
        }
    }
    return 0;
bad:
    return -1;
}
static int __Pyx_ParseKeywordDictToDict(
    PyObject *kwds,
    PyObject ** const argnames[],
    PyObject *kwds2,
    PyObject *values[],
    Py_ssize_t num_pos_args,
    const char* function_name)
{
    PyObject** const *name;
    PyObject** const *first_kw_arg = argnames + num_pos_args;
    Py_ssize_t len;
#if !CYTHON_COMPILING_IN_PYPY || defined(PyArg_ValidateKeywordArguments)
    if (unlikely(!PyArg_ValidateKeywordArguments(kwds))) return -1;
#endif
    if (PyDict_Update(kwds2, kwds) < 0) goto bad;
    name = first_kw_arg;
    while (*name) {
        PyObject *key = **name;
        PyObject *value;
#if !CYTHON_COMPILING_IN_LIMITED_API && (PY_VERSION_HEX >= 0x030d00A2 || defined(PyDict_Pop))
        int found = PyDict_Pop(kwds2, key, &value);
        if (found) {
            if (unlikely(found < 0)) goto bad;
            values[name-argnames] = value;
        }
#elif __PYX_LIMITED_VERSION_HEX >= 0x030d0000
        int found = PyDict_GetItemRef(kwds2, key, &value);
        if (found) {
            if (unlikely(found < 0)) goto bad;
            values[name-argnames] = value;
            if (unlikely(PyDict_DelItem(kwds2, key) < 0)) goto bad;
        }
#else
    #if CYTHON_COMPILING_IN_CPYTHON
        value = _PyDict_Pop(kwds2, key, kwds2);
    #else
        value = __Pyx_CallUnboundCMethod2(&__pyx_mstate_global->__pyx_umethod_PyDict_Type_pop, kwds2, key, kwds2);
    #endif
        if (value == kwds2) {
            Py_DECREF(value);
        } else {
            if (unlikely(!value)) goto bad;
            values[name-argnames] = value;
        }
#endif
        name++;
    }
    len = PyDict_Size(kwds2);
    if (len > 0) {
        return __Pyx_ValidateDuplicatePosArgs(kwds, argnames, first_kw_arg, function_name);
    } else if (unlikely(len == -1)) {
        goto bad;
    }
    return 0;
bad:
    return -1;
}
static int __Pyx_ParseKeywordsTuple(
    PyObject *kwds,
    PyObject * const *kwvalues,
    PyObject ** const argnames[],
    PyObject *kwds2,
    PyObject *values[],
    Py_ssize_t num_pos_args,
    Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs)
{
    PyObject *key = NULL;
    PyObject** const * name;
    PyObject** const *first_kw_arg = argnames + num_pos_args;
    for (Py_ssize_t pos = 0; pos < num_kwargs; pos++) {
#if CYTHON_AVOID_BORROWED_REFS
        key = __Pyx_PySequence_ITEM(kwds, pos);
#else
        key = __Pyx_PyTuple_GET_ITEM(kwds, pos);
#endif
#if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely(!key)) goto bad;
#endif
        name = first_kw_arg;
        while (*name && (**name != key)) name++;
        if (*name) {
            PyObject *value = kwvalues[pos];
            values[name-argnames] = __Pyx_NewRef(value);
        } else {
            size_t index_found = 0;
            int cmp = __Pyx_MatchKeywordArg(key, argnames, first_kw_arg, &index_found, function_name);
            if (cmp == 1) {
                PyObject *value = kwvalues[pos];
                values[index_found] = __Pyx_NewRef(value);
            } else {
                if (unlikely(cmp == -1)) goto bad;
                if (kwds2) {
                    PyObject *value = kwvalues[pos];
                    if (unlikely(PyDict_SetItem(kwds2, key, value))) goto bad;
                } else if (!ignore_unknown_kwargs) {
                    goto invalid_keyword;
                }
            }
        }
        #if CYTHON_AVOID_BORROWED_REFS
        Py_DECREF(key);
        key = NULL;
        #endif
    }
    return 0;
invalid_keyword:
    PyErr_Format(PyExc_TypeError,
        "%s() got an unexpected keyword argument '%U'",
        function_name, key);
    goto bad;
bad:
    #if CYTHON_AVOID_BORROWED_REFS
    Py_XDECREF(key);
    #endif
    return -1;
}


static int __Pyx_ParseKeywords(
    PyObject *kwds,
    PyObject * const *kwvalues,
    PyObject ** const argnames[],
    PyObject *kwds2,
    PyObject *values[],
    Py_ssize_t num_pos_args,
    Py_ssize_t num_kwargs,
    const char* function_name,
    int ignore_unknown_kwargs)
{
    if (CYTHON_VECTORCALL && likely(PyTuple_Check(kwds)))
        return __Pyx_ParseKeywordsTuple(kwds, kwvalues, argnames, kwds2, values, num_pos_args, num_kwargs, function_name, ignore_unknown_kwargs);
    else if (kwds2)
        return __Pyx_ParseKeywordDictToDict(kwds, argnames, kwds2, values, num_pos_args, function_name);
    else
        return __Pyx_ParseKeywordDict(kwds, argnames, values, num_pos_args, num_kwargs, function_name, ignore_unknown_kwargs);
}


static void __Pyx_RaiseArgtupleInvalid(
    const char* func_name,
    int exact,
    Py_ssize_t num_min,
    Py_ssize_t num_max,
    Py_ssize_t num_found)
{
    Py_ssize_t num_expected;
    const char *more_or_less;
    if (num_found < num_min) {
        num_expected = num_min;
        more_or_less = "at least";
    } else {
        num_expected = num_max;
        more_or_less = "at most";
    }
    if (exact) {
        more_or_less = "exactly";
    }
    PyErr_Format(PyExc_TypeError,
                 "%.200s() takes %.8s %" CYTHON_FORMAT_SSIZE_T "d positional argument%.1s (%" CYTHON_FORMAT_SSIZE_T "d given)",
                 func_name, more_or_less, num_expected,
                 (num_expected == 1) ? "" : "s", num_found);
}


#ifndef __Pyx_DEFINED_PyObject_CompareStrStrBoolEq
#define __Pyx_DEFINED_PyObject_CompareStrStrBoolEq
static CYTHON_INLINE int __Pyx_PyObject_CompareStrStrBoolEq(PyObject* s1, PyObject* s2) {
    #if __PYX_LIMITED_VERSION_HEX >= 0x030e0000
    int result = PyUnicode_Equal(s1, s2);
    #if !CYTHON_COMPILING_IN_CPYTHON
    if (unlikely(result == -1)) return -1;
    #endif
    if (result == 0) goto __pyx_return_false; else goto __pyx_return_true;
    #else
    int result = PyUnicode_Compare(s1, s2);
    if (unlikely((result == -1) && PyErr_Occurred())) return -1;
    if (result == 0) goto __pyx_return_true; else goto __pyx_return_false;
    #endif
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
static CYTHON_INLINE int __Pyx_PyObject_CompareBoolEq_object_str(PyObject *op1, PyObject *op2, int pyop) {
    CYTHON_UNUSED_VAR(pyop);
    if (unlikely(op2 == Py_None)) {
        if (op1 == Py_None) goto __pyx_return_true; else goto __pyx_richcmp;
    }
    if (PyFloat_CheckExact(op1)) {
        goto __pyx_richcmp;
    }
    if (PyLong_CheckExact(op1)) {
        if (op1 == op2) goto __pyx_return_true;
        goto __pyx_richcmp;
    }
    
    if (likely(PyUnicode_CheckExact(op1))) {
        if (op1 == op2) goto __pyx_return_true;
        if (likely(op2 != Py_None)) {
            return __Pyx_PyObject_CompareStrStrBoolEq(op1, op2);
        }
        goto __pyx_richcmp;
    }
    
    if ((0)) goto __pyx_richcmp;
    if ((0)) goto __pyx_return_true;
    if ((0)) goto __pyx_return_false;
__pyx_richcmp:
    return __Pyx_PyObject_RichCompareBool(op1, op2, Py_EQ);
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}


#if CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE int __Pyx_PyObject_SetAttrStr(PyObject* obj, PyObject* attr_name, PyObject* value) {
    PyTypeObject* tp = Py_TYPE(obj);
    if (likely(tp->tp_setattro))
        return tp->tp_setattro(obj, attr_name, value);
    return PyObject_SetAttr(obj, attr_name, value);
}
#endif


static void __Pyx_Raise(PyObject *type, PyObject *value, PyObject *tb, PyObject *cause) {
    PyObject* owned_instance = NULL;
    if (tb == Py_None) {
        tb = 0;
    } else if (tb && !PyTraceBack_Check(tb)) {
        PyErr_SetString(PyExc_TypeError,
            "raise: arg 3 must be a traceback or None");
        goto bad;
    }
    if (value == Py_None)
        value = 0;
    if (PyExceptionInstance_Check(type)) {
        if (value) {
            PyErr_SetString(PyExc_TypeError,
                "instance exception may not have a separate value");
            goto bad;
        }
        value = type;
        type = (PyObject*) Py_TYPE(value);
    } else if (PyExceptionClass_Check(type)) {
        PyObject *instance_class = NULL;
        if (value && PyExceptionInstance_Check(value)) {
            instance_class = (PyObject*) Py_TYPE(value);
            if (instance_class != type) {
                int is_subclass = PyObject_IsSubclass(instance_class, type);
                if (!is_subclass) {
                    instance_class = NULL;
                } else if (unlikely(is_subclass == -1)) {
                    goto bad;
                } else {
                    type = instance_class;
                }
            }
        }
        if (!instance_class) {
            PyObject *args;
            if (!value)
                args = PyTuple_New(0);
            else if (PyTuple_Check(value)) {
                Py_INCREF(value);
                args = value;
            } else
                args = PyTuple_Pack(1, value);
            if (!args)
                goto bad;
            owned_instance = PyObject_Call(type, args, NULL);
            Py_DECREF(args);
            if (!owned_instance)
                goto bad;
            value = owned_instance;
            if (!PyExceptionInstance_Check(value)) {
                PyErr_Format(PyExc_TypeError,
                             "calling %R should have returned an instance of "
                             "BaseException, not %R",
                             type, Py_TYPE(value));
                goto bad;
            }
        }
    } else {
        PyErr_SetString(PyExc_TypeError,
            "raise: exception class must be a subclass of BaseException");
        goto bad;
    }
    if (cause) {
        PyObject *fixed_cause;
        if (cause == Py_None) {
            fixed_cause = NULL;
        } else if (PyExceptionClass_Check(cause)) {
            fixed_cause = PyObject_CallObject(cause, NULL);
            if (fixed_cause == NULL)
                goto bad;
        } else if (PyExceptionInstance_Check(cause)) {
            fixed_cause = cause;
            Py_INCREF(fixed_cause);
        } else {
            PyErr_SetString(PyExc_TypeError,
                            "exception causes must derive from "
                            "BaseException");
            goto bad;
        }
        PyException_SetCause(value, fixed_cause);
    }
    PyErr_SetObject(type, value);
    if (tb) {
#if PY_VERSION_HEX >= 0x030C00A6
        PyException_SetTraceback(value, tb);
#elif CYTHON_FAST_THREAD_STATE
        PyThreadState *tstate = __Pyx_PyThreadState_Current;
        PyObject* tmp_tb = tstate->curexc_traceback;
        if (tb != tmp_tb) {
            Py_INCREF(tb);
            tstate->curexc_traceback = tb;
            Py_XDECREF(tmp_tb);
        }
#else
        PyObject *tmp_type, *tmp_value, *tmp_tb;
        PyErr_Fetch(&tmp_type, &tmp_value, &tmp_tb);
        Py_INCREF(tb);
        PyErr_Restore(tmp_type, tmp_value, tb);
        Py_XDECREF(tmp_tb);
#endif
    }
bad:
    Py_XDECREF(owned_instance);
    return;
}


#if !CYTHON_VECTORCALL
static PyObject *__Pyx_PyObject_FastCallMethod(PyObject *name, PyObject *const *args, size_t nargsf) {
    PyObject *result;
    switch (__Pyx_PyVectorcall_NARGS(nargsf)) {
        case 1:
            return PyObject_CallMethodObjArgs(args[0], name, NULL);
        case 2:
            return PyObject_CallMethodObjArgs(args[0], name, args[1], NULL);
        case 3:
            return PyObject_CallMethodObjArgs(args[0], name, args[1], args[2], NULL);
        case 4:
            return PyObject_CallMethodObjArgs(args[0], name, args[1], args[2], args[3], NULL);
        case 5:
            return PyObject_CallMethodObjArgs(args[0], name, args[1], args[2], args[3], args[4], NULL);
    }
    PyObject *attr = PyObject_GetAttr(args[0], name);
    if (unlikely(!attr))
        return NULL;
    result = __Pyx_PyObject_FastCall(attr, args+1, nargsf - 1);
    Py_DECREF(attr);
    return result;
}
#endif


#if CYTHON_USE_DICT_VERSIONS && CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE PY_UINT64_T __Pyx_get_tp_dict_version(PyObject *obj) {
    PyObject *dict = Py_TYPE(obj)->tp_dict;
    return likely(dict) ? __PYX_GET_DICT_VERSION(dict) : 0;
}
static CYTHON_INLINE PY_UINT64_T __Pyx_get_object_dict_version(PyObject *obj) {
    PyObject **dictptr = NULL;
    Py_ssize_t offset = Py_TYPE(obj)->tp_dictoffset;
    if (offset) {
#if CYTHON_COMPILING_IN_CPYTHON
        dictptr = (likely(offset > 0)) ? (PyObject **) ((char *)obj + offset) : _PyObject_GetDictPtr(obj);
#else
        dictptr = _PyObject_GetDictPtr(obj);
#endif
    }
    return (dictptr && *dictptr) ? __PYX_GET_DICT_VERSION(*dictptr) : 0;
}
static CYTHON_INLINE int __Pyx_object_dict_version_matches(PyObject* obj, PY_UINT64_T tp_dict_version, PY_UINT64_T obj_dict_version) {
    PyObject *dict = Py_TYPE(obj)->tp_dict;
    if (unlikely(!dict) || unlikely(tp_dict_version != __PYX_GET_DICT_VERSION(dict)))
        return 0;
    return obj_dict_version == __Pyx_get_object_dict_version(obj);
}
#endif


#if CYTHON_USE_DICT_VERSIONS
static PyObject *__Pyx__GetModuleGlobalName(PyObject *name, PY_UINT64_T *dict_version, PyObject **dict_cached_value)
#else
static CYTHON_INLINE PyObject *__Pyx__GetModuleGlobalName(PyObject *name)
#endif
{
    PyObject *result;
#if CYTHON_COMPILING_IN_LIMITED_API
    if (unlikely(!__pyx_m)) {
        if (!PyErr_Occurred())
            PyErr_SetNone(PyExc_NameError);
        return NULL;
    }
    result = PyObject_GetAttr(__pyx_m, name);
    if (likely(result)) {
        return result;
    }
    if (!__Pyx_IgnoreException(PyExc_Exception)) {
        return NULL; // BaseException
    }
#elif CYTHON_AVOID_BORROWED_REFS || CYTHON_AVOID_THREAD_UNSAFE_BORROWED_REFS
    if (unlikely(__Pyx_PyDict_GetItemRef(__pyx_mstate_global->__pyx_d, name, &result) == -1)) {
        if (!__Pyx_IgnoreException(PyExc_Exception)) {
            return NULL; // BaseException
        }
    }
    __PYX_UPDATE_DICT_CACHE(__pyx_mstate_global->__pyx_d, result, *dict_cached_value, *dict_version)
    if (likely(result)) {
        return result;
    }
#else
    result = _PyDict_GetItem_KnownHash(__pyx_mstate_global->__pyx_d, name, ((PyASCIIObject *) name)->hash);
    __PYX_UPDATE_DICT_CACHE(__pyx_mstate_global->__pyx_d, result, *dict_cached_value, *dict_version)
    if (likely(result)) {
        return __Pyx_NewRef(result);
    }
    PyObject *exc = PyErr_Occurred();
    if (unlikely(exc) && !__Pyx_IgnoreGivenException(exc, PyExc_Exception)) {
        return NULL; // BaseException
    }
#endif
    return __Pyx_GetBuiltinName(name);
}


#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030d0000
static __Pyx_TypeName
__Pyx_PyType_GetFullyQualifiedName(PyTypeObject* tp)
{
    PyObject *module = NULL, *name = NULL, *result = NULL;
    #if __PYX_LIMITED_VERSION_HEX < 0x030b0000
    name = __Pyx_PyObject_GetAttrStr((PyObject *)tp,
                                               __pyx_mstate_global->__pyx_n_u_qualname);
    #else
    name = PyType_GetQualName(tp);
    #endif
    if (unlikely(name == NULL) || unlikely(!PyUnicode_Check(name))) goto bad;
    module = __Pyx_PyObject_GetAttrStr((PyObject *)tp,
                                               __pyx_mstate_global->__pyx_n_u_module);
    if (unlikely(module == NULL) || unlikely(!PyUnicode_Check(module))) goto bad;
    if (PyUnicode_CompareWithASCIIString(module, "builtins") == 0) {
        result = name;
        name = NULL;
        goto done;
    }
    result = PyUnicode_FromFormat("%U.%U", module, name);
    if (unlikely(result == NULL)) goto bad;
  done:
    Py_XDECREF(name);
    Py_XDECREF(module);
    return result;
  bad:
    PyErr_Clear();
    if (name) {
        result = name;
        name = NULL;
    } else {
        result = __Pyx_NewRef(__pyx_mstate_global->__pyx_kp_u__5);
    }
    goto done;
}
#endif


static void __Pyx_RaiseErrorWithTypes1(PyObject* exc_type, const char *message, const char *arg, PyTypeObject *type_obj1, PyTypeObject *type_obj2) {
    __Pyx_TypeName type_name1 = __Pyx_PyType_GetFullyQualifiedName(type_obj1);
    #if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030d0000
    if (unlikely(!type_name1)) return;
    #endif
    __Pyx_TypeName type_name2 = __Pyx_PyType_GetFullyQualifiedName(type_obj2);
    #if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030d0000
    if (unlikely(!type_name2)) goto type2_failed;
    #endif
    PyErr_Format(exc_type, message, arg, type_name1, type_name2);
    __Pyx_DECREF_TypeName(type_name2);
#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030d0000
type2_failed:
#endif
    __Pyx_DECREF_TypeName(type_name1);
}


#if !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL || CYTHON_COMPILING_IN_LIMITED_API)
#if CYTHON_USE_TYPE_SLOTS || __PYX_LIMITED_VERSION_HEX >= 0x030A0000
#ifndef __Pyx_DEFINED_BinopTypeError
#define __Pyx_DEFINED_BinopTypeError
static void __Pyx_BinopTypeError(PyObject *op1, PyObject *op2, const char* op, int inplace) {
    char opname[4] = {op[0], op[1], 0, 0};
    if (inplace) {
        opname[op[1] ? 2 : 1] = '=';
    }
    __Pyx_RaiseErrorWithObjectTypes1(
        PyExc_TypeError,
        "unsupported operand type(s) for %.3s: '" __Pyx_FMT_TYPENAME "' and '" __Pyx_FMT_TYPENAME "'",
        opname, op1, op2);
}
#endif
#endif
#ifndef __Pyx_DEFINED_PyNumber_Add_xfloat_object
#define __Pyx_DEFINED_PyNumber_Add_xfloat_object
static PyObject* __Pyx_PyNumber_Add_xfloat_object(PyObject *op1, PyObject *op2, int inplace) {
    if (PyLong_CheckExact(op2)) {
        double int_op2;
        #if CYTHON_USE_PYLONG_INTERNALS
        if (__Pyx_PyLong_IsCompact(op2)) {
            Py_ssize_t compact_op2 = __Pyx_PyLong_CompactValue(op2);
            if (compact_op2 == 0) return __Pyx_NewRef(op1);
            int_op2 = (double) compact_op2;
        } else
        #endif
        {
            int_op2 = PyLong_AsDouble(op2);
            if (unlikely((int_op2 == -1.) && PyErr_Occurred())) return NULL;
            #if !CYTHON_USE_PYLONG_INTERNALS
            if (int_op2 == 0.) return __Pyx_NewRef(op1);
            #endif
        }
        double float_op1 = __Pyx_PyFloat_AS_DOUBLE(op1);
        #if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely((float_op1 == -1.) && PyErr_Occurred())) return NULL;
        #endif
        return PyFloat_FromDouble(float_op1 + int_op2);
    }
    if (PyLong_Check(op2)) {
        binaryfunc slot_func = __Pyx_PyType_GetSubSlot(&PyFloat_Type, tp_as_number, nb_add, binaryfunc);
        if (likely(slot_func)) {
            return slot_func(op1, op2);
        }
    }
    #if CYTHON_USE_TYPE_SLOTS || __PYX_LIMITED_VERSION_HEX >= 0x030A0000
    {
        PyTypeObject *type_op2 = Py_TYPE(op2);
        binaryfunc slot_func = __Pyx_PyType_GetSubSlot(type_op2, tp_as_number, nb_add, binaryfunc);
        if (likely(slot_func)) {
            PyObject *result = slot_func(op1, op2);
            if (likely(result != Py_NotImplemented)) {
                return result;
            }
            Py_DECREF(result);
        }
        __Pyx_BinopTypeError(op1, op2, "+", inplace);
        return NULL;
    }
    #else
    return (inplace) ? PyNumber_InPlaceAdd(op1, op2) : PyNumber_Add(op1, op2);
    #endif
}
#endif
#ifndef __Pyx_DEFINED_PyNumber_Add_xint_object
#define __Pyx_DEFINED_PyNumber_Add_xint_object
static PyObject* __Pyx_PyNumber_Add_xint_object(PyObject *op1, PyObject *op2, int inplace) {
    if (PyFloat_CheckExact(op2)) {
        double int_op1;
        #if CYTHON_USE_PYLONG_INTERNALS
        if (__Pyx_PyLong_IsCompact(op1)) {
            Py_ssize_t compact_op1 = __Pyx_PyLong_CompactValue(op1);
            if (compact_op1 == 0) return __Pyx_NewRef(op2);
            int_op1 = (double) compact_op1;
        } else
        #endif
        {
            int_op1 = PyLong_AsDouble(op1);
            if (unlikely((int_op1 == -1.) && PyErr_Occurred())) return NULL;
            #if !CYTHON_USE_PYLONG_INTERNALS
            if (int_op1 == 0.) return __Pyx_NewRef(op2);
            #endif
        }
        double float_op2 = __Pyx_PyFloat_AS_DOUBLE(op2);
        #if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely((float_op2 == -1.) && PyErr_Occurred())) return NULL;
        #endif
        return PyFloat_FromDouble(int_op1 + float_op2);
    }
    #if CYTHON_USE_TYPE_SLOTS || __PYX_LIMITED_VERSION_HEX >= 0x030A0000
    {
        PyTypeObject *type_op2 = Py_TYPE(op2);
        binaryfunc slot_func = __Pyx_PyType_GetSubSlot(type_op2, tp_as_number, nb_add, binaryfunc);
        if (likely(slot_func)) {
            PyObject *result = slot_func(op1, op2);
            if (likely(result != Py_NotImplemented)) {
                return result;
            }
            Py_DECREF(result);
        }
        __Pyx_BinopTypeError(op1, op2, "+", inplace);
        return NULL;
    }
    #else
    return (inplace) ? PyNumber_InPlaceAdd(op1, op2) : PyNumber_Add(op1, op2);
    #endif
}
#endif
static CYTHON_INLINE PyObject* __Pyx__PyNumber_Add_object_object(PyObject *op1, PyObject *op2, int inplace) {
    if (PyFloat_CheckExact(op1)) {
        if (PyFloat_CheckExact(op2)) {
            double float_op2 = __Pyx_PyFloat_AS_DOUBLE(op2);
            #if !CYTHON_ASSUME_SAFE_MACROS
            if (unlikely((float_op2 == -1.) && PyErr_Occurred())) return NULL;
            #endif
            double float_op1 = __Pyx_PyFloat_AS_DOUBLE(op1);
            #if !CYTHON_ASSUME_SAFE_MACROS
            if (unlikely((float_op1 == -1.) && PyErr_Occurred())) return NULL;
            #endif
            return PyFloat_FromDouble(float_op1 + float_op2);
        }
        return __Pyx_PyNumber_Add_xfloat_object(op1, op2, inplace);
    }
    if (PyLong_CheckExact(op1)) {
        if (PyLong_CheckExact(op2)) {
            #if CYTHON_USE_PYLONG_INTERNALS
            if (__Pyx_PyLong_IsCompact(op1)) {
                Py_ssize_t int_op1 = __Pyx_PyLong_CompactValue(op1);
                if (int_op1 == 0) return __Pyx_NewRef(op2);
                if (__Pyx_PyLong_IsCompact(op2)) {
                    Py_ssize_t int_op2 = __Pyx_PyLong_CompactValue(op2);
                    if (int_op2 == 0) return __Pyx_NewRef(op1);
                    return PyLong_FromSsize_t(int_op1 + int_op2);
                }
            }
            else if (__Pyx_PyLong_IsZero(op2)) return __Pyx_NewRef(op1);
            #endif
            binaryfunc slot_func = __Pyx_PyType_GetSubSlot(&PyLong_Type, tp_as_number, nb_add, binaryfunc);
            if (likely(slot_func)) {
                return slot_func(op1, op2);
            }
        }
        return __Pyx_PyNumber_Add_xint_object(op1, op2, inplace);
    }
    return (inplace) ? PyNumber_InPlaceAdd(op1, op2) : PyNumber_Add(op1, op2);
}
#endif


#if !CYTHON_COMPILING_IN_PYPY
static PyObject* __Pyx_Fallback___Pyx_PyLong_AddObjC(PyObject *op1, PyObject *op2, int inplace) {
    return (inplace ? PyNumber_InPlaceAdd : PyNumber_Add)(op1, op2);
}
#if CYTHON_USE_PYLONG_INTERNALS
static PyObject* __Pyx_Unpacked___Pyx_PyLong_AddObjC(PyObject *op1, PyObject *op2, long intval, int inplace, int zerodivision_check) {
    CYTHON_MAYBE_UNUSED_VAR(inplace);
    CYTHON_UNUSED_VAR(zerodivision_check);
    const long b = intval;
    long a;
    const PY_LONG_LONG llb = intval;
    PY_LONG_LONG lla;
    if (unlikely(__Pyx_PyLong_IsZero(op1))) {
        return __Pyx_NewRef(op2);
    }
    const int is_positive = __Pyx_PyLong_IsPos(op1);
    const digit* digits = __Pyx_PyLong_Digits(op1);
    const Py_ssize_t size = __Pyx_PyLong_DigitCount(op1);
    if (likely(size == 1)) {
        a = (long) digits[0];
        if (!is_positive) a *= -1;
    } else {
        if (size == 2 && 8 * sizeof(long) - 1 > 2 * PyLong_SHIFT) {
            a = (long) (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
            if (!is_positive) a *= -1;
            goto calculate_long;
        } else if (size == 2 && 8 * sizeof(PY_LONG_LONG) - 1 > 2 * PyLong_SHIFT) {
            lla = (PY_LONG_LONG) (((((unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
            if (!is_positive) lla *= -1;
            goto calculate_long_long;
        } else
        if (size == 3 && 8 * sizeof(long) - 1 > 3 * PyLong_SHIFT) {
            a = (long) (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
            if (!is_positive) a *= -1;
            goto calculate_long;
        } else if (size == 3 && 8 * sizeof(PY_LONG_LONG) - 1 > 3 * PyLong_SHIFT) {
            lla = (PY_LONG_LONG) (((((((unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
            if (!is_positive) lla *= -1;
            goto calculate_long_long;
        } else
        if (size == 4 && 8 * sizeof(long) - 1 > 4 * PyLong_SHIFT) {
            a = (long) (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
            if (!is_positive) a *= -1;
            goto calculate_long;
        } else if (size == 4 && 8 * sizeof(PY_LONG_LONG) - 1 > 4 * PyLong_SHIFT) {
            lla = (PY_LONG_LONG) (((((((((unsigned PY_LONG_LONG)digits[3]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[2]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[1]) << PyLong_SHIFT) | (unsigned PY_LONG_LONG)digits[0]));
            if (!is_positive) lla *= -1;
            goto calculate_long_long;
        } else
        {}
        return PyLong_Type.tp_as_number->nb_add(op1, op2);
    }
    calculate_long:
        {
            long x;
            x = a + b;
            return PyLong_FromLong(x);
        }
    calculate_long_long:
        {
            PY_LONG_LONG llx;
            llx = lla + llb;
            return PyLong_FromLongLong(llx);
        }
    
}
#endif
static PyObject* __Pyx_Float___Pyx_PyLong_AddObjC(PyObject *float_val, long intval, int zerodivision_check) {
    CYTHON_UNUSED_VAR(zerodivision_check);
    const long b = intval;
    double a = __Pyx_PyFloat_AS_DOUBLE(float_val);
        double result;
        
        result = ((double)a) + (double)b;
        return PyFloat_FromDouble(result);
}
static CYTHON_INLINE PyObject* __Pyx_PyLong_AddObjC(PyObject *op1, PyObject *op2, long intval, int inplace, int zerodivision_check) {
    CYTHON_MAYBE_UNUSED_VAR(intval);
    CYTHON_UNUSED_VAR(zerodivision_check);
    #if CYTHON_USE_PYLONG_INTERNALS
    if (likely(PyLong_CheckExact(op1))) {
        return __Pyx_Unpacked___Pyx_PyLong_AddObjC(op1, op2, intval, inplace, zerodivision_check);
    }
    #endif
    if (PyFloat_CheckExact(op1)) {
        return __Pyx_Float___Pyx_PyLong_AddObjC(op1, intval, zerodivision_check);
    }
    return __Pyx_Fallback___Pyx_PyLong_AddObjC(op1, op2, inplace);
}
#endif


#ifndef __Pyx_DEFINED_PyObject_CompareStrStrBoolEq
#define __Pyx_DEFINED_PyObject_CompareStrStrBoolEq
static CYTHON_INLINE int __Pyx_PyObject_CompareStrStrBoolEq(PyObject* s1, PyObject* s2) {
    #if __PYX_LIMITED_VERSION_HEX >= 0x030e0000
    int result = PyUnicode_Equal(s1, s2);
    #if !CYTHON_COMPILING_IN_CPYTHON
    if (unlikely(result == -1)) return -1;
    #endif
    if (result == 0) goto __pyx_return_false; else goto __pyx_return_true;
    #else
    int result = PyUnicode_Compare(s1, s2);
    if (unlikely((result == -1) && PyErr_Occurred())) return -1;
    if (result == 0) goto __pyx_return_true; else goto __pyx_return_false;
    #endif
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
#if !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL)
#ifndef __Pyx_DEFINED_PyObject_ComparePyBytesPyBytesBoolEq
#define __Pyx_DEFINED_PyObject_ComparePyBytesPyBytesBoolEq
static CYTHON_INLINE int __Pyx_PyObject_ComparePyBytesPyBytesBoolEq(PyObject* s1, PyObject* s2) {
    #if CYTHON_ASSUME_SAFE_SIZE && CYTHON_ASSUME_SAFE_MACROS
    const char *ps1, *ps2;
    Py_ssize_t length = PyBytes_GET_SIZE(s1);
    if (length != PyBytes_GET_SIZE(s2)) goto __pyx_return_false;
    ps1 = PyBytes_AS_STRING(s1);
    ps2 = PyBytes_AS_STRING(s2);
    #else
    char *ps1, *ps2;
    Py_ssize_t length, length2;
    if (unlikely(PyBytes_AsStringAndSize(s1, &ps1, &length) == -1)) return -1;
    if (unlikely(PyBytes_AsStringAndSize(s2, &ps2, &length2) == -1)) return -1;
    if (length != length2) goto __pyx_return_false;
    #endif
    if (ps1[0] != ps2[0]) goto __pyx_return_false;
    if (length == 1) goto __pyx_return_true;
    {
        int cmp;
#if CYTHON_USE_UNICODE_INTERNALS && (PY_VERSION_HEX < 0x030B0000)
        Py_hash_t hash1 = ((PyBytesObject*)s1)->ob_shash;
        Py_hash_t hash2 = ((PyBytesObject*)s2)->ob_shash;
        if (hash1 != hash2 && hash1 != -1 && hash2 != -1) goto __pyx_return_false;
#endif
        cmp = memcmp(ps1, ps2, (size_t)length);
        if (cmp == 0) goto __pyx_return_true; else goto __pyx_return_false;
    }
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
#endif
#if !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL)
#ifndef __Pyx_DEFINED_PyObject_ComparePyBytesPyByteArrayBoolEq
#define __Pyx_DEFINED_PyObject_ComparePyBytesPyByteArrayBoolEq
static CYTHON_INLINE int __Pyx_PyObject_ComparePyBytesPyByteArrayBoolEq(PyObject* s1, PyObject* s2) {
    #if CYTHON_ASSUME_SAFE_SIZE && CYTHON_ASSUME_SAFE_MACROS
    const char *ps1, *ps2;
    Py_ssize_t length = PyBytes_GET_SIZE(s1);
    if (length != PyByteArray_GET_SIZE(s2)) goto __pyx_return_false;
    ps1 = PyBytes_AS_STRING(s1);
    ps2 = PyByteArray_AS_STRING(s2);
    #else
    char *ps1, *ps2;
    Py_ssize_t length, length2;
    if (unlikely(PyBytes_AsStringAndSize(s1, &ps1, &length) == -1)) return -1;
    ps2 = __Pyx_PyByteArray_AsString(s2); if (unlikely(!ps2)) return -1;
    length2 = __Pyx_PyByteArray_GET_SIZE(s2); if (unlikely(length2 == -1)) return -1;
    if (length != length2) goto __pyx_return_false;
    #endif
    if (ps1[0] != ps2[0]) goto __pyx_return_false;
    if (length == 1) goto __pyx_return_true;
    {
        int cmp;
        cmp = memcmp(ps1, ps2, (size_t)length);
        if (cmp == 0) goto __pyx_return_true; else goto __pyx_return_false;
    }
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
#endif
#if !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL)
#ifndef __Pyx_DEFINED_PyObject_ComparePyByteArrayPyBytesBoolEq
#define __Pyx_DEFINED_PyObject_ComparePyByteArrayPyBytesBoolEq
static CYTHON_INLINE int __Pyx_PyObject_ComparePyByteArrayPyBytesBoolEq(PyObject* s1, PyObject* s2) {
    #if CYTHON_ASSUME_SAFE_SIZE && CYTHON_ASSUME_SAFE_MACROS
    const char *ps1, *ps2;
    Py_ssize_t length = PyByteArray_GET_SIZE(s1);
    if (length != PyBytes_GET_SIZE(s2)) goto __pyx_return_false;
    ps1 = PyByteArray_AS_STRING(s1);
    ps2 = PyBytes_AS_STRING(s2);
    #else
    char *ps1, *ps2;
    Py_ssize_t length, length2;
    ps1 = __Pyx_PyByteArray_AsString(s1); if (unlikely(!ps1)) return -1;
    length = __Pyx_PyByteArray_GET_SIZE(s1); if (unlikely(length == -1)) return -1;
    if (unlikely(PyBytes_AsStringAndSize(s2, &ps2, &length2) == -1)) return -1;
    if (length != length2) goto __pyx_return_false;
    #endif
    if (length == 0) goto __pyx_return_true;
    if (ps1[0] != ps2[0]) goto __pyx_return_false;
    if (length == 1) goto __pyx_return_true;
    {
        int cmp;
        cmp = memcmp(ps1, ps2, (size_t)length);
        if (cmp == 0) goto __pyx_return_true; else goto __pyx_return_false;
    }
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
#endif
#if !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL)
#ifndef __Pyx_DEFINED_PyObject_ComparePyByteArrayPyByteArrayBoolEq
#define __Pyx_DEFINED_PyObject_ComparePyByteArrayPyByteArrayBoolEq
static CYTHON_INLINE int __Pyx_PyObject_ComparePyByteArrayPyByteArrayBoolEq(PyObject* s1, PyObject* s2) {
    #if CYTHON_ASSUME_SAFE_SIZE && CYTHON_ASSUME_SAFE_MACROS
    const char *ps1, *ps2;
    Py_ssize_t length = PyByteArray_GET_SIZE(s1);
    if (length != PyByteArray_GET_SIZE(s2)) goto __pyx_return_false;
    ps1 = PyByteArray_AS_STRING(s1);
    ps2 = PyByteArray_AS_STRING(s2);
    #else
    char *ps1, *ps2;
    Py_ssize_t length, length2;
    ps1 = __Pyx_PyByteArray_AsString(s1); if (unlikely(!ps1)) return -1;
    length = __Pyx_PyByteArray_GET_SIZE(s1); if (unlikely(length == -1)) return -1;
    ps2 = __Pyx_PyByteArray_AsString(s2); if (unlikely(!ps2)) return -1;
    length2 = __Pyx_PyByteArray_GET_SIZE(s2); if (unlikely(length2 == -1)) return -1;
    if (length != length2) goto __pyx_return_false;
    #endif
    if (length == 0) goto __pyx_return_true;
    if (ps1[0] != ps2[0]) goto __pyx_return_false;
    if (length == 1) goto __pyx_return_true;
    {
        int cmp;
        cmp = memcmp(ps1, ps2, (size_t)length);
        if (cmp == 0) goto __pyx_return_true; else goto __pyx_return_false;
    }
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
#endif
#ifndef __Pyx_DEFINED_PyObject_CompareFloatIntBoolEq
#define __Pyx_DEFINED_PyObject_CompareFloatIntBoolEq
static int __Pyx_PyObject_CompareFloatIntBoolEq(PyObject *op1, PyObject *op2) {
    double float_op1 = __Pyx_PyFloat_AS_DOUBLE(op1);
    #if !CYTHON_ASSUME_SAFE_MACROS
    if (unlikely(float_op1 == -1. && PyErr_Occurred())) return -1;
    #endif
    #if CYTHON_USE_PYLONG_INTERNALS
    if (__Pyx_PyLong_IsCompact(op2)) {
        Py_ssize_t iop2 = __Pyx_PyLong_CompactValue(op2);
        if (float_op1 == ((double)iop2)) goto __pyx_return_true; else goto __pyx_return_false;
    }
    if (unlikely(!isfinite(float_op1))) {
        if (float_op1 == 0.0) goto __pyx_return_true; else goto __pyx_return_false;
    } else {
        int sign2 = __Pyx_PyLong_Sign(op2);
        if (float_op1 >= 0.) {
            if (sign2 < 0) goto __pyx_return_false;
            if (float_op1 < (double) (1L << PyLong_SHIFT)) goto __pyx_return_false;
        } else {
            if (sign2 > 0) goto __pyx_return_false;
            if (float_op1 > -(double) (1L << PyLong_SHIFT)) goto __pyx_return_false;
        }
    }
    #else
    if (unlikely(!isfinite(float_op1))) {
        if (float_op1 == 0.0) goto __pyx_return_true; else goto __pyx_return_false;
    } else {
        int overflow2;
        long iop2 = PyLong_AsLongAndOverflow(op2, &overflow2);
        if (likely(!overflow2)) {
            if ((long long) iop2 >= (1LL << 53)) {
                overflow2 = 1;
            } else if ((long long) iop2 <= - (1LL << 53)) {
                overflow2 = -1;
            } else {
                if (float_op1 == ((double) iop2)) goto __pyx_return_true; else goto __pyx_return_false;
            }
        }
        if (overflow2 > 0) {
            if (float_op1 < ((double) (1LL << 53))) goto __pyx_return_false;
        } else {
            if (float_op1 > - ((double) (1LL << 53))) goto __pyx_return_false;
        }
    }
    #endif
    return __Pyx_PyObject_RichCompareBool(op1, op2, Py_EQ);
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
#ifndef __Pyx_DEFINED_PyObject_CompareIntFloatBoolEq
#define __Pyx_DEFINED_PyObject_CompareIntFloatBoolEq
static int __Pyx_PyObject_CompareIntFloatBoolEq(PyObject *op1, PyObject *op2) {
    double float_op2 = __Pyx_PyFloat_AS_DOUBLE(op2);
    #if !CYTHON_ASSUME_SAFE_MACROS
    if (unlikely(float_op2 == -1. && PyErr_Occurred())) return -1;
    #endif
    #if CYTHON_USE_PYLONG_INTERNALS
    if (__Pyx_PyLong_IsCompact(op1)) {
        Py_ssize_t iop1 = __Pyx_PyLong_CompactValue(op1);
        if (((double)iop1) == float_op2) goto __pyx_return_true; else goto __pyx_return_false;
    }
    if (unlikely(!isfinite(float_op2))) {
        if (0.0 == float_op2) goto __pyx_return_true; else goto __pyx_return_false;
    } else {
        int sign1 = __Pyx_PyLong_Sign(op1);
        if (float_op2 >= 0.) {
            if (sign1 < 0) goto __pyx_return_false;
            if (float_op2 < (double) (1L << PyLong_SHIFT)) goto __pyx_return_false;
        } else {
            if (sign1 > 0) goto __pyx_return_false;
            if (float_op2 > -(double) (1L << PyLong_SHIFT)) goto __pyx_return_false;
        }
    }
    #else
    if (unlikely(!isfinite(float_op2))) {
        if (0.0 == float_op2) goto __pyx_return_true; else goto __pyx_return_false;
    } else {
        int overflow1;
        long iop1 = PyLong_AsLongAndOverflow(op1, &overflow1);
        if (likely(!overflow1)) {
            if ((long long) iop1 >= (1LL << 53)) {
                overflow1 = 1;
            } else if ((long long) iop1 <= - (1LL << 53)) {
                overflow1 = -1;
            } else {
                if (((double) iop1) == float_op2) goto __pyx_return_true; else goto __pyx_return_false;
            }
        }
        if (overflow1 < 0) {
            if (float_op2 > ((double) (1LL << 53))) goto __pyx_return_false;
        } else {
            if (float_op2 < - ((double) (1LL << 53))) goto __pyx_return_false;
        }
    }
    #endif
    return __Pyx_PyObject_RichCompareBool(op1, op2, Py_EQ);
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
#ifndef __Pyx_DEFINED_PyObject_CompareIntIntBoolEq
#define __Pyx_DEFINED_PyObject_CompareIntIntBoolEq
static int __Pyx_PyObject_CompareIntIntBoolEq(PyObject *op1, PyObject *op2) {
#if CYTHON_USE_PYLONG_INTERNALS
    Py_ssize_t cmp = __Pyx_PyLong_CompareSignAndSize(op1, op2);
    if (cmp == 0) {
        Py_ssize_t size = __Pyx_PyLong_DigitCount(op1);
        if (size > 0) {
            const digit* digits1 = __Pyx_PyLong_Digits(op1);
            const digit* digits2 = __Pyx_PyLong_Digits(op2);
            if (size == 1) {
                cmp = (Py_ssize_t) digits1[0] - (Py_ssize_t) digits2[0];
            } else if ((size == 2) && (8 * sizeof(Py_ssize_t) >= 2 * PyLong_SHIFT)) {
                cmp = (Py_ssize_t) (((((size_t)digits1[1]) << PyLong_SHIFT) | (size_t)digits1[0])) - (Py_ssize_t) (((((size_t)digits2[1]) << PyLong_SHIFT) | (size_t)digits2[0]));
            } else {
                for (Py_ssize_t i=size-1; i >= 0 && !cmp; --i) {
                    cmp = (Py_ssize_t) digits1[i] - (Py_ssize_t) digits2[i];
                }
            }
        }
        if (cmp == 0) goto __pyx_return_true;
        if (__Pyx_PyLong_IsNeg(op1)) cmp = -cmp;
    }
    goto __pyx_return_false;
#else
    int overflow1, overflow2;
    long long iop1 = PyLong_AsLongLongAndOverflow(op1, &overflow1);
    long long iop2 = PyLong_AsLongLongAndOverflow(op2, &overflow2);
    if (likely(!(overflow1 | overflow2))) {
        if (iop1 == iop2) goto __pyx_return_true; else goto __pyx_return_false;
    } else if (overflow1 != overflow2) {
        if (overflow1 == overflow2) goto __pyx_return_true; else goto __pyx_return_false;
    } else {
        return __Pyx_PyObject_RichCompareBool(op1, op2, Py_EQ);
    }
#endif
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}
#endif
static CYTHON_INLINE int __Pyx_PyObject_CompareBoolEq_object_object(PyObject *op1, PyObject *op2, int pyop) {
    CYTHON_UNUSED_VAR(pyop);
    if (PyFloat_CheckExact(op1)) {
        if (PyFloat_CheckExact(op2)) {
            double float_op1 = __Pyx_PyFloat_AS_DOUBLE(op1);
            #if !CYTHON_ASSUME_SAFE_MACROS
            if (unlikely(float_op1 == -1. && PyErr_Occurred())) return -1;
            #endif
            double float_op2 = __Pyx_PyFloat_AS_DOUBLE(op2);
            #if !CYTHON_ASSUME_SAFE_MACROS
            if (unlikely(float_op2 == -1. && PyErr_Occurred())) return -1;
            #endif
            if (float_op1 == float_op2) goto __pyx_return_true; else goto __pyx_return_false;
        }
        if (PyLong_CheckExact(op2)) {
            return __Pyx_PyObject_CompareFloatIntBoolEq(op1, op2);
        }
        goto __pyx_richcmp;
    }
    if (PyLong_CheckExact(op1)) {
        if (op1 == op2) goto __pyx_return_true;
        if (PyLong_CheckExact(op2)) {
            return __Pyx_PyObject_CompareIntIntBoolEq(op1, op2);
        }
        if (PyFloat_CheckExact(op2)) {
            return __Pyx_PyObject_CompareIntFloatBoolEq(op1, op2);
        }
        goto __pyx_richcmp;
    }
    
    if (PyUnicode_CheckExact(op1)) {
        if (op1 == op2) goto __pyx_return_true;
        if (PyUnicode_CheckExact(op2)) {
            return __Pyx_PyObject_CompareStrStrBoolEq(op1, op2);
        }
        goto __pyx_richcmp;
    }
    
    #if !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL)
    if (PyBytes_CheckExact(op1)) {
        if (op1 == op2) goto __pyx_return_true;
        if (PyBytes_CheckExact(op2)) {
            return __Pyx_PyObject_ComparePyBytesPyBytesBoolEq(op1, op2);
        }
        if (PyByteArray_CheckExact(op2)) {
            return __Pyx_PyObject_ComparePyBytesPyByteArrayBoolEq(op1, op2);
        }
        goto __pyx_richcmp;
    }
    #endif
    #if !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL)
    if (PyByteArray_CheckExact(op1)) {
        if (op1 == op2) goto __pyx_return_true;
        if (PyByteArray_CheckExact(op2)) {
            return __Pyx_PyObject_ComparePyByteArrayPyByteArrayBoolEq(op1, op2);
        }
        if (PyBytes_CheckExact(op2)) {
            return __Pyx_PyObject_ComparePyByteArrayPyBytesBoolEq(op1, op2);
        }
        goto __pyx_richcmp;
    }
    #endif
    if ((0)) goto __pyx_richcmp;
    if ((0)) goto __pyx_return_true;
    if ((0)) goto __pyx_return_false;
__pyx_richcmp:
    return __Pyx_PyObject_RichCompareBool(op1, op2, Py_EQ);
__pyx_return_true:
    return 1;
__pyx_return_false:
    return 0;
}


#if CYTHON_COMPILING_IN_LIMITED_API
static CYTHON_INLINE PyObject* __Pyx__PyFrozenDict_New(PyObject* frozendict_type, PyObject* it) {
    return PyObject_CallFunctionObjArgs(frozendict_type, it, NULL);
}
#endif


#if CYTHON_USE_TYPE_SLOTS && !CYTHON_COMPILING_IN_PYPY
static int __Pyx_GetItemInt_wraparound(PyObject *o, PySequenceMethods *sm, Py_ssize_t *i) {
    assert(*i < 0);
    if (likely(sm->sq_length)) {
        Py_ssize_t l = sm->sq_length(o);
        if (likely(l >= 0)) {
            *i += l;
        } else {
            if (!PyErr_ExceptionMatches(PyExc_OverflowError))
                return -1;
            PyErr_Clear();
        }
    }
    return 0;
}
#endif


static PyObject *__Pyx_GetItemInt_Generic(PyObject *o, PyObject* j) {
    PyObject *r;
    if (unlikely(!j)) return NULL;
    r = PyObject_GetItem(o, j);
    Py_DECREF(j);
    return r;
}
static PyObject *__Pyx_GetItemInt_Generic_size(PyObject *o, Py_ssize_t i) {
    return __Pyx_GetItemInt_Generic(o, PyLong_FromSsize_t(i));
}
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_List_Fast(PyObject *o, Py_ssize_t i,
                                                              int wraparound, int boundscheck, int unsafe_shared) {
    CYTHON_MAYBE_UNUSED_VAR(unsafe_shared);
#if CYTHON_AVOID_BORROWED_REFS
    CYTHON_UNUSED_VAR(boundscheck);
    Py_ssize_t wrapped_i = i;
    if (wraparound & unlikely(i < 0)) {
        Py_ssize_t size = __Pyx_PyList_GET_SIZE(o);
        #if !CYTHON_ASSUME_SAFE_SIZE
        if (unlikely(size < 0)) return NULL;
        #endif
        wrapped_i += size;
    }
    return __Pyx_PyList_GetItemRef(o, wrapped_i);
#elif CYTHON_ASSUME_SAFE_SIZE && CYTHON_ASSUME_SAFE_MACROS
    Py_ssize_t wrapped_i = i;
    Py_ssize_t size = (wraparound | boundscheck) ? PyList_GET_SIZE(o) : -1;
    if (wraparound & unlikely(i < 0)) {
        wrapped_i += size;
    }
    if ((!boundscheck) || likely(__Pyx_is_valid_index(wrapped_i, size))) {
        return __Pyx_PyList_GET_ITEM_REF(o, wrapped_i, unsafe_shared);
    }
    return __Pyx_GetItemInt_Generic_size(o, i);
#else
    (void)wraparound;
    (void)boundscheck;
    return PySequence_GetItem(o, i);
#endif
}
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_Tuple_Fast(PyObject *o, Py_ssize_t i,
                                                              int wraparound, int boundscheck, int unsafe_shared) {
    CYTHON_MAYBE_UNUSED_VAR(unsafe_shared);
#if CYTHON_AVOID_BORROWED_REFS
    CYTHON_UNUSED_VAR(boundscheck);
    Py_ssize_t wrapped_i = i;
    if (wraparound & unlikely(i < 0)) {
        Py_ssize_t size = __Pyx_PyTuple_GET_SIZE(o);
        #if !CYTHON_ASSUME_SAFE_SIZE
        if (unlikely(size < 0)) return NULL;
        #endif
        wrapped_i += size;
    }
    #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_COMPILING_IN_LIMITED_API
    return PySequence_ITEM(o, wrapped_i);
    #else
    if (unlikely(wrapped_i < 0)) {
        PyErr_SetString(PyExc_IndexError, "tuple index out of range");
        return NULL;
    }
    return PySequence_GetItem(o, wrapped_i);
    #endif
#elif CYTHON_ASSUME_SAFE_SIZE && CYTHON_ASSUME_SAFE_MACROS
    Py_ssize_t wrapped_i = i;
    Py_ssize_t size = (wraparound | boundscheck) ? PyTuple_GET_SIZE(o) : -1;
    if (wraparound & unlikely(i < 0)) {
        wrapped_i += size;
    }
    if ((!boundscheck) || likely(__Pyx_is_valid_index(wrapped_i, size))) {
        return __Pyx_NewRef(__Pyx_PyTuple_GET_ITEM(o, wrapped_i));
    }
    return __Pyx_GetItemInt_Generic_size(o, i);
#else
    (void)wraparound;
    (void)boundscheck;
    return PySequence_GetItem(o, i);
#endif
}
#if CYTHON_USE_TYPE_SLOTS && !CYTHON_COMPILING_IN_PYPY
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_Fast_mapping(PyObject *o, binaryfunc getitem, Py_ssize_t i) {
    PyObject *r, *key = PyLong_FromSsize_t(i);
    if (unlikely(!key)) return NULL;
    r = getitem(o, key);
    Py_DECREF(key);
    return r;
}
#endif
static CYTHON_INLINE PyObject *__Pyx_GetItemInt_Fast(PyObject *o, Py_ssize_t i,
                                                     int wraparound, int boundscheck, int unsafe_shared) {
    CYTHON_MAYBE_UNUSED_VAR(unsafe_shared);
#if CYTHON_ASSUME_SAFE_SIZE
    if (PyList_CheckExact(o)) {
        return __Pyx_GetItemInt_List_Fast(o, i, wraparound, boundscheck, unsafe_shared);
    } else
    #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
    if (PyTuple_CheckExact(o)) {
        return __Pyx_GetItemInt_Tuple_Fast(o, i, wraparound, boundscheck, unsafe_shared);
    } else
    #endif
#else
    if ((!wraparound || i >= 0) & PyList_CheckExact(o)) {
        return boundscheck ? __Pyx_PyList_GetItemRef(o, i) : __Pyx_PyList_GET_ITEM_REF(o, i, unsafe_shared);
    } else
#endif
#if CYTHON_USE_TYPE_SLOTS && !CYTHON_COMPILING_IN_PYPY
    if (PyDict_CheckExact(o)) {
        return __Pyx_GetItemInt_Fast_mapping(o, PyDict_Type.tp_as_mapping->mp_subscript, i);
    #if defined(PyFrozenDict_CheckExact)
    } else if (PyFrozenDict_CheckExact(o)) {
        return __Pyx_GetItemInt_Fast_mapping(o, PyFrozenDict_Type.tp_as_mapping->mp_subscript, i);
    #endif
    } else
    {
        PyTypeObject *obj_type = Py_TYPE(o);
        int seq_or_mapping = __Pyx_PyType_GetFlags(obj_type) & (Py_TPFLAGS_SEQUENCE|Py_TPFLAGS_MAPPING);
        if (seq_or_mapping != Py_TPFLAGS_SEQUENCE) {
            PyMappingMethods *mm = obj_type->tp_as_mapping;
            if (mm && mm->mp_subscript)
                return __Pyx_GetItemInt_Fast_mapping(o, mm->mp_subscript, i);
        }
        PySequenceMethods *sm = obj_type->tp_as_sequence;
        if (likely(sm && sm->sq_item)) {
            if (wraparound && (i < 0) && unlikely(__Pyx_GetItemInt_wraparound(o, sm, &i) == -1))
                return NULL;
            return sm->sq_item(o, i);
        }
        if (seq_or_mapping == Py_TPFLAGS_SEQUENCE) {
            PyMappingMethods *mm = obj_type->tp_as_mapping;
            if (likely(mm && mm->mp_subscript))
                return __Pyx_GetItemInt_Fast_mapping(o, mm->mp_subscript, i);
        }
    }
#else
    if (!PyMapping_Check(o)) {
        return PySequence_GetItem(o, i);
    }
#endif
    (void)wraparound;
    (void)boundscheck;
    return __Pyx_GetItemInt_Generic_size(o, i);
}


#if CYTHON_USE_EXC_INFO_STACK && CYTHON_FAST_THREAD_STATE
static _PyErr_StackItem *
__Pyx_PyErr_GetTopmostException(PyThreadState *tstate)
{
    _PyErr_StackItem *exc_info = tstate->exc_info;
    while ((exc_info->exc_value == NULL || exc_info->exc_value == Py_None) &&
           exc_info->previous_item != NULL)
    {
        exc_info = exc_info->previous_item;
    }
    return exc_info;
}
#endif


#if CYTHON_FAST_THREAD_STATE
static CYTHON_INLINE void __Pyx__ExceptionSave(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb) {
  #if CYTHON_USE_EXC_INFO_STACK && PY_VERSION_HEX >= 0x030B00a4
    _PyErr_StackItem *exc_info = __Pyx_PyErr_GetTopmostException(tstate);
    PyObject *exc_value = exc_info->exc_value;
    if (exc_value == NULL || exc_value == Py_None) {
        *value = NULL;
        *type = NULL;
        *tb = NULL;
    } else {
        *value = exc_value;
        Py_INCREF(*value);
        *type = (PyObject*) Py_TYPE(exc_value);
        Py_INCREF(*type);
        *tb = PyException_GetTraceback(exc_value);
    }
  #elif CYTHON_USE_EXC_INFO_STACK
    _PyErr_StackItem *exc_info = __Pyx_PyErr_GetTopmostException(tstate);
    *type = exc_info->exc_type;
    *value = exc_info->exc_value;
    *tb = exc_info->exc_traceback;
    Py_XINCREF(*type);
    Py_XINCREF(*value);
    Py_XINCREF(*tb);
  #else
    *type = tstate->exc_type;
    *value = tstate->exc_value;
    *tb = tstate->exc_traceback;
    Py_XINCREF(*type);
    Py_XINCREF(*value);
    Py_XINCREF(*tb);
  #endif
}
static CYTHON_INLINE void __Pyx__ExceptionReset(PyThreadState *tstate, PyObject *type, PyObject *value, PyObject *tb) {
  #if CYTHON_USE_EXC_INFO_STACK && PY_VERSION_HEX >= 0x030B00a4
    _PyErr_StackItem *exc_info = tstate->exc_info;
    PyObject *tmp_value = exc_info->exc_value;
    exc_info->exc_value = value;
    Py_XDECREF(tmp_value);
    Py_XDECREF(type);
    Py_XDECREF(tb);
  #else
    PyObject *tmp_type, *tmp_value, *tmp_tb;
    #if CYTHON_USE_EXC_INFO_STACK
    _PyErr_StackItem *exc_info = tstate->exc_info;
    tmp_type = exc_info->exc_type;
    tmp_value = exc_info->exc_value;
    tmp_tb = exc_info->exc_traceback;
    exc_info->exc_type = type;
    exc_info->exc_value = value;
    exc_info->exc_traceback = tb;
    #else
    tmp_type = tstate->exc_type;
    tmp_value = tstate->exc_value;
    tmp_tb = tstate->exc_traceback;
    tstate->exc_type = type;
    tstate->exc_value = value;
    tstate->exc_traceback = tb;
    #endif
    Py_XDECREF(tmp_type);
    Py_XDECREF(tmp_value);
    Py_XDECREF(tmp_tb);
  #endif
}
#endif


#if CYTHON_FAST_THREAD_STATE
static int __Pyx__GetException(PyThreadState *tstate, PyObject **type, PyObject **value, PyObject **tb)
#else
static int __Pyx_GetException(PyObject **type, PyObject **value, PyObject **tb)
#endif
{
    PyObject *local_type = NULL, *local_value, *local_tb = NULL;
#if CYTHON_FAST_THREAD_STATE
    PyObject *tmp_type, *tmp_value, *tmp_tb;
  #if PY_VERSION_HEX >= 0x030C0000
    local_value = tstate->current_exception;
    tstate->current_exception = 0;
  #else
    local_type = tstate->curexc_type;
    local_value = tstate->curexc_value;
    local_tb = tstate->curexc_traceback;
    tstate->curexc_type = 0;
    tstate->curexc_value = 0;
    tstate->curexc_traceback = 0;
  #endif
#elif __PYX_LIMITED_VERSION_HEX >= 0x030C0000
    local_value = PyErr_GetRaisedException();
#else
    PyErr_Fetch(&local_type, &local_value, &local_tb);
#endif
#if __PYX_LIMITED_VERSION_HEX >= 0x030C0000
    if (likely(local_value)) {
        local_type = (PyObject*) Py_TYPE(local_value);
        Py_INCREF(local_type);
        local_tb = PyException_GetTraceback(local_value);
    }
#else
    PyErr_NormalizeException(&local_type, &local_value, &local_tb);
#if CYTHON_FAST_THREAD_STATE
    if (unlikely(tstate->curexc_type))
#else
    if (unlikely(PyErr_Occurred()))
#endif
        goto bad;
    if (local_tb) {
        if (unlikely(PyException_SetTraceback(local_value, local_tb) < 0))
            goto bad;
    }
#endif // __PYX_LIMITED_VERSION_HEX >= 0x030C0000
    Py_XINCREF(local_tb);
    Py_XINCREF(local_type);
    Py_XINCREF(local_value);
    *type = local_type;
    *value = local_value;
    *tb = local_tb;
#if CYTHON_FAST_THREAD_STATE
    #if CYTHON_USE_EXC_INFO_STACK
    {
        _PyErr_StackItem *exc_info = tstate->exc_info;
      #if PY_VERSION_HEX >= 0x030B00a4
        tmp_value = exc_info->exc_value;
        exc_info->exc_value = local_value;
        tmp_type = NULL;
        tmp_tb = NULL;
        Py_XDECREF(local_type);
        Py_XDECREF(local_tb);
      #else
        tmp_type = exc_info->exc_type;
        tmp_value = exc_info->exc_value;
        tmp_tb = exc_info->exc_traceback;
        exc_info->exc_type = local_type;
        exc_info->exc_value = local_value;
        exc_info->exc_traceback = local_tb;
      #endif
    }
    #else
    tmp_type = tstate->exc_type;
    tmp_value = tstate->exc_value;
    tmp_tb = tstate->exc_traceback;
    tstate->exc_type = local_type;
    tstate->exc_value = local_value;
    tstate->exc_traceback = local_tb;
    #endif
    Py_XDECREF(tmp_type);
    Py_XDECREF(tmp_value);
    Py_XDECREF(tmp_tb);
#elif __PYX_LIMITED_VERSION_HEX >= 0x030b0000
    PyErr_SetHandledException(local_value);
    Py_XDECREF(local_value);
    Py_XDECREF(local_type);
    Py_XDECREF(local_tb);
#else
    PyErr_SetExcInfo(local_type, local_value, local_tb);
#endif
    return 0;
#if __PYX_LIMITED_VERSION_HEX < 0x030C0000
bad:
    *type = 0;
    *value = 0;
    *tb = 0;
    Py_XDECREF(local_type);
    Py_XDECREF(local_value);
    Py_XDECREF(local_tb);
    return -1;
#endif
}


#if CYTHON_USE_PYLIST_INTERNALS && CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE
static CYTHON_INLINE void __Pyx__ListComp_AppendAndDecref(PyObject* list, Py_ssize_t len, PyObject* x) {
    PyList_SET_ITEM(list, len, x);
    Py_SET_SIZE(list, len + 1);
}
#endif


#if CYTHON_USE_PYLIST_INTERNALS && CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE
static CYTHON_INLINE int __Pyx_PyList_Append(PyObject* list, PyObject* x) {
    PyListObject* L = (PyListObject*) list;
    Py_ssize_t len = Py_SIZE(list);
    if (likely(L->allocated > len) & likely(len > (L->allocated >> 1))) {
        Py_INCREF(x);
        __Pyx__ListComp_AppendAndDecref(list, len, x);
        return 0;
    }
    return PyList_Append(list, x);
}
#endif


static CYTHON_INLINE PyObject* __Pyx_PyObject_CallMethod1(PyObject* obj, PyObject* method_name, PyObject* arg) {
#if CYTHON_VECTORCALL && (__PYX_LIMITED_VERSION_HEX >= 0x030C0000 || !CYTHON_COMPILING_IN_LIMITED_API)
    PyObject *args[2] = {obj, arg};
    return PyObject_VectorcallMethod(method_name, args, 2 | PY_VECTORCALL_ARGUMENTS_OFFSET, NULL);
#elif CYTHON_COMPILING_IN_LIMITED_API
    return PyObject_CallMethodObjArgs(obj, method_name, arg, NULL);
#else
    return PyObject_CallMethodOneArg(obj, method_name, arg);
#endif
}


static CYTHON_INLINE int __Pyx_PyObject_Append(PyObject* L, PyObject* x) {
    if (likely(PyList_CheckExact(L))) {
        if (unlikely(__Pyx_PyList_Append(L, x) < 0)) return -1;
    } else {
        PyObject* retval = __Pyx_PyObject_CallMethod1(L, __pyx_mstate_global->__pyx_n_u_append, x);
        if (unlikely(!retval))
            return -1;
        Py_DECREF(retval);
    }
    return 0;
}


#if !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_GRAAL || CYTHON_COMPILING_IN_LIMITED_API)
#if CYTHON_USE_TYPE_SLOTS || __PYX_LIMITED_VERSION_HEX >= 0x030A0000
#ifndef __Pyx_DEFINED_BinopTypeError
#define __Pyx_DEFINED_BinopTypeError
static void __Pyx_BinopTypeError(PyObject *op1, PyObject *op2, const char* op, int inplace) {
    char opname[4] = {op[0], op[1], 0, 0};
    if (inplace) {
        opname[op[1] ? 2 : 1] = '=';
    }
    __Pyx_RaiseErrorWithObjectTypes1(
        PyExc_TypeError,
        "unsupported operand type(s) for %.3s: '" __Pyx_FMT_TYPENAME "' and '" __Pyx_FMT_TYPENAME "'",
        opname, op1, op2);
}
#endif
#endif
#ifndef __Pyx_DEFINED_PyNumber_Subtract_xfloat_int
#define __Pyx_DEFINED_PyNumber_Subtract_xfloat_int
static PyObject* __Pyx_PyNumber_Subtract_xfloat_int(PyObject *op1, PyObject *op2, int inplace) {
    if (likely(op2 != Py_None)) {
        double int_op2;
        #if CYTHON_USE_PYLONG_INTERNALS
        if (__Pyx_PyLong_IsCompact(op2)) {
            Py_ssize_t compact_op2 = __Pyx_PyLong_CompactValue(op2);
            if (compact_op2 == 0) return __Pyx_NewRef(op1);
            int_op2 = (double) compact_op2;
        } else
        #endif
        {
            int_op2 = PyLong_AsDouble(op2);
            if (unlikely((int_op2 == -1.) && PyErr_Occurred())) return NULL;
            #if !CYTHON_USE_PYLONG_INTERNALS
            if (int_op2 == 0.) return __Pyx_NewRef(op1);
            #endif
        }
        double float_op1 = __Pyx_PyFloat_AS_DOUBLE(op1);
        #if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely((float_op1 == -1.) && PyErr_Occurred())) return NULL;
        #endif
        return PyFloat_FromDouble(float_op1 - int_op2);
    }
    #if CYTHON_USE_TYPE_SLOTS || __PYX_LIMITED_VERSION_HEX >= 0x030A0000
    {
        PyTypeObject *type_op2 = Py_TYPE(op2);
        binaryfunc slot_func = __Pyx_PyType_GetSubSlot(type_op2, tp_as_number, nb_subtract, binaryfunc);
        if (likely(slot_func)) {
            PyObject *result = slot_func(op1, op2);
            if (likely(result != Py_NotImplemented)) {
                return result;
            }
            Py_DECREF(result);
        }
        __Pyx_BinopTypeError(op1, op2, "-", inplace);
        return NULL;
    }
    #else
    return (inplace) ? PyNumber_InPlaceSubtract(op1, op2) : PyNumber_Subtract(op1, op2);
    #endif
}
#endif
#ifndef __Pyx_DEFINED_PyNumber_Subtract_xint_int
#define __Pyx_DEFINED_PyNumber_Subtract_xint_int
static PyObject* __Pyx_PyNumber_Subtract_xint_int(PyObject *op1, PyObject *op2, int inplace) {
    #if CYTHON_USE_TYPE_SLOTS || __PYX_LIMITED_VERSION_HEX >= 0x030A0000
    {
        PyTypeObject *type_op2 = Py_TYPE(op2);
        binaryfunc slot_func = __Pyx_PyType_GetSubSlot(type_op2, tp_as_number, nb_subtract, binaryfunc);
        if (likely(slot_func)) {
            PyObject *result = slot_func(op1, op2);
            if (likely(result != Py_NotImplemented)) {
                return result;
            }
            Py_DECREF(result);
        }
        __Pyx_BinopTypeError(op1, op2, "-", inplace);
        return NULL;
    }
    #else
    return (inplace) ? PyNumber_InPlaceSubtract(op1, op2) : PyNumber_Subtract(op1, op2);
    #endif
}
#endif
static CYTHON_INLINE PyObject* __Pyx__PyNumber_Subtract_object_int(PyObject *op1, PyObject *op2, int inplace) {
    if (PyFloat_CheckExact(op1)) {
        return __Pyx_PyNumber_Subtract_xfloat_int(op1, op2, inplace);
    }
    if (likely(PyLong_CheckExact(op1))) {
        if (likely(op2 != Py_None)) {
            #if CYTHON_USE_PYLONG_INTERNALS
            if (__Pyx_PyLong_IsCompact(op1)) {
                Py_ssize_t int_op1 = __Pyx_PyLong_CompactValue(op1);
                if (__Pyx_PyLong_IsCompact(op2)) {
                    Py_ssize_t int_op2 = __Pyx_PyLong_CompactValue(op2);
                    if (int_op2 == 0) return __Pyx_NewRef(op1);
                    return PyLong_FromSsize_t(int_op1 - int_op2);
                }
            }
            else if (__Pyx_PyLong_IsZero(op2)) return __Pyx_NewRef(op1);
            #endif
            binaryfunc slot_func = __Pyx_PyType_GetSubSlot(&PyLong_Type, tp_as_number, nb_subtract, binaryfunc);
            if (likely(slot_func)) {
                return slot_func(op1, op2);
            }
        }
        return __Pyx_PyNumber_Subtract_xint_int(op1, op2, inplace);
    }
    return (inplace) ? PyNumber_InPlaceSubtract(op1, op2) : PyNumber_Subtract(op1, op2);
}
#endif


#if CYTHON_VECTORCALL
CYTHON_UNUSED static int __Pyx_CheckVectorcallKwarg(PyObject *kwnames, Py_ssize_t i) {
    PyObject *key = __Pyx_PyTuple_GET_ITEM(kwnames, i);
#if !CYTHON_ASSUME_SAFE_MACROS
    if (unlikely(!key)) return -1;
#endif
    if (unlikely(!PyUnicode_Check(key))) {
        PyErr_SetString(PyExc_TypeError, "keywords must be strings");
        return -1;
    }
    return 0;
}
#else
CYTHON_UNUSED static PyObject *__Pyx_MakeKwargDict(PyObject **keys, PyObject **values, Py_ssize_t n) {
    PyObject *out = PyDict_New();
    if (unlikely(!out)) return NULL;
    for (Py_ssize_t i=0; i<n; ++i) {
        if (unlikely(PyDict_SetItem(out, keys[i], values[i]) < 0)) {
            Py_DECREF(out);
            return NULL;
        }
    }
    return out;
}
CYTHON_UNUSED static int __Pyx_CheckVectorcallKwarg(PyObject **kwnames, Py_ssize_t i) {
    PyObject *key = kwnames[i];
    if (unlikely(!PyUnicode_Check(key))) {
        PyErr_SetString(PyExc_TypeError, "keywords must be strings");
        return -1;
    }
    return 0;
}
#endif


#if !CYTHON_VECTORCALL
static PyObject *__Pyx_Object_VectorcallMethodKwds(PyObject *name, PyObject *const *args, size_t nargsf, PyObject *kwnames) {
    PyObject *result;
    PyObject *obj = PyObject_GetAttr(args[0], name);
    if (unlikely(!obj))
        return NULL;
    result = __Pyx_Object_VectorcallKwds(obj, args+1, nargsf-1, kwnames);
    Py_DECREF(obj);
    return result;
}
#endif


static void __Pyx_RaiseErrorWithType(PyObject* exc_type, const char* message, PyTypeObject *type_obj) {
    __Pyx_TypeName type_name = __Pyx_PyType_GetFullyQualifiedName(type_obj);
    #if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030d0000
    if (unlikely(!type_name)) return;
    #endif
    PyErr_Format(exc_type, message, type_name);
    __Pyx_DECREF_TypeName(type_name);
}


#if CYTHON_USE_TYPE_SLOTS
static PyObject *__Pyx_PyObject_GetIndex(PyObject *obj, PyObject *index) {
    PyObject *runerr = NULL;
    Py_ssize_t key_value;
    key_value = __Pyx_PyIndex_AsSsize_t(index);
    if (likely(key_value != -1 || !(runerr = PyErr_Occurred()))) {
        return __Pyx_GetItemInt_Fast(obj, key_value, 1, 1, 1);
    }
    if (PyErr_GivenExceptionMatches(runerr, PyExc_OverflowError)) {
        PyErr_Clear();
        __Pyx_RaiseErrorWithObjectType(
            PyExc_IndexError,
            "cannot fit '" __Pyx_FMT_TYPENAME "' into an index-sized integer",
            index);
    }
    return NULL;
}
static PyObject *__Pyx_PyObject_GetItem_Slow(PyObject *obj, PyObject *key) {
    if (likely(PyType_Check(obj))) {
        if ((PyTypeObject*)obj == &PyType_Type) {
            return Py_GenericAlias(obj, key);
        }
        PyObject *meth = __Pyx_PyObject_GetAttrStrNoError(obj, __pyx_mstate_global->__pyx_n_u_class_getitem);
        if (!meth) {
            if (PyErr_Occurred()) {
                return NULL;
            }
        } else {
            PyObject *result = __Pyx_PyObject_CallOneArg(meth, key);
            Py_DECREF(meth);
            return result;
        }
    }
    __Pyx_RaiseTypeErrorWithObjectType(
        "'" __Pyx_FMT_TYPENAME "' object is not subscriptable", obj);
    return NULL;
}
static PyObject *__Pyx_PyObject_GetItem(PyObject *obj, PyObject *key) {
    PyTypeObject *tp = Py_TYPE(obj);
    PyMappingMethods *mm = tp->tp_as_mapping;
    PySequenceMethods *sm = tp->tp_as_sequence;
    if (likely(mm && mm->mp_subscript)) {
        return mm->mp_subscript(obj, key);
    }
    if (likely(sm && sm->sq_item)) {
        return __Pyx_PyObject_GetIndex(obj, key);
    }
    return __Pyx_PyObject_GetItem_Slow(obj, key);
}
#endif


#if CYTHON_USE_PYLIST_INTERNALS && CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE
static CYTHON_INLINE int __Pyx_ListComp_AppendAndDecref(PyObject* list, PyObject* x) {
    PyListObject* L = (PyListObject*) list;
    Py_ssize_t len = Py_SIZE(list);
    if (likely(L->allocated > len)) {
        __Pyx__ListComp_AppendAndDecref(list, len, x);
        return 0;
    }
    int result = PyList_Append(list, x);
    Py_DECREF(x);
    return result;
}
#else
static CYTHON_INLINE int __Pyx_ListComp_AppendAndDecref(PyObject* list, PyObject* x) {
    int result = PyList_Append(list, x);
    Py_DECREF(x);
    return result;
}
#endif


static CYTHON_INLINE PyObject* __Pyx_PyObject_GetSlice(PyObject* obj,
        Py_ssize_t cstart, Py_ssize_t cstop,
        PyObject** _py_start, PyObject** _py_stop, PyObject** _py_slice,
        int has_cstart, int has_cstop, CYTHON_UNUSED int wraparound) {
#if CYTHON_USE_TYPE_SLOTS
    PyMappingMethods* mp = Py_TYPE(obj)->tp_as_mapping;
    if (likely(mp && mp->mp_subscript))
#else
    if ((1))
#endif
    {
        PyObject* result;
        PyObject *py_slice, *py_start, *py_stop;
        if (_py_slice) {
            py_slice = *_py_slice;
        } else {
            PyObject* owned_start = NULL;
            PyObject* owned_stop = NULL;
            if (_py_start) {
                py_start = *_py_start;
            } else {
                if (has_cstart) {
                    owned_start = py_start = PyLong_FromSsize_t(cstart);
                    if (unlikely(!py_start)) goto bad;
                } else
                    py_start = Py_None;
            }
            if (_py_stop) {
                py_stop = *_py_stop;
            } else {
                if (has_cstop) {
                    owned_stop = py_stop = PyLong_FromSsize_t(cstop);
                    if (unlikely(!py_stop)) {
                        Py_XDECREF(owned_start);
                        goto bad;
                    }
                } else
                    py_stop = Py_None;
            }
            py_slice = PySlice_New(py_start, py_stop, Py_None);
            Py_XDECREF(owned_start);
            Py_XDECREF(owned_stop);
            if (unlikely(!py_slice)) goto bad;
        }
#if CYTHON_USE_TYPE_SLOTS
        result = mp->mp_subscript(obj, py_slice);
#else
        result = PyObject_GetItem(obj, py_slice);
#endif
        if (!_py_slice) {
            Py_DECREF(py_slice);
        }
        return result;
    } else {
        __Pyx_RaiseTypeErrorWithObjectType(
            "'" __Pyx_FMT_TYPENAME "' object is unsliceable", obj);
    }
bad:
    return NULL;
}


CYTHON_UNUSED static PyObject *
__Pyx_PyList_FromArray(PyObject *const *src, Py_ssize_t n) {
    PyObject *res = PyList_New(n);
    if (unlikely(res == NULL)) return NULL;
    #if CYTHON_COMPILING_IN_CPYTHON
    __Pyx_copy_object_array(src, ((PyListObject*)res)->ob_item, n);
    #else
    Py_ssize_t i;
    for (i = 0; i < n; i++) {
        Py_INCREF(src[i]);
        if (unlikely(__Pyx_PyList_SET_ITEM(res, i, src[i]) < (0))) {
            Py_DECREF(res);
            return NULL;
        }
    }
    #endif
    return res;
}


#if CYTHON_COMPILING_IN_CPYTHON
static CYTHON_INLINE void __Pyx_crop_slice(Py_ssize_t* _start, Py_ssize_t* _stop, Py_ssize_t* _length) {
    Py_ssize_t start = *_start, stop = *_stop, length = *_length;
    if (start < 0) {
        start += length;
        if (start < 0)
            start = 0;
    }
    if (stop < 0)
        stop += length;
    else if (stop > length)
        stop = length;
    *_length = stop - start;
    *_start = start;
    *_stop = stop;
}
static CYTHON_INLINE PyObject* __Pyx_PyTuple_GetSlice(
            PyObject* src, Py_ssize_t start, Py_ssize_t stop) {
    Py_ssize_t length = PyTuple_GET_SIZE(src);
    __Pyx_crop_slice(&start, &stop, &length);
    return __Pyx_PyTuple_FromArray(((PyTupleObject*)src)->ob_item + start, length);
}
static CYTHON_INLINE PyObject* __Pyx_PyList_GetSlice_locked(
            PyObject* src, Py_ssize_t start, Py_ssize_t stop) {
    Py_ssize_t length = PyList_GET_SIZE(src);
    __Pyx_crop_slice(&start, &stop, &length);
    if (length <= 0) {
        return PyList_New(0);
    }
    return __Pyx_PyList_FromArray(((PyListObject*)src)->ob_item + start, length);
}
static CYTHON_INLINE PyObject* __Pyx_PyList_GetSlice(
            PyObject* src, Py_ssize_t start, Py_ssize_t stop) {
    PyObject *result;
    __Pyx_BEGIN_CRITICAL_SECTION(src);
    result = __Pyx_PyList_GetSlice_locked(src, start, stop);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
#endif // CYTHON_COMPILING_IN_CPYTHON


static CYTHON_INLINE void __Pyx_RaiseTooManyValuesError(Py_ssize_t expected) {
    PyErr_Format(PyExc_ValueError,
                 "too many values to unpack (expected %" CYTHON_FORMAT_SSIZE_T "d)", expected);
}


static CYTHON_INLINE void __Pyx_RaiseNeedMoreValuesError(Py_ssize_t index) {
    PyErr_Format(PyExc_ValueError,
                 "need more than %" CYTHON_FORMAT_SSIZE_T "d value%.1s to unpack",
                 index, (index == 1) ? "" : "s");
}


static CYTHON_INLINE int __Pyx_IterFinish(void) {
    PyObject* exc_type;
    __Pyx_PyThreadState_declare
    __Pyx_PyThreadState_assign
    exc_type = __Pyx_PyErr_CurrentExceptionType();
    if (unlikely(exc_type)) {
        if (unlikely(!__Pyx_PyErr_GivenExceptionMatches(exc_type, PyExc_StopIteration)))
            return -1;
        __Pyx_PyErr_Clear();
        return 0;
    }
    return 0;
}


static int __Pyx_IternextUnpackEndCheck(PyObject *retval, Py_ssize_t expected) {
    if (unlikely(retval)) {
        Py_DECREF(retval);
        __Pyx_RaiseTooManyValuesError(expected);
        return -1;
    }
    return __Pyx_IterFinish();
}


static PyObject *__Pyx_AllocateExtensionType(PyTypeObject *t, int is_final) {
    if (is_final || likely(!__Pyx_PyType_HasFeature(t, Py_TPFLAGS_IS_ABSTRACT))) {
        allocfunc alloc_func = __Pyx_PyType_GetSlot(t, tp_alloc, allocfunc);
        return alloc_func(t, 0);
    } else {
        newfunc tp_new = __Pyx_PyType_TryGetSlot(&PyBaseObject_Type, tp_new, newfunc);
    #if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030A0000
        if (!tp_new) {
            PyObject *new_str = PyUnicode_FromString("__new__");
            if (likely(new_str)) {
                PyObject *o = PyObject_CallMethodObjArgs((PyObject *)&PyBaseObject_Type, new_str, t, NULL);
                Py_DECREF(new_str);
                return o;
            } else
                return NULL;
        } else
    #endif
        return tp_new(t, __pyx_mstate_global->__pyx_empty_tuple, 0);
    }
}


static CYTHON_INLINE int __Pyx_CallSlotAsVectorcallUnpackDict(Py_ssize_t args_size, PyObject *keys_dict, PyObject **args, PyObject *kwnames) {
    Py_ssize_t pos = 0, i = 0;
    PyObject *key, *value;
    while (PyDict_Next(keys_dict, &pos, &key, &value)) {
        Py_INCREF(value);
        args[args_size+i] = value;
        Py_INCREF(key);
        if (unlikely(__Pyx_PyTuple_SET_ITEM(kwnames, i, key) == -1)) {
            return -1;
        }
        ++i;
    }
    return 0;
}


#if CYTHON_VECTORCALL_TPNEW
static PyObject * __Pyx_CallTpnewAsVectorcall(__Pyx_tpnewvectorcallfunc f, PyTypeObject* o, PyObject *a, PyObject *k) {
    Py_ssize_t k_size = k ? __Pyx_PyDict_GET_SIZE(k) : 0;
#if !CYTHON_ASSUME_SAFE_SIZE
    if (unlikely(k_size < 0)) return NULL;
#endif
    Py_ssize_t a_size = __Pyx_PyTuple_GET_SIZE(a);
#if !CYTHON_ASSUME_SAFE_SIZE
    if (unlikely(a_size < 0)) return NULL;
#endif
#if CYTHON_ASSUME_SAFE_MACROS
    if (k_size == 0) {
        return f(o, &PyTuple_GET_ITEM(a, 0), a_size, NULL);
    }
#else
    if (k_size == 0 && a_size == 0) {
        return f(o, NULL, 0, NULL);
    }
#endif
    PyObject *stack_args[5];
    PyObject **args = stack_args;
    Py_ssize_t maxnargs = PY_SSIZE_T_MAX / sizeof(PyObject*) - 1;
    if (a_size > maxnargs - k_size) {
        PyErr_NoMemory();
        return NULL;
    }
    Py_ssize_t total_size = a_size + k_size;
    if (total_size > 5) {
        args = (PyObject**)PyMem_Malloc(((size_t)total_size)*sizeof(PyObject*));
        if (unlikely(!args)) {
            PyErr_NoMemory();
            return NULL;
        }
    }
    PyObject * result = NULL;
    PyObject *kwnames = NULL;
    int unpack_dict_result;
    Py_ssize_t i = 0;
    for (; i < a_size; ++i) {
        args[i] = __Pyx_PyTuple_GET_ITEM(a, i);
#if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely(!args[i])) goto cleanup;
#endif
    }
#if !CYTHON_ASSUME_SAFE_MACROS
    if (k)  // There's a specific shortcut earlier for ASSUME_SAFE_MACROS with no keywords
#endif
    {
        kwnames = PyTuple_New(k_size);
        if (unlikely(!kwnames)) goto cleanup;
        __Pyx_BEGIN_CRITICAL_SECTION(k);
        unpack_dict_result = __Pyx_CallSlotAsVectorcallUnpackDict(a_size, k, args, kwnames);
        __Pyx_END_CRITICAL_SECTION();
        if (unlikely(unpack_dict_result == -1)) goto cleanup;
    }
    result = f(o, args, a_size, kwnames);
  cleanup:
    Py_XDECREF(kwnames);
    for (i=a_size; i<total_size; ++i) {
        Py_XDECREF(args[i]);
    }
    if (args != stack_args) {
        PyMem_Free(args);
    }
    return result;
}
#endif


#if CYTHON_VECTORCALL_TPNEW
static PyObject *__Pyx_CallNewInitFromVectorcall(PyTypeObject *t, PyObject *const *args, size_t nargsf, PyObject *kwnames) {
    newfunc tp_new = __Pyx_PyType_GetSlot(t, tp_new, newfunc);
    if (unlikely(!tp_new)) {
        __Pyx_RaiseErrorWithType(PyExc_TypeError, "cannot create " __Pyx_FMT_TYPENAME " instances", t);
        return NULL;
    }
    Py_ssize_t nargs = __Pyx_PyVectorcall_NARGS(nargsf);
    PyObject *result = NULL, *args_tuple = NULL, *kwds_dict = NULL;
    Py_ssize_t kw_size = kwnames ? __Pyx_PyTuple_GET_SIZE(kwnames) : 0;
#if !CYTHON_ASSUME_SAFE_SIZE
    if (unlikely(kw_size == -1)) {
        return NULL;
    }
#endif
    if (kw_size) {
        kwds_dict = __Pyx_PyDict_NewPresized(kw_size);
        if (unlikely(!kwds_dict)) {
            return NULL;
        }
        for (Py_ssize_t i=0; i<kw_size; ++i) {
            PyObject *v = args[nargs + i];
            PyObject *k = __Pyx_PyTuple_GET_ITEM(kwnames, i);
#if !CYTHON_ASSUME_SAFE_MACROS
            if (unlikely(!k)) {
                goto end;
            }
#endif
            if (unlikely(PyDict_SetItem(kwds_dict, k, v) < 0)) {
                goto end;
            }
        }
    }
    if (nargs) {
        args_tuple = __Pyx_PyTuple_FromArray(args, nargs);
        if (unlikely(!args_tuple)) {
            goto end;
        }
    } else {
        args_tuple = __Pyx_NewRef(__pyx_mstate_global->__pyx_empty_tuple);
    }
    result = tp_new(t, args_tuple, kwds_dict);
    if (unlikely(!result)) {
        goto end;
    }
    if (PyObject_TypeCheck(result, t)) {
        initproc tp_init = __Pyx_PyObject_GetSlot(result, tp_init, initproc);
        if (tp_init && unlikely(tp_init(result, args_tuple, kwds_dict) < 0)) {
            Py_CLEAR(result);
        }
    }
  end:
    Py_XDECREF(args_tuple);
    Py_XDECREF(kwds_dict);
    return result;
}
#endif


#if !CYTHON_USE_TYPE_SPECS
#else
static int __Pyx_call_type_traverse(PyObject *o, int always_call, visitproc visit, void *arg) {
    if (!always_call) {
        PyTypeObject *base = __Pyx_PyObject_GetSlot(o, tp_base, PyTypeObject*);
        unsigned long flags = PyType_GetFlags(base);
        if (flags & Py_TPFLAGS_HEAPTYPE) {
            return 0;
        }
    }
    Py_VISIT((PyObject*)Py_TYPE(o));
    return 0;
}
#endif


static CYTHON_INLINE PyObject* __Pyx_PyObject_CallMethod0(PyObject* obj, PyObject* method_name) {
#if CYTHON_VECTORCALL && (__PYX_LIMITED_VERSION_HEX >= 0x030C0000 || !CYTHON_COMPILING_IN_LIMITED_API)
    return PyObject_VectorcallMethod(method_name, &obj, 1 | PY_VECTORCALL_ARGUMENTS_OFFSET, NULL);
#elif CYTHON_COMPILING_IN_LIMITED_API
    return PyObject_CallMethodObjArgs(obj, method_name, NULL);
#else
    return PyObject_CallMethodNoArgs(obj, method_name);
#endif
}


#if !CYTHON_USE_TYPE_SLOTS
CYTHON_UNUSED static Py_ssize_t __Pyx_GetTypeDictOffset(PyObject *tp, int require_cython_valid_result) {
    PyObject *tp_dictoffset_o;
    Py_ssize_t tp_dictoffset;
    tp_dictoffset_o = PyObject_GetAttrString(tp, "__dictoffset__");
    if (unlikely(!tp_dictoffset_o)) return -1;
    tp_dictoffset = PyLong_AsSsize_t(tp_dictoffset_o);
    Py_DECREF(tp_dictoffset_o);
    if (unlikely(require_cython_valid_result && tp_dictoffset == 0)) {
        PyErr_SetString(
            PyExc_TypeError,
            "'type' doesn't have a dictoffset");
        return -1;
    } else if (unlikely(require_cython_valid_result && tp_dictoffset < 0)) {
        PyErr_SetString(
            PyExc_TypeError,
            "'type' has an unexpected negative dictoffset. "
            "Please report this as Cython bug");
        return -1;
    }
    return tp_dictoffset;
}
#endif


static void __Pyx_RaiseErrorWithType1(PyObject* exc_type, const char* message, const char *arg, PyTypeObject *type_obj) {
    __Pyx_TypeName type_name = __Pyx_PyType_GetFullyQualifiedName(type_obj);
    #if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030d0000
    if (unlikely(!type_name)) return;
    #endif
    PyErr_Format(exc_type, message, arg, type_name);
    __Pyx_DECREF_TypeName(type_name);
}


#if CYTHON_COMPILING_IN_CPYTHON || CYTHON_COMPILING_IN_LIMITED_API || CYTHON_USE_TYPE_SPECS
static int __Pyx_validate_bases_tuple(const char *type_name, int has_dictoffset, PyObject *bases) {
    Py_ssize_t i, n;
#if CYTHON_ASSUME_SAFE_SIZE
    n = PyTuple_GET_SIZE(bases);
#else
    n = PyTuple_Size(bases);
    if (unlikely(n < 0)) return -1;
#endif
    if (!has_dictoffset) {
        PyObject *b;
#if CYTHON_AVOID_BORROWED_REFS
        b = PySequence_GetItem(bases, 0);
        if (!b) return -1;
#elif CYTHON_ASSUME_SAFE_MACROS
        b = PyTuple_GET_ITEM(bases, 0);
#else
        b = PyTuple_GetItem(bases, 0);
        if (!b) return -1;
#endif
#if CYTHON_USE_TYPE_SLOTS
        has_dictoffset = ((PyTypeObject*)b)->tp_dictoffset != 0;
#else
        Py_ssize_t dictoffset = __Pyx_GetTypeDictOffset(b, 0);
        has_dictoffset = dictoffset != 0;
#endif
#if CYTHON_AVOID_BORROWED_REFS
        Py_DECREF(b);
#endif
#if !CYTHON_USE_TYPE_SLOTS
        if (dictoffset == -1 && PyErr_Occurred()) return -1;
#endif
    }
    for (i = 1; i < n; i++)
    {
        PyTypeObject *b;
#if CYTHON_AVOID_BORROWED_REFS
        PyObject *b0 = PySequence_GetItem(bases, i);
        if (!b0) return -1;
#elif CYTHON_ASSUME_SAFE_MACROS
        PyObject *b0 = PyTuple_GET_ITEM(bases, i);
#else
        PyObject *b0 = PyTuple_GetItem(bases, i);
        if (!b0) return -1;
#endif
        b = (PyTypeObject*) b0;
        if (!__Pyx_PyType_HasFeature(b, Py_TPFLAGS_HEAPTYPE))
        {
            __Pyx_RaiseErrorWithType(
                PyExc_TypeError, "base class '" __Pyx_FMT_TYPENAME "' is not a heap type", b);
#if CYTHON_AVOID_BORROWED_REFS
            Py_DECREF(b0);
#endif
            return -1;
        }
        if (!has_dictoffset)
        {
            Py_ssize_t b_dictoffset = 0;
#if CYTHON_USE_TYPE_SLOTS
            b_dictoffset = b->tp_dictoffset;
#else
            b_dictoffset = __Pyx_GetTypeDictOffset((PyObject*)b, 0);
            if (b_dictoffset == -1 && PyErr_Occurred()) goto dictoffset_return;
#endif
            if (b_dictoffset) {
                __Pyx_RaiseErrorWithType1(
                    PyExc_TypeError,
                    "extension type '%.200s' has no __dict__ slot, "
                    "but base type '" __Pyx_FMT_TYPENAME "' has: "
                    "either add 'cdef dict __dict__' to the extension type "
                    "or add '__slots__ = [...]' to the base type",
                    type_name, b);
#if !CYTHON_USE_TYPE_SLOTS
              dictoffset_return:
#endif
#if CYTHON_AVOID_BORROWED_REFS
                Py_DECREF(b0);
#endif
                return -1;
            }
        }
#if CYTHON_AVOID_BORROWED_REFS
        Py_DECREF(b0);
#endif
    }
    return 0;
}
#endif


CYTHON_UNUSED static int __Pyx_PyType_HasMultipleInheritance(PyTypeObject *t) {
    while (t) {
        PyObject *bases = __Pyx_PyType_GetSlot(t, tp_bases, PyObject*);
        if (bases) {
            return 1;
        }
        t = __Pyx_PyType_GetSlot(t, tp_base, PyTypeObject*);
    }
    return 0;
}
static int __Pyx_PyType_Ready(PyTypeObject *t) {
#if CYTHON_USE_TYPE_SPECS || !CYTHON_COMPILING_IN_CPYTHON
    (void)__Pyx_PyObject_CallMethod0;
#if CYTHON_USE_TYPE_SPECS
    (void)__Pyx_validate_bases_tuple;
#endif
    return PyType_Ready(t);
#else
    int r;
    if (!__Pyx_PyType_HasMultipleInheritance(t)) {
        return PyType_Ready(t);
    }
    PyObject *bases = __Pyx_PyType_GetSlot(t, tp_bases, PyObject*);
    if (bases && unlikely(__Pyx_validate_bases_tuple(t->tp_name, t->tp_dictoffset != 0, bases) == -1))
        return -1;
    {
        int gc_was_enabled;
    #if PY_VERSION_HEX >= 0x030A00b1
        gc_was_enabled = PyGC_Disable();
        (void)__Pyx_PyObject_CallMethod0;
    #else
        PyObject *ret, *py_status;
        PyObject *gc = NULL;
        #if (!CYTHON_COMPILING_IN_PYPY || PYPY_VERSION_NUM+0 >= 0x07030400) &&\
                !CYTHON_COMPILING_IN_GRAAL
        gc = PyImport_GetModule(__pyx_mstate_global->__pyx_kp_u_gc);
        #endif
        if (unlikely(!gc)) gc = PyImport_Import(__pyx_mstate_global->__pyx_kp_u_gc);
        if (unlikely(!gc)) return -1;
        py_status = __Pyx_PyObject_CallMethod0(gc, __pyx_mstate_global->__pyx_kp_u_isenabled);
        if (unlikely(!py_status)) {
            Py_DECREF(gc);
            return -1;
        }
        gc_was_enabled = __Pyx_PyObject_IsTrue(py_status);
        Py_DECREF(py_status);
        if (gc_was_enabled > 0) {
            ret = __Pyx_PyObject_CallMethod0(gc, __pyx_mstate_global->__pyx_kp_u_disable);
            if (unlikely(!ret)) {
                Py_DECREF(gc);
                return -1;
            }
            Py_DECREF(ret);
        } else if (unlikely(gc_was_enabled == -1)) {
            Py_DECREF(gc);
            return -1;
        }
    #endif
        t->tp_flags |= Py_TPFLAGS_HEAPTYPE;
#if PY_VERSION_HEX >= 0x030A0000
        t->tp_flags |= Py_TPFLAGS_IMMUTABLETYPE;
#endif
        r = PyType_Ready(t);
        t->tp_flags &= ~Py_TPFLAGS_HEAPTYPE;
    #if PY_VERSION_HEX >= 0x030A00b1
        if (gc_was_enabled)
            PyGC_Enable();
    #else
        if (gc_was_enabled) {
            PyObject *tp, *v, *tb;
            PyErr_Fetch(&tp, &v, &tb);
            ret = __Pyx_PyObject_CallMethod0(gc, __pyx_mstate_global->__pyx_kp_u_enable);
            if (likely(ret || r == -1)) {
                Py_XDECREF(ret);
                PyErr_Restore(tp, v, tb);
            } else {
                Py_XDECREF(tp);
                Py_XDECREF(v);
                Py_XDECREF(tb);
                r = -1;
            }
        }
        Py_DECREF(gc);
    #endif
    }
    return r;
#endif
}


#if __PYX_LIMITED_VERSION_HEX < 0x030d0000
static CYTHON_INLINE int __Pyx_HasAttr(PyObject *o, PyObject *n) {
    PyObject *r;
    if (unlikely(!PyUnicode_Check(n))) {
        PyErr_SetString(PyExc_TypeError,
                        "hasattr(): attribute name must be string");
        return -1;
    }
    r = __Pyx_PyObject_GetAttrStrNoError(o, n);
    if (!r) {
        return (unlikely(PyErr_Occurred())) ? -1 : 0;
    } else {
        Py_DECREF(r);
        return 1;
    }
}
#endif


static int __Pyx__Import_GetModule(PyObject *qualname, PyObject **module) {
    PyObject *imported_module = PyImport_GetModule(qualname);
    if (unlikely(!imported_module)) {
        *module = NULL;
        if (PyErr_Occurred()) {
            return -1;
        }
        return 0;
    }
    *module = imported_module;
    return 1;
}
static int __Pyx__Import_Lookup(PyObject *qualname, PyObject *const *imported_names, Py_ssize_t len_imported_names, PyObject **module) {
    PyObject *imported_module;
    PyObject *top_level_package_name;
    Py_ssize_t i;
    int status, module_found;
    Py_ssize_t dot_index;
    module_found = __Pyx__Import_GetModule(qualname, &imported_module);
    if (unlikely(!module_found || module_found == -1)) {
        *module = NULL;
        return module_found;
    }
    if (imported_names) {
        for (i = 0; i < len_imported_names; i++) {
            PyObject *imported_name = imported_names[i];
#if __PYX_LIMITED_VERSION_HEX < 0x030d0000
            int has_imported_attribute = PyObject_HasAttr(imported_module, imported_name);
#else
            int has_imported_attribute = PyObject_HasAttrWithError(imported_module, imported_name);
            if (unlikely(has_imported_attribute == -1)) goto error;
#endif
            if (!has_imported_attribute) {
                goto not_found;
            }
        }
        *module = imported_module;
        return 1;
    }
    dot_index = PyUnicode_FindChar(qualname, '.', 0, PY_SSIZE_T_MAX, 1);
    if (dot_index == -1) {
        *module = imported_module;
        return 1;
    }
    if (unlikely(dot_index == -2)) goto error;
    top_level_package_name = PyUnicode_Substring(qualname, 0, dot_index);
    if (unlikely(!top_level_package_name)) goto error;
    Py_DECREF(imported_module);
    status = __Pyx__Import_GetModule(top_level_package_name, module);
    Py_DECREF(top_level_package_name);
    return status;
error:
    Py_DECREF(imported_module);
    *module = NULL;
    return -1;
not_found:
    Py_DECREF(imported_module);
    *module = NULL;
    return 0;
}
static PyObject *__Pyx__Import(PyObject *name, PyObject *const *imported_names, Py_ssize_t len_imported_names, PyObject *qualname, PyObject *moddict, int level) {
    PyObject *module = 0;
    PyObject *empty_dict = 0;
    PyObject *from_list = 0;
    int module_found;
    if (!qualname) {
        qualname = name;
    }
    module_found = __Pyx__Import_Lookup(qualname, imported_names, len_imported_names, &module);
    if (likely(module_found == 1)) {
        return module;
    } else if (unlikely(module_found == -1)) {
        return NULL;
    }
    #if !CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX >= 0x030f00a6
    empty_dict = PyFrozenDict_New(NULL);
    #else
    empty_dict = PyDict_New();
    #endif
    if (unlikely(!empty_dict))
        goto bad;
    if (imported_names) {
        from_list = __Pyx_PyList_FromArray(imported_names, len_imported_names);
        if (unlikely(!from_list))
            goto bad;
    }
    if (level == -1) {
        const char* package_sep = strchr(__Pyx_MODULE_NAME, '.');
        if (package_sep != (0)) {
            module = PyImport_ImportModuleLevelObject(
                name, moddict, empty_dict, from_list, 1);
            if (unlikely(!module)) {
                if (unlikely(!PyErr_ExceptionMatches(PyExc_ImportError)))
                    goto bad;
                PyErr_Clear();
            }
        }
        level = 0;
    }
    if (!module) {
        module = PyImport_ImportModuleLevelObject(
            name, moddict, empty_dict, from_list, level);
    }
bad:
    Py_XDECREF(from_list);
    Py_XDECREF(empty_dict);
    return module;
}


static PyObject *__Pyx_Import(PyObject *name, PyObject *const *imported_names, Py_ssize_t len_imported_names, PyObject *qualname, int level) {
    return __Pyx__Import(name, imported_names, len_imported_names, qualname, __pyx_mstate_global->__pyx_d, level);
}


static PyObject* __Pyx_ImportFrom(PyObject* module, PyObject* name) {
    PyObject* value = __Pyx_PyObject_GetAttrStr(module, name);
    if (unlikely(!value) && PyErr_ExceptionMatches(PyExc_AttributeError)) {
        const char* module_name_str = 0;
        PyObject* module_name = 0;
        PyObject* module_dot = 0;
        PyObject* full_name = 0;
        PyErr_Clear();
        module_name_str = PyModule_GetName(module);
        if (unlikely(!module_name_str)) { goto modbad; }
        module_name = PyUnicode_FromString(module_name_str);
        if (unlikely(!module_name)) { goto modbad; }
        module_dot = PyUnicode_Concat(module_name, __pyx_mstate_global->__pyx_kp_u__9);
        if (unlikely(!module_dot)) { goto modbad; }
        full_name = PyUnicode_Concat(module_dot, name);
        if (unlikely(!full_name)) { goto modbad; }
        #if (CYTHON_COMPILING_IN_PYPY && PYPY_VERSION_NUM  < 0x07030400) ||\
                CYTHON_COMPILING_IN_GRAAL
        {
            PyObject *modules = PyImport_GetModuleDict();
            if (unlikely(!modules))
                goto modbad;
            value = PyObject_GetItem(modules, full_name);
        }
        #else
        value = PyImport_GetModule(full_name);
        #endif
      modbad:
        Py_XDECREF(full_name);
        Py_XDECREF(module_dot);
        Py_XDECREF(module_name);
    }
    if (unlikely(!value)) {
        PyErr_Format(PyExc_ImportError, "cannot import name %S", name);
    }
    return value;
}


static CYTHON_INLINE PyObject *__Pyx_PyDict_SetDefault(PyObject *d, PyObject *key, PyObject *default_value) {
    PyObject* value;
#if __PYX_LIMITED_VERSION_HEX >= 0x030F0000 || (!CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX >= 0x030d00A4)
    PyDict_SetDefaultRef(d, key, default_value, &value);
#elif CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX >= 0x030C0000
    PyObject *args[] = {d, key, default_value};
    value = PyObject_VectorcallMethod(__pyx_mstate_global->__pyx_n_u_setdefault, args, 3 | PY_VECTORCALL_ARGUMENTS_OFFSET, NULL);
#elif CYTHON_COMPILING_IN_LIMITED_API
    value = PyObject_CallMethodObjArgs(d, __pyx_mstate_global->__pyx_n_u_setdefault, key, default_value, NULL);
#else
    value = PyDict_SetDefault(d, key, default_value);
    if (unlikely(!value)) return NULL;
    Py_INCREF(value);
#endif
    return value;
}


#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING && PY_VERSION_HEX < 0x030F00a3
  static PyObject *__Pyx_PyImport_AddModuleObjectRef(PyObject *name) {
      PyObject *module_dict = PyImport_GetModuleDict();
      PyObject *m;
      if (PyMapping_GetOptionalItem(module_dict, name, &m) < 0) {
          return NULL;
      }
      if (m != NULL && PyModule_Check(m)) {
          return m;
      }
      Py_XDECREF(m);
      m = PyModule_NewObject(name);
      if (m == NULL)
          return NULL;
      if (PyDict_CheckExact(module_dict)) {
          PyObject *new_m;
          (void)PyDict_SetDefaultRef(module_dict, name, m, &new_m);
          Py_DECREF(m);
          return new_m;
      } else {
           if (PyObject_SetItem(module_dict, name, m) != 0) {
                Py_DECREF(m);
                return NULL;
            }
            return m;
      }
  }
  static PyObject *__Pyx_PyImport_AddModuleRef(const char *name) {
      if ((PY_VERSION_HEX >= 0x030E0000) &&  Py_Version >= 0x030E0100) {
          return PyImport_AddModuleRef(name);
      }
      PyObject *py_name = PyUnicode_FromString(name);
      if (!py_name) return NULL;
      PyObject *module = __Pyx_PyImport_AddModuleObjectRef(py_name);
      Py_DECREF(py_name);
      return module;
  }
#elif __PYX_LIMITED_VERSION_HEX < 0x030d0000
  static PyObject *__Pyx_PyImport_AddModuleRef(const char *name) {
      PyObject *module = PyImport_AddModule(name);
      Py_XINCREF(module);
      return module;
  }
#endif


static PyObject *__Pyx_FetchSharedCythonABIModule(void) {
    return __Pyx_PyImport_AddModuleRef(__PYX_ABI_MODULE_NAME);
}


static int __Pyx_VerifyCachedType(PyObject *cached_type,
                               const char *name,
                               Py_ssize_t expected_basicsize) {
    Py_ssize_t basicsize;
    if (!PyType_Check(cached_type)) {
        PyErr_Format(PyExc_TypeError,
            "Shared Cython type %.200s is not a type object", name);
        return -1;
    }
    if (expected_basicsize == 0) {
        return 0; // size is inherited, nothing useful to check
    }
#if CYTHON_COMPILING_IN_LIMITED_API && CYTHON_OPAQUE_OBJECTS
    if (expected_basicsize < 0) {
        basicsize = PyType_GetTypeDataSize((PyTypeObject*)cached_type);
    } else
#endif
    {
    #if CYTHON_COMPILING_IN_LIMITED_API
        PyObject *py_basicsize;
        py_basicsize = PyObject_GetAttrString(cached_type, "__basicsize__");
        if (unlikely(!py_basicsize)) return -1;
        basicsize = PyLong_AsSsize_t(py_basicsize);
        Py_DECREF(py_basicsize);
        py_basicsize = NULL;
        if (unlikely(basicsize == (Py_ssize_t)-1) && PyErr_Occurred()) return -1;
    #else
        basicsize = ((PyTypeObject*) cached_type)->tp_basicsize;
    #endif
    }
    if ((expected_basicsize >= 0) ?
            (basicsize != expected_basicsize) :
            (basicsize < -expected_basicsize)) {
        PyErr_Format(PyExc_TypeError,
            "Shared Cython type %.200s has the wrong size, try recompiling",
            name);
        return -1;
    }
    return 0;
}


#if __PYX_LIMITED_VERSION_HEX < 0x030C0000
static PyObject* __Pyx_PyType_FromMetaclass(PyTypeObject *metaclass, PyObject *module, PyType_Spec *spec, PyObject *bases) {
    PyObject *result = __Pyx_PyType_FromModuleAndSpec(module, spec, bases);
    if (result && metaclass) {
        PyObject *old_tp = (PyObject*)Py_TYPE(result);
        Py_INCREF((PyObject*)metaclass);
        Py_SET_TYPE(result, metaclass);
        Py_DECREF(old_tp);
        PyType_Modified((PyTypeObject*)result);
    }
    return result;
}
#else
#define __Pyx_PyType_FromMetaclass(me, mo, s, b) PyType_FromMetaclass(me, mo, s, b)
#endif
static PyTypeObject *__Pyx_FetchCommonTypeFromSpec(PyTypeObject *metaclass, PyObject *module, PyType_Spec *spec, PyObject *bases) {
    PyObject *abi_module = NULL, *cached_type = NULL, *abi_module_dict, *new_cached_type, *py_object_name;
    int get_item_ref_result;
    const char* object_name = strrchr(spec->name, '.');
    object_name = object_name ? object_name+1 : spec->name;
    py_object_name = PyUnicode_FromString(object_name);
    if (!py_object_name) return NULL;
    abi_module = __Pyx_FetchSharedCythonABIModule();
    if (!abi_module) goto done;
    abi_module_dict = PyModule_GetDict(abi_module);
    if (!abi_module_dict) goto done;
    get_item_ref_result = __Pyx_PyDict_GetItemRef(abi_module_dict, py_object_name, &cached_type);
    if (get_item_ref_result == 1) {
        if (__Pyx_VerifyCachedType(
              cached_type,
              object_name,
              spec->basicsize) < 0) {
            goto bad;
        }
        goto done;
    } else if (unlikely(get_item_ref_result == -1)) {
        goto bad;
    }
    cached_type = __Pyx_PyType_FromMetaclass(
        metaclass,
        CYTHON_USE_MODULE_STATE ? module : abi_module,
        spec, bases);
    if (unlikely(!cached_type)) goto bad;
    new_cached_type = __Pyx_PyDict_SetDefault(abi_module_dict, py_object_name, cached_type);
    if (unlikely(new_cached_type != cached_type)) {
        if (unlikely(!new_cached_type)) goto bad;
        Py_DECREF(cached_type);
        cached_type = new_cached_type;
        if (__Pyx_VerifyCachedType(
                cached_type,
                object_name,
                spec->basicsize) < 0) {
            goto bad;
        }
        goto done;
    } else {
        Py_DECREF(new_cached_type);
    }
done:
    Py_XDECREF(abi_module);
    Py_DECREF(py_object_name);
    assert(cached_type == NULL || PyType_Check(cached_type));
    return (PyTypeObject *) cached_type;
bad:
    Py_XDECREF(cached_type);
    cached_type = NULL;
    goto done;
}


static PyObject* __pyx_CommonTypesMetaclass_get_module(CYTHON_UNUSED PyObject *self, CYTHON_UNUSED void* context) {
    return PyUnicode_FromString(__PYX_ABI_MODULE_NAME);
}
#if __PYX_LIMITED_VERSION_HEX < 0x030A0000
static PyObject* __pyx_CommonTypesMetaclass_call(CYTHON_UNUSED PyObject *self, CYTHON_UNUSED PyObject *args, CYTHON_UNUSED PyObject *kwds) {
    PyErr_SetString(PyExc_TypeError, "Cannot instantiate Cython internal types");
    return NULL;
}
static int __pyx_CommonTypesMetaclass_setattr(CYTHON_UNUSED PyObject *self, CYTHON_UNUSED PyObject *attr, CYTHON_UNUSED PyObject *value) {
    PyErr_SetString(PyExc_TypeError, "Cython internal types are immutable");
    return -1;
}
#endif
static PyGetSetDef __pyx_CommonTypesMetaclass_getset[] = {
    {"__module__", __pyx_CommonTypesMetaclass_get_module, NULL, NULL, NULL},
    {0, 0, 0, 0, 0}
};
static PyType_Slot __pyx_CommonTypesMetaclass_slots[] = {
    {Py_tp_getset, (void *)__pyx_CommonTypesMetaclass_getset},
    #if __PYX_LIMITED_VERSION_HEX < 0x030A0000
    {Py_tp_call, (void*)__pyx_CommonTypesMetaclass_call},
    {Py_tp_new, (void*)__pyx_CommonTypesMetaclass_call},
    {Py_tp_setattro, (void*)__pyx_CommonTypesMetaclass_setattr},
    #endif
    {0, 0}
};
static PyType_Spec __pyx_CommonTypesMetaclass_spec = {
    __PYX_TYPE_MODULE_PREFIX "_common_types_metatype",
    0,
    0,
    Py_TPFLAGS_IMMUTABLETYPE |
    Py_TPFLAGS_DISALLOW_INSTANTIATION |
    Py_TPFLAGS_DEFAULT,
    __pyx_CommonTypesMetaclass_slots
};
static int __pyx_CommonTypesMetaclass_init(PyObject *module) {
    __pyx_mstatetype *mstate = __Pyx_PyModule_GetState(module);
    PyObject *bases = PyTuple_Pack(1, &PyType_Type);
    if (unlikely(!bases)) {
        return -1;
    }
    mstate->__pyx_CommonTypesMetaclassType = __Pyx_FetchCommonTypeFromSpec(NULL, module, &__pyx_CommonTypesMetaclass_spec, bases);
    Py_DECREF(bases);
    if (unlikely(mstate->__pyx_CommonTypesMetaclassType == NULL)) {
        return -1;
    }
    return 0;
}


#if CYTHON_COMPILING_IN_LIMITED_API
static CYTHON_INLINE int __Pyx__IsSameCyOrCFunctionNoMethod(PyObject *func, void (*cfunc)(void)) {
    if (__Pyx_CyFunction_Check(func)) {
        return __Pyx_as_CyFunctionObject(func)->func_methoddef->ml_meth == (PyCFunction) cfunc;
    } else if (PyCFunction_Check(func)) {
        return PyCFunction_GetFunction(func) == (PyCFunction) cfunc;
    }
    return 0;
}
static CYTHON_INLINE int __Pyx__IsSameCyOrCFunction(PyObject *func, void (*cfunc)(void)) {
    if ((PyObject*)Py_TYPE(func) == __pyx_mstate_global->__Pyx_CachedMethodType) {
        int result;
        PyObject *newFunc = PyObject_GetAttr(func, __pyx_mstate_global->__pyx_n_u_func);
        if (unlikely(!newFunc)) {
            PyErr_Clear(); // It's only an optimization, so don't throw an error
            return 0;
        }
        result = __Pyx__IsSameCyOrCFunctionNoMethod(newFunc, cfunc);
        Py_DECREF(newFunc);
        return result;
    }
    return __Pyx__IsSameCyOrCFunctionNoMethod(func, cfunc);
}
#else
static CYTHON_INLINE int __Pyx__IsSameCyOrCFunction(PyObject *func, void (*cfunc)(void)) {
    if (PyMethod_Check(func)) {
        func = PyMethod_GET_FUNCTION(func);
    }
    return __Pyx_CyOrPyCFunction_Check(func) && __Pyx_CyOrPyCFunction_GET_FUNCTION(func) == (PyCFunction) cfunc;
}
#endif
static CYTHON_INLINE void __Pyx__CyFunction_SetClassObj(__pyx_CyFunctionObject* f, PyObject* classobj) {
#if CYTHON_COMPILING_IN_LIMITED_API
    __Pyx_Py_XDECREF_SET(
        __Pyx__CyFunction_GetClassObj(f),
            ((classobj) ? __Pyx_NewRef(classobj) : NULL));
#else
    __Pyx_Py_XDECREF_SET(
        ((PyCMethodObject *) (f))->mm_class,
        (PyTypeObject*)((classobj) ? __Pyx_NewRef(classobj) : NULL));
#endif
}
static CYTHON_INLINE PyObject *__Pyx_CyFunction_InitDefaults(PyObject *func, PyTypeObject *defaults_type) {
    __pyx_CyFunctionObject *m = __Pyx_as_CyFunctionObject(func);
    m->defaults = PyObject_CallObject((PyObject*)defaults_type, NULL); // _PyObject_New(defaults_type);
    if (unlikely(!m->defaults))
        return NULL;
    return m->defaults;
}
static CYTHON_INLINE void __Pyx_CyFunction_SetDefaultsTuple(PyObject *func, PyObject *tuple) {
    __pyx_CyFunctionObject *m = __Pyx_as_CyFunctionObject(func);
    m->defaults_tuple = tuple;
    Py_INCREF(tuple);
}
static CYTHON_INLINE void __Pyx_CyFunction_SetDefaultsKwDict(PyObject *func, PyObject *dict) {
    __pyx_CyFunctionObject *m = __Pyx_as_CyFunctionObject(func);
    m->defaults_kwdict = dict;
    Py_INCREF(dict);
}
static CYTHON_INLINE void __Pyx_CyFunction_SetAnnotationsDict(PyObject *func, PyObject *dict) {
    __pyx_CyFunctionObject *m = __Pyx_as_CyFunctionObject(func);
    m->func_annotations = dict;
    Py_INCREF(dict);
}


#if CYTHON_COMPILING_IN_LIMITED_API
static PyObject *__Pyx_PyMethod_New(PyObject *func, PyObject *self, PyObject *typ) {
    PyObject *result;
    CYTHON_UNUSED_VAR(typ);
    if (!self)
        return __Pyx_NewRef(func);
    #if __PYX_LIMITED_VERSION_HEX >= 0x030C0000
    {
        PyObject *args[] = {func, self};
        result = PyObject_Vectorcall(__pyx_mstate_global->__Pyx_CachedMethodType, args, 2, NULL);
    }
    #else
    result = PyObject_CallFunctionObjArgs(__pyx_mstate_global->__Pyx_CachedMethodType, func, self, NULL);
    #endif
    return result;
}
#else
static PyObject *__Pyx_PyMethod_New(PyObject *func, PyObject *self, PyObject *typ) {
    CYTHON_UNUSED_VAR(typ);
    if (!self)
        return __Pyx_NewRef(func);
    return PyMethod_New(func, self);
}
#endif


#if CYTHON_VECTORCALL
static PyObject *__Pyx_PyVectorcall_FastCallDict_kw(PyObject *func, __pyx_vectorcallfunc vc, PyObject *const *args, size_t nargs, PyObject *kw)
{
    PyObject *res = NULL;
    PyObject *kwnames;
    PyObject **newargs;
    PyObject **kwvalues;
    Py_ssize_t i;
    #if CYTHON_AVOID_BORROWED_REFS
    PyObject *pos;
    #else
    Py_ssize_t pos;
    #endif
    size_t j;
    PyObject *key, *value;
    unsigned long keys_are_strings;
    #if !CYTHON_ASSUME_SAFE_SIZE
    Py_ssize_t nkw = PyDict_Size(kw);
    if (unlikely(nkw == -1)) return NULL;
    #else
    Py_ssize_t nkw = PyDict_GET_SIZE(kw);
    #endif
    newargs = (PyObject **)PyMem_Malloc((nargs + (size_t)nkw) * sizeof(args[0]));
    if (unlikely(newargs == NULL)) {
        PyErr_NoMemory();
        return NULL;
    }
    for (j = 0; j < nargs; j++) newargs[j] = args[j];
    kwnames = PyTuple_New(nkw);
    if (unlikely(kwnames == NULL)) {
        PyMem_Free(newargs);
        return NULL;
    }
    kwvalues = newargs + nargs;
    pos = 0;
    i = 0;
    keys_are_strings = Py_TPFLAGS_UNICODE_SUBCLASS;
    while (__Pyx_PyDict_NextRef(kw, &pos, &key, &value)) {
        keys_are_strings &=
        #if CYTHON_COMPILING_IN_LIMITED_API
            PyType_GetFlags(Py_TYPE(key));
        #else
            Py_TYPE(key)->tp_flags;
        #endif
        #if !CYTHON_ASSUME_SAFE_MACROS
        if (unlikely(PyTuple_SetItem(kwnames, i, key) < 0)) goto cleanup;
        #else
        PyTuple_SET_ITEM(kwnames, i, key);
        #endif
        kwvalues[i] = value;
        i++;
    }
    if (unlikely(!keys_are_strings)) {
        PyErr_SetString(PyExc_TypeError, "keywords must be strings");
        goto cleanup;
    }
    res = vc(func, newargs, nargs, kwnames);
cleanup:
    #if CYTHON_AVOID_BORROWED_REFS
    Py_DECREF(pos);
    #endif
    Py_DECREF(kwnames);
    for (i = 0; i < nkw; i++)
        Py_DECREF(kwvalues[i]);
    PyMem_Free(newargs);
    return res;
}
static CYTHON_INLINE PyObject *__Pyx_PyVectorcall_FastCallDict(PyObject *func, __pyx_vectorcallfunc vc, PyObject *const *args, size_t nargs, PyObject *kw)
{
    Py_ssize_t kw_size =
        likely(kw == NULL) ?
        0 :
#if !CYTHON_ASSUME_SAFE_SIZE
        PyDict_Size(kw);
#else
        PyDict_GET_SIZE(kw);
#endif
    if (kw_size == 0) {
        return vc(func, args, nargs, NULL);
    }
#if !CYTHON_ASSUME_SAFE_SIZE
    else if (unlikely(kw_size == -1)) {
        return NULL;
    }
#endif
    return __Pyx_PyVectorcall_FastCallDict_kw(func, vc, args, nargs, kw);
}
#endif


static PyObject *
__Pyx_CyFunction_get_doc_locked(__pyx_CyFunctionObject *op)
{
    if (unlikely(op->func_doc == NULL)) {
#if CYTHON_COMPILING_IN_LIMITED_API
        const char *doc = op->func_methoddef->ml_doc;
#else
        const char *doc = ((PyCFunctionObject*)op)->m_ml->ml_doc;
#endif
        if (doc) {
            op->func_doc = PyUnicode_FromString(doc);
            if (unlikely(op->func_doc == NULL))
                return NULL;
        } else {
            Py_INCREF(Py_None);
            return Py_None;
        }
    }
    Py_INCREF(op->func_doc);
    return op->func_doc;
}
static PyObject *
__Pyx_CyFunction_get_doc(PyObject *op_in, void *closure) {
    PyObject *result;
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    CYTHON_UNUSED_VAR(closure);
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    result = __Pyx_CyFunction_get_doc_locked(op);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_doc(PyObject *op_in, PyObject *value, void *context)
{
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    CYTHON_UNUSED_VAR(context);
    if (value == NULL) {
        value = Py_None;
    }
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    __Pyx_Py_XDECREF_SET(op->func_doc, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_name_locked(__pyx_CyFunctionObject *op)
{
    if (unlikely(op->func_name == NULL)) {
#if CYTHON_COMPILING_IN_LIMITED_API
        const char *name = op->func_methoddef->ml_name;
#else
        const char *name = ((PyCFunctionObject*)op)->m_ml->ml_name;
#endif
        op->func_name = PyUnicode_InternFromString(name);
        if (unlikely(op->func_name == NULL))
            return NULL;
    }
    Py_INCREF(op->func_name);
    return op->func_name;
}
static PyObject *
__Pyx_CyFunction_get_name(PyObject *op, void *context)
{
    PyObject *result = NULL;
    CYTHON_UNUSED_VAR(context);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    result = __Pyx_CyFunction_get_name_locked(__Pyx_as_CyFunctionObject(op));
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_name(PyObject *op_in, PyObject *value, void *context)
{
    CYTHON_UNUSED_VAR(context);
    if (unlikely(value == NULL || !PyUnicode_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__name__ must be set to a string object");
        return -1;
    }
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    __Pyx_Py_XDECREF_SET(op->func_name, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_qualname(PyObject *op_in, void *context)
{
    CYTHON_UNUSED_VAR(context);
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    PyObject *result;
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    Py_INCREF(op->func_qualname);
    result = op->func_qualname;
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_qualname(PyObject *op_in, PyObject *value, void *context)
{
    CYTHON_UNUSED_VAR(context);
    if (unlikely(value == NULL || !PyUnicode_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__qualname__ must be set to a string object");
        return -1;
    }
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    __Pyx_Py_XDECREF_SET(op->func_qualname, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030A0000
static PyObject *
__Pyx_CyFunction_get_dict(__pyx_CyFunctionObject *op, void *context)
{
    CYTHON_UNUSED_VAR(context);
    if (unlikely(op->func_dict == NULL)) {
        op->func_dict = PyDict_New();
        if (unlikely(op->func_dict == NULL))
            return NULL;
    }
    Py_INCREF(op->func_dict);
    return op->func_dict;
}
#endif
static PyObject *
__Pyx_CyFunction_get_globals(PyObject *op_in, void *context)
{
    CYTHON_UNUSED_VAR(context);
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    Py_INCREF(op->func_globals);
    return op->func_globals;
}
static PyObject *
__Pyx_CyFunction_get_closure(PyObject *op, void *context)
{
    CYTHON_UNUSED_VAR(op);
    CYTHON_UNUSED_VAR(context);
    Py_INCREF(Py_None);
    return Py_None;
}
static PyObject *
__Pyx_CyFunction_get_code(PyObject *op_in, void *context)
{
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    PyObject* result = (op->func_code) ? op->func_code : Py_None;
    CYTHON_UNUSED_VAR(context);
    Py_INCREF(result);
    return result;
}
static int
__Pyx_CyFunction_init_defaults(__pyx_CyFunctionObject *op, PyObject *op_obj) {
    int result = 0;
    PyObject *res = op->defaults_getter(op_obj);
    if (unlikely(!res))
        return -1;
    #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
    op->defaults_tuple = PyTuple_GET_ITEM(res, 0);
    Py_INCREF(op->defaults_tuple);
    op->defaults_kwdict = PyTuple_GET_ITEM(res, 1);
    Py_INCREF(op->defaults_kwdict);
    #else
    op->defaults_tuple = __Pyx_PySequence_ITEM(res, 0);
    if (unlikely(!op->defaults_tuple)) result = -1;
    else {
        op->defaults_kwdict = __Pyx_PySequence_ITEM(res, 1);
        if (unlikely(!op->defaults_kwdict)) result = -1;
    }
    #endif
    Py_DECREF(res);
    return result;
}
static int
__Pyx_CyFunction_set_defaults(PyObject *op_in, PyObject* value, void *context) {
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    CYTHON_UNUSED_VAR(context);
    if (!value) {
        value = Py_None;
    } else if (unlikely(value != Py_None && !PyTuple_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__defaults__ must be set to a tuple object");
        return -1;
    }
    PyErr_WarnEx(PyExc_RuntimeWarning, "changes to cyfunction.__defaults__ will not "
                 "currently affect the values used in function calls", 1);
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    __Pyx_Py_XDECREF_SET(op->defaults_tuple, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_defaults_locked(PyObject *op_in) {
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    PyObject* result = op->defaults_tuple;
    if (unlikely(!result)) {
        if (op->defaults_getter) {
            if (unlikely(__Pyx_CyFunction_init_defaults(op, op_in) < 0)) return NULL;
            result = op->defaults_tuple;
        } else {
            result = Py_None;
        }
    }
    Py_INCREF(result);
    return result;
}
static PyObject *
__Pyx_CyFunction_get_defaults(PyObject *op, void *context) {
    PyObject* result = NULL;
    CYTHON_UNUSED_VAR(context);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    result = __Pyx_CyFunction_get_defaults_locked(op);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int
__Pyx_CyFunction_set_kwdefaults(PyObject *op_in, PyObject* value, void *context) {
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    CYTHON_UNUSED_VAR(context);
    if (!value) {
        value = Py_None;
    } else if (unlikely(value != Py_None && !PyDict_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__kwdefaults__ must be set to a dict object");
        return -1;
    }
    PyErr_WarnEx(PyExc_RuntimeWarning, "changes to cyfunction.__kwdefaults__ will not "
                 "currently affect the values used in function calls", 1);
    Py_INCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    __Pyx_Py_XDECREF_SET(op->defaults_kwdict, value);
    __Pyx_END_CRITICAL_SECTION();
    return 0;
}
static PyObject *
__Pyx_CyFunction_get_kwdefaults_locked(PyObject *op_in) {
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    PyObject* result = op->defaults_kwdict;
    if (unlikely(!result)) {
        if (op->defaults_getter) {
            if (unlikely(__Pyx_CyFunction_init_defaults(op, op_in) < 0)) return NULL;
            result = op->defaults_kwdict;
        } else {
            result = Py_None;
        }
    }
    Py_INCREF(result);
    return result;
}
static PyObject *
__Pyx_CyFunction_get_kwdefaults(PyObject *op, void *context) {
    PyObject* result;
    CYTHON_UNUSED_VAR(context);
    __Pyx_BEGIN_CRITICAL_SECTION(op);
    result = __Pyx_CyFunction_get_kwdefaults_locked(op);
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static int __Pyx_CyFunction_set_annotate_in_dict_if_exists(PyObject *op_in, PyObject *value);
static int
__Pyx_CyFunction_set_annotations(PyObject *op_in, PyObject* value, void *context) {
    CYTHON_UNUSED_VAR(context);
    if (!value || value == Py_None) {
        value = NULL;
    } else if (unlikely(!PyDict_Check(value))) {
        PyErr_SetString(PyExc_TypeError,
                        "__annotations__ must be set to a dict object");
        return -1;
    }
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    Py_XINCREF(value);
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    __Pyx_Py_XDECREF_SET(op->func_annotations, value);
    __Pyx_END_CRITICAL_SECTION();
    if (unlikely(__Pyx_CyFunction_set_annotate_in_dict_if_exists(op_in, Py_None) < 0)) return -1;
    return 0;
}
static int
__Pyx_CyFunction_get_dict_if_exists(PyObject *op_in, PyObject **dict) {
    
#if CYTHON_COMPILING_IN_PYPY
    *dict = PyObject_GenericGetDict(op_in, NULL);
#elif CYTHON_COMPILING_IN_LIMITED_API || PY_VERSION_HEX < 0x030C0000
    *dict = __Pyx_as_CyFunctionObject(op_in)->func_dict;
#else
    PyObject **dictptr = _PyObject_GetDictPtr(op_in);
    *dict = likely(dictptr) ? *dictptr : NULL;
#endif
    return *dict ? 1 : 0;
}
static int
__Pyx_CyFunction_get_annotate_from_dict_if_exists(PyObject *op_in, PyObject **annotate) {
    PyObject *dict;
    int dict_found;
    *annotate = NULL;
    dict_found = __Pyx_CyFunction_get_dict_if_exists(op_in, &dict);
    if (!dict_found) return 0;
    return __Pyx_PyDict_GetItemRef(dict, __pyx_mstate_global->__pyx_n_u_annotate, annotate);
}
static int
__Pyx_CyFunction_set_annotate_in_dict_if_exists(PyObject *op_in, PyObject *value) {
    PyObject *dict;
    int dict_found;
    dict_found = __Pyx_CyFunction_get_dict_if_exists(op_in, &dict);
    if (!dict_found) return 0;
    if (value) {
        return PyDict_SetItem(dict, __pyx_mstate_global->__pyx_n_u_annotate, value);
    } else {
#if !CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX >= 0x030d0000
        return PyDict_Pop(dict, __pyx_mstate_global->__pyx_n_u_annotate, NULL);
#else
        int result = PyDict_Contains(dict, __pyx_mstate_global->__pyx_n_u_annotate);
        if (result == 1) {
            result = PyDict_DelItem(dict, __pyx_mstate_global->__pyx_n_u_annotate);
        }
        return result;
#endif
    }
}
static int
__Pyx_CyFunction_set_annotate_in_dict(PyObject *op_in, PyObject *value) {
    PyObject *dict;
    int result;
#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030A0000
    dict = __Pyx_CyFunction_get_dict(__Pyx_as_CyFunctionObject(op_in), NULL);
#else
    dict = PyObject_GenericGetDict(op_in, NULL);
#endif
    if (unlikely(!dict)) return -1;
    result = PyDict_SetItem(dict, __pyx_mstate_global->__pyx_n_u_annotate, value);
    Py_DECREF(dict);
    return result;
}
static PyObject *
__Pyx_CyFunction_get_annotations_locked(__pyx_CyFunctionObject *op) {
    PyObject* result = op->func_annotations;
    if (unlikely(!result)) {
        result = PyDict_New();
        if (unlikely(!result)) return NULL;
        op->func_annotations = result;
    }
    Py_INCREF(result);
    return result;
}
static PyObject *
__Pyx_CyFunction_get_annotations(PyObject *op_in, void *context) {
    PyObject *annotate = NULL;
    PyObject *result = NULL;
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    CYTHON_UNUSED_VAR(context);
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    result = __Pyx_XNewRef(op->func_annotations);
    __Pyx_END_CRITICAL_SECTION();
    if (result) return result;
    if (unlikely(__Pyx_CyFunction_get_annotate_from_dict_if_exists(op_in, &annotate) < 0)) return NULL;
    if (!annotate || annotate == Py_None) {
        Py_XDECREF(annotate);
        __Pyx_BEGIN_CRITICAL_SECTION(op_in);
        result = __Pyx_CyFunction_get_annotations_locked(op);
        __Pyx_END_CRITICAL_SECTION();
        return result;
    }
    PyObject *format = PyLong_FromLong(1L);  // annotationlib.Format.VALUE
    if (likely(format)) {
        if (!Py_EnterRecursiveCall(" cyfunction __annotations__.__get__")) {
            result = __Pyx_PyObject_CallOneArg(annotate, format);
            Py_LeaveRecursiveCall();
            Py_DECREF(format);
        }
    }
    Py_DECREF(annotate);
    if (unlikely(!result)) return NULL;
    if (unlikely(!PyDict_Check(result))) {
        PyErr_SetString(PyExc_TypeError, "__annotate__ must return a dict");
        Py_DECREF(result);
        return NULL;
    }
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    __Pyx_Py_XDECREF_SET(op->func_annotations, __Pyx_NewRef(result));
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static PyObject *__Pyx_CyFunction_annotate_impl(PyObject *self, PyObject *arg) {
    CYTHON_UNUSED_VAR(arg);
    if (unlikely(!self)) {
        PyErr_SetString(PyExc_SystemError, "cython __annotate__ called without 'self' argument");
        return NULL;
    }
    PyObject *result;
    if (Py_EnterRecursiveCall(" in cyfunction annotate")) {
        return NULL;
    }
    result = __Pyx_CyFunction_get_annotations(self, NULL);
    Py_LeaveRecursiveCall();
    return result;
}
static PyObject *
__Pyx_CyFunction_get_annotate(PyObject *op_in, void *context);
static int
__Pyx_CyFunction_set_annotate(PyObject *op_in, PyObject* value, void *context) {
    CYTHON_UNUSED_VAR(context);
    if (value == NULL) {
        PyErr_SetString(PyExc_TypeError, "__annotate__ cannot be deleted");
        return -1;
    }
    if (unlikely(value != Py_None && !PyCallable_Check(value))) {
        PyErr_SetString(PyExc_TypeError, "__annotate__ must be callable or None");
        return -1;
    }
    if (unlikely(__Pyx_TypeCheck(value, &PyCFunction_Type))) {
#if !CYTHON_ASSUME_SAFE_MACROS && !CYTHON_COMPILING_IN_PYPY
        PyCFunction cfunction = PyCFunction_GetFunction(value);
        if (unlikely(!cfunction)) return -1;
        PyObject *value_self = PyCFunction_GetSelf(value);
        if (unlikely(!value_self && PyErr_Occurred())) return -1;
#else
        PyCFunction cfunction = PyCFunction_GET_FUNCTION(value);
        PyObject *value_self = PyCFunction_GET_SELF(value);
#endif
        if (cfunction == __Pyx_CyFunction_annotate_impl && value_self == op_in) {
            return __Pyx_CyFunction_set_annotate_in_dict_if_exists(op_in, NULL);
        }
    }
    if (value != Py_None) {
        __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
        __Pyx_BEGIN_CRITICAL_SECTION(op_in);
        Py_CLEAR(op->func_annotations);
        __Pyx_END_CRITICAL_SECTION();
    }
    return __Pyx_CyFunction_set_annotate_in_dict(op_in, value);
}
#if __PYX_LIMITED_VERSION_HEX < 0x030B0000
static PyObject *
__Pyx_CyFunction_get_is_coroutine_value(__pyx_CyFunctionObject *op) {
    int is_coroutine = op->flags & __Pyx_CYFUNCTION_COROUTINE;
    if (is_coroutine) {
        PyObject *is_coroutine_value, *module, *fromlist, *marker = __pyx_mstate_global->__pyx_n_u_is_coroutine;
        fromlist = PyList_New(1);
        if (unlikely(!fromlist)) return NULL;
        Py_INCREF(marker);
#if CYTHON_ASSUME_SAFE_MACROS
        PyList_SET_ITEM(fromlist, 0, marker);
#else
        if (unlikely(PyList_SetItem(fromlist, 0, marker) < 0)) {
            Py_DECREF(fromlist);
            return NULL;
        }
#endif
        module = PyImport_ImportModuleLevelObject(__pyx_mstate_global->__pyx_n_u_asyncio_coroutines, NULL, NULL, fromlist, 0);
        Py_DECREF(fromlist);
        if (unlikely(!module)) {
            goto ignore_or_error;
        }
        is_coroutine_value = __Pyx_PyObject_GetAttrStr(module, marker);
        Py_DECREF(module);
        if (likely(is_coroutine_value)) {
            return is_coroutine_value;
        }
ignore_or_error:
        if (!__Pyx_IgnoreException(PyExc_Exception)) {
            return NULL;
        }
    }
    return __Pyx_PyBool_FromLong(is_coroutine);
}
static PyObject *
__Pyx_CyFunction_get_is_coroutine(PyObject *op_in, void *context) {
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    PyObject *result;
    CYTHON_UNUSED_VAR(context);
    if (op->func_is_coroutine) {
        return __Pyx_NewRef(op->func_is_coroutine);
    }
    result = __Pyx_CyFunction_get_is_coroutine_value(op);
    if (unlikely(!result))
        return NULL;
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    if (op->func_is_coroutine) {
        Py_DECREF(result);
        result = __Pyx_NewRef(op->func_is_coroutine);
    } else {
        op->func_is_coroutine = __Pyx_NewRef(result);
    }
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
#endif
static void __Pyx_CyFunction_raise_argument_count_error(PyObject *func, const char* message, Py_ssize_t size) {
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject *py_name = __Pyx_CyFunction_get_name(func, NULL);
    if (!py_name) return;
    PyErr_Format(PyExc_TypeError,
        "%.200S() %s (%" CYTHON_FORMAT_SSIZE_T "d given)",
        py_name, message, size);
    Py_DECREF(py_name);
#else
    const char* name = ((PyCFunctionObject*)func)->m_ml->ml_name;
    PyErr_Format(PyExc_TypeError,
        "%.200s() %s (%" CYTHON_FORMAT_SSIZE_T "d given)",
        name, message, size);
#endif
}
static void __Pyx_CyFunction_raise_type_error(PyObject *func, const char* message) {
#if CYTHON_COMPILING_IN_LIMITED_API
    PyObject *py_name = __Pyx_CyFunction_get_name(func, NULL);
    if (!py_name) return;
    PyErr_Format(PyExc_TypeError,
        "%.200S() %s",
        py_name, message);
    Py_DECREF(py_name);
#else
    const char* name = ((PyCFunctionObject*)func)->m_ml->ml_name;
    PyErr_Format(PyExc_TypeError,
        "%.200s() %s",
        name, message);
#endif
}
#if CYTHON_COMPILING_IN_LIMITED_API
static PyObject *
__Pyx_CyFunction_get_module(PyObject *op_in, void *context) {
    CYTHON_UNUSED_VAR(context);
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    Py_INCREF(op->func_module);
    return op->func_module;
}
static int
__Pyx_CyFunction_set_module(PyObject *op_in, PyObject* value, void *context) {
    CYTHON_UNUSED_VAR(context);
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    if (value == NULL) {
        value = Py_None;
    }
    Py_INCREF(value);
    PyObject *old = op->func_module;
    op->func_module = value;
    Py_DECREF(old);
    return 0;
}
#endif
static PyGetSetDef __pyx_CyFunction_getsets[] = {
    {"func_doc", (getter)__Pyx_CyFunction_get_doc, (setter)__Pyx_CyFunction_set_doc, 0, 0},
    {"__doc__",  (getter)__Pyx_CyFunction_get_doc, (setter)__Pyx_CyFunction_set_doc, 0, 0},
    {"func_name", (getter)__Pyx_CyFunction_get_name, (setter)__Pyx_CyFunction_set_name, 0, 0},
    {"__name__", (getter)__Pyx_CyFunction_get_name, (setter)__Pyx_CyFunction_set_name, 0, 0},
    {"__qualname__", (getter)__Pyx_CyFunction_get_qualname, (setter)__Pyx_CyFunction_set_qualname, 0, 0},
#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030A0000
    {"func_dict", (getter)__Pyx_CyFunction_get_dict, (setter)PyObject_GenericSetDict, 0, 0},
    {"__dict__", (getter)__Pyx_CyFunction_get_dict, (setter)PyObject_GenericSetDict, 0, 0},
#else
    {"func_dict", (getter)PyObject_GenericGetDict, (setter)PyObject_GenericSetDict, 0, 0},
    {"__dict__", (getter)PyObject_GenericGetDict, (setter)PyObject_GenericSetDict, 0, 0},
#endif
    {"func_globals", (getter)__Pyx_CyFunction_get_globals, 0, 0, 0},
    {"__globals__", (getter)__Pyx_CyFunction_get_globals, 0, 0, 0},
    {"func_closure", (getter)__Pyx_CyFunction_get_closure, 0, 0, 0},
    {"__closure__", (getter)__Pyx_CyFunction_get_closure, 0, 0, 0},
    {"func_code", (getter)__Pyx_CyFunction_get_code, 0, 0, 0},
    {"__code__", (getter)__Pyx_CyFunction_get_code, 0, 0, 0},
    {"func_defaults", (getter)__Pyx_CyFunction_get_defaults, (setter)__Pyx_CyFunction_set_defaults, 0, 0},
    {"__defaults__", (getter)__Pyx_CyFunction_get_defaults, (setter)__Pyx_CyFunction_set_defaults, 0, 0},
    {"__kwdefaults__", (getter)__Pyx_CyFunction_get_kwdefaults, (setter)__Pyx_CyFunction_set_kwdefaults, 0, 0},
    {"__annotations__", (getter)__Pyx_CyFunction_get_annotations, (setter)__Pyx_CyFunction_set_annotations, 0, 0},
    {"__annotate__", (getter)__Pyx_CyFunction_get_annotate, (setter)__Pyx_CyFunction_set_annotate, 0, 0},
#if __PYX_LIMITED_VERSION_HEX < 0x030B0000
    {"_is_coroutine", (getter)__Pyx_CyFunction_get_is_coroutine, 0, 0, 0},
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
    {"__module__", (getter)__Pyx_CyFunction_get_module, (setter)__Pyx_CyFunction_set_module, 0, 0},
#endif
    {0, 0, 0, 0, 0}
};
static PyMemberDef __pyx_CyFunction_members[] = {
#if !CYTHON_COMPILING_IN_LIMITED_API
    {"__module__", T_OBJECT, offsetof(PyCFunctionObject, m_module), 0, 0},
#endif
#if PY_VERSION_HEX < 0x030C0000 || CYTHON_COMPILING_IN_LIMITED_API
    {"__dictoffset__", T_PYSSIZET, offsetof(__pyx_CyFunctionObject, func_dict),
        __PYX_SHARED_RELATIVE_OFFSET | READONLY, 0},
#endif
#if CYTHON_VECTORCALL
#if CYTHON_COMPILING_IN_LIMITED_API || CYTHON_COMPILING_IN_PYPY
    {"__vectorcalloffset__", T_PYSSIZET, offsetof(__pyx_CyFunctionObject, func_vectorcall),
        __PYX_SHARED_RELATIVE_OFFSET | READONLY, 0},
#else
    {"__vectorcalloffset__", T_PYSSIZET, offsetof(PyCFunctionObject, vectorcall), READONLY, 0},
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
    {"__weaklistoffset__", T_PYSSIZET, offsetof(__pyx_CyFunctionObject, func_weakreflist),
        __PYX_SHARED_RELATIVE_OFFSET | READONLY, 0},
#else
    {"__weaklistoffset__", T_PYSSIZET, offsetof(PyCFunctionObject, m_weakreflist), READONLY, 0},
#endif
#endif
    {0, 0, 0,  0, 0}
};
static PyObject *
__Pyx_CyFunction_reduce(PyObject *m_in, PyObject *args)
{
    PyObject *result = NULL;
    __pyx_CyFunctionObject *m = __Pyx_as_CyFunctionObject(m_in);
    CYTHON_UNUSED_VAR(args);
    __Pyx_BEGIN_CRITICAL_SECTION(m_in);
    Py_INCREF(m->func_qualname);
    result = m->func_qualname;
    __Pyx_END_CRITICAL_SECTION();
    return result;
}
static PyMethodDef __pyx_CyFunction_methods[] = {
    {"__annotate_cython__", __Pyx_CyFunction_annotate_impl, METH_O,
        "Placeholder __annotate__ function to allow 'functools.wraps' to work "
        "on Cython functions."},
    {"__reduce__", (PyCFunction)__Pyx_CyFunction_reduce, METH_NOARGS, 0},
    {0, 0, 0, 0}
};
static PyObject *
__Pyx_CyFunction_get_annotate(PyObject *op_in, void *context) {
    PyObject *annotate = NULL;
    CYTHON_UNUSED_VAR(context);
    if (unlikely(__Pyx_CyFunction_get_annotate_from_dict_if_exists(op_in, &annotate) < 0)) return NULL;
    if (annotate) return annotate;
    PyObject *method = PyCFunction_New(
        &__pyx_CyFunction_methods[0],
        op_in);
    return method;
}
#if CYTHON_COMPILING_IN_LIMITED_API
#define __Pyx_CyFunction_weakreflist(cyfunc) ((cyfunc)->func_weakreflist)
#else
#define __Pyx_CyFunction_weakreflist(cyfunc) (((PyCFunctionObject*)cyfunc)->m_weakreflist)
#endif
static PyObject *__Pyx_CyFunction_Init(PyObject *op_in,
                                       PyMethodDef *ml, int flags, PyObject* qualname,
                                       PyObject *closure, PyObject *module, PyObject* globals, PyObject* code) {
    __pyx_CyFunctionObject* op = __Pyx_as_CyFunctionObject(op_in);
#if !CYTHON_COMPILING_IN_LIMITED_API
    PyCFunctionObject *cf = (PyCFunctionObject*) op;
#endif
    if (unlikely(op == NULL))
        return NULL;
#if CYTHON_COMPILING_IN_LIMITED_API
    op->func_methoddef = ml;
    Py_INCREF(module);
    op->func_module = module;
#endif
    op->flags = flags;
    __Pyx_CyFunction_weakreflist(op) = NULL;
#if !CYTHON_COMPILING_IN_LIMITED_API
    cf->m_ml = ml;
    cf->m_self = (PyObject *) op;
#endif
    Py_XINCREF(closure);
    op->func_closure = closure;
#if !CYTHON_COMPILING_IN_LIMITED_API
    Py_XINCREF(module);
    cf->m_module = module;
#endif
#if PY_VERSION_HEX < 0x030C0000 || CYTHON_COMPILING_IN_LIMITED_API
    op->func_dict = NULL;
#endif
    op->func_name = NULL;
    Py_INCREF(qualname);
    op->func_qualname = qualname;
    op->func_doc = NULL;
#if CYTHON_COMPILING_IN_LIMITED_API
    op->func_classobj = NULL;
#else
    ((PyCMethodObject*)op)->mm_class = NULL;
#endif
    op->func_globals = globals;
    Py_INCREF(op->func_globals);
    Py_XINCREF(code);
    op->func_code = code;
    op->defaults = NULL;
    op->defaults_tuple = NULL;
    op->defaults_kwdict = NULL;
    op->defaults_getter = NULL;
    op->func_annotations = NULL;
#if __PYX_LIMITED_VERSION_HEX < 0x030B0000
    op->func_is_coroutine = NULL;
#endif
#if CYTHON_VECTORCALL
    switch (ml->ml_flags & (METH_VARARGS | METH_FASTCALL | METH_NOARGS | METH_O | METH_KEYWORDS | METH_METHOD)) {
    case METH_NOARGS:
        __Pyx_CyFunction_func_vectorcall(op) = __Pyx_CyFunction_Vectorcall_NOARGS;
        break;
    case METH_O:
        __Pyx_CyFunction_func_vectorcall(op) = __Pyx_CyFunction_Vectorcall_O;
        break;
    case METH_METHOD | METH_FASTCALL | METH_KEYWORDS:
        __Pyx_CyFunction_func_vectorcall(op) = __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS_METHOD;
        break;
    case METH_FASTCALL | METH_KEYWORDS:
        __Pyx_CyFunction_func_vectorcall(op) = __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS;
        break;
    case METH_VARARGS | METH_KEYWORDS:
        __Pyx_CyFunction_func_vectorcall(op) = NULL;
        break;
    default:
        PyErr_SetString(PyExc_SystemError, "Bad call flags for CyFunction");
        Py_DECREF(op_in);
        return NULL;
    }
#endif
    return op_in;
}
static int __Pyx__CyFunction_clear(__pyx_CyFunctionObject *m)
{
    Py_CLEAR(m->func_closure);
#if CYTHON_COMPILING_IN_LIMITED_API
    Py_CLEAR(m->func_module);
#else
    Py_CLEAR(((PyCFunctionObject*)m)->m_module);
#endif
#if PY_VERSION_HEX < 0x030C0000 || CYTHON_COMPILING_IN_LIMITED_API
    Py_CLEAR(m->func_dict);
#elif PY_VERSION_HEX < 0x030d0000
    _PyObject_ClearManagedDict((PyObject*)m);
#else
    PyObject_ClearManagedDict((PyObject*)m);
#endif
    Py_CLEAR(m->func_name);
    Py_CLEAR(m->func_qualname);
    Py_CLEAR(m->func_doc);
    Py_CLEAR(m->func_globals);
    Py_CLEAR(m->func_code);
#if CYTHON_COMPILING_IN_LIMITED_API
    Py_CLEAR(m->func_classobj);
#else
    {
        PyObject *cls = (PyObject*) ((PyCMethodObject *) (m))->mm_class;
        ((PyCMethodObject *) (m))->mm_class = NULL;
        Py_XDECREF(cls);
    }
#endif
    Py_CLEAR(m->defaults_tuple);
    Py_CLEAR(m->defaults_kwdict);
    Py_CLEAR(m->func_annotations);
#if __PYX_LIMITED_VERSION_HEX < 0x030B0000
    Py_CLEAR(m->func_is_coroutine);
#endif
    Py_CLEAR(m->defaults);
    return 0;
}
static int
__Pyx_CyFunction_clear(PyObject *m)
{
    return __Pyx__CyFunction_clear(__Pyx_as_CyFunctionObject(m));
}
static void __Pyx__CyFunction_dealloc(PyObject *m)
{
    __pyx_CyFunctionObject *cyfunc = __Pyx_as_CyFunctionObject(m);
    if (__Pyx_CyFunction_weakreflist(cyfunc) != NULL)
        PyObject_ClearWeakRefs(m);
    __Pyx__CyFunction_clear(cyfunc);
    __Pyx_PyHeapTypeObject_GC_Del(m);
}
static void __Pyx_CyFunction_dealloc(PyObject *m)
{
    PyObject_GC_UnTrack(m);
    __Pyx__CyFunction_dealloc(m);
}
static int __Pyx_CyFunction_traverse(PyObject *m_in, visitproc visit, void *arg)
{
    __pyx_CyFunctionObject *m = __Pyx_as_CyFunctionObject(m_in);
    {
        int e = __Pyx_call_type_traverse(m_in, 1, visit, arg);
        if (e) return e;
    }
    Py_VISIT(m->func_closure);
#if CYTHON_COMPILING_IN_LIMITED_API
    Py_VISIT(m->func_module);
#else
    Py_VISIT(((PyCFunctionObject*)m)->m_module);
#endif
#if PY_VERSION_HEX < 0x030C0000 || CYTHON_COMPILING_IN_LIMITED_API
    Py_VISIT(m->func_dict);
#else
    {
        int e =
#if PY_VERSION_HEX < 0x030d0000
            _PyObject_VisitManagedDict
#else
            PyObject_VisitManagedDict
#endif
                ((PyObject*)m, visit, arg);
        if (e != 0) return e;
    }
#endif
    __Pyx_VISIT_CONST(m->func_name);
    __Pyx_VISIT_CONST(m->func_qualname);
    Py_VISIT(m->func_doc);
    Py_VISIT(m->func_globals);
    __Pyx_VISIT_CONST(m->func_code);
    Py_VISIT(__Pyx__CyFunction_GetClassObj(m));
    Py_VISIT(m->defaults_tuple);
    Py_VISIT(m->defaults_kwdict);
    Py_VISIT(m->func_annotations);
#if __PYX_LIMITED_VERSION_HEX < 0x030B0000
    Py_VISIT(m->func_is_coroutine);
#endif
    Py_VISIT(m->defaults);
    return 0;
}
static PyObject*
__Pyx_CyFunction_repr(PyObject *op_in)
{
    __pyx_CyFunctionObject *op = __Pyx_as_CyFunctionObject(op_in);
    PyObject *repr;
    __Pyx_BEGIN_CRITICAL_SECTION(op_in);
    repr = PyUnicode_FromFormat("<cyfunction %U at %p>",
                                op->func_qualname, (void *)op);
    __Pyx_END_CRITICAL_SECTION();
    return repr;
}
static PyObject * __Pyx_CyFunction_CallMethod(PyObject *func, PyObject *self, PyObject *arg, PyObject *kw) {
#if CYTHON_COMPILING_IN_LIMITED_API
    __pyx_CyFunctionObject *cyfunc = __Pyx_as_CyFunctionObject(func);
    PyCFunction meth = cyfunc->func_methoddef->ml_meth;
    int flags = cyfunc->func_methoddef->ml_flags;
#else
    PyCFunctionObject* f = (PyCFunctionObject*)func;
    PyCFunction meth = f->m_ml->ml_meth;
    int flags = f->m_ml->ml_flags;
#endif
    Py_ssize_t size;
    switch (flags & (METH_VARARGS | METH_KEYWORDS | METH_NOARGS | METH_O)) {
    case METH_VARARGS:
        if (likely(kw == NULL || PyDict_Size(kw) == 0))
            return (*meth)(self, arg);
        break;
    case METH_VARARGS | METH_KEYWORDS:
        return (*(PyCFunctionWithKeywords)(void(*)(void))meth)(self, arg, kw);
    case METH_NOARGS:
        if (likely(kw == NULL || PyDict_Size(kw) == 0)) {
#if CYTHON_ASSUME_SAFE_SIZE
            size = PyTuple_GET_SIZE(arg);
#else
            size = PyTuple_Size(arg);
            if (unlikely(size < 0)) return NULL;
#endif
            if (likely(size == 0))
                return (*meth)(self, NULL);
            __Pyx_CyFunction_raise_argument_count_error(
                func,
                "takes no arguments", size);
            return NULL;
        }
        break;
    case METH_O:
        if (likely(kw == NULL || PyDict_Size(kw) == 0)) {
#if CYTHON_ASSUME_SAFE_SIZE
            size = PyTuple_GET_SIZE(arg);
#else
            size = PyTuple_Size(arg);
            if (unlikely(size < 0)) return NULL;
#endif
            if (likely(size == 1)) {
                PyObject *result, *arg0;
                #if CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS
                arg0 = PyTuple_GET_ITEM(arg, 0);
                #else
                arg0 = __Pyx_PySequence_ITEM(arg, 0); if (unlikely(!arg0)) return NULL;
                #endif
                result = (*meth)(self, arg0);
                #if !(CYTHON_ASSUME_SAFE_MACROS && !CYTHON_AVOID_BORROWED_REFS)
                Py_DECREF(arg0);
                #endif
                return result;
            }
            __Pyx_CyFunction_raise_argument_count_error(
                func,
                "takes exactly one argument", size);
            return NULL;
        }
        break;
    default:
        PyErr_SetString(PyExc_SystemError, "Bad call flags for CyFunction");
        return NULL;
    }
    __Pyx_CyFunction_raise_type_error(
        func, "takes no keyword arguments");
    return NULL;
}
static CYTHON_INLINE PyObject *__Pyx_CyFunction_Call(PyObject *func, PyObject *arg, PyObject *kw) {
    PyObject *result;
    result = __Pyx_CyFunction_CallMethod(func, func, arg, kw);
    return result;
}
static PyObject *__Pyx_CyFunction_CallAsMethod(PyObject *func, PyObject *args, PyObject *kw) {
    PyObject *result;
    __pyx_CyFunctionObject *cyfunc = __Pyx_as_CyFunctionObject(func);
#if CYTHON_VECTORCALL
     __pyx_vectorcallfunc vc = __Pyx_CyFunction_func_vectorcall(cyfunc);
    if (vc) {
#if CYTHON_ASSUME_SAFE_MACROS && CYTHON_ASSUME_SAFE_SIZE
        return __Pyx_PyVectorcall_FastCallDict(func, vc, &PyTuple_GET_ITEM(args, 0), (size_t)PyTuple_GET_SIZE(args), kw);
#else
        (void) &__Pyx_PyVectorcall_FastCallDict;
        return PyVectorcall_Call(func, args, kw);
#endif
    }
#endif
    if ((cyfunc->flags & __Pyx_CYFUNCTION_CCLASS) && !(cyfunc->flags & __Pyx_CYFUNCTION_STATICMETHOD)) {
        Py_ssize_t argc;
        PyObject *new_args;
        PyObject *self;
#if CYTHON_ASSUME_SAFE_SIZE
        argc = PyTuple_GET_SIZE(args);
#else
        argc = PyTuple_Size(args);
        if (unlikely(argc < 0)) return NULL;
#endif
        new_args = PyTuple_GetSlice(args, 1, argc);
        if (unlikely(!new_args))
            return NULL;
        self = PyTuple_GetItem(args, 0);
        if (unlikely(!self)) {
            Py_DECREF(new_args);
            PyErr_Format(PyExc_TypeError,
                         "unbound method %.200S() needs an argument",
                         cyfunc->func_qualname);
            return NULL;
        }
        result = __Pyx_CyFunction_CallMethod(func, self, new_args, kw);
        Py_DECREF(new_args);
    } else {
        result = __Pyx_CyFunction_Call(func, args, kw);
    }
    return result;
}
#if CYTHON_VECTORCALL
static CYTHON_INLINE int __Pyx_CyFunction_Vectorcall_CheckArgs(PyObject *func, __pyx_CyFunctionObject *cyfunc, Py_ssize_t nargs, PyObject *kwnames)
{
    int ret = 0;
    if ((cyfunc->flags & __Pyx_CYFUNCTION_CCLASS) && !(cyfunc->flags & __Pyx_CYFUNCTION_STATICMETHOD)) {
        if (unlikely(nargs < 1)) {
            __Pyx_CyFunction_raise_type_error(
                func, "needs an argument");
            return -1;
        }
        ret = 1;
    }
    if (unlikely(kwnames) && unlikely(__Pyx_PyTuple_GET_SIZE(kwnames))) {
        __Pyx_CyFunction_raise_type_error(
            func, "takes no keyword arguments");
        return -1;
    }
    return ret;
}
static PyObject * __Pyx_CyFunction_Vectorcall_NOARGS(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames)
{
    __pyx_CyFunctionObject *cyfunc = __Pyx_as_CyFunctionObject(func);
    Py_ssize_t nargs = PyVectorcall_NARGS(nargsf);
    PyObject *self;
#if CYTHON_COMPILING_IN_LIMITED_API
    PyCFunction meth = cyfunc->func_methoddef->ml_meth;
    if (unlikely(!meth)) return NULL;
#else
    PyCFunction meth = ((PyCFunctionObject*)cyfunc)->m_ml->ml_meth;
#endif
    switch (__Pyx_CyFunction_Vectorcall_CheckArgs(func, cyfunc, nargs, kwnames)) {
    case 1:
        self = args[0];
        args += 1;
        nargs -= 1;
        break;
    case 0:
        self = func;
        break;
    default:
        return NULL;
    }
    if (unlikely(nargs != 0)) {
        __Pyx_CyFunction_raise_argument_count_error(
            func, "takes no arguments", nargs);
        return NULL;
    }
    return meth(self, NULL);
}
static PyObject * __Pyx_CyFunction_Vectorcall_O(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames)
{
    __pyx_CyFunctionObject *cyfunc = __Pyx_as_CyFunctionObject(func);
    Py_ssize_t nargs = PyVectorcall_NARGS(nargsf);
    PyObject *self;
#if CYTHON_COMPILING_IN_LIMITED_API
    PyCFunction meth = cyfunc->func_methoddef->ml_meth;
    if (unlikely(!meth)) return NULL;
#else
    PyCFunction meth = ((PyCFunctionObject*)cyfunc)->m_ml->ml_meth;
#endif
    switch (__Pyx_CyFunction_Vectorcall_CheckArgs(func, cyfunc, nargs, kwnames)) {
    case 1:
        self = args[0];
        args += 1;
        nargs -= 1;
        break;
    case 0:
        self = func;
        break;
    default:
        return NULL;
    }
    if (unlikely(nargs != 1)) {
        __Pyx_CyFunction_raise_argument_count_error(
            func, "takes exactly one argument", nargs);
        return NULL;
    }
    return meth(self, args[0]);
}
static PyObject * __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames)
{
    __pyx_CyFunctionObject *cyfunc = __Pyx_as_CyFunctionObject(func);
    Py_ssize_t nargs = PyVectorcall_NARGS(nargsf);
    PyObject *self;
#if CYTHON_COMPILING_IN_LIMITED_API
    PyCFunction meth = cyfunc->func_methoddef->ml_meth;
    if (unlikely(!meth)) return NULL;
#else
    PyCFunction meth = ((PyCFunctionObject*)cyfunc)->m_ml->ml_meth;
#endif
    switch (__Pyx_CyFunction_Vectorcall_CheckArgs(func, cyfunc, nargs, NULL)) {
    case 1:
        self = args[0];
        args += 1;
        nargs -= 1;
        break;
    case 0:
        self = func;
        break;
    default:
        return NULL;
    }
    return ((__Pyx_PyCFunctionFastWithKeywords)(void(*)(void))meth)(self, args, nargs, kwnames);
}
static PyObject * __Pyx_CyFunction_Vectorcall_FASTCALL_KEYWORDS_METHOD(PyObject *func, PyObject *const *args, size_t nargsf, PyObject *kwnames)
{
    __pyx_CyFunctionObject *cyfunc = __Pyx_as_CyFunctionObject(func);
    PyTypeObject *cls = (PyTypeObject *) __Pyx__CyFunction_GetClassObj(cyfunc);
    Py_ssize_t nargs = PyVectorcall_NARGS(nargsf);
    PyObject *self;
#if CYTHON_COMPILING_IN_LIMITED_API
    PyCFunction meth = cyfunc->func_methoddef->ml_meth;
    if (unlikely(!meth)) return NULL;
#else
    PyCFunction meth = ((PyCFunctionObject*)cyfunc)->m_ml->ml_meth;
#endif
    switch (__Pyx_CyFunction_Vectorcall_CheckArgs(func, cyfunc, nargs, NULL)) {
    case 1:
        self = args[0];
        args += 1;
        nargs -= 1;
        break;
    case 0:
        self = func;
        break;
    default:
        return NULL;
    }
    #if PY_VERSION_HEX < 0x030e00A6
    size_t nargs_value = (size_t) nargs;
    #else
    Py_ssize_t nargs_value = nargs;
    #endif
    return ((__Pyx_PyCMethod)(void(*)(void))meth)(self, cls, args, nargs_value, kwnames);
}
#endif
static PyType_Slot __pyx_CyFunctionType_slots[] = {
    {Py_tp_dealloc, (void *)__Pyx_CyFunction_dealloc},
    {Py_tp_repr, (void *)__Pyx_CyFunction_repr},
    {Py_tp_call, (void *)__Pyx_CyFunction_CallAsMethod},
    {Py_tp_traverse, (void *)__Pyx_CyFunction_traverse},
    {Py_tp_clear, (void *)__Pyx_CyFunction_clear},
    {Py_tp_methods, (void *)__pyx_CyFunction_methods},
    {Py_tp_members, (void *)__pyx_CyFunction_members},
    {Py_tp_getset, (void *)__pyx_CyFunction_getsets},
    {Py_tp_descr_get, (void *)__Pyx_PyMethod_New},
    {0, 0},
};
static PyType_Spec __pyx_CyFunctionType_spec = {
    __PYX_TYPE_MODULE_PREFIX "cython_function_or_method",
    __PYX_SHARED_SIZEOF(__pyx_CyFunctionObject),
    0,
#ifdef Py_TPFLAGS_METHOD_DESCRIPTOR
    Py_TPFLAGS_METHOD_DESCRIPTOR |
#endif
#if CYTHON_VECTORCALL
#if defined(Py_TPFLAGS_HAVE_VECTORCALL)
    Py_TPFLAGS_HAVE_VECTORCALL |
#elif defined(_Py_TPFLAGS_HAVE_VECTORCALL)
    _Py_TPFLAGS_HAVE_VECTORCALL |
#endif
#endif // CYTHON_VECTORCALL
#if PY_VERSION_HEX >= 0x030C0000 && !CYTHON_COMPILING_IN_LIMITED_API
    Py_TPFLAGS_MANAGED_DICT |
#endif
    Py_TPFLAGS_IMMUTABLETYPE | Py_TPFLAGS_DISALLOW_INSTANTIATION |
    Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HAVE_GC | Py_TPFLAGS_BASETYPE,
    __pyx_CyFunctionType_slots
};
static int __pyx_CyFunction_init(PyObject *module) {
    __pyx_mstatetype *mstate = __Pyx_PyModule_GetState(module);
    mstate->__pyx_CyFunctionType = __Pyx_FetchCommonTypeFromSpec(
        mstate->__pyx_CommonTypesMetaclassType, module, &__pyx_CyFunctionType_spec, NULL);
    if (unlikely(mstate->__pyx_CyFunctionType == NULL)) {
        return -1;
    }
    return 0;
}


static PyObject *__Pyx_CyFunction_New(PyMethodDef *ml, int flags, PyObject* qualname,
                                      PyObject *closure, PyObject *module, PyObject* globals, PyObject* code) {
    (void)&__Pyx_Get_CyFunction_Type;
    PyObject *op = __Pyx_CyFunction_Init(
        PyObject_GC_New(PyObject, __pyx_mstate_global->__pyx_CyFunctionType),
        ml, flags, qualname, closure, module, globals, code
    );
    if (likely(op)) {
        PyObject_GC_Track(op);
    }
    return op;
}
static PyTypeObject *__Pyx_Get_CyFunction_Type(void) {
    PyTypeObject *tp = __pyx_mstate_global->__pyx_CyFunctionType;
    Py_INCREF((PyObject*)tp);
    return tp;
}


static PyObject *__Pyx_CalculateMetaclass(PyTypeObject *metaclass, PyObject *bases) {
    Py_ssize_t i, nbases;
#if CYTHON_ASSUME_SAFE_SIZE
    nbases = PyTuple_GET_SIZE(bases);
#else
    nbases = PyTuple_Size(bases);
    if (nbases < 0) return NULL;
#endif
    for (i=0; i < nbases; i++) {
        PyTypeObject *tmptype;
#if CYTHON_ASSUME_SAFE_MACROS
        PyObject *tmp = PyTuple_GET_ITEM(bases, i);
#else
        PyObject *tmp = PyTuple_GetItem(bases, i);
        if (!tmp) return NULL;
#endif
        tmptype = Py_TYPE(tmp);
        if (!metaclass) {
            metaclass = tmptype;
            continue;
        }
        if (PyType_IsSubtype(metaclass, tmptype))
            continue;
        if (PyType_IsSubtype(tmptype, metaclass)) {
            metaclass = tmptype;
            continue;
        }
        PyErr_SetString(PyExc_TypeError,
                        "metaclass conflict: "
                        "the metaclass of a derived class "
                        "must be a (non-strict) subclass "
                        "of the metaclasses of all its bases");
        return NULL;
    }
    if (!metaclass) {
        metaclass = &PyType_Type;
    }
    Py_INCREF((PyObject*) metaclass);
    return (PyObject*) metaclass;
}


static CYTHON_INLINE PyObject* __Pyx_PyObject_Call2Args(PyObject* function, PyObject* arg1, PyObject* arg2) {
    PyObject *args[3] = {NULL, arg1, arg2};
    return __Pyx_PyObject_FastCall(function, args+1, 2 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET);
}


#if CYTHON_USE_PYTYPE_LOOKUP && CYTHON_USE_TYPE_SLOTS
static CYTHON_INLINE PyObject* __Pyx__PyObject_LookupSpecial(PyObject* obj, PyObject* attr_name, int with_error) {
    PyObject *res;
    PyTypeObject *tp = Py_TYPE(obj);
    res = _PyType_Lookup(tp, attr_name);
    if (likely(res)) {
        descrgetfunc f = Py_TYPE(res)->tp_descr_get;
        if (!f) {
            Py_INCREF(res);
        } else {
            res = f(res, obj, (PyObject *)tp);
        }
    } else if (with_error) {
        PyErr_SetObject(PyExc_AttributeError, attr_name);
    }
    return res;
}
#endif


static PyObject *__Pyx_Py3MetaclassPrepare(PyObject *metaclass, PyObject *bases, PyObject *name,
                                           PyObject *qualname, PyObject *mkw, PyObject *modname, PyObject *doc) {
    PyObject *ns;
    if (metaclass) {
        PyObject *prep = __Pyx_PyObject_GetAttrStrNoError(metaclass, __pyx_mstate_global->__pyx_n_u_prepare);
        if (prep) {
            PyObject *pargs[3] = {NULL, name, bases};
            ns = __Pyx_PyObject_FastCallDict(prep, pargs+1, 2 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET, mkw);
            Py_DECREF(prep);
        } else {
            if (unlikely(PyErr_Occurred()))
                return NULL;
            ns = PyDict_New();
        }
    } else {
        ns = PyDict_New();
    }
    if (unlikely(!ns))
        return NULL;
    if (unlikely(PyObject_SetItem(ns, __pyx_mstate_global->__pyx_n_u_module, modname) < 0)) goto bad;
    if (unlikely(PyObject_SetItem(ns, __pyx_mstate_global->__pyx_n_u_qualname, qualname) < 0)) goto bad;
    if (unlikely(doc && PyObject_SetItem(ns, __pyx_mstate_global->__pyx_n_u_doc, doc) < 0)) goto bad;
    return ns;
bad:
    Py_DECREF(ns);
    return NULL;
}
static PyObject *__Pyx_Py3ClassCreate(PyObject *metaclass, PyObject *name, PyObject *bases,
                                      PyObject *dict, PyObject *mkw,
                                      int calculate_metaclass, int allow_py2_metaclass) {
    PyObject *result;
    PyObject *owned_metaclass = NULL;
    PyObject *margs[4] = {NULL, name, bases, dict};
    if (allow_py2_metaclass) {
        owned_metaclass = PyObject_GetItem(dict, __pyx_mstate_global->__pyx_n_u_metaclass);
        if (owned_metaclass) {
            metaclass = owned_metaclass;
        } else if (likely(PyErr_ExceptionMatches(PyExc_KeyError))) {
            PyErr_Clear();
        } else {
            return NULL;
        }
    }
    if (calculate_metaclass && (!metaclass || PyType_Check(metaclass))) {
        metaclass = __Pyx_CalculateMetaclass((PyTypeObject*) metaclass, bases);
        Py_XDECREF(owned_metaclass);
        if (unlikely(!metaclass))
            return NULL;
        owned_metaclass = metaclass;
    }
    result = __Pyx_PyObject_FastCallDict(metaclass, margs+1, 3 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET, mkw);
    Py_XDECREF(owned_metaclass);
    return result;
}


#if CYTHON_CLINE_IN_TRACEBACK && CYTHON_CLINE_IN_TRACEBACK_RUNTIME
#if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030A0000
#define __Pyx_PyProbablyModule_GetDict(o) __Pyx_XNewRef(PyModule_GetDict(o))
#elif !CYTHON_COMPILING_IN_CPYTHON || CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
#define __Pyx_PyProbablyModule_GetDict(o) PyObject_GenericGetDict(o, NULL);
#else
PyObject* __Pyx_PyProbablyModule_GetDict(PyObject *o) {
    PyObject **dict_ptr = _PyObject_GetDictPtr(o);
    return dict_ptr ? __Pyx_XNewRef(*dict_ptr) : NULL;
}
#endif
static int __Pyx_CLineForTraceback(PyThreadState *tstate, int c_line) {
    PyObject *use_cline = NULL;
    PyObject *ptype, *pvalue, *ptraceback;
    PyObject *cython_runtime_dict;
    CYTHON_MAYBE_UNUSED_VAR(tstate);
    if (unlikely(!__pyx_mstate_global->__pyx_cython_runtime)) {
        return c_line;
    }
    __Pyx_ErrFetchInState(tstate, &ptype, &pvalue, &ptraceback);
    cython_runtime_dict = __Pyx_PyProbablyModule_GetDict(__pyx_mstate_global->__pyx_cython_runtime);
    if (likely(cython_runtime_dict)) {
        __PYX_PY_DICT_LOOKUP_IF_MODIFIED(
            use_cline, cython_runtime_dict,
            __Pyx_PyDict_SetDefault(cython_runtime_dict, __pyx_mstate_global->__pyx_n_u_cline_in_traceback, Py_False))
    }
    if (use_cline == NULL || use_cline == Py_False || (use_cline != Py_True && PyObject_Not(use_cline) != 0)) {
        c_line = 0;
    }
    Py_XDECREF(use_cline);
    Py_XDECREF(cython_runtime_dict);
    __Pyx_ErrRestoreInState(tstate, ptype, pvalue, ptraceback);
    return c_line;
}
#endif


static int __pyx_bisect_code_objects(__Pyx_CodeObjectCacheEntry* entries, int count, int code_line) {
    int start = 0, mid = 0, end = count - 1;
    if (end >= 0 && code_line > entries[end].code_line) {
        return count;
    }
    while (start < end) {
        mid = start + (end - start) / 2;
        if (code_line < entries[mid].code_line) {
            end = mid;
        } else if (code_line > entries[mid].code_line) {
             start = mid + 1;
        } else {
            return mid;
        }
    }
    if (code_line <= entries[mid].code_line) {
        return mid;
    } else {
        return mid + 1;
    }
}
static __Pyx_CachedCodeObjectType *__pyx__find_code_object(struct __Pyx_CodeObjectCache *code_cache, int code_line) {
    __Pyx_CachedCodeObjectType* code_object;
    int pos;
    if (unlikely(!code_line) || unlikely(!code_cache->entries)) {
        return NULL;
    }
    pos = __pyx_bisect_code_objects(code_cache->entries, code_cache->count, code_line);
    if (unlikely(pos >= code_cache->count) || unlikely(code_cache->entries[pos].code_line != code_line)) {
        return NULL;
    }
    code_object = code_cache->entries[pos].code_object;
    Py_INCREF(code_object);
    return code_object;
}
static __Pyx_CachedCodeObjectType *__pyx_find_code_object(int code_line) {
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING && !CYTHON_ATOMICS
    (void)__pyx__find_code_object;
    return NULL; // Most implementation should have atomics. But otherwise, don't make it thread-safe, just miss.
#else
    struct __Pyx_CodeObjectCache *code_cache = &__pyx_mstate_global->__pyx_code_cache;
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_nonatomic_int_type old_count = __pyx_atomic_incr_acq_rel(&code_cache->accessor_count);
    if (old_count < 0) {
        __pyx_atomic_decr_acq_rel(&code_cache->accessor_count);
        return NULL;
    }
#endif
    __Pyx_CachedCodeObjectType *result = __pyx__find_code_object(code_cache, code_line);
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_atomic_decr_acq_rel(&code_cache->accessor_count);
#endif
    return result;
#endif
}
static void __pyx__insert_code_object(struct __Pyx_CodeObjectCache *code_cache, int code_line, __Pyx_CachedCodeObjectType* code_object)
{
    int pos, i;
    __Pyx_CodeObjectCacheEntry* entries = code_cache->entries;
    if (unlikely(!code_line)) {
        return;
    }
    if (unlikely(!entries)) {
        entries = (__Pyx_CodeObjectCacheEntry*)PyMem_Malloc(64*sizeof(__Pyx_CodeObjectCacheEntry));
        if (likely(entries)) {
            code_cache->entries = entries;
            code_cache->max_count = 64;
            code_cache->count = 1;
            entries[0].code_line = code_line;
            entries[0].code_object = code_object;
            Py_INCREF(code_object);
        }
        return;
    }
    pos = __pyx_bisect_code_objects(code_cache->entries, code_cache->count, code_line);
    if ((pos < code_cache->count) && unlikely(code_cache->entries[pos].code_line == code_line)) {
        __Pyx_CachedCodeObjectType* tmp = entries[pos].code_object;
        entries[pos].code_object = code_object;
        Py_INCREF(code_object);
        Py_DECREF(tmp);
        return;
    }
    if (code_cache->count == code_cache->max_count) {
        int new_max = code_cache->max_count + 64;
        entries = (__Pyx_CodeObjectCacheEntry*)PyMem_Realloc(
            code_cache->entries, ((size_t)new_max) * sizeof(__Pyx_CodeObjectCacheEntry));
        if (unlikely(!entries)) {
            return;
        }
        code_cache->entries = entries;
        code_cache->max_count = new_max;
    }
    for (i=code_cache->count; i>pos; i--) {
        entries[i] = entries[i-1];
    }
    entries[pos].code_line = code_line;
    entries[pos].code_object = code_object;
    code_cache->count++;
    Py_INCREF(code_object);
}
static void __pyx_insert_code_object(int code_line, __Pyx_CachedCodeObjectType* code_object) {
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING && !CYTHON_ATOMICS
    (void)__pyx__insert_code_object;
    return; // Most implementation should have atomics. But otherwise, don't make it thread-safe, just fail.
#else
    struct __Pyx_CodeObjectCache *code_cache = &__pyx_mstate_global->__pyx_code_cache;
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_nonatomic_int_type expected = 0;
    if (!__pyx_atomic_int_cmp_exchange(&code_cache->accessor_count, &expected, INT_MIN)) {
        return;
    }
#endif
    __pyx__insert_code_object(code_cache, code_line, code_object);
#if CYTHON_COMPILING_IN_CPYTHON_FREETHREADING
    __pyx_atomic_sub(&code_cache->accessor_count, INT_MIN);
#endif
#endif
}


#include "compile.h"
#include "frameobject.h"
#include "traceback.h"
#if PY_VERSION_HEX >= 0x030b00a6 && !CYTHON_COMPILING_IN_LIMITED_API && !defined(PYPY_VERSION)
  #ifndef Py_BUILD_CORE
    #define Py_BUILD_CORE 1
  #endif
  #include "internal/pycore_frame.h"
#endif
#if CYTHON_COMPILING_IN_LIMITED_API
static PyObject *__Pyx_PyCode_Replace_For_AddTraceback(PyObject *code, PyObject *scratch_dict,
                                                       PyObject *firstlineno, PyObject *name) {
    PyObject *replace = NULL;
    if (unlikely(PyDict_SetItemString(scratch_dict, "co_firstlineno", firstlineno))) return NULL;
    if (unlikely(PyDict_SetItemString(scratch_dict, "co_name", name))) return NULL;
    replace = PyObject_GetAttrString(code, "replace");
    if (likely(replace)) {
        PyObject *result = PyObject_Call(replace, __pyx_mstate_global->__pyx_empty_tuple, scratch_dict);
        Py_DECREF(replace);
        return result;
    }
    return NULL;
}
static void __Pyx_AddTraceback(const char *funcname, int c_line,
                               int py_line, const char *filename) {
    PyObject *code_object = NULL, *py_py_line = NULL, *py_funcname = NULL, *dict = NULL;
    PyObject *replace = NULL, *getframe = NULL, *frame = NULL;
    PyObject *exc_type, *exc_value, *exc_traceback;
    int success = 0;
    if (c_line) {
        c_line = __Pyx_CLineForTraceback(__Pyx_PyThreadState_Current, c_line);
    }
    __Pyx_PyErr_FetchException(&exc_type, &exc_value, &exc_traceback);
    code_object = __pyx_find_code_object(c_line ? -c_line : py_line);
    if (!code_object) {
        code_object = Py_CompileString("_getframe()", filename, Py_eval_input);
        if (unlikely(!code_object)) goto bad;
        py_py_line = PyLong_FromLong(py_line);
        if (unlikely(!py_py_line)) goto bad;
        if (c_line) {
            py_funcname = PyUnicode_FromFormat( "%s (%s:%d)", funcname, __pyx_cfilenm, c_line);
        } else {
            py_funcname = PyUnicode_FromString(funcname);
        }
        if (unlikely(!py_funcname)) goto bad;
        dict = PyDict_New();
        if (unlikely(!dict)) goto bad;
        {
            PyObject *old_code_object = code_object;
            code_object = __Pyx_PyCode_Replace_For_AddTraceback(code_object, dict, py_py_line, py_funcname);
            Py_DECREF(old_code_object);
        }
        if (unlikely(!code_object)) goto bad;
        __pyx_insert_code_object(c_line ? -c_line : py_line, code_object);
    } else {
        dict = PyDict_New();
    }
    getframe = PySys_GetObject("_getframe");
    if (unlikely(!getframe)) goto bad;
    if (unlikely(PyDict_SetItemString(dict, "_getframe", getframe))) goto bad;
    frame = PyEval_EvalCode(code_object, dict, dict);
    if (unlikely(!frame) || frame == Py_None) goto bad;
    success = 1;
  bad:
    __Pyx_PyErr_RestoreException(exc_type, exc_value, exc_traceback);
    Py_XDECREF(code_object);
    Py_XDECREF(py_py_line);
    Py_XDECREF(py_funcname);
    Py_XDECREF(dict);
    Py_XDECREF(replace);
    if (success) {
        PyTraceBack_Here(
            (struct _frame*)frame);
    }
    Py_XDECREF(frame);
}
#else
static PyCodeObject* __Pyx_CreateCodeObjectForTraceback(
            const char *funcname, int c_line,
            int py_line, const char *filename) {
    PyCodeObject *py_code = NULL;
    PyObject *py_funcname = NULL;
    if (c_line) {
        py_funcname = PyUnicode_FromFormat( "%s (%s:%d)", funcname, __pyx_cfilenm, c_line);
        if (!py_funcname) goto bad;
        funcname = PyUnicode_AsUTF8(py_funcname);
        if (!funcname) goto bad;
    }
    py_code = PyCode_NewEmpty(filename, funcname, py_line);
    Py_XDECREF(py_funcname);
    return py_code;
bad:
    Py_XDECREF(py_funcname);
    return NULL;
}
static void __Pyx_AddTraceback(const char *funcname, int c_line,
                               int py_line, const char *filename) {
    PyCodeObject *py_code = 0;
    PyFrameObject *py_frame = 0;
    PyThreadState *tstate = __Pyx_PyThreadState_Current;
    PyObject *ptype, *pvalue, *ptraceback;
    if (c_line) {
        c_line = __Pyx_CLineForTraceback(tstate, c_line);
    }
    py_code = __pyx_find_code_object(c_line ? -c_line : py_line);
    if (!py_code) {
        __Pyx_ErrFetchInState(tstate, &ptype, &pvalue, &ptraceback);
        py_code = __Pyx_CreateCodeObjectForTraceback(
            funcname, c_line, py_line, filename);
        if (!py_code) {
            
            Py_XDECREF(ptype);
            Py_XDECREF(pvalue);
            Py_XDECREF(ptraceback);
            goto bad;
        }
        __Pyx_ErrRestoreInState(tstate, ptype, pvalue, ptraceback);
        __pyx_insert_code_object(c_line ? -c_line : py_line, py_code);
    }
    py_frame = PyFrame_New(
        tstate,            
        py_code,           
        __pyx_mstate_global->__pyx_d,    
        0                  
    );
    if (!py_frame) goto bad;
    __Pyx_PyFrame_SetLineNumber(py_frame, py_line);
    PyTraceBack_Here(py_frame);
bad:
    Py_XDECREF(py_code);
    Py_XDECREF(py_frame);
}
#endif


static CYTHON_INLINE PyObject* __Pyx_PyLong_From_long(long value) {
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#endif
    const long neg_one = (long) -1, const_zero = (long) 0;
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic pop
#endif
    const int is_unsigned = neg_one > const_zero;
    if (is_unsigned) {
        if (sizeof(long) < sizeof(long)) {
            return PyLong_FromLong((long) value);
        } else if (sizeof(long) <= sizeof(unsigned long)) {
            return PyLong_FromUnsignedLong((unsigned long) value);
#if !CYTHON_COMPILING_IN_PYPY
        } else if (sizeof(long) <= sizeof(unsigned PY_LONG_LONG)) {
            return PyLong_FromUnsignedLongLong((unsigned PY_LONG_LONG) value);
#endif
        }
    } else {
        if (sizeof(long) <= sizeof(long)) {
            return PyLong_FromLong((long) value);
        } else if (sizeof(long) <= sizeof(PY_LONG_LONG)) {
            return PyLong_FromLongLong((PY_LONG_LONG) value);
        }
    }
    {
        unsigned char *bytes = (unsigned char *)&value;
#if !CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX >= 0x030d00A4
        if (is_unsigned) {
            return PyLong_FromUnsignedNativeBytes(bytes, sizeof(value), -1);
        } else {
            return PyLong_FromNativeBytes(bytes, sizeof(value), -1);
        }
#elif !CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX < 0x030d0000
        int one = 1; int little = (int)*(unsigned char *)&one;
        return _PyLong_FromByteArray(bytes, sizeof(long),
                                     little, !is_unsigned);
#else
        int one = 1; int little = (int)*(unsigned char *)&one;
        PyObject *result = NULL, *kwds = NULL;
        PyObject *py_bytes = NULL, *order_str = NULL, *from_bytes_str = NULL;;
        py_bytes = PyBytes_FromStringAndSize((char*)bytes, sizeof(long));
        if (!py_bytes) goto limited_bad;
        from_bytes_str = PyUnicode_FromStringAndSize("from_bytes", 10);
        if (!from_bytes_str) goto limited_bad;
        order_str = PyUnicode_FromString(little ? "little" : "big");
        if (!order_str) goto limited_bad;
        {
            PyObject *args[] = { (PyObject*)&PyLong_Type, py_bytes, order_str, Py_True };
            if (!is_unsigned) {
                PyObject *signed_str = PyUnicode_FromStringAndSize("signed", 6);
                if (!signed_str) goto limited_bad;
#if CYTHON_VECTORCALL
                kwds = PyTuple_Pack(1, signed_str);
#else
                {
                    PyObject *keys[] = {signed_str};
                    PyObject *values[] = {Py_True};
                    kwds = __Pyx_MakeKwargDict(keys, values, 1);
                }
#endif
                Py_DECREF(signed_str);
                if (unlikely(!kwds)) goto limited_bad;
            }
            result = __Pyx_Object_VectorcallMethodKwds(from_bytes_str, args, 3 | __Pyx_PY_VECTORCALL_ARGUMENTS_OFFSET, kwds);
        }
        limited_bad:
        Py_XDECREF(kwds);
        Py_XDECREF(order_str);
        Py_XDECREF(py_bytes);
        Py_XDECREF(from_bytes_str);
        return result;
#endif
    }
}


#define __PYX_VERIFY_RETURN_INT(target_type, func_type, func_value)\
    __PYX__VERIFY_RETURN_INT(target_type, func_type, func_value, 0)
#define __PYX_VERIFY_RETURN_INT_EXC(target_type, func_type, func_value)\
    __PYX__VERIFY_RETURN_INT(target_type, func_type, func_value, 1)
#define __PYX__VERIFY_RETURN_INT(target_type, func_type, func_value, exc)\
    {\
        func_type value = func_value;\
        if (sizeof(target_type) < sizeof(func_type)) {\
            if (unlikely(value != (func_type) (target_type) value)) {\
                func_type zero = 0;\
                if (exc && unlikely(value == (func_type)-1 && PyErr_Occurred()))\
                    return (target_type) -1;\
                if (is_unsigned && unlikely(value < zero))\
                    goto raise_neg_overflow;\
                else\
                    goto raise_overflow;\
            }\
        }\
        return (target_type) value;\
    }


static long __Pyx_LargePyLong___Pyx_PyLong_As_long(PyObject *x);
static long __Pyx_raise_neg_overflow___Pyx_PyLong_As_long(void) {
    const char* type_name = "long";
    PyErr_Format(PyExc_OverflowError,
        "can't convert negative value to %.200s", type_name);
    return (long) -1;
}
static long __Pyx_raise_overflow___Pyx_PyLong_As_long(void) {
    const char* type_name = "long";
    PyErr_Format(PyExc_OverflowError,
        "value too large to convert to %.200s", type_name);
    return (long) -1;
}
static CYTHON_INLINE long __Pyx_PyULong___Pyx_PyLong_As_long(PyObject *x) {
    const int is_unsigned = 1;
#if CYTHON_USE_PYLONG_INTERNALS
    {
        const digit* digits = __Pyx_PyLong_Digits(x);
        const Py_ssize_t size = __Pyx_PyLong_DigitCount(x);
        if (size == 2 && (8 * sizeof(long) > 1 * PyLong_SHIFT)) {
            if ((8 * sizeof(unsigned long) > 2 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(long) >= 2 * PyLong_SHIFT)) {
                return (long) (((((long)digits[1]) << PyLong_SHIFT) | (long)digits[0]));
            }
        } else
        if (size == 3 && (8 * sizeof(long) > 2 * PyLong_SHIFT)) {
            if ((8 * sizeof(unsigned long) > 3 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(long) >= 3 * PyLong_SHIFT)) {
                return (long) (((((((long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0]));
            }
        } else
        if (size == 4 && (8 * sizeof(long) > 3 * PyLong_SHIFT)) {
            if ((8 * sizeof(unsigned long) > 4 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(long) >= 4 * PyLong_SHIFT)) {
                return (long) (((((((((long)digits[3]) << PyLong_SHIFT) | (long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0]));
            }
        } else
        {}
    }
#elif CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX < 0x030C00A7
    if (unlikely(Py_SIZE(x) < 0)) {
        goto raise_neg_overflow;
    }
#else
    {
        int result = PyObject_RichCompareBool(x, Py_False, Py_LT);
        if (unlikely(result < 0))
            return (long) -1;
        if (unlikely(result == 1))
            goto raise_neg_overflow;
    }
#endif
    if ((sizeof(long) <= sizeof(unsigned long))) {
        __PYX_VERIFY_RETURN_INT_EXC(long, unsigned long, PyLong_AsUnsignedLong(x))
    } else if ((sizeof(long) <= sizeof(unsigned PY_LONG_LONG))) {
        __PYX_VERIFY_RETURN_INT_EXC(long, unsigned PY_LONG_LONG, PyLong_AsUnsignedLongLong(x))
    }
    return __Pyx_LargePyLong___Pyx_PyLong_As_long(x);
raise_neg_overflow:
    return __Pyx_raise_neg_overflow___Pyx_PyLong_As_long();
raise_overflow:
    return __Pyx_raise_overflow___Pyx_PyLong_As_long();
}
static CYTHON_INLINE long __Pyx_PySLong___Pyx_PyLong_As_long(PyObject *x) {
    const int is_unsigned = 0;
#if CYTHON_USE_PYLONG_INTERNALS
    if (__Pyx_PyLong_IsNeg(x)) {
        const Py_ssize_t size = __Pyx_PyLong_DigitCount(x);
        const digit* digits = __Pyx_PyLong_Digits(x);
        if (size == 2 && (8 * sizeof(long) > 1 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 2 * PyLong_SHIFT)) {
                long ival = - (long) (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                __PYX_VERIFY_RETURN_INT(long, long, ival)
            } else if ((8 * sizeof(long) - 1 > 2 * PyLong_SHIFT)) {
                return (long) (((long) -1) * (((((long)digits[1]) << PyLong_SHIFT) | (long)digits[0])));
            }
        } else
        if (size == 3 && (8 * sizeof(long) > 2 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 3 * PyLong_SHIFT)) {
                long ival = - (long) (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                __PYX_VERIFY_RETURN_INT(long, long, ival)
            } else if ((8 * sizeof(long) - 1 > 3 * PyLong_SHIFT)) {
                return (long) (((long) -1) * (((((((long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0])));
            }
        } else
        if (size == 4 && (8 * sizeof(long) > 3 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 4 * PyLong_SHIFT)) {
                long ival = - (long) (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                __PYX_VERIFY_RETURN_INT(long, long, ival)
            } else if ((8 * sizeof(long) - 1 > 4 * PyLong_SHIFT)) {
                return (long) (((long) -1) * (((((((((long)digits[3]) << PyLong_SHIFT) | (long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0])));
            }
        } else
        {}
    } else {
        const Py_ssize_t size = __Pyx_PyLong_DigitCount(x);
        const digit* digits = __Pyx_PyLong_Digits(x);
        if (size == 2 && (8 * sizeof(long) > 1 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 2 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(long) - 1 > 2 * PyLong_SHIFT)) {
                return (long) (((((long)digits[1]) << PyLong_SHIFT) | (long)digits[0]));
            }
        } else
        if (size == 3 && (8 * sizeof(long) > 2 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 3 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(long) - 1 > 3 * PyLong_SHIFT)) {
                return (long) (((((((long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0]));
            }
        } else
        if (size == 4 && (8 * sizeof(long) > 3 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 4 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(long, unsigned long, (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(long) - 1 > 4 * PyLong_SHIFT)) {
                return (long) (((((((((long)digits[3]) << PyLong_SHIFT) | (long)digits[2]) << PyLong_SHIFT) | (long)digits[1]) << PyLong_SHIFT) | (long)digits[0]));
            }
        } else
        {}
    }
#endif
    #if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
    if ((sizeof(long) <= sizeof(int)) && (sizeof(int) < sizeof(long))) {
        __PYX_VERIFY_RETURN_INT_EXC(long, int, PyLong_AsInt(x))
    } else
    #endif
    if ((sizeof(long) <= sizeof(long))) {
        __PYX_VERIFY_RETURN_INT_EXC(long, long, PyLong_AsLong(x))
    } else if ((sizeof(long) <= sizeof(PY_LONG_LONG))) {
        __PYX_VERIFY_RETURN_INT_EXC(long, PY_LONG_LONG, PyLong_AsLongLong(x))
    }
    return __Pyx_LargePyLong___Pyx_PyLong_As_long(x);
raise_neg_overflow:
    return __Pyx_raise_neg_overflow___Pyx_PyLong_As_long();
raise_overflow:
    return __Pyx_raise_overflow___Pyx_PyLong_As_long();
}
static long __Pyx_LargePyLong___Pyx_PyLong_As_long(PyObject *x) {
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#endif
    const long neg_one = (long) -1, const_zero = (long) 0;
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic pop
#endif
    const int is_unsigned = neg_one > const_zero;
    long val;
    int ret = -1;
#if PY_VERSION_HEX >= 0x030d00A6 && !CYTHON_COMPILING_IN_LIMITED_API
    Py_ssize_t bytes_copied = PyLong_AsNativeBytes(
        x, &val, sizeof(val), Py_ASNATIVEBYTES_NATIVE_ENDIAN | (is_unsigned ? Py_ASNATIVEBYTES_UNSIGNED_BUFFER | Py_ASNATIVEBYTES_REJECT_NEGATIVE : 0));
    if (unlikely(bytes_copied == -1)) {
    } else if (unlikely(bytes_copied > (Py_ssize_t) sizeof(val))) {
        goto raise_overflow;
    } else {
        ret = 0;
    }
#elif PY_VERSION_HEX < 0x030d0000 && !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_LIMITED_API) || defined(_PyLong_AsByteArray)
    int one = 1; int is_little = (int)*(unsigned char *)&one;
    unsigned char *bytes = (unsigned char *)&val;
    ret = _PyLong_AsByteArray((PyLongObject *)x,
                                bytes, sizeof(val),
                                is_little, !is_unsigned);
    if ((0)) goto raise_overflow;
#else
    PyObject *v;
    PyObject *stepval = NULL, *mask = NULL, *shift = NULL;
    int bits, remaining_bits, is_negative = 0;
    int chunk_size = (sizeof(long) < 8) ? 30 : 62;
    if (likely(PyLong_CheckExact(x))) {
        v = __Pyx_NewRef(x);
    } else {
        v = PyNumber_Long(x);
        if (unlikely(!v)) return (long) -1;
        assert(PyLong_CheckExact(v));
    }
    {
        int result = PyObject_RichCompareBool(v, Py_False, Py_LT);
        if (unlikely(result < 0)) {
            Py_DECREF(v);
            return (long) -1;
        }
        is_negative = result == 1;
    }
    if (is_unsigned && unlikely(is_negative)) {
        Py_DECREF(v);
        PyErr_SetString(PyExc_OverflowError,
            "can't convert negative value to long");
        return (long) -1;
    } else if (is_negative) {
        stepval = PyNumber_Invert(v);
        Py_DECREF(v);
        if (unlikely(!stepval))
            return (long) -1;
    } else {
        stepval = v;
    }
    v = NULL;
    val = (long) 0;
    mask = PyLong_FromLong((1L << chunk_size) - 1); if (unlikely(!mask)) goto done;
    shift = PyLong_FromLong(chunk_size); if (unlikely(!shift)) goto done;
    for (bits = 0; bits < (int) sizeof(long) * 8 - chunk_size; bits += chunk_size) {
        PyObject *tmp, *digit;
        long idigit;
        digit = PyNumber_And(stepval, mask);
        if (unlikely(!digit)) goto done;
        idigit = PyLong_AsLong(digit);
        Py_DECREF(digit);
        if (unlikely(idigit < 0)) goto done;
        val |= ((long) idigit) << bits;
        tmp = PyNumber_Rshift(stepval, shift);
        if (unlikely(!tmp)) goto done;
        Py_DECREF(stepval); stepval = tmp;
    }
    Py_DECREF(shift); shift = NULL;
    Py_DECREF(mask); mask = NULL;
    {
        long idigit = PyLong_AsLong(stepval);
        if (unlikely(idigit < 0)) goto done;
        remaining_bits = ((int) sizeof(long) * 8) - bits - (is_unsigned ? 0 : 1);
        if (unlikely(idigit >= (1L << remaining_bits)))
            goto raise_overflow;
        val |= ((long) idigit) << bits;
    }
    if (!is_unsigned) {
        if (unlikely(val & (((long) 1) << (sizeof(long) * 8 - 1))))
            goto raise_overflow;
        if (is_negative)
            val = ~val;
    }
    ret = 0;
done:
    Py_XDECREF(shift);
    Py_XDECREF(mask);
    Py_XDECREF(stepval);
#endif
    if (unlikely(ret))
        return (long) -1;
    return val;
raise_overflow:
    return __Pyx_raise_overflow___Pyx_PyLong_As_long();
}
static CYTHON_INLINE long __Pyx_PyLong___Pyx_PyLong_As_long(PyObject *x) {
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#endif
    const long neg_one = (long) -1, const_zero = (long) 0;
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic pop
#endif
    const int is_unsigned = neg_one > const_zero;
    if (is_unsigned) {
        #if CYTHON_USE_PYLONG_INTERNALS
        if (unlikely(__Pyx_PyLong_IsNeg(x))) {
            goto raise_neg_overflow;
        } else if (__Pyx_PyLong_IsCompact(x)) {
            __PYX_VERIFY_RETURN_INT(long, __Pyx_compact_upylong, __Pyx_PyLong_CompactValueUnsigned(x))
        } else
        #endif
        {
            return __Pyx_PyULong___Pyx_PyLong_As_long(x);
        }
    } else {
        #if CYTHON_USE_PYLONG_INTERNALS
        if (__Pyx_PyLong_IsCompact(x)) {
            __PYX_VERIFY_RETURN_INT(long, __Pyx_compact_pylong, __Pyx_PyLong_CompactValue(x))
        } else
        #endif
        {
            return __Pyx_PySLong___Pyx_PyLong_As_long(x);
        }
    }
#if CYTHON_USE_PYLONG_INTERNALS
raise_neg_overflow:
    return __Pyx_raise_neg_overflow___Pyx_PyLong_As_long();
raise_overflow:
    return __Pyx_raise_overflow___Pyx_PyLong_As_long();
#endif
}
static long __Pyx_NonPyLong___Pyx_PyLong_As_long(PyObject *x) {
    long val;
    PyObject *tmp = __Pyx_PyNumber_Long(x);
    if (!tmp) return (long) -1;
    val = __Pyx_PyLong_As_long(tmp);
    Py_DECREF(tmp);
    return val;
}
static CYTHON_INLINE long __Pyx_PyLong_As_long(PyObject *x) {
    if (likely(PyLong_Check(x))) {
        return __Pyx_PyLong___Pyx_PyLong_As_long(x);
    } else {
        return __Pyx_NonPyLong___Pyx_PyLong_As_long(x);
    }
}


static int __Pyx_LargePyLong___Pyx_PyLong_As_int(PyObject *x);
static int __Pyx_raise_neg_overflow___Pyx_PyLong_As_int(void) {
    const char* type_name = "int";
    PyErr_Format(PyExc_OverflowError,
        "can't convert negative value to %.200s", type_name);
    return (int) -1;
}
static int __Pyx_raise_overflow___Pyx_PyLong_As_int(void) {
    const char* type_name = "int";
    PyErr_Format(PyExc_OverflowError,
        "value too large to convert to %.200s", type_name);
    return (int) -1;
}
static CYTHON_INLINE int __Pyx_PyULong___Pyx_PyLong_As_int(PyObject *x) {
    const int is_unsigned = 1;
#if CYTHON_USE_PYLONG_INTERNALS
    {
        const digit* digits = __Pyx_PyLong_Digits(x);
        const Py_ssize_t size = __Pyx_PyLong_DigitCount(x);
        if (size == 2 && (8 * sizeof(int) > 1 * PyLong_SHIFT)) {
            if ((8 * sizeof(unsigned long) > 2 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(int) >= 2 * PyLong_SHIFT)) {
                return (int) (((((int)digits[1]) << PyLong_SHIFT) | (int)digits[0]));
            }
        } else
        if (size == 3 && (8 * sizeof(int) > 2 * PyLong_SHIFT)) {
            if ((8 * sizeof(unsigned long) > 3 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(int) >= 3 * PyLong_SHIFT)) {
                return (int) (((((((int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0]));
            }
        } else
        if (size == 4 && (8 * sizeof(int) > 3 * PyLong_SHIFT)) {
            if ((8 * sizeof(unsigned long) > 4 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(int) >= 4 * PyLong_SHIFT)) {
                return (int) (((((((((int)digits[3]) << PyLong_SHIFT) | (int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0]));
            }
        } else
        {}
    }
#elif CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX < 0x030C00A7
    if (unlikely(Py_SIZE(x) < 0)) {
        goto raise_neg_overflow;
    }
#else
    {
        int result = PyObject_RichCompareBool(x, Py_False, Py_LT);
        if (unlikely(result < 0))
            return (int) -1;
        if (unlikely(result == 1))
            goto raise_neg_overflow;
    }
#endif
    if ((sizeof(int) <= sizeof(unsigned long))) {
        __PYX_VERIFY_RETURN_INT_EXC(int, unsigned long, PyLong_AsUnsignedLong(x))
    } else if ((sizeof(int) <= sizeof(unsigned PY_LONG_LONG))) {
        __PYX_VERIFY_RETURN_INT_EXC(int, unsigned PY_LONG_LONG, PyLong_AsUnsignedLongLong(x))
    }
    return __Pyx_LargePyLong___Pyx_PyLong_As_int(x);
raise_neg_overflow:
    return __Pyx_raise_neg_overflow___Pyx_PyLong_As_int();
raise_overflow:
    return __Pyx_raise_overflow___Pyx_PyLong_As_int();
}
static CYTHON_INLINE int __Pyx_PySLong___Pyx_PyLong_As_int(PyObject *x) {
    const int is_unsigned = 0;
#if CYTHON_USE_PYLONG_INTERNALS
    if (__Pyx_PyLong_IsNeg(x)) {
        const Py_ssize_t size = __Pyx_PyLong_DigitCount(x);
        const digit* digits = __Pyx_PyLong_Digits(x);
        if (size == 2 && (8 * sizeof(int) > 1 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 2 * PyLong_SHIFT)) {
                long ival = - (long) (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                __PYX_VERIFY_RETURN_INT(int, long, ival)
            } else if ((8 * sizeof(int) - 1 > 2 * PyLong_SHIFT)) {
                return (int) (((int) -1) * (((((int)digits[1]) << PyLong_SHIFT) | (int)digits[0])));
            }
        } else
        if (size == 3 && (8 * sizeof(int) > 2 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 3 * PyLong_SHIFT)) {
                long ival = - (long) (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                __PYX_VERIFY_RETURN_INT(int, long, ival)
            } else if ((8 * sizeof(int) - 1 > 3 * PyLong_SHIFT)) {
                return (int) (((int) -1) * (((((((int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0])));
            }
        } else
        if (size == 4 && (8 * sizeof(int) > 3 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 4 * PyLong_SHIFT)) {
                long ival = - (long) (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0]));
                __PYX_VERIFY_RETURN_INT(int, long, ival)
            } else if ((8 * sizeof(int) - 1 > 4 * PyLong_SHIFT)) {
                return (int) (((int) -1) * (((((((((int)digits[3]) << PyLong_SHIFT) | (int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0])));
            }
        } else
        {}
    } else {
        const Py_ssize_t size = __Pyx_PyLong_DigitCount(x);
        const digit* digits = __Pyx_PyLong_Digits(x);
        if (size == 2 && (8 * sizeof(int) > 1 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 2 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(int) - 1 > 2 * PyLong_SHIFT)) {
                return (int) (((((int)digits[1]) << PyLong_SHIFT) | (int)digits[0]));
            }
        } else
        if (size == 3 && (8 * sizeof(int) > 2 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 3 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((((unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(int) - 1 > 3 * PyLong_SHIFT)) {
                return (int) (((((((int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0]));
            }
        } else
        if (size == 4 && (8 * sizeof(int) > 3 * PyLong_SHIFT)) {
            if ((8 * sizeof(long) > 4 * PyLong_SHIFT)) {
                __PYX_VERIFY_RETURN_INT(int, unsigned long, (((((((((unsigned long)digits[3]) << PyLong_SHIFT) | (unsigned long)digits[2]) << PyLong_SHIFT) | (unsigned long)digits[1]) << PyLong_SHIFT) | (unsigned long)digits[0])))
            } else if ((8 * sizeof(int) - 1 > 4 * PyLong_SHIFT)) {
                return (int) (((((((((int)digits[3]) << PyLong_SHIFT) | (int)digits[2]) << PyLong_SHIFT) | (int)digits[1]) << PyLong_SHIFT) | (int)digits[0]));
            }
        } else
        {}
    }
#endif
    #if __PYX_LIMITED_VERSION_HEX >= 0x030d0000
    if ((sizeof(int) <= sizeof(int)) && (sizeof(int) < sizeof(long))) {
        __PYX_VERIFY_RETURN_INT_EXC(int, int, PyLong_AsInt(x))
    } else
    #endif
    if ((sizeof(int) <= sizeof(long))) {
        __PYX_VERIFY_RETURN_INT_EXC(int, long, PyLong_AsLong(x))
    } else if ((sizeof(int) <= sizeof(PY_LONG_LONG))) {
        __PYX_VERIFY_RETURN_INT_EXC(int, PY_LONG_LONG, PyLong_AsLongLong(x))
    }
    return __Pyx_LargePyLong___Pyx_PyLong_As_int(x);
raise_neg_overflow:
    return __Pyx_raise_neg_overflow___Pyx_PyLong_As_int();
raise_overflow:
    return __Pyx_raise_overflow___Pyx_PyLong_As_int();
}
static int __Pyx_LargePyLong___Pyx_PyLong_As_int(PyObject *x) {
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#endif
    const int neg_one = (int) -1, const_zero = (int) 0;
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic pop
#endif
    const int is_unsigned = neg_one > const_zero;
    int val;
    int ret = -1;
#if PY_VERSION_HEX >= 0x030d00A6 && !CYTHON_COMPILING_IN_LIMITED_API
    Py_ssize_t bytes_copied = PyLong_AsNativeBytes(
        x, &val, sizeof(val), Py_ASNATIVEBYTES_NATIVE_ENDIAN | (is_unsigned ? Py_ASNATIVEBYTES_UNSIGNED_BUFFER | Py_ASNATIVEBYTES_REJECT_NEGATIVE : 0));
    if (unlikely(bytes_copied == -1)) {
    } else if (unlikely(bytes_copied > (Py_ssize_t) sizeof(val))) {
        goto raise_overflow;
    } else {
        ret = 0;
    }
#elif PY_VERSION_HEX < 0x030d0000 && !(CYTHON_COMPILING_IN_PYPY || CYTHON_COMPILING_IN_LIMITED_API) || defined(_PyLong_AsByteArray)
    int one = 1; int is_little = (int)*(unsigned char *)&one;
    unsigned char *bytes = (unsigned char *)&val;
    ret = _PyLong_AsByteArray((PyLongObject *)x,
                                bytes, sizeof(val),
                                is_little, !is_unsigned);
    if ((0)) goto raise_overflow;
#else
    PyObject *v;
    PyObject *stepval = NULL, *mask = NULL, *shift = NULL;
    int bits, remaining_bits, is_negative = 0;
    int chunk_size = (sizeof(long) < 8) ? 30 : 62;
    if (likely(PyLong_CheckExact(x))) {
        v = __Pyx_NewRef(x);
    } else {
        v = PyNumber_Long(x);
        if (unlikely(!v)) return (int) -1;
        assert(PyLong_CheckExact(v));
    }
    {
        int result = PyObject_RichCompareBool(v, Py_False, Py_LT);
        if (unlikely(result < 0)) {
            Py_DECREF(v);
            return (int) -1;
        }
        is_negative = result == 1;
    }
    if (is_unsigned && unlikely(is_negative)) {
        Py_DECREF(v);
        PyErr_SetString(PyExc_OverflowError,
            "can't convert negative value to int");
        return (int) -1;
    } else if (is_negative) {
        stepval = PyNumber_Invert(v);
        Py_DECREF(v);
        if (unlikely(!stepval))
            return (int) -1;
    } else {
        stepval = v;
    }
    v = NULL;
    val = (int) 0;
    mask = PyLong_FromLong((1L << chunk_size) - 1); if (unlikely(!mask)) goto done;
    shift = PyLong_FromLong(chunk_size); if (unlikely(!shift)) goto done;
    for (bits = 0; bits < (int) sizeof(int) * 8 - chunk_size; bits += chunk_size) {
        PyObject *tmp, *digit;
        long idigit;
        digit = PyNumber_And(stepval, mask);
        if (unlikely(!digit)) goto done;
        idigit = PyLong_AsLong(digit);
        Py_DECREF(digit);
        if (unlikely(idigit < 0)) goto done;
        val |= ((int) idigit) << bits;
        tmp = PyNumber_Rshift(stepval, shift);
        if (unlikely(!tmp)) goto done;
        Py_DECREF(stepval); stepval = tmp;
    }
    Py_DECREF(shift); shift = NULL;
    Py_DECREF(mask); mask = NULL;
    {
        long idigit = PyLong_AsLong(stepval);
        if (unlikely(idigit < 0)) goto done;
        remaining_bits = ((int) sizeof(int) * 8) - bits - (is_unsigned ? 0 : 1);
        if (unlikely(idigit >= (1L << remaining_bits)))
            goto raise_overflow;
        val |= ((int) idigit) << bits;
    }
    if (!is_unsigned) {
        if (unlikely(val & (((int) 1) << (sizeof(int) * 8 - 1))))
            goto raise_overflow;
        if (is_negative)
            val = ~val;
    }
    ret = 0;
done:
    Py_XDECREF(shift);
    Py_XDECREF(mask);
    Py_XDECREF(stepval);
#endif
    if (unlikely(ret))
        return (int) -1;
    return val;
raise_overflow:
    return __Pyx_raise_overflow___Pyx_PyLong_As_int();
}
static CYTHON_INLINE int __Pyx_PyLong___Pyx_PyLong_As_int(PyObject *x) {
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wconversion"
#endif
    const int neg_one = (int) -1, const_zero = (int) 0;
#ifdef __Pyx_HAS_GCC_DIAGNOSTIC
#pragma GCC diagnostic pop
#endif
    const int is_unsigned = neg_one > const_zero;
    if (is_unsigned) {
        #if CYTHON_USE_PYLONG_INTERNALS
        if (unlikely(__Pyx_PyLong_IsNeg(x))) {
            goto raise_neg_overflow;
        } else if (__Pyx_PyLong_IsCompact(x)) {
            __PYX_VERIFY_RETURN_INT(int, __Pyx_compact_upylong, __Pyx_PyLong_CompactValueUnsigned(x))
        } else
        #endif
        {
            return __Pyx_PyULong___Pyx_PyLong_As_int(x);
        }
    } else {
        #if CYTHON_USE_PYLONG_INTERNALS
        if (__Pyx_PyLong_IsCompact(x)) {
            __PYX_VERIFY_RETURN_INT(int, __Pyx_compact_pylong, __Pyx_PyLong_CompactValue(x))
        } else
        #endif
        {
            return __Pyx_PySLong___Pyx_PyLong_As_int(x);
        }
    }
#if CYTHON_USE_PYLONG_INTERNALS
raise_neg_overflow:
    return __Pyx_raise_neg_overflow___Pyx_PyLong_As_int();
raise_overflow:
    return __Pyx_raise_overflow___Pyx_PyLong_As_int();
#endif
}
static int __Pyx_NonPyLong___Pyx_PyLong_As_int(PyObject *x) {
    int val;
    PyObject *tmp = __Pyx_PyNumber_Long(x);
    if (!tmp) return (int) -1;
    val = __Pyx_PyLong_As_int(tmp);
    Py_DECREF(tmp);
    return val;
}
static CYTHON_INLINE int __Pyx_PyLong_As_int(PyObject *x) {
    if (likely(PyLong_Check(x))) {
        return __Pyx_PyLong___Pyx_PyLong_As_int(x);
    } else {
        return __Pyx_NonPyLong___Pyx_PyLong_As_int(x);
    }
}


#if __PYX_LIMITED_VERSION_HEX < 0x030b0000
void __Pyx_init_runtime_version(void) {
    if (__Pyx_cached_runtime_version == 0) {
        const char* rt_version = Py_GetVersion();
        unsigned long version = 0;
        unsigned long factor = 0x01000000UL;
        unsigned int digit = 0;
        int i = 0;
        while (factor) {
            while ('0' <= rt_version[i] && rt_version[i] <= '9') {
                digit = digit * 10 + (unsigned int) (rt_version[i] - '0');
                ++i;
            }
            version += factor * digit;
            if (rt_version[i] != '.')
                break;
            digit = 0;
            factor >>= 8;
            ++i;
        }
        __Pyx_cached_runtime_version = version;
    }
}
#endif
static unsigned long __Pyx_get_runtime_version(void) {
#if __PYX_LIMITED_VERSION_HEX >= 0x030b0000
    return Py_Version & ~0xFFUL;
#else
    return __Pyx_cached_runtime_version;
#endif
}


static int __Pyx_check_binary_version(unsigned long ct_version, unsigned long rt_version, int allow_newer) {
    const unsigned long MAJOR_MINOR = 0xFFFF0000UL;
    if ((rt_version & MAJOR_MINOR) == (ct_version & MAJOR_MINOR))
        return 0;
    if (likely(allow_newer && (rt_version & MAJOR_MINOR) > (ct_version & MAJOR_MINOR)))
        return 1;
    {
        char message[200];
        PyOS_snprintf(message, sizeof(message),
                      "compile time Python version %d.%d "
                      "of module '%.100s' "
                      "%s "
                      "runtime version %d.%d",
                       (int) (ct_version >> 24), (int) ((ct_version >> 16) & 0xFF),
                       __Pyx_MODULE_NAME,
                       (allow_newer) ? "was newer than" : "does not match",
                       (int) (rt_version >> 24), (int) ((rt_version >> 16) & 0xFF)
       );
        return PyErr_WarnEx(NULL, message, 1);
    }
}


#if CYTHON_COMPILING_IN_LIMITED_API
    static PyObject* __Pyx__PyCode_New(int a, int p, int k, int l, int s, int f,
                                       PyObject *code, PyObject *c, PyObject* n, PyObject *v,
                                       PyObject *fv, PyObject *cell, PyObject* fn,
                                       PyObject *name, int fline, PyObject *lnos) {
        PyObject *exception_table = NULL;
        PyObject *types_module=NULL, *code_type=NULL, *result=NULL;
        #if __PYX_LIMITED_VERSION_HEX < 0x030b0000
        PyObject *version_info;
        PyObject *py_minor_version = NULL;
        #endif
        long minor_version = 0;
        #if __PYX_LIMITED_VERSION_HEX >= 0x030b0000
        minor_version = 11;
        #else
        if (!(version_info = PySys_GetObject("version_info"))) goto end;
        if (!(py_minor_version = PySequence_GetItem(version_info, 1))) goto end;
        minor_version = PyLong_AsLong(py_minor_version);
        Py_DECREF(py_minor_version);
        if (minor_version == -1 && PyErr_Occurred()) goto end;
        #endif
        if (!(types_module = PyImport_ImportModule("types"))) goto end;
        if (!(code_type = PyObject_GetAttrString(types_module, "CodeType"))) goto end;
        if (minor_version <= 10) {
            result = PyObject_CallFunction(code_type, "iiiiiiOOOOOOiOOO", a,p, k, l, s, f, code,
                          c, n, v, fn, name, fline, lnos, fv, cell);
        } else {
            if (!(exception_table = PyBytes_FromStringAndSize(NULL, 0))) goto end;
            result = PyObject_CallFunction(code_type, "iiiiiiOOOOOOOiOOOO", a,p, k, l, s, f, code,
                          c, n, v, fn, name, name, fline, lnos, exception_table, fv, cell);
        }
    end:
        Py_XDECREF(code_type);
        Py_XDECREF(exception_table);
        Py_XDECREF(types_module);
        if (!result) {
            PyObject *exc_type, *exc_value, *exc_tb;
            PyErr_Fetch(&exc_type, &exc_value, &exc_tb);
            if (PyErr_WarnFormat(
                    PyExc_RuntimeWarning, 1,
                    "Code object creation failed in Cython module: %S\nTry recompiling with a more recent version of Cython.",
                    exc_value ? exc_value : exc_type) == 0) {
                result = Py_None;
                Py_INCREF(result);
            }
            Py_DECREF(exc_type);
            Py_XDECREF(exc_value);
            Py_XDECREF(exc_tb);
        }
        return result;
    }
#elif PY_VERSION_HEX >= 0x030B0000
  static PyCodeObject* __Pyx__PyCode_New(int a, int p, int k, int l, int s, int f,
                                         PyObject *code, PyObject *c, PyObject* n, PyObject *v,
                                         PyObject *fv, PyObject *cell, PyObject* fn,
                                         PyObject *name, int fline, PyObject *lnos) {
    PyCodeObject *result;
    result =
      #if PY_VERSION_HEX >= 0x030C0000
        PyUnstable_Code_NewWithPosOnlyArgs
      #else
        PyCode_NewWithPosOnlyArgs
      #endif
        (a, p, k, l, s, f, code, c, n, v, fv, cell, fn, name, name, fline, lnos, __pyx_mstate_global->__pyx_empty_bytes);
    #if CYTHON_COMPILING_IN_CPYTHON && PY_VERSION_HEX >= 0x030c00A1
    if (likely(result))
        result->_co_firsttraceable = 0;
    #endif
    return result;
  }
#elif !CYTHON_COMPILING_IN_PYPY
  #define __Pyx__PyCode_New(a, p, k, l, s, f, code, c, n, v, fv, cell, fn, name, fline, lnos)\
          PyCode_NewWithPosOnlyArgs(a, p, k, l, s, f, code, c, n, v, fv, cell, fn, name, fline, lnos)
#else
  #define __Pyx__PyCode_New(a, p, k, l, s, f, code, c, n, v, fv, cell, fn, name, fline, lnos)\
          PyCode_New(a, k, l, s, f, code, c, n, v, fv, cell, fn, name, fline, lnos)
#endif
static PyObject* __Pyx_PyCode_New(
        const __Pyx_PyCode_New_function_description descr,
        PyObject * const *varnames,
        PyObject *filename,
        PyObject *funcname,
        PyObject *line_table,
        PyObject *tuple_dedup_map
) {
    PyObject *code_obj = NULL, *varnames_tuple_dedup = NULL, *code_bytes = NULL;
    Py_ssize_t var_count = (Py_ssize_t) descr.nlocals;
    PyObject *varnames_tuple = PyTuple_New(var_count);
    if (unlikely(!varnames_tuple)) return NULL;
    for (Py_ssize_t i=0; i < var_count; i++) {
        Py_INCREF(varnames[i]);
        if (__Pyx_PyTuple_SET_ITEM(varnames_tuple, i, varnames[i]) != (0)) goto done;
    }
    #if CYTHON_COMPILING_IN_LIMITED_API
    varnames_tuple_dedup = PyDict_GetItem(tuple_dedup_map, varnames_tuple);
    if (!varnames_tuple_dedup) {
        if (unlikely(PyDict_SetItem(tuple_dedup_map, varnames_tuple, varnames_tuple) < 0)) goto done;
        varnames_tuple_dedup = varnames_tuple;
    }
    #else
    varnames_tuple_dedup = PyDict_SetDefault(tuple_dedup_map, varnames_tuple, varnames_tuple);
    if (unlikely(!varnames_tuple_dedup)) goto done;
    #endif
    #if CYTHON_AVOID_BORROWED_REFS
    Py_INCREF(varnames_tuple_dedup);
    #endif
    if (__PYX_LIMITED_VERSION_HEX >= (0x030b0000) && line_table != NULL && !CYTHON_COMPILING_IN_GRAAL) {
        Py_ssize_t line_table_length = __Pyx_PyBytes_GET_SIZE(line_table);
        #if !CYTHON_ASSUME_SAFE_SIZE
        if (unlikely(line_table_length == -1)) goto done;
        #endif
        Py_ssize_t code_len = (line_table_length * 2 + 4) & ~3LL;
        code_bytes = PyBytes_FromStringAndSize(NULL, code_len);
        if (unlikely(!code_bytes)) goto done;
        char* c_code_bytes = PyBytes_AsString(code_bytes);
        if (unlikely(!c_code_bytes)) goto done;
        memset(c_code_bytes, 0, (size_t) code_len);
    }
    code_obj = (PyObject*) __Pyx__PyCode_New(
        (int) descr.argcount,
        (int) descr.num_posonly_args,
        (int) descr.num_kwonly_args,
        (int) descr.nlocals,
        0,
        (int) descr.flags,
        code_bytes ? code_bytes : __pyx_mstate_global->__pyx_empty_bytes,
        __pyx_mstate_global->__pyx_empty_tuple,
        __pyx_mstate_global->__pyx_empty_tuple,
        varnames_tuple_dedup,
        __pyx_mstate_global->__pyx_empty_tuple,
        __pyx_mstate_global->__pyx_empty_tuple,
        filename,
        funcname,
        (int) descr.first_line,
        (__PYX_LIMITED_VERSION_HEX >= (0x030b0000) && line_table) ? line_table : __pyx_mstate_global->__pyx_empty_bytes
    );
done:
    Py_XDECREF(code_bytes);
    #if CYTHON_AVOID_BORROWED_REFS
    Py_XDECREF(varnames_tuple_dedup);
    #endif
    Py_DECREF(varnames_tuple);
    return code_obj;
}


CYTHON_UNUSED
static CYTHON_SMALL_CODE PyObject *__Pyx_DecompressString(const char *s, Py_ssize_t length, int algo) {
#ifdef __Pyx_DecompressString_UNUSED
    CYTHON_UNUSED_VAR(s);
    CYTHON_UNUSED_VAR(length);
    CYTHON_UNUSED_VAR(algo);
    return NULL;
#else
    PyObject *module = NULL, *decompress, *compressed_bytes, *decompressed;
    const char* module_name = algo == 3 ? "compression.zstd" : algo == 2 ? "bz2" : "zlib";
    PyObject *methodname = PyUnicode_FromString("decompress");
    if (unlikely(!methodname)) return NULL;
    #if __PYX_LIMITED_VERSION_HEX >= 0x030e0000
    if (algo == 3) {
        PyObject *fromlist = Py_BuildValue("[O]", methodname);
        if (unlikely(!fromlist)) goto bad;
        module = PyImport_ImportModuleLevel("compression.zstd", NULL, NULL, fromlist, 0);
        Py_DECREF(fromlist);
    } else
    #endif
        module = PyImport_ImportModule(module_name);
    if (unlikely(!module)) goto import_failed;
    decompress = PyObject_GetAttr(module, methodname);
    if (unlikely(!decompress)) goto import_failed;
    {
        #ifdef __cplusplus
            char *memview_bytes = const_cast<char*>(s);
        #else
            #if defined(__clang__)
              #pragma clang diagnostic push
              #pragma clang diagnostic ignored "-Wcast-qual"
            #elif !defined(__INTEL_COMPILER) && defined(__GNUC__)
              #pragma GCC diagnostic push
              #pragma GCC diagnostic ignored "-Wcast-qual"
            #endif
            char *memview_bytes = (char*) s;
            #if defined(__clang__)
              #pragma clang diagnostic pop
            #elif !defined(__INTEL_COMPILER) && defined(__GNUC__)
              #pragma GCC diagnostic pop
            #endif
        #endif
        #if CYTHON_COMPILING_IN_LIMITED_API && !defined(PyBUF_READ)
        int memview_flags = 0x100;
        #else
        int memview_flags = PyBUF_READ;
        #endif
        compressed_bytes = PyMemoryView_FromMemory(memview_bytes, length, memview_flags);
    }
    if (unlikely(!compressed_bytes)) {
        Py_DECREF(decompress);
        goto bad;
    }
    decompressed = PyObject_CallFunctionObjArgs(decompress, compressed_bytes, NULL);
    Py_DECREF(compressed_bytes);
    Py_DECREF(decompress);
    Py_DECREF(module);
    Py_DECREF(methodname);
    return decompressed;
import_failed:
    PyErr_Format(PyExc_ImportError,
        "Failed to import '%.20s.decompress' - cannot initialise module strings. "
        "String compression was configured with the C macro 'CYTHON_COMPRESS_STRINGS=%d'.",
        module_name, algo);
bad:
    Py_XDECREF(module);
    Py_DECREF(methodname);
    return NULL;
#endif
}


#ifndef __Pyx_DecompressString_LZSS_UNUSED
CYTHON_UNUSED
static CYTHON_SMALL_CODE size_t __pyx_lzss_decompress(const uint8_t* src, uint8_t* dst, size_t dst_len) {
    size_t pos = 0, out_pos = 0;
    while (1) {
        uint32_t flags = src[pos++] | 0xFF00;
        while (flags & 0x100) {
            if (flags & 1) {
                dst[out_pos++] = src[pos++];
            } else {
                uint32_t lo = src[pos++], hi = src[pos++];
                uint32_t end_offset_of_last_occurrence, match_length;
                if (!(lo & 0x80)) {
                    end_offset_of_last_occurrence = lo;
                    match_length = hi;
                } else if (!(hi & 0x80)) {
                    end_offset_of_last_occurrence = 0x80 + (((hi << 2) & 0x180) | (lo & 0x7F));
                    match_length = hi & 0x1F;
                } else {
                    end_offset_of_last_occurrence = 0x80 + ((hi & 0x7F) << 7 | (lo & 0x7F));
                    match_length = src[pos++];
                }
                match_length += 3;
                size_t ref_pos = out_pos - end_offset_of_last_occurrence - match_length;
                memcpy(dst + out_pos, dst + ref_pos, match_length);
                out_pos += match_length;
            }
            if (out_pos >= dst_len) return pos;
            flags >>= 1;
        }
    }
}
#endif
static CYTHON_SMALL_CODE PyObject *__Pyx_DecompressString_LZSS(const char *s, size_t compressed_length, size_t uncompressed_length) {
#ifdef __Pyx_DecompressString_LZSS_UNUSED
    CYTHON_UNUSED_VAR(s);
    CYTHON_UNUSED_VAR(compressed_length);
    CYTHON_UNUSED_VAR(uncompressed_length);
    return NULL;
#else
    PyObject *result;
    unsigned char *result_data;
    size_t src_length;
    result = PyBytes_FromStringAndSize(NULL, (Py_ssize_t) uncompressed_length);
    if (unlikely(!result)) return NULL;
    result_data = __Pyx_PyBytes_AsWritableUString(result);
    if (unlikely(!result_data)) goto bad;
    src_length = __pyx_lzss_decompress((const uint8_t*) s, result_data, uncompressed_length);
    if (unlikely(src_length != compressed_length)) goto decompression_failed;
    return result;
decompression_failed:
    PyErr_SetString(PyExc_RuntimeError, "LZSS string data decompression failed");
bad:
    Py_DECREF(result);
    return NULL;
#endif
}

#include <string.h>
static CYTHON_INLINE Py_ssize_t __Pyx_ssize_strlen(const char *s) {
    size_t len = strlen(s);
    if (unlikely(len > (size_t) PY_SSIZE_T_MAX)) {
        PyErr_SetString(PyExc_OverflowError, "byte string is too long");
        return -1;
    }
    return (Py_ssize_t) len;
}
static CYTHON_INLINE PyObject* __Pyx_PyUnicode_FromString(const char* c_str) {
    Py_ssize_t len = __Pyx_ssize_strlen(c_str);
    if (unlikely(len < 0)) return NULL;
    return __Pyx_PyUnicode_FromStringAndSize(c_str, len);
}
static CYTHON_INLINE PyObject* __Pyx_PyByteArray_FromString(const char* c_str) {
    Py_ssize_t len = __Pyx_ssize_strlen(c_str);
    if (unlikely(len < 0)) return NULL;
    return PyByteArray_FromStringAndSize(c_str, len);
}
static CYTHON_INLINE const char* __Pyx_PyObject_AsString(PyObject* o) {
    Py_ssize_t ignore;
    return __Pyx_PyObject_AsStringAndSize(o, &ignore);
}
#if __PYX_DEFAULT_STRING_ENCODING_IS_ASCII || __PYX_DEFAULT_STRING_ENCODING_IS_UTF8
static CYTHON_INLINE const char* __Pyx_PyUnicode_AsStringAndSize(PyObject* o, Py_ssize_t *length) {
    if (unlikely(__Pyx_PyUnicode_READY(o) == -1)) return NULL;
#if CYTHON_COMPILING_IN_LIMITED_API
    {
        const char* result;
        Py_ssize_t unicode_length;
        CYTHON_MAYBE_UNUSED_VAR(unicode_length); // only for __PYX_DEFAULT_STRING_ENCODING_IS_ASCII
        #if __PYX_LIMITED_VERSION_HEX < 0x030A0000
        if (unlikely(PyArg_Parse(o, "s#", &result, length) < 0)) return NULL;
        #else
        result = PyUnicode_AsUTF8AndSize(o, length);
        #endif
        #if __PYX_DEFAULT_STRING_ENCODING_IS_ASCII
        unicode_length = PyUnicode_GetLength(o);
        if (unlikely(unicode_length < 0)) return NULL;
        if (unlikely(unicode_length != *length)) {
            PyUnicode_AsASCIIString(o);
            return NULL;
        }
        #endif
        return result;
    }
#else
#if __PYX_DEFAULT_STRING_ENCODING_IS_ASCII
    if (likely(PyUnicode_IS_ASCII(o))) {
        *length = PyUnicode_GET_LENGTH(o);
        return PyUnicode_AsUTF8(o);
    } else {
        PyUnicode_AsASCIIString(o);
        return NULL;
    }
#else
    return PyUnicode_AsUTF8AndSize(o, length);
#endif
#endif
}
#endif
static CYTHON_INLINE const char* __Pyx_PyObject_AsStringAndSize(PyObject* o, Py_ssize_t *length) {
#if __PYX_DEFAULT_STRING_ENCODING_IS_ASCII || __PYX_DEFAULT_STRING_ENCODING_IS_UTF8
    if (PyUnicode_Check(o)) {
        return __Pyx_PyUnicode_AsStringAndSize(o, length);
    } else
#endif
    if (PyByteArray_Check(o)) {
#if (CYTHON_ASSUME_SAFE_SIZE && CYTHON_ASSUME_SAFE_MACROS) || (CYTHON_COMPILING_IN_PYPY && (defined(PyByteArray_AS_STRING) && defined(PyByteArray_GET_SIZE)))
        *length = PyByteArray_GET_SIZE(o);
        return PyByteArray_AS_STRING(o);
#else
        *length = PyByteArray_Size(o);
        if (*length == -1) return NULL;
        return PyByteArray_AsString(o);
#endif
    } else
    {
        char* result;
        int r = PyBytes_AsStringAndSize(o, &result, length);
        if (unlikely(r < 0)) {
            return NULL;
        } else {
            return result;
        }
    }
}
static CYTHON_INLINE int __Pyx_PyObject_IsTrue(PyObject* x) {
   int is_true = x == Py_True;
   if (is_true | (x == Py_False) | (x == Py_None)) return is_true;
   else return PyObject_IsTrue(x);
}
static CYTHON_INLINE int __Pyx_PyObject_IsTrueAndDecref(PyObject* x) {
    int retval;
    if (unlikely(!x)) return -1;
    retval = __Pyx_PyObject_IsTrue(x);
    Py_DECREF(x);
    return retval;
}
static PyObject* __Pyx_PyNumber_LongWrongResultType(PyObject* result) {
    __Pyx_TypeName result_type_name = __Pyx_PyType_GetFullyQualifiedName(Py_TYPE(result));
    #if CYTHON_COMPILING_IN_LIMITED_API && __PYX_LIMITED_VERSION_HEX < 0x030d0000
    if (unlikely(!result_type_name)) goto bad;
    #endif
    if (PyLong_Check(result)) {
        if (PyErr_WarnFormat(PyExc_DeprecationWarning, 1,
                "__int__ returned non-int (type " __Pyx_FMT_TYPENAME ").  "
                "The ability to return an instance of a strict subclass of int is deprecated, "
                "and may be removed in a future version of Python.",
                result_type_name)) {
            __Pyx_DECREF_TypeName(result_type_name);
            goto bad;
        }
        __Pyx_DECREF_TypeName(result_type_name);
        return result;
    }
    PyErr_Format(PyExc_TypeError,
                 "__int__ returned non-int (type " __Pyx_FMT_TYPENAME ")",
                 result_type_name);
    __Pyx_DECREF_TypeName(result_type_name);
bad:
    Py_DECREF(result);
    return NULL;
}
static CYTHON_INLINE PyObject* __Pyx_PyNumber_Long(PyObject* x) {
#if CYTHON_USE_TYPE_SLOTS
  PyNumberMethods *m;
#endif
  PyObject *res = NULL;
  if (likely(PyLong_Check(x)))
      return __Pyx_NewRef(x);
#if CYTHON_USE_TYPE_SLOTS
  m = Py_TYPE(x)->tp_as_number;
  if (likely(m && m->nb_int)) {
      res = m->nb_int(x);
  }
#else
  if (!PyBytes_CheckExact(x) && !PyUnicode_CheckExact(x)) {
      res = PyNumber_Long(x);
  }
#endif
  if (likely(res)) {
      if (unlikely(!PyLong_CheckExact(res))) {
          return __Pyx_PyNumber_LongWrongResultType(res);
      }
  }
  else if (!PyErr_Occurred()) {
      PyErr_SetString(PyExc_TypeError,
                      "an integer is required");
  }
  return res;
}
static CYTHON_INLINE Py_ssize_t __Pyx_PyLong_AsSsize_t(PyObject* b) {
    #if CYTHON_USE_PYLONG_INTERNALS
    Py_ssize_t ival;
    const Py_ssize_t size = __Pyx_PyLong_DigitCount(b);
    const int is_neg = __Pyx_PyLong_IsNeg(b);
    const digit* digits = __Pyx_PyLong_Digits(b);
    if (size == 0) return 0;
    #if SIZEOF_SIZE_T * 8 > 1 * PyLong_SHIFT
    if (size == 1) {
        ival = (Py_ssize_t) (((size_t)digits[0]));
    } else
    #endif
    #if SIZEOF_SIZE_T * 8 > 2 * PyLong_SHIFT
    if (size == 2) {
        ival = (Py_ssize_t) (((((size_t)digits[1]) << PyLong_SHIFT) | (size_t)digits[0]));
    } else
    #endif
    #if SIZEOF_SIZE_T * 8 > 3 * PyLong_SHIFT
    if (size == 3) {
        ival = (Py_ssize_t) (((((((size_t)digits[2]) << PyLong_SHIFT) | (size_t)digits[1]) << PyLong_SHIFT) | (size_t)digits[0]));
    } else
    #endif
    #if SIZEOF_SIZE_T * 8 > 4 * PyLong_SHIFT
    if (size == 4) {
        ival = (Py_ssize_t) (((((((((size_t)digits[3]) << PyLong_SHIFT) | (size_t)digits[2]) << PyLong_SHIFT) | (size_t)digits[1]) << PyLong_SHIFT) | (size_t)digits[0]));
    } else
    #endif
        return PyLong_AsSsize_t(b);
    return is_neg ? -ival : ival;
    #else
    return PyLong_AsSsize_t(b);
    #endif
}
static CYTHON_INLINE Py_ssize_t __Pyx_PyIndex_AsSsize_t(PyObject* b) {
    if (likely(PyLong_Check(b))) {
        return __Pyx_PyLong_AsSsize_t(b);
    } else {
        Py_ssize_t ival;
        PyObject *x = PyNumber_Index(b);
        if (unlikely(!x)) return -1;
        ival = __Pyx_PyLong_AsSsize_t(x);
        Py_DECREF(x);
        return ival;
    }
}
static CYTHON_INLINE Py_hash_t __Pyx_PyIndex_AsHash_t(PyObject* o) {
  if (sizeof(Py_hash_t) == sizeof(Py_ssize_t)) {
    return (Py_hash_t) __Pyx_PyIndex_AsSsize_t(o);
  } else {
    Py_ssize_t ival;
    PyObject *x;
    x = PyNumber_Index(o);
    if (!x) return -1;
    ival = PyLong_AsLong(x);
    Py_DECREF(x);
    return ival;
  }
}
static CYTHON_INLINE PyObject *__Pyx_Owned_Py_None(int b) {
    CYTHON_UNUSED_VAR(b);
    return __Pyx_NewRef(Py_None);
}
static CYTHON_INLINE PyObject * __Pyx_PyBool_FromLong(long b) {
  return __Pyx_NewRef(b ? Py_True: Py_False);
}
static CYTHON_INLINE PyObject * __Pyx_PyLong_FromSize_t(size_t ival) {
    return PyLong_FromSize_t(ival);
}



#if CYTHON_PEP489_MULTI_PHASE_INIT && CYTHON_USE_MODULE_STATE
#ifndef CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
#if (CYTHON_COMPILING_IN_LIMITED_API || PY_VERSION_HEX >= 0x030C0000)
  #define CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE 1
#else
  #define CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE 0
#endif
#endif
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE && !CYTHON_ATOMICS
#error "Module state with PEP489 requires atomics. Currently that's one of\
 C11, C++11, gcc atomic intrinsics or MSVC atomic intrinsics"
#endif
#if !CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
#define __Pyx_ModuleStateLookup_Lock()
#define __Pyx_ModuleStateLookup_Unlock()
#elif !CYTHON_COMPILING_IN_LIMITED_API && PY_VERSION_HEX >= 0x030d0000
static PyMutex __Pyx_ModuleStateLookup_mutex = {0};
#define __Pyx_ModuleStateLookup_Lock() PyMutex_Lock(&__Pyx_ModuleStateLookup_mutex)
#define __Pyx_ModuleStateLookup_Unlock() PyMutex_Unlock(&__Pyx_ModuleStateLookup_mutex)
#elif defined(__cplusplus) && __cplusplus >= 201103L
#include <mutex>
static std::mutex __Pyx_ModuleStateLookup_mutex;
#define __Pyx_ModuleStateLookup_Lock() __Pyx_ModuleStateLookup_mutex.lock()
#define __Pyx_ModuleStateLookup_Unlock() __Pyx_ModuleStateLookup_mutex.unlock()
#elif defined(__STDC_VERSION__) && (__STDC_VERSION__ > 201112L) && !defined(__STDC_NO_THREADS__)
#include <threads.h>
static mtx_t __Pyx_ModuleStateLookup_mutex;
static once_flag __Pyx_ModuleStateLookup_mutex_once_flag = ONCE_FLAG_INIT;
static void __Pyx_ModuleStateLookup_initialize_mutex(void) {
    mtx_init(&__Pyx_ModuleStateLookup_mutex, mtx_plain);
}
#define __Pyx_ModuleStateLookup_Lock()\
  call_once(&__Pyx_ModuleStateLookup_mutex_once_flag, __Pyx_ModuleStateLookup_initialize_mutex);\
  mtx_lock(&__Pyx_ModuleStateLookup_mutex)
#define __Pyx_ModuleStateLookup_Unlock() mtx_unlock(&__Pyx_ModuleStateLookup_mutex)
#elif defined(HAVE_PTHREAD_H)
#include <pthread.h>
static pthread_mutex_t __Pyx_ModuleStateLookup_mutex = PTHREAD_MUTEX_INITIALIZER;
#define __Pyx_ModuleStateLookup_Lock() pthread_mutex_lock(&__Pyx_ModuleStateLookup_mutex)
#define __Pyx_ModuleStateLookup_Unlock() pthread_mutex_unlock(&__Pyx_ModuleStateLookup_mutex)
#elif defined(_WIN32)
#include <Windows.h>  // synchapi.h on its own doesn't work
static SRWLOCK __Pyx_ModuleStateLookup_mutex = SRWLOCK_INIT;
#define __Pyx_ModuleStateLookup_Lock() AcquireSRWLockExclusive(&__Pyx_ModuleStateLookup_mutex)
#define __Pyx_ModuleStateLookup_Unlock() ReleaseSRWLockExclusive(&__Pyx_ModuleStateLookup_mutex)
#else
#error "No suitable lock available for CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE.\
 Requires C standard >= C11, or C++ standard >= C++11,\
 or pthreads, or the Windows 32 API, or Python >= 3.13."
#endif
typedef struct {
    int64_t id;
    PyObject *module;
} __Pyx_InterpreterIdAndModule;
typedef struct {
    char interpreter_id_as_index;
    Py_ssize_t count;
    Py_ssize_t allocated;
    __Pyx_InterpreterIdAndModule table[1];
} __Pyx_ModuleStateLookupData;
#define __PYX_MODULE_STATE_LOOKUP_SMALL_SIZE 32
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
static __pyx_atomic_int_type __Pyx_ModuleStateLookup_read_counter = 0;
#endif
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
static __pyx_atomic_ptr_type __Pyx_ModuleStateLookup_data = 0;
#else
static __Pyx_ModuleStateLookupData* __Pyx_ModuleStateLookup_data = NULL;
#endif
static __Pyx_InterpreterIdAndModule* __Pyx_State_FindModuleStateLookupTableLowerBound(
        __Pyx_InterpreterIdAndModule* table,
        Py_ssize_t count,
        int64_t interpreterId) {
    __Pyx_InterpreterIdAndModule* begin = table;
    __Pyx_InterpreterIdAndModule* end = begin + count;
    if (begin->id == interpreterId) {
        return begin;
    }
    while ((end - begin) > __PYX_MODULE_STATE_LOOKUP_SMALL_SIZE) {
        __Pyx_InterpreterIdAndModule* halfway = begin + (end - begin)/2;
        if (halfway->id == interpreterId) {
            return halfway;
        }
        if (halfway->id < interpreterId) {
            begin = halfway;
        } else {
            end = halfway;
        }
    }
    for (; begin < end; ++begin) {
        if (begin->id >= interpreterId) return begin;
    }
    return begin;
}
static PyObject *__Pyx_State_FindModule(CYTHON_UNUSED void* dummy) {
    int64_t interpreter_id = PyInterpreterState_GetID(PyInterpreterState_Get());
    if (interpreter_id == -1) return NULL;
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __Pyx_ModuleStateLookupData* data = (__Pyx_ModuleStateLookupData*)__pyx_atomic_pointer_load_relaxed(&__Pyx_ModuleStateLookup_data);
    {
        __pyx_atomic_incr_acq_rel(&__Pyx_ModuleStateLookup_read_counter);
        if (likely(data)) {
            __Pyx_ModuleStateLookupData* new_data = (__Pyx_ModuleStateLookupData*)__pyx_atomic_pointer_load_acquire(&__Pyx_ModuleStateLookup_data);
            if (likely(data == new_data)) {
                goto read_finished;
            }
        }
        __pyx_atomic_decr_acq_rel(&__Pyx_ModuleStateLookup_read_counter);
        __Pyx_ModuleStateLookup_Lock();
        __pyx_atomic_incr_relaxed(&__Pyx_ModuleStateLookup_read_counter);
        data = (__Pyx_ModuleStateLookupData*)__pyx_atomic_pointer_load_relaxed(&__Pyx_ModuleStateLookup_data);
        __Pyx_ModuleStateLookup_Unlock();
    }
  read_finished:;
#else
    __Pyx_ModuleStateLookupData* data = __Pyx_ModuleStateLookup_data;
#endif
    __Pyx_InterpreterIdAndModule* found = NULL;
    if (unlikely(!data)) goto end;
    if (data->interpreter_id_as_index) {
        if (interpreter_id < data->count) {
            found = data->table+interpreter_id;
        }
    } else {
        found = __Pyx_State_FindModuleStateLookupTableLowerBound(
            data->table, data->count, interpreter_id);
    }
  end:
    {
        PyObject *result=NULL;
        if (found && found->id == interpreter_id) {
            result = found->module;
        }
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
        __pyx_atomic_decr_acq_rel(&__Pyx_ModuleStateLookup_read_counter);
#endif
        return result;
    }
}
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
static void __Pyx_ModuleStateLookup_wait_until_no_readers(void) {
    while (__pyx_atomic_load(&__Pyx_ModuleStateLookup_read_counter) != 0);
}
#else
#define __Pyx_ModuleStateLookup_wait_until_no_readers()
#endif
static int __Pyx_State_AddModuleInterpIdAsIndex(__Pyx_ModuleStateLookupData **old_data, PyObject* module, int64_t interpreter_id) {
    Py_ssize_t to_allocate = (*old_data)->allocated;
    while (to_allocate <= interpreter_id) {
        if (to_allocate == 0) to_allocate = 1;
        else to_allocate *= 2;
    }
    __Pyx_ModuleStateLookupData *new_data = *old_data;
    if (to_allocate != (*old_data)->allocated) {
         new_data = (__Pyx_ModuleStateLookupData *)realloc(
            *old_data,
            sizeof(__Pyx_ModuleStateLookupData)+(to_allocate-1)*sizeof(__Pyx_InterpreterIdAndModule));
        if (!new_data) {
            PyErr_NoMemory();
            return -1;
        }
        for (Py_ssize_t i = new_data->allocated; i < to_allocate; ++i) {
            new_data->table[i].id = i;
            new_data->table[i].module = NULL;
        }
        new_data->allocated = to_allocate;
    }
    new_data->table[interpreter_id].module = module;
    if (new_data->count < interpreter_id+1) {
        new_data->count = interpreter_id+1;
    }
    *old_data = new_data;
    return 0;
}
static void __Pyx_State_ConvertFromInterpIdAsIndex(__Pyx_ModuleStateLookupData *data) {
    __Pyx_InterpreterIdAndModule *read = data->table;
    __Pyx_InterpreterIdAndModule *write = data->table;
    __Pyx_InterpreterIdAndModule *end = read + data->count;
    for (; read<end; ++read) {
        if (read->module) {
            write->id = read->id;
            write->module = read->module;
            ++write;
        }
    }
    data->count = write - data->table;
    for (; write<end; ++write) {
        write->id = 0;
        write->module = NULL;
    }
    data->interpreter_id_as_index = 0;
}
static int __Pyx_State_AddModule(PyObject* module, CYTHON_UNUSED void* dummy) {
    int64_t interpreter_id = PyInterpreterState_GetID(PyInterpreterState_Get());
    if (interpreter_id == -1) return -1;
    int result = 0;
    __Pyx_ModuleStateLookup_Lock();
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __Pyx_ModuleStateLookupData *old_data = (__Pyx_ModuleStateLookupData *)
            __pyx_atomic_pointer_exchange(&__Pyx_ModuleStateLookup_data, 0);
#else
    __Pyx_ModuleStateLookupData *old_data = __Pyx_ModuleStateLookup_data;
#endif
    __Pyx_ModuleStateLookupData *new_data = old_data;
    if (!new_data) {
        new_data = (__Pyx_ModuleStateLookupData *)calloc(1, sizeof(__Pyx_ModuleStateLookupData));
        if (!new_data) {
            result = -1;
            PyErr_NoMemory();
            goto end;
        }
        new_data->allocated = 1;
        new_data->interpreter_id_as_index = 1;
    }
    __Pyx_ModuleStateLookup_wait_until_no_readers();
    if (new_data->interpreter_id_as_index) {
        if (interpreter_id < __PYX_MODULE_STATE_LOOKUP_SMALL_SIZE) {
            result = __Pyx_State_AddModuleInterpIdAsIndex(&new_data, module, interpreter_id);
            goto end;
        }
        __Pyx_State_ConvertFromInterpIdAsIndex(new_data);
    }
    {
        Py_ssize_t insert_at = 0;
        {
            __Pyx_InterpreterIdAndModule* lower_bound = __Pyx_State_FindModuleStateLookupTableLowerBound(
                new_data->table, new_data->count, interpreter_id);
            assert(lower_bound);
            insert_at = lower_bound - new_data->table;
            if (unlikely(insert_at < new_data->count && lower_bound->id == interpreter_id)) {
                lower_bound->module = module;
                goto end;  // already in table, nothing more to do
            }
        }
        if (new_data->count+1 >= new_data->allocated) {
            Py_ssize_t to_allocate = (new_data->count+1)*2;
            new_data =
                (__Pyx_ModuleStateLookupData*)realloc(
                    new_data,
                    sizeof(__Pyx_ModuleStateLookupData) +
                    (to_allocate-1)*sizeof(__Pyx_InterpreterIdAndModule));
            if (!new_data) {
                result = -1;
                new_data = old_data;
                PyErr_NoMemory();
                goto end;
            }
            new_data->allocated = to_allocate;
        }
        ++new_data->count;
        int64_t last_id = interpreter_id;
        PyObject *last_module = module;
        for (Py_ssize_t i=insert_at; i<new_data->count; ++i) {
            int64_t current_id = new_data->table[i].id;
            new_data->table[i].id = last_id;
            last_id = current_id;
            PyObject *current_module = new_data->table[i].module;
            new_data->table[i].module = last_module;
            last_module = current_module;
        }
    }
  end:
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __pyx_atomic_pointer_exchange(&__Pyx_ModuleStateLookup_data, new_data);
#else
    __Pyx_ModuleStateLookup_data = new_data;
#endif
    __Pyx_ModuleStateLookup_Unlock();
    return result;
}
static int __Pyx_State_RemoveModule(CYTHON_UNUSED void* dummy) {
    int64_t interpreter_id = PyInterpreterState_GetID(PyInterpreterState_Get());
    if (interpreter_id == -1) return -1;
    __Pyx_ModuleStateLookup_Lock();
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __Pyx_ModuleStateLookupData *data = (__Pyx_ModuleStateLookupData *)
            __pyx_atomic_pointer_exchange(&__Pyx_ModuleStateLookup_data, 0);
#else
    __Pyx_ModuleStateLookupData *data = __Pyx_ModuleStateLookup_data;
#endif
    if (data->interpreter_id_as_index) {
        if (interpreter_id < data->count) {
            data->table[interpreter_id].module = NULL;
        }
        goto done;
    }
    {
        __Pyx_ModuleStateLookup_wait_until_no_readers();
        __Pyx_InterpreterIdAndModule* lower_bound = __Pyx_State_FindModuleStateLookupTableLowerBound(
            data->table, data->count, interpreter_id);
        if (!lower_bound) goto done;
        if (lower_bound->id != interpreter_id) goto done;
        __Pyx_InterpreterIdAndModule *end = data->table+data->count;
        for (;lower_bound<end-1; ++lower_bound) {
            lower_bound->id = (lower_bound+1)->id;
            lower_bound->module = (lower_bound+1)->module;
        }
    }
    --data->count;
    if (data->count == 0) {
        free(data);
        data = NULL;
    }
  done:
#if CYTHON_MODULE_STATE_LOOKUP_THREAD_SAFE
    __pyx_atomic_pointer_exchange(&__Pyx_ModuleStateLookup_data, data);
#else
    __Pyx_ModuleStateLookup_data = data;
#endif
    __Pyx_ModuleStateLookup_Unlock();
    return 0;
}
#endif


#ifdef _MSC_VER
#pragma warning( pop )
#endif




#endif 
