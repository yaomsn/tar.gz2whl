
from cloze.pandas_query import PandasQuery
import pandas

data1=pandas.DataFrame({"列1": range(100),"y": range(100)})
data2=pandas.DataFrame({"x": range(100),"y": range(100)})

sql='select data1.*,data2.* from data1,data2 where data1.y=data2.y;'

query=PandasQuery()
result=query(sql, {'data1':data1,'data2':data2})


#%%
from cloze.template_docx import TemplateDocx
import pandas
import matplotlib.pyplot as plt
from io import BytesIO

data1=pandas.Series(range(100),index=['a%i'%i for i in range(100)])
data2=pandas.DataFrame({"x": range(10),"y": range(10)})



plot=BytesIO()
plt.plot(data2.y)
plt.savefig(plot)

ax = data2.y.plot()
fig = ax.get_figure()
fig.savefig(plot)

template=TemplateDocx()
template('Template.docx','Save.docx',env={'data1':data1,'data2':data2,'plot':plot})

#%%
from cloze.template_xlsx import TemplateXlsx
import pandas
import matplotlib.pyplot as plt
from io import BytesIO

data1=pandas.Series(range(100),index=['a%i'%i for i in range(100)])
data2=pandas.DataFrame({"x": range(10),"y": range(10)})



plot=BytesIO()

plt.plot(data2.y)
plt.savefig(plot)

data2.y.plot().get_figure().savefig(plot)

template=TemplateXlsx(restore=False)
template('Template.xlsx','Save.xlsx',env={'data1':data1,'data2':data2,'plot':plot})

template=TemplateXlsx(restore=True)
template('Template.xlsx','Save.xlsx',env={'data1':data1,'data2':data2,'plot':plot})
#%%
from cloze.template_text import TemplateText
import pandas
template=TemplateText()
template('这是一个测试{data.a}',{'data':pandas.Series({'a':1})})

